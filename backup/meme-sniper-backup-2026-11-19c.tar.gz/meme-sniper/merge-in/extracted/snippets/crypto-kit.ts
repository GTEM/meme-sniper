// crypto-kit.ts — every crypto readout from Ulvarin in one file, no app imports.
//
// Nothing here is simulated: each number is a live quote from a keyless public
// API. Copy the file into any TypeScript project that can run fetch — Node 18+,
// Bun, Deno, Cloudflare Workers, or a browser (CORS permitting) — and call it:
//
//   import { memeFeed, topCrypto, venueQuotes, walletPortfolio } from './crypto-kit'
//
//   const feed  = await memeFeed('volume')   // pump.fun + PumpSwap, by 24h volume
//   const fresh = await memeFeed('new')      // newest pump.fun launches
//   const top   = await topCrypto(8)         // BTC, ETH, SOL, …
//   const book  = await venueQuotes('BTC')   // Coinbase, Binance, Kraken in parallel
//   const bag   = await walletPortfolio('7xK…', process.env.SOLANA_RPC_URL)
//
// Sources and what each one is actually good for:
//   CoinGecko                 price, market cap, 7-day sparkline, global dominance
//   Coinbase / Binance / Kraken  independent order books, so the spread is visible
//   GeckoTerminal             pump.fun bonding-curve and PumpSwap pools, plus OHLCV
//   DexScreener               real pool liquidity per mint, 30 mints per call
//   Solana RPC                read-only wallet balances (needs your own endpoint)
//
// Limits that are not bugs:
//   - GeckoTerminal allows 30 requests a minute per IP, so a shared server IP
//     gets 429s and the retry below is what makes it work anyway.
//   - Binance answers 451 from blocked regions (the US among them). Pass a relay
//     URL to read it through, or accept the two venues that do answer.
//   - Wallet reads need an RPC endpoint: the public ones refuse
//     getTokenAccountsByOwner. A free Helius or QuickNode URL is enough.
//   - A pump.fun launch is often hours old, so its best candle series may be
//     hourly. That is reported, never hidden.
//   - Wallets are read-only by design. No signing, no keys, no transactions.

/* ------------------------------------------------------------------ shared */

export type Quote = {
  ref: string
  ticker: string
  name: string
  kind: 'crypto' | 'stock'
  price: number | null
  change: number | null
  changePct: number | null
  currency: string
  marketCap: number | null
  volume: number | null
  /** Sampled price series for a sparkline: 7 days for crypto, 1 month for stocks. */
  spark: number[]
  updatedAt: number
  /** True when the number came from a delayed source. */
  degraded?: boolean
}

const UA = 'Mozilla/5.0 (compatible; crypto-kit/1.0)'

const num = (value: unknown): number | null => {
  const parsed = typeof value === 'number' ? value : Number.parseFloat(String(value ?? ''))
  return Number.isFinite(parsed) ? parsed : null
}

type CacheEntry = { at: number; value: unknown; ttl: number }
const cache = new Map<string, CacheEntry>()

/** A short in-process cache. The isolate keeps it; a server keeps it per worker. */
async function cached<T>(key: string, ttlMs: number, load: () => Promise<T>): Promise<T> {
  const hit = cache.get(key)
  if (hit && Date.now() - hit.at < hit.ttl) return hit.value as T
  const value = await load()
  cache.set(key, { at: Date.now(), value, ttl: ttlMs })
  if (cache.size > 300) {
    for (const [entryKey, entry] of cache) if (Date.now() - entry.at > 5 * 60_000) cache.delete(entryKey)
  }
  return value
}

/** The last good value, however old, so a throttle does not blank a working page. */
function peek<T>(key: string): { at: number; value: T } | null {
  const hit = cache.get(key)
  return hit ? { at: hit.at, value: hit.value as T } : null
}

/** GET JSON, retrying 429 and 5xx. A 4xx that will not change is thrown at once. */
async function getJson<T>(url: string, timeoutMs = 12_000): Promise<T> {
  const host = new URL(url).hostname
  let wait = 500
  for (let attempt = 0; attempt < 3; attempt++) {
    const response = await fetch(url, {
      headers: { accept: 'application/json', 'user-agent': UA },
      signal: AbortSignal.timeout(timeoutMs),
    }).catch(() => null)
    if (response?.ok) return (await response.json()) as T
    const status = response?.status ?? 0
    if (status !== 0 && status !== 429 && status < 500) throw new Error(`${host} responded ${status}`)
    if (attempt === 2) {
      throw new Error(
        status === 429 ? `${host} is throttling this IP (HTTP 429). It allows 30 requests a minute — another try usually gets through.` : `${host} responded ${status || 'nothing'}.`,
      )
    }
    const header = Number(response?.headers.get('retry-after'))
    await new Promise((resolve) => setTimeout(resolve, Number.isFinite(header) && header > 0 ? Math.min(header * 1_000, 2_000) : wait))
    wait *= 3
  }
  throw new Error(`${host} did not answer.`)
}

/** "$1,234.56", "$0.00042" — a price, not a rounded display figure. */
export const usd = (value: number | null): string => {
  if (value == null) return '—'
  if (Math.abs(value) >= 1) return `$${value.toLocaleString('en-US', { maximumFractionDigits: 2 })}`
  return `$${value.toPrecision(4)}`
}

/** "$1.23T" / "$456.78M" — market cap and volume. */
export const compact = (value: number | null): string => {
  if (value == null) return '—'
  const units: [number, string][] = [
    [1e12, 'T'],
    [1e9, 'B'],
    [1e6, 'M'],
    [1e3, 'K'],
  ]
  for (const [size, suffix] of units) if (Math.abs(value) >= size) return `$${(value / size).toFixed(2)}${suffix}`
  return `$${value.toFixed(2)}`
}

/** Downsample a long series for a sparkline without losing its shape. */
function downsample(values: number[], size = 44): number[] {
  const clean = values.filter((value) => Number.isFinite(value))
  if (clean.length <= size) return clean
  const step = clean.length / size
  return Array.from({ length: size }, (_, index) => clean[Math.min(clean.length - 1, Math.floor(index * step))]!)
}

/* ----------------------------------------------------------- CoinGecko -- */

const CG = 'https://api.coingecko.com/api/v3'
const TTL = 45_000

type CgCoin = {
  id: string
  symbol: string
  name: string
  current_price: number | null
  market_cap: number | null
  total_volume: number | null
  price_change_percentage_24h: number | null
  sparkline_in_7d?: { price?: number[] }
}

function cryptoQuote(coin: CgCoin): Quote {
  const price = num(coin.current_price)
  const pct = num(coin.price_change_percentage_24h)
  return {
    ref: coin.id,
    ticker: coin.symbol.toUpperCase(),
    kind: 'crypto',
    name: coin.name,
    price,
    change: price != null && pct != null ? (price * pct) / 100 : null,
    changePct: pct,
    currency: 'USD',
    marketCap: num(coin.market_cap),
    volume: num(coin.total_volume),
    spark: downsample(coin.sparkline_in_7d?.price ?? []),
    updatedAt: Date.now(),
  }
}

const cgMarketsUrl = (ids: string[] | null, perPage: number) =>
  `${CG}/coins/markets?vs_currency=usd&order=market_cap_desc&per_page=${perPage}&page=1&sparkline=true&price_change_percentage=24h${
    ids ? `&ids=${ids.map(encodeURIComponent).join('%2C')}` : ''
  }`

/** Quotes by CoinGecko id ("bitcoin", "solana"), in one request. */
export async function cryptoQuotes(ids: string[]): Promise<Quote[]> {
  if (!ids.length) return []
  const key = `cg:${[...ids].sort().join(',')}`
  return cached(key, TTL, async () => {
    try {
      const coins = await getJson<CgCoin[]>(cgMarketsUrl(ids, 250))
      return coins.map(cryptoQuote)
    } catch {
      return []
    }
  })
}

/** The largest coins by market cap. */
export async function topCrypto(limit = 8): Promise<Quote[]> {
  return cached(`cg:top:${limit}`, TTL, async () => {
    try {
      return (await getJson<CgCoin[]>(cgMarketsUrl(null, limit))).map(cryptoQuote)
    } catch {
      return []
    }
  })
}

export type CoinHit = { id: string; ticker: string; name: string; marketCapRank: number | null }

/** Symbol or name to CoinGecko id — the step before any quote lookup. */
export async function searchCoins(query: string, limit = 6): Promise<CoinHit[]> {
  if (!query.trim()) return []
  try {
    const body = await getJson<{ coins?: { id: string; symbol: string; name: string; market_cap_rank?: number | null }[] }>(
      `${CG}/search?query=${encodeURIComponent(query.trim())}`,
    )
    return (body.coins ?? []).slice(0, limit).map((coin) => ({
      id: coin.id,
      ticker: coin.symbol.toUpperCase(),
      name: coin.name,
      marketCapRank: coin.market_cap_rank ?? null,
    }))
  } catch {
    return []
  }
}

export type GlobalMarket = { marketCap: number | null; volume: number | null; btcDominance: number | null; change24h: number | null }

/** Whole-market totals: total cap, 24h volume, BTC dominance, 24h cap change. */
export async function globalOverview(): Promise<GlobalMarket | null> {
  return cached('cg:global', TTL, async () => {
    type CgGlobal = {
      data?: {
        total_market_cap?: Record<string, number>
        total_volume?: Record<string, number>
        market_cap_percentage?: Record<string, number>
        market_cap_change_percentage_24h_usd?: number
      }
    }
    const body = await getJson<CgGlobal>(`${CG}/global`).catch(() => null)
    if (!body?.data) return null
    return {
      marketCap: num(body.data.total_market_cap?.usd),
      volume: num(body.data.total_volume?.usd),
      btcDominance: num(body.data.market_cap_percentage?.btc),
      change24h: num(body.data.market_cap_change_percentage_24h_usd),
    }
  })
}

/* ------------------------------------------------------------- venues -- */

// One number from one exchange can be stale, regional or thin. Ask several
// venues at once and keep whatever answers, so a spread is visible instead of a
// single price presented as the whole market.

export type VenueQuote = {
  venue: 'Coinbase' | 'Binance' | 'Kraken'
  pair: string
  price: number
  change24h: number | null
  /** Quote-currency volume for the last 24h, when the venue reports it. */
  volume24h: number | null
  /** True when the quote came through a relay, not directly. */
  viaRelay?: boolean
}

type Attempt = { venue: VenueQuote['venue']; pair: string; run: () => Promise<VenueQuote | null> }

const venueJson = <T>(url: string) => getJson<T>(url, 8_000).catch(() => null)

const coinbase = (ticker: string): Attempt => {
  const pair = `${ticker}-USD`
  return {
    venue: 'Coinbase',
    pair,
    run: async () => {
      const body = await venueJson<{ open?: string; last?: string; volume?: string }>(`https://api.exchange.coinbase.com/products/${pair}/stats`)
      const price = num(body?.last)
      if (!body || price == null) return null
      const open = num(body.open)
      return {
        venue: 'Coinbase',
        pair,
        price,
        change24h: open ? ((price - open) / open) * 100 : null,
        volume24h: num(body.volume),
      }
    },
  }
}

const binance = (ticker: string, relayUrl?: string): Attempt => {
  const pair = `${ticker}USDT`
  const target = `https://api.binance.com/api/v3/ticker/24hr?symbol=${pair}`
  const parse = (body: { lastPrice?: string; priceChangePercent?: string; quoteVolume?: string } | null, viaRelay: boolean) => {
    const price = num(body?.lastPrice)
    if (!body || price == null) return null
    return { venue: 'Binance' as const, pair, price, change24h: num(body.priceChangePercent), volume24h: num(body.quoteVolume), viaRelay }
  }
  return {
    venue: 'Binance',
    pair,
    run: async () => {
      const direct = parse(await venueJson<{ lastPrice?: string; priceChangePercent?: string; quoteVolume?: string }>(target), false)
      if (direct) return direct
      // Binance answers 451 to blocked regions; a relay reads it from elsewhere.
      if (!relayUrl) return null
      return parse(
        await venueJson<{ lastPrice?: string; priceChangePercent?: string; quoteVolume?: string }>(
          `${relayUrl}${relayUrl.includes('?') ? '&' : '?'}url=${encodeURIComponent(target)}`,
        ),
        true,
      )
    },
  }
}

// Kraken still calls Bitcoin XBT and wraps some pairs in X/Z prefixes.
const KRAKEN_ALIAS: Record<string, string> = { BTC: 'XBT', DOGE: 'XDG' }

const kraken = (ticker: string): Attempt => {
  const base = KRAKEN_ALIAS[ticker] ?? ticker
  const pair = `${base}USD`
  return {
    venue: 'Kraken',
    pair,
    run: async () => {
      const body = await venueJson<{ error?: string[]; result?: Record<string, { c?: string[]; o?: string; v?: string[] }> }>(
        `https://api.kraken.com/0/public/Ticker?pair=${pair}`,
      )
      if (!body || (body.error?.length ?? 0) > 0 || !body.result) return null
      const key = Object.keys(body.result).find((entry) => entry !== 'last')
      const entry = key ? body.result[key] : undefined
      const price = num(entry?.c?.[0])
      if (!entry || price == null) return null
      const open = num(entry.o)
      return {
        venue: 'Kraken',
        pair: key ?? pair,
        price,
        change24h: open ? ((price - open) / open) * 100 : null,
        volume24h: num(entry.v?.[1]),
      }
    },
  }
}

/** Every venue that quotes this ticker, in parallel. Failures are dropped. */
export async function venueQuotes(ticker: string, relayUrl?: string): Promise<VenueQuote[]> {
  const symbol = ticker.trim().toUpperCase().replace(/[^A-Z0-9]/g, '')
  if (!symbol) return []
  const settled = await Promise.all([coinbase(symbol), binance(symbol, relayUrl), kraken(symbol)].map((attempt) => attempt.run().catch(() => null)))
  return settled.filter((quote): quote is VenueQuote => quote != null)
}

/** Spread across venues, as a percentage of the cheapest price. */
export function venueSpread(quotes: VenueQuote[]): number | null {
  const prices = quotes.map((quote) => quote.price).filter((price) => price > 0)
  if (prices.length < 2) return null
  const low = Math.min(...prices)
  return low ? ((Math.max(...prices) - low) / low) * 100 : null
}

/* ------------------------------------------------------------ pump.fun -- */

// pump.fun's own frontend API answers servers with a Cloudflare challenge, and
// its developer API needs an approved organisation key and serves social data,
// not prices. GeckoTerminal indexes the bonding curve (`pump-fun`) and PumpSwap
// (`pumpswap`) pools directly, so that is the source here — labelled as such.

const GT = 'https://api.geckoterminal.com/api/v2'
const DS = 'https://api.dexscreener.com'
const SOL_MINT = 'So11111111111111111111111111111111111111112'
const TOKEN_PROGRAM = 'TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA'
const TOKEN_2022_PROGRAM = 'TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb'

export type MemeCoin = {
  mint: string
  symbol: string
  name: string
  price: number | null
  change24h: number | null
  volume24h: number | null
  marketCap: number | null
  liquidity: number | null
  pool: string
  dex: string
  venue: string
  createdAt: number | null
  url: string
}

export type MemeFeed = { items: MemeCoin[]; updatedAt: number; source: string }

type GtPool = {
  id: string
  attributes?: {
    name?: string
    base_token_price_usd?: string
    fdv_usd?: string
    market_cap_usd?: string | null
    reserve_in_usd?: string
    pool_created_at?: string
    volume_usd?: Record<string, string>
    price_change_percentage?: Record<string, string>
  }
  relationships?: { base_token?: { data?: { id?: string } }; dex?: { data?: { id?: string } } }
}

type DsPair = {
  dexId?: string
  pairAddress?: string
  priceUsd?: string
  fdv?: number
  marketCap?: number
  baseToken?: { address?: string; name?: string; symbol?: string }
  liquidity?: { usd?: number }
  volume?: { h24?: number }
  priceChange?: { h24?: number }
}

/** Symbol out of a GeckoTerminal pool name like "COOKED / SOL". */
const symbolFromPoolName = (name?: string): string => (name ?? '').split(' / ')[0]!.trim()

function toCoin(pool: GtPool): MemeCoin | null {
  const mint = (pool.relationships?.base_token?.data?.id ?? '').replace(/^solana_/, '')
  if (!mint) return null
  const attributes = pool.attributes ?? {}
  const dex = pool.relationships?.dex?.data?.id ?? 'unknown'
  const symbol = symbolFromPoolName(attributes.name) || `${mint.slice(0, 4)}…`
  const created = attributes.pool_created_at ? Date.parse(attributes.pool_created_at) : Number.NaN
  const reserve = num(attributes.reserve_in_usd)
  return {
    mint,
    symbol,
    name: symbol,
    price: num(attributes.base_token_price_usd),
    change24h: num(attributes.price_change_percentage?.h24),
    volume24h: num(attributes.volume_usd?.h24),
    marketCap: num(attributes.market_cap_usd) ?? num(attributes.fdv_usd),
    liquidity: reserve != null && reserve > 1 ? reserve : null,
    pool: pool.id.replace(/^solana_/, ''),
    dex,
    venue: dex === 'pump-fun' ? 'pump.fun' : dex === 'pumpswap' ? 'PumpSwap' : dex,
    createdAt: Number.isFinite(created) ? created : null,
    url: `https://pump.fun/coin/${mint}`,
  }
}

/** One row per mint, keeping whichever pool carries the most volume. */
function mergePools(lists: (GtPool[] | undefined)[]): MemeCoin[] {
  const seen = new Map<string, MemeCoin>()
  for (const list of lists) {
    for (const pool of list ?? []) {
      const coin = toCoin(pool)
      if (!coin) continue
      const existing = seen.get(coin.mint)
      if (!existing || (coin.volume24h ?? 0) > (existing.volume24h ?? 0)) seen.set(coin.mint, coin)
    }
  }
  return [...seen.values()]
}

type PriceInfo = { price: number | null; change24h: number | null; liquidity: number | null; symbol: string | null }

function chunk<T>(items: T[], size: number): T[][] {
  const out: T[][] = []
  for (let index = 0; index < items.length; index += size) out.push(items.slice(index, index + size))
  return out
}

/** DexScreener prices for 30 mints per call, best-liquidity pair wins. */
async function pricesFor(mints: string[]): Promise<Map<string, PriceInfo>> {
  const prices = new Map<string, PriceInfo>()
  const wanted = new Set(mints)
  const groups = await Promise.all(
    chunk(mints, 30).map((group) => getJson<DsPair[]>(`${DS}/tokens/v1/solana/${group.join(',')}`).catch(() => [] as DsPair[])),
  )
  for (const pairs of groups) {
    for (const pair of pairs) {
      const mint = pair.baseToken?.address
      if (!mint || !wanted.has(mint)) continue
      const liquidity = pair.liquidity?.usd ?? 0
      const existing = prices.get(mint)
      if (existing && (existing.liquidity ?? 0) >= liquidity) continue
      prices.set(mint, { price: num(pair.priceUsd), change24h: num(pair.priceChange?.h24), liquidity, symbol: pair.baseToken?.symbol ?? null })
    }
  }
  return prices
}

/** GeckoTerminal's reserve collapses on bonding curves; DexScreener measures the pair. */
async function withLiquidity(items: MemeCoin[]): Promise<MemeCoin[]> {
  if (!items.length) return items
  const prices = await pricesFor(items.map((coin) => coin.mint))
  return items.map((coin) => {
    const market = prices.get(coin.mint)
    if (!market) return coin
    return {
      ...coin,
      price: coin.price ?? market.price,
      change24h: coin.change24h ?? market.change24h,
      liquidity: coin.liquidity ?? (market.liquidity != null && market.liquidity > 1 ? market.liquidity : null),
    }
  })
}

/**
 * The pump.fun leaderboard: movers by 24h volume (bonding curve plus graduated
 * PumpSwap pools), or the freshest launches. A throttled feed returns the last
 * snapshot with its age in the source line rather than an empty list.
 */
export async function memeFeed(sort: 'volume' | 'new' = 'volume'): Promise<MemeFeed> {
  const key = `feed:${sort}`
  const load = async (): Promise<MemeFeed> => {
    if (sort === 'new') {
      const fresh = await getJson<{ data?: GtPool[] }>(`${GT}/networks/solana/new_pools?page=1`)
      const items = mergePools([fresh.data])
        .filter((coin) => coin.dex === 'pump-fun' || coin.dex === 'pumpswap')
        .sort((a, b) => (b.createdAt ?? 0) - (a.createdAt ?? 0))
      return { items: await withLiquidity(items.slice(0, 24)), updatedAt: Date.now(), source: 'GeckoTerminal · new pump.fun launches' }
    }
    const [curve, graduated] = await Promise.all([
      getJson<{ data?: GtPool[] }>(`${GT}/networks/solana/dexes/pump-fun/pools?page=1&sort=h24_volume_usd_desc`),
      getJson<{ data?: GtPool[] }>(`${GT}/networks/solana/dexes/pumpswap/pools?page=1&sort=h24_volume_usd_desc`),
    ])
    const items = mergePools([curve.data, graduated.data]).sort((a, b) => (b.volume24h ?? 0) - (a.volume24h ?? 0))
    return { items: await withLiquidity(items.slice(0, 24)), updatedAt: Date.now(), source: 'GeckoTerminal · pump.fun + PumpSwap by 24h volume' }
  }

  try {
    return await cached(key, 60_000, load)
  } catch (error) {
    const previous = peek<MemeFeed>(key)
    if (!previous) throw error
    const at = new Date(previous.at).toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' })
    return { ...previous.value, source: `${previous.value.source} · snapshot from ${at} while the feed is throttled` }
  }
}

/* ------------------------------------------------------------- candles -- */

export type Candle = { t: number; o: number; h: number; l: number; c: number; v: number }

/** Newest-first OHLCV from GeckoTerminal, returned oldest-first for indicators. */
export async function poolCandles(pool: string, interval: 'day' | 'hour'): Promise<Candle[]> {
  return cached(`ohlcv:${pool}:${interval}`, 45_000, async () => {
    let wait = 400
    for (let attempt = 0; attempt < 3; attempt++) {
      const response = await fetch(`${GT}/networks/solana/pools/${pool}/ohlcv/${interval}?limit=180&currency=usd`, {
        headers: { accept: 'application/json', 'user-agent': UA },
        signal: AbortSignal.timeout(12_000),
      }).catch(() => null)
      if (response?.status === 429) {
        if (attempt === 2) throw new Error('Candle data is rate limited right now. Try again in a minute — this is a feed limit, not a problem with the token.')
        const header = Number(response.headers.get('retry-after'))
        await new Promise((resolve) => setTimeout(resolve, Number.isFinite(header) && header > 0 ? Math.min(header * 1_000, 2_000) : wait))
        wait *= 3
        continue
      }
      if (!response?.ok) return []
      const body = (await response.json().catch(() => null)) as { data?: { attributes?: { ohlcv_list?: number[][] } } } | null
      return (body?.data?.attributes?.ohlcv_list ?? [])
        .map(([t, o, h, l, c, v]) => ({ t: (t ?? 0) * 1000, o: o ?? 0, h: h ?? 0, l: l ?? 0, c: c ?? 0, v: v ?? 0 }))
        .reverse()
    }
    return []
  })
}

export type MemeSeries = {
  symbol: string
  price: number
  candles: Candle[]
  timeframe: 'daily' | 'hourly'
  source: string
  note: string
}

/**
 * The best candle series a mint has. A pump.fun launch is often hours old, so
 * daily candles may not exist; hourly is the honest fallback, and a pool with
 * neither is refused instead of forecast from noise.
 */
export async function memeSeries(mint: string): Promise<MemeSeries> {
  const pairs = await getJson<DsPair[]>(`${DS}/tokens/v1/solana/${mint}`).catch(() => [] as DsPair[])
  // Highest liquidity first, but try several: a dead pool can outrank the one
  // that actually trades, and an empty pool has no candles to read.
  const candidates = pairs
    .filter((pair) => pair.pairAddress && pair.priceUsd && pair.baseToken?.address === mint)
    .sort((a, b) => (b.liquidity?.usd ?? 0) - (a.liquidity?.usd ?? 0))
    .slice(0, 3)
  if (!candidates.length) throw new Error('That mint has no trading pair with a price yet.')

  const symbol = candidates[0]!.baseToken?.symbol ?? `${mint.slice(0, 4)}…`
  let best: { candles: Candle[]; pair: DsPair; hourly: boolean } | null = null
  for (const pair of candidates) {
    const daily = await poolCandles(pair.pairAddress!, 'day')
    if (daily.length >= 30) {
      best = { candles: daily, pair, hourly: false }
      break
    }
    const hourly = await poolCandles(pair.pairAddress!, 'hour')
    if (hourly.length >= 30) {
      best = { candles: hourly, pair, hourly: true }
      break
    }
  }
  if (!best) {
    throw new Error(`${symbol} has no pool with enough candle history to read — pump.fun launches are often only hours old. Give it a few days.`)
  }

  return {
    symbol,
    price: num(best.pair.priceUsd) ?? best.candles.at(-1)?.c ?? 0,
    candles: best.candles,
    timeframe: best.hourly ? 'hourly' : 'daily',
    source: `GeckoTerminal ${best.hourly ? 'hourly' : 'daily'} candles · ${best.pair.dexId ?? 'unknown venue'}`,
    note: [
      best.hourly ? 'Hourly candles because the pool is young, so levels are intraday, not multi-week.' : '',
      best.pair.dexId === 'pump-fun'
        ? 'Bonding-curve pool: liquidity is thin and can be pulled, so treat levels as approximate.'
        : 'Pool-level candles: wicks reflect one venue, not the whole market.',
    ]
      .filter(Boolean)
      .join(' '),
  }
}

/* -------------------------------------------------------------- wallet -- */

export type WalletHolding = {
  mint: string
  symbol: string
  name: string
  amount: number
  price: number | null
  value: number | null
  change24h: number | null
  liquidity: number | null
}

export type WalletPortfolio = {
  address: string
  sol: number
  solValue: number | null
  totalValue: number | null
  holdings: WalletHolding[]
  unpriced: number
  updatedAt: number
}

export const isSolanaAddress = (value: string): boolean => /^[1-9A-HJ-NP-Za-km-z]{32,44}$/.test(value)

type RpcAccount = { account?: { data?: { parsed?: { info?: { mint?: string; tokenAmount?: { uiAmount?: number | null } } } } } }

const MAX_RPC_BYTES = 6 * 1024 * 1024

class RpcTooLarge extends Error {}
class RpcHttpError extends Error {
  constructor(
    public status: number,
    detail = '',
  ) {
    super(`The Solana RPC responded ${status}${detail ? `: ${detail}` : ''}`)
  }
}

async function readBounded(response: Response, limit: number): Promise<string> {
  if (!response.body) return ''
  const reader = response.body.getReader()
  const decoder = new TextDecoder()
  let text = ''
  let received = 0
  try {
    for (;;) {
      const { value, done } = await reader.read()
      if (done) break
      received += value.byteLength
      if (received > limit) throw new RpcTooLarge('That wallet has more token accounts than this will read in one request.')
      text += decoder.decode(value, { stream: true })
    }
    return text + decoder.decode()
  } finally {
    void reader.cancel().catch(() => {})
  }
}

async function rpc<T>(url: string, body: unknown, timeout = 20_000): Promise<T> {
  const response = await fetch(url, {
    method: 'POST',
    // An honest agent, not a browser one: impersonating Chrome from a server
    // trips bot detection, because the TLS fingerprint does not match.
    headers: { 'content-type': 'application/json', accept: 'application/json', 'user-agent': 'crypto-kit/1.0' },
    body: JSON.stringify(body),
    signal: AbortSignal.timeout(timeout),
  })
  if (!response.ok) throw new RpcHttpError(response.status, (await response.text()).replace(/\s+/g, ' ').slice(0, 140))
  const payload = JSON.parse(await readBounded(response, MAX_RPC_BYTES)) as { result?: T; error?: { message?: string } }
  if (payload.error) throw new Error(payload.error.message ?? 'The Solana RPC returned an error.')
  return payload.result as T
}

/** Public RPCs rate-limit bursts, so every wallet call gets one retry. */
async function rpcWithRetry<T>(url: string, body: unknown): Promise<T | null> {
  for (let attempt = 0; attempt < 2; attempt++) {
    try {
      return await rpc<T>(url, body)
    } catch (error) {
      if (error instanceof RpcTooLarge) throw error
      // A 401/403/400 will not improve by waiting.
      if (error instanceof RpcHttpError && error.status !== 429 && error.status < 500) throw error
      if (attempt === 0) await new Promise((resolve) => setTimeout(resolve, 600))
    }
  }
  return null
}

type RawAccounts = {
  balance: { value: number } | null
  classic: { value: RpcAccount[] } | null
  token2022: { value: RpcAccount[] } | null
}

async function readAccounts(rpcUrl: string, address: string): Promise<RawAccounts> {
  try {
    const balance = await rpcWithRetry<{ value: number }>(rpcUrl, { jsonrpc: '2.0', id: 1, method: 'getBalance', params: [address] })
    const classic = await rpcWithRetry<{ value: RpcAccount[] }>(rpcUrl, {
      jsonrpc: '2.0',
      id: 2,
      method: 'getTokenAccountsByOwner',
      params: [address, { programId: TOKEN_PROGRAM }, { encoding: 'jsonParsed' }],
    })
    const token2022 = await rpcWithRetry<{ value: RpcAccount[] }>(rpcUrl, {
      jsonrpc: '2.0',
      id: 3,
      method: 'getTokenAccountsByOwner',
      params: [address, { programId: TOKEN_2022_PROGRAM }, { encoding: 'jsonParsed' }],
    })
    if (!balance && !classic && !token2022) throw new Error('The Solana RPC rate-limited this request.')
    return { balance, classic, token2022 }
  } catch (error) {
    if (error instanceof RpcTooLarge) throw error
    throw new Error(error instanceof Error ? error.message : 'The Solana RPC did not answer.')
  }
}

/**
 * Public balances for a Solana address, priced in USD. Both token programs are
 * read, because pump.fun tokens can be issued under either. A token with no
 * market is reported as unpriced, never valued at zero.
 *
 * SOLANA_RPC_URL is required: publicnode blocks getTokenAccountsByOwner, and
 * mainnet-beta blocks server egress. A free Helius or QuickNode URL works.
 */
export async function walletPortfolio(address: string, rpcUrl?: string): Promise<WalletPortfolio> {
  if (!isSolanaAddress(address)) throw new Error('That is not a Solana wallet address.')
  if (!rpcUrl) {
    throw new Error('Reading a Solana wallet needs an RPC endpoint. Set SOLANA_RPC_URL to a node you control — a free Helius or QuickNode URL takes a minute.')
  }

  return cached(`wallet:${address}`, 30_000, async () => {
    const { balance, classic, token2022 } = await readAccounts(rpcUrl, address)

    const amounts = new Map<string, number>()
    for (const entry of [...(classic?.value ?? []), ...(token2022?.value ?? [])]) {
      const info = entry.account?.data?.parsed?.info
      const mint = info?.mint
      const amount = info?.tokenAmount?.uiAmount ?? null
      if (!mint || amount == null || amount <= 0) continue
      amounts.set(mint, (amounts.get(mint) ?? 0) + amount)
    }

    // Priced in batches of 30, so 100 mints is four lookups and a real wallet is
    // never silently truncated.
    const mints = [...amounts.keys()].slice(0, 100)
    const prices = await pricesFor([SOL_MINT, ...mints])
    const sol = (balance?.value ?? 0) / 1e9
    const solPrice = prices.get(SOL_MINT)?.price ?? null

    const holdings: WalletHolding[] = mints
      .map((mint) => {
        const amount = amounts.get(mint) ?? 0
        const price = prices.get(mint)
        return {
          mint,
          symbol: price?.symbol ?? `${mint.slice(0, 4)}…`,
          name: price?.symbol ?? 'Unlisted token',
          amount,
          price: price?.price ?? null,
          value: price?.price != null ? amount * price.price : null,
          change24h: price?.change24h ?? null,
          liquidity: price?.liquidity ?? null,
        }
      })
      .sort((a, b) => (b.value ?? -1) - (a.value ?? -1))

    const priced = holdings.reduce((sum, holding) => sum + (holding.value ?? 0), 0)
    const solValue = solPrice != null ? sol * solPrice : null
    return {
      address,
      sol,
      solValue,
      totalValue: solValue != null || priced > 0 ? (solValue ?? 0) + priced : null,
      holdings,
      unpriced: holdings.filter((holding) => holding.value == null).length,
      updatedAt: Date.now(),
    }
  })
}
