import { ArrowUpRight, Loader2, MessageSquare, Plus, RefreshCw, Search, Sparkles, Trash2, TrendingDown, TrendingUp } from 'lucide-react'
import { useState } from 'react'

import type { Quote } from '../../shared/types'
import { AskPanel, type AskSeed } from '../components/AskPanel'
import { Sparkline } from '../components/Sparkline'
import { Badge, Button, Dialog, Input, Spinner, useToast } from '../components/ui'
import { useAddWatch, useMarketOverview, useMarketSearch, useRemoveWatch, useWatchlist } from '../lib/api'
import { cx } from '../lib/cx'
import { formatCompact, formatPct, formatPrice } from '../lib/format'

const QUICK: { ref: string; kind: 'crypto' | 'stock'; name: string }[] = [
  { ref: 'bitcoin', kind: 'crypto', name: 'Bitcoin' },
  { ref: 'ethereum', kind: 'crypto', name: 'Ethereum' },
  { ref: 'solana', kind: 'crypto', name: 'Solana' },
  { ref: 'AAPL', kind: 'stock', name: 'Apple' },
  { ref: 'NVDA', kind: 'stock', name: 'NVIDIA' },
  { ref: 'SPY', kind: 'stock', name: 'S&P 500 ETF' },
]

function Change({ value, className }: { value: number | null; className?: string }) {
  const tone = value == null ? 'text-faint' : value >= 0 ? 'text-up' : 'text-down'
  return (
    <span className={cx('inline-flex items-center gap-1 tabular-nums', tone, className)}>
      {value != null && (value >= 0 ? <TrendingUp className="size-3.5" /> : <TrendingDown className="size-3.5" />)}
      {formatPct(value)}
    </span>
  )
}

/** A price carries its own quote currency; only USD gets a dollar sign. */
const quoteMoney = (quote: Quote): string =>
  quote.price == null
    ? '—'
    : `${quote.currency === 'USD' ? '$' : ''}${formatPrice(quote.price)}${quote.currency && quote.currency !== 'USD' ? ` ${quote.currency}` : ''}`

const analysisPrompt = (quote: Quote) =>
  `Look at ${quote.name} (${quote.ticker}). It is at ${quoteMoney(quote)} right now, ${formatPct(quote.changePct)} on the day, ${formatCompact(quote.marketCap)} market cap, ${formatCompact(quote.volume)} volume. Give me: direction over the next 5 sessions with an explicit probability, the levels that matter, what invalidates the call, a position size for a $10,000 risk budget, and the two catalysts I should watch next. Work from these live figures and say what you are inferring; if the signals disagree, give the range instead of a point call. Skip the disclaimers.`

export function Markets() {
  const overview = useMarketOverview()
  const watch = useWatchlist()
  const remove = useRemoveWatch()
  const toast = useToast()
  const [adding, setAdding] = useState(false)
  const [asking, setAsking] = useState(false)
  const [seed, setSeed] = useState<AskSeed | null>(null)

  const quotes = watch.data?.quotes ?? []
  const indices = overview.data?.indices ?? []
  const coins = overview.data?.crypto ?? []
  const global = overview.data?.global ?? null
  const fresh = overview.data?.updatedAt ?? watch.dataUpdatedAt
  // Sent with every question asked from this page, so "these" resolves to the
  // rows on screen and the answer never needs an invented price.
  const screen = [
    'The Markets page: live indices, the watchlist and the top coins by market cap.',
    `Indices: ${indices.map((quote) => `${quote.ticker} ${quoteMoney(quote)} (${formatPct(quote.changePct)})`).join(', ') || 'not loaded'}`,
    `Watchlist: ${quotes.map((quote) => `${quote.ticker} ${quoteMoney(quote)} (${formatPct(quote.changePct)})`).join(', ') || 'empty'}`,
    `Top coins: ${coins.slice(0, 5).map((quote) => `${quote.ticker} ${quoteMoney(quote)} (${formatPct(quote.changePct)})`).join(', ') || 'not loaded'}`,
    `"These" means those instruments. Answer from this list and use only these numbers in their own quote currency; never invent a price and never convert one.`,
  ].join('\n')

  const ask = (prompt?: string) => {
    setSeed(prompt ? { text: prompt, id: Date.now() } : null)
    setAsking(true)
  }
  const analyze = (quote: Quote) => ask(analysisPrompt(quote))
  const itemId = (quote: Quote) =>
    watch.data?.items.find((item) => item.kind === quote.kind && item.ref.toLowerCase() === quote.ref.toLowerCase())?.id
  const refresh = () => {
    void overview.refetch()
    void watch.refetch()
  }

  return (
    <div className="scrollbar-thin min-h-0 flex-1 overflow-y-auto">
      <div className="mx-auto w-full max-w-[1060px] px-4 pb-14 pt-4 md:px-8 md:pt-7">
        <header className="flex flex-wrap items-end justify-between gap-3">
          <div>
            <p className="text-[12px] font-medium uppercase tracking-[0.1em] text-faint">Live tape</p>
            <h1 className="mt-1 text-[26px] font-semibold tracking-[-0.025em] md:text-[30px]">Markets</h1>
            <p className="mt-1 max-w-xl text-[13.5px] leading-relaxed text-muted">
              Indices, equities and crypto. Add any instrument, then hand it to Ulvarin with the live numbers attached.
            </p>
          </div>
          <div className="flex items-center gap-2">
            <Button size="sm" onClick={() => ask()}>
              <Sparkles />
              Ask
            </Button>
            <Button size="sm" onClick={refresh} aria-label="Refresh market data">
              <RefreshCw className={cx(overview.isFetching && 'animate-spin')} />
              Refresh
            </Button>
            <Button size="sm" variant="primary" onClick={() => setAdding(true)}>
              <Plus />
              Add symbol
            </Button>
          </div>
        </header>

        <section className="mt-6" aria-label="Indices">
          {indices.length === 0 ? (
            <div className="grid place-items-center rounded-card bg-surface py-10 shadow-card">{overview.isLoading ? <Spinner /> : <p className="text-[13px] text-faint">Index data is unavailable right now.</p>}</div>
          ) : (
            <div className="grid grid-cols-2 gap-2.5 sm:grid-cols-3 lg:grid-cols-6">
              {indices.map((quote) => (
                <div key={quote.ticker} className="rounded-card bg-surface px-3.5 py-3 shadow-card">
                  <p className="truncate text-[11.5px] font-medium text-faint">{quote.name}</p>
                  <p className="mt-1 text-[16px] font-semibold tabular-nums">
                    {quoteMoney(quote)}
                  </p>
                  <Change value={quote.changePct} className="mt-0.5 text-[12px]" />
                </div>
              ))}
            </div>
          )}
        </section>

        <section className="mt-3 grid gap-3 lg:grid-cols-[1.15fr_1fr]" aria-label="Crypto market">
          <div className="rounded-card bg-surface p-5 shadow-card">
            <div className="flex items-center justify-between">
              <h2 className="text-[14px] font-semibold">Crypto market</h2>
              <Badge tone="neutral">24h</Badge>
            </div>
            <dl className="mt-4 grid grid-cols-2 gap-x-6 gap-y-4">
              <Stat label="Total market cap" value={formatCompact(global?.marketCap ?? null)} />
              <Stat label="24h volume" value={formatCompact(global?.volume ?? null)} />
              <Stat label="BTC dominance" value={global?.btcDominance == null ? '—' : `${global.btcDominance.toFixed(1)}%`} />
              <div>
                <dt className="text-[11.5px] text-faint">Market cap, 24h</dt>
                <dd className="mt-1">
                  <Change value={global?.change24h ?? null} className="text-[16px] font-semibold" />
                </dd>
              </div>
            </dl>
            <button
              type="button"
              onClick={() =>
                ask(
                  'Give me a macro read on crypto right now: total market cap trend, BTC dominance, where we are in the cycle, and the two levels that decide the next move. Pull the live market overview first.',
                )
              }
              className="mt-5 inline-flex h-8 items-center gap-1.5 rounded-tile px-2.5 text-[13px] font-medium text-muted transition-colors hover:bg-surface-2 hover:text-fg"
            >
              <MessageSquare className="size-3.5" />
              Ask Ulvarin for the macro read
              <ArrowUpRight className="size-3.5 text-faint" />
            </button>
          </div>

          <div className="rounded-card bg-surface p-5 shadow-card">
            <div className="flex items-center justify-between">
              <h2 className="text-[14px] font-semibold">Top coins</h2>
              <span className="text-[11.5px] text-faint">by market cap</span>
            </div>
            <ul className="mt-3 divide-y divide-line">
              {coins.length === 0 && <li className="py-6 text-center text-[13px] text-faint">Coin data is unavailable right now.</li>}
              {coins.slice(0, 6).map((coin) => (
                <li key={coin.ref}>
                  <button
                    type="button"
                    onClick={() => analyze(coin)}
                    className="group flex w-full items-center gap-3 py-2.5 text-left transition-colors hover:text-fg"
                  >
                    <span className="w-12 shrink-0 text-[12.5px] font-semibold">{coin.ticker}</span>
                    <span className="min-w-0 flex-1 truncate text-[12.5px] text-faint">{coin.name}</span>
                    <Sparkline data={coin.spark} up={(coin.changePct ?? 0) >= 0} width={64} height={22} className="hidden sm:block" />
                    <span className="w-20 text-right text-[13px] tabular-nums">{formatPrice(coin.price)}</span>
                    <Change value={coin.changePct} className="w-[74px] justify-end text-[12px]" />
                  </button>
                </li>
              ))}
            </ul>
          </div>
        </section>

        <section className="mt-8" aria-label="Watchlist">
          <div className="flex items-end justify-between gap-3">
            <div>
              <h2 className="text-[15px] font-semibold">Your watchlist</h2>
              <p className="mt-0.5 text-[12.5px] text-muted">
                {quotes.length ? `${quotes.length} instrument${quotes.length === 1 ? '' : 's'} · updated ${fresh ? new Date(fresh).toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' }) : '—'}` : 'Nothing tracked yet.'}
              </p>
            </div>
          </div>

          {watch.isLoading ? (
            <div className="mt-4 grid place-items-center rounded-card bg-surface py-14 shadow-card">
              <Spinner />
            </div>
          ) : quotes.length === 0 ? (
            <div className="mt-4 rounded-card border border-dashed border-line-strong bg-surface/60 px-5 py-8 text-center">
              <p className="text-[14px] font-medium">Start with something you actually follow.</p>
              <p className="mx-auto mt-1 max-w-md text-[13px] leading-relaxed text-muted">
                A watchlist row is one click from a full analysis: Ulvarin pulls the quote, reads the tape and sizes the trade.
              </p>
              <div className="mt-4 flex flex-wrap justify-center gap-2">
                {QUICK.map((item) => (
                  <QuickAdd key={item.ref} item={item} />
                ))}
              </div>
            </div>
          ) : (
            <ul className="mt-3 divide-y divide-line overflow-hidden rounded-card bg-surface shadow-card">
              {quotes.map((quote) => (
                <li key={`${quote.kind}:${quote.ref}`} className="group flex items-center gap-3 px-4 py-3">
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2">
                      <span className="text-[13.5px] font-semibold">{quote.ticker}</span>
                      <span className="truncate text-[12.5px] text-faint">{quote.name}</span>
                      {quote.degraded && <Badge tone="warning">delayed</Badge>}
                    </div>
                    <p className="mt-0.5 text-[11.5px] text-faint">
                      {quote.kind === 'crypto' ? 'Crypto' : 'Equity'}
                      {quote.marketCap ? ` · ${formatCompact(quote.marketCap)} cap` : ''}
                      {quote.volume ? ` · ${formatCompact(quote.volume)} vol` : ''}
                    </p>
                  </div>
                  <Sparkline data={quote.spark} up={(quote.changePct ?? 0) >= 0} className="hidden shrink-0 sm:block" />
                  <div className="w-[92px] shrink-0 text-right">
                    <p className="text-[14px] font-medium tabular-nums">{quoteMoney(quote)}</p>
                    <Change value={quote.changePct} className="justify-end text-[12px]" />
                  </div>
                  <div className="flex shrink-0 items-center gap-0.5">
                    <button
                      type="button"
                      onClick={() => analyze(quote)}
                      aria-label={`Forecast ${quote.ticker} with Ulvarin`}
                      title="Forecast with Ulvarin"
                      className="grid size-8 place-items-center rounded-tile text-faint transition-colors hover:bg-surface-2 hover:text-fg [&_svg]:size-4"
                    >
                      <MessageSquare />
                    </button>
                    <button
                      type="button"
                      onClick={() => remove.mutate(itemId(quote) ?? '', { onError: () => toast('Could not remove that symbol', 'danger') })}
                      aria-label={`Remove ${quote.ticker}`}
                      title="Remove"
                      className="grid size-8 place-items-center rounded-tile text-faint transition-colors hover:bg-danger-soft hover:text-danger [&_svg]:size-4"
                    >
                      <Trash2 />
                    </button>
                  </div>
                </li>
              ))}
            </ul>
          )}

          {watch.error && <p className="mt-3 text-[12.5px] text-danger">Could not load the watchlist. Refresh to try again.</p>}
        </section>

        <section className="mt-8 rounded-card bg-surface p-5 shadow-card">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div className="min-w-0">
              <h2 className="text-[14px] font-semibold">Financial analysis, on demand</h2>
              <p className="mt-1 max-w-xl text-[13px] leading-relaxed text-muted">
                Ulvarin reads live quotes, filings and news pages, then builds the case: trend, levels, invalidation, sizing and catalysts. Ask for crypto, equities, FX or a macro view.
              </p>
            </div>
            <Button
              variant="primary"
              onClick={() =>
                ask(
                  'Build me a one-page market brief for today: what moved, why, and what I should watch into the next session. Use the live market overview and search the web for the two biggest stories. Be specific about levels and catalysts.',
                )
              }
            >
              Build today&apos;s brief
              <ArrowUpRight />
            </Button>
          </div>
        </section>
      </div>

      <AddSymbolDialog open={adding} onClose={() => setAdding(false)} />

      <AskPanel
        open={asking}
        onClose={() => setAsking(false)}
        title="Market desk"
        context="Grounded in live quotes, your watchlist and the market overview."
        screen={screen}
        suggestions={[
          'Which setup here is strongest right now, and why?',
          'Where is my watchlist overexposed?',
          'What would invalidate the index trend?',
        ]}
        seed={seed}
      />
    </div>
  )
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <dt className="text-[11.5px] text-faint">{label}</dt>
      <dd className="mt-1 text-[16px] font-semibold tabular-nums">{value}</dd>
    </div>
  )
}

function QuickAdd({ item }: { item: { ref: string; kind: 'crypto' | 'stock'; name: string } }) {
  const add = useAddWatch()
  const toast = useToast()
  return (
    <button
      type="button"
      disabled={add.isPending}
      onClick={() =>
        add.mutate(item, {
          onError: (error) => toast(error instanceof Error ? error.message : 'Could not add that', 'danger'),
        })
      }
      className="inline-flex h-8 items-center gap-1.5 rounded-tile border border-line-strong bg-surface px-3 text-[12.5px] font-medium transition-colors hover:bg-surface-2 disabled:opacity-50"
    >
      {add.isPending ? <Loader2 className="size-3.5 animate-spin" /> : <Plus className="size-3.5" />}
      {item.name}
    </button>
  )
}

function AddSymbolDialog({ open, onClose }: { open: boolean; onClose: () => void }) {
  const [query, setQuery] = useState('')
  const search = useMarketSearch(query)
  const add = useAddWatch()
  const toast = useToast()

  const close = () => {
    setQuery('')
    onClose()
  }
  const pick = (hit: { ref: string; kind: string; name: string }) =>
    add.mutate(
      { ref: hit.ref, kind: hit.kind, name: hit.name },
      { onSuccess: close, onError: (error) => toast(error instanceof Error ? error.message : 'Could not add that symbol', 'danger') },
    )

  return (
    <Dialog
      open={open}
      onClose={close}
      title="Add to watchlist"
      description="Search any listed stock, ETF or coin. Prices are live within about a minute."
      footer={<Button onClick={close}>Done</Button>}
    >
      <div className="relative">
        <Search className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-faint" />
        <Input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="AAPL, NVDA, bitcoin, ETH…" className="pl-9" aria-label="Search symbols" />
      </div>

      {query.trim().length < 2 ? (
        <div className="mt-4">
          <p className="text-[12px] font-medium text-faint">Popular</p>
          <div className="mt-2 grid grid-cols-2 gap-1.5">
            {QUICK.map((item) => (
              <button
                key={item.ref}
                type="button"
                disabled={add.isPending}
                onClick={() => pick({ ref: item.ref, kind: item.kind, name: item.name })}
                className="flex h-9 items-center justify-between rounded-tile border border-line bg-surface px-3 text-left text-[13px] transition-colors hover:bg-surface-2 disabled:opacity-50"
              >
                <span>{item.name}</span>
                <span className="text-[11.5px] text-faint">{item.kind === 'crypto' ? 'Crypto' : 'Equity'}</span>
              </button>
            ))}
          </div>
        </div>
      ) : (
        <ul className="mt-3 max-h-[46vh] divide-y divide-line overflow-y-auto">
          {search.isFetching && (
            <li className="flex items-center gap-2 py-3 text-[13px] text-faint">
              <Loader2 className="size-4 animate-spin" /> Searching…
            </li>
          )}
          {!search.isFetching && search.data?.items.length === 0 && <li className="py-3 text-[13px] text-faint">Nothing matched “{query}”. Try the ticker.</li>}
          {search.data?.items.map((hit) => (
            <li key={`${hit.kind}:${hit.ref}`}>
              <button
                type="button"
                disabled={add.isPending}
                onClick={() => pick(hit)}
                className="flex w-full items-center gap-3 py-2.5 text-left transition-colors hover:bg-surface-2 disabled:opacity-50"
              >
                <span className="w-16 shrink-0 text-[13px] font-semibold">{hit.ticker}</span>
                <span className="min-w-0 flex-1">
                  <span className="block truncate text-[13px]">{hit.name}</span>
                  <span className="block truncate text-[11.5px] text-faint">
                    {hit.kind === 'crypto' ? 'Crypto' : (hit.exchange ?? 'Equity')}
                  </span>
                </span>
                {add.isPending && add.variables?.ref === hit.ref ? <Loader2 className="size-4 animate-spin text-faint" /> : <Plus className="size-4 text-faint" />}
              </button>
            </li>
          ))}
        </ul>
      )}
    </Dialog>
  )
}
