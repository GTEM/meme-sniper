import { ExternalLink, Flame, MessageSquare, RefreshCw, Sparkles, Wallet } from 'lucide-react'
import { useEffect, useState } from 'react'

import type { MemeCoin, WalletHolding } from '../../shared/types'
import { AskPanel, type AskSeed } from '../components/AskPanel'
import { Badge, Button, Input, Spinner, useToast } from '../components/ui'
import { ApiError, useMemeFeed, useWallet } from '../lib/api'
import { cx } from '../lib/cx'
import { formatCompact, formatPct, formatPrice } from '../lib/format'

/** The subset of Phantom's injected provider this page uses. Read-only. */
type PhantomProvider = {
  connect(options?: { onlyIfTrusted?: boolean }): Promise<{ publicKey: { toString(): string } }>
  disconnect(): Promise<void>
  on(event: 'accountChanged', handler: (publicKey: { toString(): string } | null) => void): void
  off?(event: 'accountChanged', handler: (publicKey: { toString(): string } | null) => void): void
}

declare global {
  interface Window {
    phantom?: { solana?: PhantomProvider }
    solana?: PhantomProvider
  }
}

const phantom = (): PhantomProvider | undefined =>
  typeof window === 'undefined' ? undefined : (window.phantom?.solana ?? window.solana)

const age = (ts: number | null): string => {
  if (!ts) return ''
  const minutes = Math.round((Date.now() - ts) / 60_000)
  if (minutes < 60) return `${Math.max(1, minutes)}m old`
  const hours = Math.round(minutes / 60)
  if (hours < 48) return `${hours}h old`
  return `${Math.round(hours / 24)}d old`
}

const coinPrompt = (coin: MemeCoin) =>
  `Give me a read on ${coin.symbol} on Solana (mint ${coin.mint}). Right now it trades at $${formatPrice(coin.price)} on ${coin.venue}, ${formatPct(coin.change24h)} over 24h, ${formatCompact(coin.volume24h)} volume, ${formatCompact(coin.marketCap)} market cap, and ${
    coin.liquidity == null ? 'no reported pool liquidity' : `${formatCompact(coin.liquidity)} of pool liquidity`
  }${coin.createdAt ? `, ${age(coin.createdAt)}` : ''}. Tell me: the setup, the levels that matter, an explicit probability and horizon, what invalidates it, and how the pool depth changes the risk. Use these live figures rather than inventing a chart. Skip the disclaimers.`

/** Quick flags from the feed row itself — no extra requests, no guessing. */
function riskBadges(coin: MemeCoin): { label: string; tone: 'warning' | 'danger'; title: string }[] {
  const badges: { label: string; tone: 'warning' | 'danger'; title: string }[] = []
  const ratio = coin.liquidity != null && coin.marketCap ? (coin.liquidity / coin.marketCap) * 100 : null
  if (ratio != null && ratio < 2) badges.push({ label: 'thin', tone: 'warning', title: `Pool liquidity is ${ratio.toFixed(2)}% of market cap` })
  if (coin.createdAt && Date.now() - coin.createdAt < 24 * 3_600_000) badges.push({ label: 'new', tone: 'warning', title: 'Less than 24 hours old' })
  if (coin.change24h != null && coin.change24h <= -50) badges.push({ label: 'dumped', tone: 'danger', title: `Down ${coin.change24h.toFixed(0)}% in 24 hours` })
  return badges
}

const holdingPrompt = (holding: WalletHolding, address: string) =>
  `I hold ${holding.amount.toLocaleString('en-US', { maximumFractionDigits: 4 })} ${holding.symbol} (mint ${holding.mint}) in ${address}. Call meme_forecast for the mint, then tell me whether to keep it: the trend, the level that invalidates the hold, an explicit probability over the next 5 sessions, and whether the liquidity can absorb my size. Skip the disclaimers.`

export function Meme() {
  const toast = useToast()
  const [sort, setSort] = useState<'volume' | 'new'>('volume')
  const [address, setAddress] = useState<string | null>(null)
  const [manual, setManual] = useState('')
  const [busy, setBusy] = useState(false)
  const [asking, setAsking] = useState(false)
  const [seed, setSeed] = useState<AskSeed | null>(null)
  const feed = useMemeFeed(sort)
  const portfolio = useWallet(address ?? '')

  // Restore a previously trusted Phantom connection, and follow account
  // switches. Nothing is signed and no key material reaches this page.
  useEffect(() => {
    const provider = phantom()
    if (!provider) return
    let alive = true
    provider
      .connect({ onlyIfTrusted: true })
      .then((result) => {
        if (alive) setAddress(result.publicKey.toString())
      })
      .catch(() => {})
    const onAccountChanged = (key: { toString(): string } | null) => setAddress(key ? key.toString() : null)
    provider.on('accountChanged', onAccountChanged)
    return () => {
      alive = false
      provider.off?.('accountChanged', onAccountChanged)
    }
  }, [])

  const connect = async () => {
    const provider = phantom()
    if (!provider) {
      toast('Phantom is not installed in this browser. Paste a wallet address instead.', 'danger')
      return
    }
    setBusy(true)
    try {
      const result = await provider.connect()
      setAddress(result.publicKey.toString())
    } catch {
      toast('Phantom declined the connection.', 'danger')
    } finally {
      setBusy(false)
    }
  }

  const ask = (prompt?: string) => {
    setSeed(prompt ? { text: prompt, id: Date.now() } : null)
    setAsking(true)
  }

  const disconnect = async () => {
    setAddress(null)
    await phantom()?.disconnect().catch(() => {})
  }

  const coins = feed.data?.items ?? []
  const data = portfolio.data
  // The panel gets the actual rows, not just a description of the page: the
  // answer can then be grounded without the model having to fetch anything,
  // and it cannot be tempted to invent a ticker.
  const screen = [
    'The Meme coins page: a live pump.fun and PumpSwap leaderboard ranked by 24h trading volume.',
    coins.length
      ? `Current leaderboard, just fetched:\n${coins
          .slice(0, 6)
          .map(
            (coin, index) =>
              `${index + 1}. ${coin.symbol} · mint ${coin.mint} · ${coin.venue} · price $${formatPrice(coin.price)} · 24h ${formatPct(coin.change24h)} · vol ${formatCompact(coin.volume24h)} · cap ${formatCompact(coin.marketCap)} · ${coin.liquidity == null ? 'no reported pool liquidity' : `liquidity ${formatCompact(coin.liquidity)}`}${coin.createdAt ? ` · ${age(coin.createdAt)}` : ''}`,
          )
          .join('\n')}`
      : 'The leaderboard has not loaded yet.',
    address ? `The user has this Solana wallet connected: ${address}.` : '',
    `"These" means those coins. Answer from this list and use only these numbers and mints; never invent a ticker, mint, price or volume.`,
  ]
    .filter(Boolean)
    .join('\n')
  const tokenValue = data?.totalValue != null && data.solValue != null ? data.totalValue - data.solValue : null

  return (
    <div className="scrollbar-thin min-h-0 flex-1 overflow-y-auto">
      <div className="mx-auto w-full max-w-[1060px] px-4 pb-14 pt-4 md:px-8 md:pt-7">
        <header className="flex flex-wrap items-end justify-between gap-3">
          <div>
            <p className="text-[12px] font-medium uppercase tracking-[0.1em] text-faint">Solana · pump.fun</p>
            <h1 className="mt-1 text-[26px] font-semibold tracking-[-0.025em] md:text-[30px]">Meme coins</h1>
            <p className="mt-1 max-w-xl text-[13.5px] leading-relaxed text-muted">
              Live pump.fun launches and PumpSwap movers, plus a read-only Phantom wallet so Ulvarin can talk about what you actually hold.
            </p>
          </div>
          <div className="flex items-center gap-2">
          <Button size="sm" variant="primary" onClick={() => ask()}>
            <Sparkles />
            Ask
          </Button>
          <div className="flex items-center gap-1 rounded-control bg-surface-2 p-1">
            {(['volume', 'new'] as const).map((option) => (
              <button
                key={option}
                type="button"
                onClick={() => setSort(option)}
                className={cx(
                  'h-7 rounded-tile px-3 text-[12.5px] font-medium transition-colors',
                  sort === option ? 'bg-surface text-fg shadow-card' : 'text-muted hover:text-fg',
                )}
              >
                {option === 'volume' ? 'Movers' : 'Fresh'}
              </button>
            ))}
            <Button variant="ghost" size="icon-sm" aria-label="Refresh the feed" onClick={() => void feed.refetch()}>
              <RefreshCw className={cx(feed.isFetching && 'animate-spin')} />
            </Button>
          </div>
          </div>
        </header>

        <section className="mt-5 rounded-card bg-surface shadow-card" aria-label="Phantom wallet">
          <div className="flex flex-wrap items-center justify-between gap-3 p-5 pb-4">
            <div className="min-w-0">
              <h2 className="flex items-center gap-2 text-[14px] font-semibold">
                <Wallet className="size-4 text-faint" />
                Phantom wallet
              </h2>
              <p className="mt-1 max-w-lg text-[12.5px] leading-relaxed text-muted">
                Read-only: the public address is enough to price your tokens. Ulvarin never asks for a signature, a seed phrase or a private key.
              </p>
            </div>
            {address ? (
              <Button size="sm" onClick={disconnect}>
                Disconnect
              </Button>
            ) : (
              <Button size="sm" variant="primary" loading={busy} onClick={connect}>
                Connect Phantom
              </Button>
            )}
          </div>

          {!address && (
            <form
              className="flex flex-wrap items-center gap-2 px-5 pb-5"
              onSubmit={(event) => {
                event.preventDefault()
                if (manual.trim()) setAddress(manual.trim())
              }}
            >
              <Input
                value={manual}
                onChange={(event) => setManual(event.target.value)}
                placeholder="Or paste any Solana address to watch it"
                aria-label="Solana wallet address"
                className="max-w-md flex-1"
              />
              <Button size="sm" disabled={!manual.trim()} onClick={() => setAddress(manual.trim())}>
                Track wallet
              </Button>
            </form>
          )}

          {address && (
            <div className="border-t border-line px-5 pb-5 pt-4">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <p className="font-mono text-[12px] text-faint">
                  {address.slice(0, 6)}…{address.slice(-6)}
                </p>
                <button
                  type="button"
                  onClick={() =>
                    ask(
                      `Here is my Solana wallet: ${address}. Call wallet_holdings, then tell me what this bag is actually exposed to, which positions are the same trade wearing different tickers, and which one I should cut first. Be specific about liquidity. Skip the disclaimers.`,
                    )
                  }
                  className="inline-flex h-8 items-center gap-1.5 rounded-tile px-2.5 text-[12.5px] font-medium text-muted transition-colors hover:bg-surface-2 hover:text-fg"
                >
                  <MessageSquare className="size-3.5" />
                  Read my bag
                </button>
              </div>

              {portfolio.isLoading ? (
                <div className="grid place-items-center py-8">
                  <Spinner />
                </div>
              ) : portfolio.error instanceof ApiError && portfolio.error.code === 'rpc-required' ? (
                <div className="mt-3 rounded-tile bg-surface-2 p-3.5">
                  <p className="text-[12.5px] font-medium">Wallet reads need an RPC endpoint</p>
                  <p className="mt-1 max-w-xl text-[12px] leading-relaxed text-muted">
                    Add a Solana RPC in <span className="font-medium text-fg">Settings → Data sources</span> — a free Helius or QuickNode URL takes a minute. It also
                    unlocks the holder and rug checks. The Phantom connection and the feed above already work without it.
                  </p>
                </div>
              ) : portfolio.error ? (
                <p className="mt-3 text-[12.5px] text-danger">{portfolio.error.message}</p>
              ) : data ? (
                <>
                  <dl className="mt-3 grid grid-cols-2 gap-x-6 gap-y-4 sm:grid-cols-4">
                    <Stat label="Total value" value={data.totalValue == null ? '—' : formatCompact(data.totalValue)} />
                    <Stat label="SOL" value={`${data.sol.toLocaleString('en-US', { maximumFractionDigits: 3 })}`} />
                    <Stat label="Tokens" value={tokenValue == null ? '—' : formatCompact(tokenValue)} />
                    <Stat
                      label="Positions"
                      value={`${data.holdings.length}${data.unpriced ? ` · ${data.unpriced} unpriced` : ''}`}
                    />
                  </dl>

                  {data.holdings.length === 0 ? (
                    <p className="mt-4 text-[12.5px] text-faint">No SPL tokens in this wallet right now.</p>
                  ) : (
                    <ul className="mt-3 divide-y divide-line/70">
                      {data.holdings.slice(0, 12).map((holding) => (
                        <li key={holding.mint} className="flex items-center gap-3 py-2.5">
                          <div className="min-w-0 flex-1">
                            <p className="truncate text-[13px] font-medium">{holding.symbol}</p>
                            <p className="text-[11.5px] text-faint">
                              {holding.amount.toLocaleString('en-US', { maximumFractionDigits: 2 })}
                              {holding.liquidity == null ? ' · no market' : ` · ${formatCompact(holding.liquidity)} liq`}
                            </p>
                          </div>
                          <div className="text-right">
                            <p className="text-[13px] tabular-nums">{holding.value == null ? '—' : formatCompact(holding.value)}</p>
                            <p className={cx('text-[11.5px] tabular-nums', (holding.change24h ?? 0) >= 0 ? 'text-up' : 'text-down')}>
                              {formatPct(holding.change24h)}
                            </p>
                          </div>
                          <button
                            type="button"
                            onClick={() => ask(holdingPrompt(holding, data.address))}
                            aria-label={`Forecast ${holding.symbol}`}
                            className="grid size-8 shrink-0 place-items-center rounded-tile text-faint transition-colors hover:bg-surface-2 hover:text-fg [&_svg]:size-4"
                          >
                            <MessageSquare />
                          </button>
                        </li>
                      ))}
                    </ul>
                  )}
                </>
              ) : null}
            </div>
          )}
        </section>

        <section className="mt-3 rounded-card bg-surface shadow-card" aria-label="Pump.fun leaderboard">
          <div className="flex items-center justify-between border-b border-line px-5 py-3.5">
            <h2 className="flex items-center gap-2 text-[14px] font-semibold">
              <Flame className="size-4 text-accent" />
              {sort === 'volume' ? 'Pumping now' : 'Just launched'}
            </h2>
            <span className="text-[11.5px] text-faint">{feed.data?.source ?? 'pump.fun via GeckoTerminal'}</span>
          </div>

          {feed.isLoading ? (
            <div className="grid place-items-center py-12">
              <Spinner />
            </div>
          ) : feed.error ? (
            <p className="px-5 py-6 text-[13px] text-danger">{feed.error.message}</p>
          ) : coins.length === 0 ? (
            <p className="px-5 py-6 text-[13px] text-faint">The pump.fun feed is quiet right now.</p>
          ) : (
            <ul className="divide-y divide-line/70">
              {coins.map((coin) => (
                <li key={coin.mint} className="group flex items-center gap-3 px-4 py-3">
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2">
                      <span className="text-[13.5px] font-semibold">{coin.symbol}</span>
                      <Badge tone="neutral">{coin.venue}</Badge>
                      {coin.createdAt && <span className="hidden text-[11.5px] text-faint sm:inline">{age(coin.createdAt)}</span>}
                    </div>
                    <div className="mt-1 flex flex-wrap items-center gap-x-1.5 gap-y-1 text-[11.5px] text-faint">
                      {riskBadges(coin).map((badge) => (
                        <span key={badge.label} title={badge.title}>
                          <Badge tone={badge.tone} className="h-5 px-1.5 text-[10.5px]">
                            {badge.label}
                          </Badge>
                        </span>
                      ))}
                      <span className="truncate">
                        {formatCompact(coin.volume24h)} 24h vol · {formatCompact(coin.marketCap)} cap ·{' '}
                        {coin.liquidity == null ? 'thin book' : `${formatCompact(coin.liquidity)} liq`}
                      </span>
                    </div>
                  </div>
                  <div className="w-[104px] shrink-0 text-right">
                    <p className="text-[14px] font-medium tabular-nums">${formatPrice(coin.price)}</p>
                    <p className={cx('text-[12px] tabular-nums', (coin.change24h ?? 0) >= 0 ? 'text-up' : 'text-down')}>
                      {formatPct(coin.change24h)}
                    </p>
                  </div>
                  <div className="flex shrink-0 items-center gap-0.5">
                    <button
                      type="button"
                      onClick={() => ask(coinPrompt(coin))}
                      aria-label={`Forecast ${coin.symbol}`}
                      title="Forecast with Ulvarin"
                      className="grid size-8 place-items-center rounded-tile text-faint transition-colors hover:bg-surface-2 hover:text-fg [&_svg]:size-4"
                    >
                      <MessageSquare />
                    </button>
                    <a
                      href={coin.url}
                      target="_blank"
                      rel="noreferrer"
                      aria-label={`Open ${coin.symbol} on pump.fun`}
                      title="Open on pump.fun"
                      className="grid size-8 place-items-center rounded-tile text-faint transition-colors hover:bg-surface-2 hover:text-fg [&_svg]:size-4"
                    >
                      <ExternalLink />
                    </a>
                  </div>
                </li>
              ))}
            </ul>
          )}

          <p className="border-t border-line px-5 py-3 text-[11.5px] leading-relaxed text-faint">
            Launch and pool data from GeckoTerminal indexing pump.fun and PumpSwap. Prices on brand-new tokens are indicative and move on single trades.
          </p>
        </section>
      </div>

      <AskPanel
        open={asking}
        onClose={() => setAsking(false)}
        title="Meme desk"
        context="Grounded in the live pump.fun feed and, when you connect one, your Phantom wallet."
        screen={screen}
        suggestions={[
          'Which of these should I buy next, and why?',
          'Which one actually has liquidity behind it?',
          'Is the top mover a trap?',
        ]}
        seed={seed}
      />
    </div>
  )
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <dt className="text-[11.5px] text-faint">{label}</dt>
      <dd className="mt-1 text-[16px] font-semibold tabular-nums">{value}</dd>
    </div>
  )
}
