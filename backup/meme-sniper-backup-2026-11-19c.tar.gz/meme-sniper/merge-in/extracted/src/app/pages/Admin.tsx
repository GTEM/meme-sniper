import { Ban, Check, Copy, Link2, Share2, ShieldCheck, Trash2, UserCheck, UserPlus } from 'lucide-react'
import { useState } from 'react'

import type { AccountStatus, AdminAccount, RegistrationMode, Role } from '../../shared/types'
import { Avatar, Badge, Button, ConfirmDialog, Input, Spinner, useToast } from '../components/ui'
import {
  useAdmin,
  useCreateInvite,
  useDeleteAccount,
  useRemoveInvite,
  useSetRegistration,
  useUpdateAccount,
} from '../lib/api'
import { cx } from '../lib/cx'
import { relativeTime } from '../lib/format'

const ROLE_LABEL: Record<Role, string> = { owner: 'Owner', admin: 'Admin', member: 'Member' }
const ROLE_TONE: Record<Role, 'success' | 'warning' | 'neutral'> = { owner: 'success', admin: 'warning', member: 'neutral' }
const STATUS_TONE: Record<AccountStatus, 'success' | 'warning' | 'danger'> = { active: 'success', pending: 'warning', suspended: 'danger' }

const MODES: { value: RegistrationMode; label: string; detail: string }[] = [
  { value: 'closed', label: 'Invite only', detail: 'Nobody can sign up without a code you issue.' },
  { value: 'approval', label: 'Approval', detail: 'Anyone can request an account; you admit them.' },
  { value: 'open', label: 'Open', detail: 'Anyone who signs up is active immediately.' },
]

export function Admin() {
  const admin = useAdmin()
  const update = useUpdateAccount()
  const remove = useDeleteAccount()
  const invite = useCreateInvite()
  const revoke = useRemoveInvite()
  const registration = useSetRegistration()
  const toast = useToast()

  const [inviteRole, setInviteRole] = useState<'member' | 'admin'>('member')
  const [inviteUses, setInviteUses] = useState('1')
  const [inviteDays, setInviteDays] = useState('7')
  const [copied, setCopied] = useState<string | null>(null)
  const [copiedLink, setCopiedLink] = useState<string | null>(null)
  const [deleting, setDeleting] = useState<AdminAccount | null>(null)

  const data = admin.data
  if (admin.error) {
    return (
      <div className="grid flex-1 place-items-center p-6 text-center">
        <div>
          <p className="text-[15px] font-medium">Administration is not available</p>
          <p className="mt-1 text-[13px] text-muted">{admin.error.message}</p>
          <Button className="mt-4" onClick={() => window.location.assign('/')}>
            Back to Ulvarin
          </Button>
        </div>
      </div>
    )
  }
  if (admin.isLoading || !data) {
    return (
      <div className="grid flex-1 place-items-center">
        <Spinner />
      </div>
    )
  }

  const owner = data.me.role === 'owner'
  const pending = data.accounts.filter((account) => account.status === 'pending')
  const active = data.accounts.filter((account) => account.status !== 'pending')

  const copy = async (code: string) => {
    try {
      await navigator.clipboard.writeText(code)
      setCopied(code)
      window.setTimeout(() => setCopied(null), 1500)
    } catch {
      toast('Could not copy the code', 'danger')
    }
  }

  // A code on its own is not shareable: /join?invite=CODE opens the sign-up form
  // with the code already applied, which is what a person can actually send.
  const linkFor = (code: string) => `${window.location.origin}/join?invite=${encodeURIComponent(code)}`

  const copyLink = async (code: string) => {
    try {
      await navigator.clipboard.writeText(linkFor(code))
      setCopiedLink(code)
      window.setTimeout(() => setCopiedLink(null), 1500)
    } catch {
      toast('Could not copy the link', 'danger')
    }
  }

  const shareSheet = (navigator as Navigator & { share?: (data: ShareData) => Promise<void> }).share

  const share = async (code: string) => {
    try {
      await shareSheet?.({ title: 'Ulvarin invite', text: 'This link gets you into Ulvarin:', url: linkFor(code) })
    } catch {
      /* the share sheet was dismissed: the link is still on screen and copyable */
    }
  }

  const fail = (error: unknown) => toast(error instanceof Error ? error.message : 'That did not work', 'danger')

  return (
    <div className="scrollbar-thin min-h-0 flex-1 overflow-y-auto">
      <div className="mx-auto w-full max-w-[920px] px-4 pb-16 pt-4 md:px-8 md:pt-7">
        <header>
          <p className="text-[12px] font-medium uppercase tracking-[0.1em] text-faint">{owner ? 'Owner' : 'Administrator'}</p>
          <h1 className="mt-1 text-[26px] font-semibold tracking-[-0.025em] md:text-[30px]">Administration</h1>
          <p className="mt-1 max-w-2xl text-[13.5px] leading-relaxed text-muted">
            Admission, invites and roles. Removing an account deletes everything it owns — chats, memory, watchlist and sessions.
          </p>
        </header>

        <section className="mt-6 grid grid-cols-2 gap-2.5 lg:grid-cols-4" aria-label="Instance statistics">
          <Stat label="Accounts" value={String(data.accounts.length)} />
          <Stat label="Active" value={String(data.accounts.filter((account) => account.status === 'active').length)} />
          <Stat label="Waiting" value={String(pending.length)} />
          <Stat label="Live invites" value={String(data.invites.filter((entry) => entry.uses < entry.maxUses && (!entry.expiresAt || entry.expiresAt > Date.now())).length)} />
        </section>

        <section className="mt-6" aria-label="Registration">
          <div className="flex items-end justify-between gap-3">
            <h2 className="text-[15px] font-semibold">Who can get in</h2>
            {!owner && <span className="text-[11.5px] text-faint">Only the owner can change this</span>}
          </div>
          <div className="mt-3 grid gap-2 sm:grid-cols-3">
            {MODES.map((mode) => {
              const selected = data.instance.registration === mode.value
              return (
                <button
                  key={mode.value}
                  type="button"
                  disabled={!owner || registration.isPending}
                  onClick={() => registration.mutate(mode.value, { onError: fail })}
                  className={cx(
                    'rounded-card border p-3.5 text-left transition-colors disabled:cursor-not-allowed disabled:opacity-60',
                    selected ? 'border-fg bg-surface shadow-card' : 'border-line bg-surface/60 hover:bg-surface',
                  )}
                >
                  <span className="flex items-center gap-1.5 text-[13px] font-medium">
                    {selected && <Check className="size-3.5 text-success" />}
                    {mode.label}
                  </span>
                  <span className="mt-1 block text-[11.5px] leading-relaxed text-faint">{mode.detail}</span>
                </button>
              )
            })}
          </div>
        </section>

        {pending.length > 0 && (
          <section className="mt-8" aria-label="Admission queue">
            <h2 className="text-[15px] font-semibold">
              Waiting for admission <span className="font-normal text-faint">· {pending.length}</span>
            </h2>
            <ul className="mt-3 divide-y divide-line overflow-hidden rounded-card bg-surface shadow-card">
              {pending.map((account) => (
                <li key={account.id} className="flex flex-wrap items-center gap-3 px-4 py-3">
                  <Avatar name={account.name || account.email} size={32} />
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-[13.5px] font-medium">{account.name || account.email}</p>
                    <p className="truncate text-[11.5px] text-faint">
                      {account.email} · requested {relativeTime(account.createdAt)}
                    </p>
                  </div>
                  <div className="flex gap-1.5">
                    <Button
                      size="sm"
                      variant="primary"
                      loading={update.isPending && update.variables?.id === account.id}
                      onClick={() => update.mutate({ id: account.id, patch: { status: 'active' } }, { onSuccess: () => toast(`${account.name || account.email} admitted`), onError: fail })}
                    >
                      <UserCheck />
                      Admit
                    </Button>
                    <Button size="sm" variant="ghost" onClick={() => setDeleting(account)}>
                      Reject
                    </Button>
                  </div>
                </li>
              ))}
            </ul>
          </section>
        )}

        <section className="mt-8" aria-label="Accounts">
          <h2 className="text-[15px] font-semibold">People</h2>
          <ul className="mt-3 divide-y divide-line overflow-hidden rounded-card bg-surface shadow-card">
            {active.map((account) => {
              const self = account.id === data.me.id
              const locked = account.role === 'owner' || (!owner && account.role !== 'member') || self
              return (
                <li key={account.id} className="flex flex-wrap items-center gap-3 px-4 py-3">
                  <Avatar name={account.name || account.email} size={32} />
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2">
                      <p className="truncate text-[13.5px] font-medium">{account.name || account.email}</p>
                      <Badge tone={ROLE_TONE[account.role]}>{ROLE_LABEL[account.role]}</Badge>
                      {account.status === 'suspended' && <Badge tone={STATUS_TONE.suspended}>Suspended</Badge>}
                    </div>
                    <p className="truncate text-[11.5px] text-faint">
                      {account.email} · last seen {relativeTime(account.lastLoginAt)}
                    </p>
                  </div>

                  {owner && account.role !== 'owner' && !self && (
                    <select
                      value={account.role}
                      onChange={(event) => update.mutate({ id: account.id, patch: { role: event.target.value } }, { onError: fail })}
                      aria-label={`Role for ${account.email}`}
                      className="h-8 rounded-tile border border-line-strong bg-surface px-2 text-[12.5px]"
                    >
                      <option value="member">Member</option>
                      <option value="admin">Admin</option>
                    </select>
                  )}

                  {!locked && (
                    <div className="flex gap-0.5">
                      <button
                        type="button"
                        title={account.status === 'suspended' ? 'Reinstate' : 'Suspend'}
                        aria-label={account.status === 'suspended' ? `Reinstate ${account.email}` : `Suspend ${account.email}`}
                        onClick={() =>
                          update.mutate(
                            { id: account.id, patch: { status: account.status === 'suspended' ? 'active' : 'suspended' } },
                            { onSuccess: () => toast(account.status === 'suspended' ? 'Account reinstated' : 'Account suspended'), onError: fail },
                          )
                        }
                        className="grid size-8 place-items-center rounded-tile text-faint transition-colors hover:bg-surface-2 hover:text-fg [&_svg]:size-4"
                      >
                        {account.status === 'suspended' ? <UserCheck /> : <Ban />}
                      </button>
                      <button
                        type="button"
                        title="Delete account"
                        aria-label={`Delete ${account.email}`}
                        onClick={() => setDeleting(account)}
                        className="grid size-8 place-items-center rounded-tile text-faint transition-colors hover:bg-danger-soft hover:text-danger [&_svg]:size-4"
                      >
                        <Trash2 />
                      </button>
                    </div>
                  )}
                </li>
              )
            })}
          </ul>
        </section>

        <section className="mt-8" aria-label="Invites">
          <h2 className="text-[15px] font-semibold">Invite links</h2>
          <p className="mt-1 text-[12.5px] text-muted">A link admits its holder immediately, whatever the registration mode is.</p>

          <div className="mt-3 flex flex-wrap items-end gap-2 rounded-card bg-surface p-3 shadow-card">
            <label className="block">
              <span className="mb-1 block text-[11.5px] text-faint">Role</span>
              <select
                value={inviteRole}
                onChange={(event) => setInviteRole(event.target.value as 'member' | 'admin')}
                disabled={!owner}
                className="h-9 rounded-control border border-line-strong bg-surface px-2.5 text-[13px] disabled:opacity-60"
              >
                <option value="member">Member</option>
                {owner && <option value="admin">Admin</option>}
              </select>
            </label>
            <label className="block w-[92px]">
              <span className="mb-1 block text-[11.5px] text-faint">Uses</span>
              <Input value={inviteUses} onChange={(event) => setInviteUses(event.target.value)} inputMode="numeric" className="h-9" />
            </label>
            <label className="block w-[110px]">
              <span className="mb-1 block text-[11.5px] text-faint">Expires (days)</span>
              <Input value={inviteDays} onChange={(event) => setInviteDays(event.target.value)} inputMode="numeric" className="h-9" />
            </label>
            <Button
              variant="primary"
              loading={invite.isPending}
              onClick={() =>
                invite.mutate(
                  { role: inviteRole, maxUses: Number(inviteUses), expiresInDays: Number(inviteDays) },
                  { onSuccess: (next) => toast(`Invite created: ${next.invites[0]?.code ?? 'ready'}`), onError: fail },
                )
              }
            >
              <UserPlus />
              Create invite
            </Button>
          </div>

          {data.invites.length === 0 ? (
            <p className="mt-3 rounded-card border border-dashed border-line-strong px-4 py-6 text-center text-[13px] text-faint">
              No invites yet. Create one and send the link to whoever should get in.
            </p>
          ) : (
            <ul className="mt-3 divide-y divide-line overflow-hidden rounded-card bg-surface shadow-card">
              {data.invites.map((entry) => {
                const spent = entry.uses >= entry.maxUses
                const expired = Boolean(entry.expiresAt && entry.expiresAt < Date.now())
                return (
                  <li key={entry.code} className="px-4 py-3">
                    <div className="flex flex-wrap items-center gap-3">
                      <span className="inline-flex items-center gap-1.5 font-mono text-[13px] font-semibold tracking-wide">
                        {entry.code}
                        <button
                          type="button"
                          onClick={() => copy(entry.code)}
                          aria-label="Copy invite code"
                          className="grid size-7 place-items-center rounded-[8px] text-faint transition-colors hover:bg-surface-2 hover:text-fg [&_svg]:size-3.5"
                        >
                          {copied === entry.code ? <Check /> : <Copy />}
                        </button>
                      </span>
                      <Badge tone={ROLE_TONE[entry.role]}>{ROLE_LABEL[entry.role]}</Badge>
                      <span className="text-[11.5px] text-faint">
                        {entry.uses}/{entry.maxUses} used · {expired ? 'expired' : entry.expiresAt ? `expires ${new Date(entry.expiresAt).toLocaleDateString()}` : 'no expiry'}
                        {spent ? ' · used up' : ''}
                      </span>
                      <div className="ml-auto flex items-center gap-1">
                        <button
                          type="button"
                          onClick={() => copyLink(entry.code)}
                          aria-label={`Copy invite link for ${entry.code}`}
                          className="inline-flex h-8 items-center gap-1.5 rounded-tile px-2 text-[12px] text-faint transition-colors hover:bg-surface-2 hover:text-fg [&_svg]:size-3.5"
                        >
                          {copiedLink === entry.code ? <Check /> : <Link2 />}
                          <span>{copiedLink === entry.code ? 'Copied' : 'Copy link'}</span>
                        </button>
                        {typeof shareSheet === 'function' && (
                          <button
                            type="button"
                            onClick={() => share(entry.code)}
                            aria-label={`Share invite link for ${entry.code}`}
                            className="inline-flex h-8 items-center gap-1.5 rounded-tile px-2 text-[12px] text-faint transition-colors hover:bg-surface-2 hover:text-fg [&_svg]:size-3.5"
                          >
                            <Share2 />
                            <span>Share</span>
                          </button>
                        )}
                        <button
                          type="button"
                          onClick={() => revoke.mutate(entry.code, { onError: fail })}
                          aria-label={`Revoke ${entry.code}`}
                          className="grid size-8 place-items-center rounded-tile text-faint transition-colors hover:bg-danger-soft hover:text-danger [&_svg]:size-4"
                        >
                          <Trash2 />
                        </button>
                      </div>
                    </div>
                    <a
                      href={linkFor(entry.code)}
                      target="_blank"
                      rel="noreferrer"
                      className="mt-1.5 block truncate font-mono text-[11.5px] text-faint underline-offset-2 hover:text-fg hover:underline"
                    >
                      {linkFor(entry.code)}
                    </a>
                  </li>
                )
              })}
            </ul>
          )}
        </section>

        <p className="mt-8 flex items-center gap-1.5 text-[11.5px] text-faint">
          <ShieldCheck className="size-3.5" />
          Owner accounts cannot be deleted, suspended or demoted from the interface.
        </p>
      </div>

      <ConfirmDialog
        open={Boolean(deleting)}
        onClose={() => setDeleting(null)}
        title={deleting?.status === 'pending' ? 'Reject this request?' : 'Delete this account?'}
        description={
          deleting?.status === 'pending'
            ? `${deleting?.email} will not be admitted. Their request is removed.`
            : `${deleting?.email} and everything they own — chats, memory, watchlist, sessions — are removed for good.`
        }
        confirmLabel={deleting?.status === 'pending' ? 'Reject' : 'Delete account'}
        loading={remove.isPending}
        onConfirm={() => {
          if (!deleting) return
          remove.mutate(deleting.id, {
            onSuccess: () => {
              toast('Account removed')
              setDeleting(null)
            },
            onError: fail,
          })
        }}
      />
    </div>
  )
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-card bg-surface px-4 py-3 shadow-card">
      <p className="text-[11.5px] text-faint">{label}</p>
      <p className="mt-1 text-[19px] font-semibold tabular-nums">{value}</p>
    </div>
  )
}
