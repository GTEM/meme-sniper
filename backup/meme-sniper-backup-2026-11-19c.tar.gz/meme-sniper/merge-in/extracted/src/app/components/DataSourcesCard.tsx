// Optional data sources, entered in the app. Both are server credentials: the
// browser gets a hint and a host, never the value.

import { Globe, Radio } from 'lucide-react'
import { useState } from 'react'

import { useClearSource, useSaveSources, useSources } from '../lib/api'
import { Button, useToast } from './ui'

export function DataSourcesCard() {
  const { data, isLoading } = useSources()
  const save = useSaveSources()
  const clear = useClearSource()
  const toast = useToast()
  const [rpc, setRpc] = useState('')
  const [relay, setRelay] = useState('')
  const [replacingRpc, setReplacingRpc] = useState(false)

  if (isLoading || !data) return null

  const saved = (label: string) => toast(`${label} saved`)

  const saveRpc = () => {
    const value = rpc.trim()
    if (!value) return
    save.mutate(
      { solanaRpcUrl: value },
      {
        onSuccess: () => {
          setRpc('')
          setReplacingRpc(false)
          saved('Solana RPC')
        },
        onError: (error) => toast(error instanceof Error ? error.message : 'That RPC did not answer', 'danger'),
      },
    )
  }

  const saveRelay = () => {
    const value = relay.trim()
    if (!value) return
    save.mutate(
      { relayUrl: value },
      {
        onSuccess: () => {
          setRelay('')
          saved('Binance relay')
        },
        onError: (error) => toast(error instanceof Error ? error.message : 'That relay did not answer correctly', 'danger'),
      },
    )
  }

  return (
    <div className="divide-y divide-line rounded-card bg-surface shadow-card">
      <div className="p-4">
        <div className="flex items-start gap-3">
          <span className="grid size-8 shrink-0 place-items-center rounded-tile bg-surface-2 text-muted">
            <Radio className="size-4" />
          </span>
          <div className="min-w-0 flex-1">
            <p className="text-[13.5px] font-medium">Solana RPC</p>
            <p className="mt-0.5 text-[12px] leading-snug text-faint">
              Unlocks holder concentration, mint and freeze authority, and wallet reads. Checked with <code className="font-mono text-[11.5px]">getHealth</code> before it is
              saved. A free Helius or QuickNode URL works.
            </p>
            {data.solanaRpc.configured && !replacingRpc ? (
              <div className="mt-2 flex flex-wrap items-center gap-3">
                <span className="text-[12px] text-muted">
                  Connected {data.solanaRpc.hint} · {data.solanaRpc.host ?? 'saved endpoint'}
                  {data.solanaRpc.source === 'environment' ? ' · from the server environment' : ''}
                </span>
                <Button size="sm" onClick={() => setReplacingRpc(true)}>
                  Replace
                </Button>
                <Button size="sm" loading={clear.isPending} onClick={() => clear.mutate('solana', { onSuccess: () => toast('Solana RPC removed') })}>
                  Remove
                </Button>
              </div>
            ) : (
              <div className="mt-2 flex flex-wrap gap-2">
                <input
                  type="url"
                  value={rpc}
                  onChange={(event) => setRpc(event.target.value)}
                  placeholder="https://mainnet.helius-rpc.com/?api-key=…"
                  aria-label="Solana RPC URL"
                  autoComplete="off"
                  spellCheck={false}
                  className="h-10 min-w-0 flex-1 rounded-control border border-line-strong bg-surface px-3 font-mono text-[12.5px] focus:border-fg/40 focus:outline-none"
                />
                <Button variant="primary" loading={save.isPending} disabled={!rpc.trim()} onClick={saveRpc}>
                  {replacingRpc ? 'Replace' : 'Save'}
                </Button>
                {replacingRpc ? (
                  <Button size="sm" onClick={() => setReplacingRpc(false)}>
                    Cancel
                  </Button>
                ) : null}
              </div>
            )}
          </div>
        </div>
      </div>

      <div className="p-4">
        <div className="flex items-start gap-3">
          <span className="grid size-8 shrink-0 place-items-center rounded-tile bg-surface-2 text-muted">
            <Globe className="size-4" />
          </span>
          <div className="min-w-0 flex-1">
            <p className="text-[13.5px] font-medium">Binance relay</p>
            <p className="mt-0.5 text-[12px] leading-snug text-faint">
              Binance answers 451 to this server&apos;s region. A VPN cannot fix that — the Worker has no proxy support — but a tiny HTTP relay in an allowed region can.
              Point this at one (<code className="font-mono text-[11.5px]">deploy/relay</code> in the repo) and Binance quotes come through it. Checked with a live BTC quote
              before saving.
            </p>
            {data.relay.configured ? (
              <div className="mt-2 flex flex-wrap items-center gap-3">
                <span className="text-[12px] text-muted">
                  Connected · {data.relay.host ?? 'saved relay'}
                  {data.relay.source === 'environment' ? ' · from the server environment' : ''}
                </span>
                <Button size="sm" loading={clear.isPending} onClick={() => clear.mutate('relay', { onSuccess: () => toast('Relay removed') })}>
                  Remove
                </Button>
              </div>
            ) : (
              <div className="mt-2 flex flex-wrap gap-2">
                <input
                  type="url"
                  value={relay}
                  onChange={(event) => setRelay(event.target.value)}
                  placeholder="https://ulvarin-relay.fly.dev"
                  aria-label="Binance relay URL"
                  autoComplete="off"
                  spellCheck={false}
                  className="h-10 min-w-0 flex-1 rounded-control border border-line-strong bg-surface px-3 font-mono text-[12.5px] focus:border-fg/40 focus:outline-none"
                />
                <Button variant="primary" loading={save.isPending} disabled={!relay.trim()} onClick={saveRelay}>
                  Save
                </Button>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
