import { cx } from '../lib/cx'

/** A quiet recent-price line for a watchlist row. No chart library. */
export function Sparkline({
  data,
  up,
  width = 96,
  height = 30,
  className,
}: {
  data: number[]
  up: boolean
  width?: number
  height?: number
  className?: string
}) {
  if (data.length < 2) {
    return <div className={cx('h-[30px] w-[96px] rounded-[6px] bg-surface-2/70', className)} aria-hidden />
  }
  const min = Math.min(...data)
  const max = Math.max(...data)
  const span = max - min || 1
  const points = data.map((value, index) => {
    const x = (index / (data.length - 1)) * (width - 2) + 1
    const y = height - 2 - ((value - min) / span) * (height - 4)
    return [x, y] as const
  })
  const line = points.map(([x, y], index) => `${index ? 'L' : 'M'}${x.toFixed(1)} ${y.toFixed(1)}`).join(' ')
  const area = `${line} L${width - 1} ${height} L1 ${height} Z`
  const color = up ? 'var(--color-up)' : 'var(--color-down)'
  return (
    <svg width={width} height={height} viewBox={`0 0 ${width} ${height}`} className={className} aria-hidden>
      <path d={area} fill={color} opacity={0.1} />
      <path d={line} fill="none" stroke={color} strokeWidth={1.5} strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  )
}
