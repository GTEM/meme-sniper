import { QueryClient, QueryClientProvider } from '@tanstack/react-query'
import { BrowserRouter, Navigate, Route, Routes } from 'react-router'

import { Shell } from './components/Shell'
import { Spinner, ToastProvider } from './components/ui'
import { ApiError, useMe } from './lib/api'
import { LOAD_ATTEMPTS, backoffDelay, shouldRetry } from './lib/retry'
import { Admin } from './pages/Admin'
import { Chat } from './pages/Chat'
import { Markets } from './pages/Markets'
import { Meme } from './pages/Meme'
import { Memory } from './pages/Memory'
import { Settings } from './pages/Settings'
import { Studio } from './pages/Studio'
import { Pending, SetupNeeded, SignIn, Suspended } from './pages/SignIn'

const client = new QueryClient({
  defaultOptions: {
    queries: {
      retry: shouldRetry,
      retryDelay: backoffDelay,
      refetchOnWindowFocus: false,
      staleTime: 15_000,
    },
  },
})

function Gate() {
  const me = useMe()
  if (me.isLoading) {
    return (
      <div className="grid min-h-dvh place-items-center gap-3 text-center">
        <Spinner />
        {me.failureCount > 0 ? (
          <p className="text-[12.5px] text-faint">
            Reconnecting — attempt {Math.min(me.failureCount + 1, LOAD_ATTEMPTS)} of {LOAD_ATTEMPTS}
          </p>
        ) : null}
      </div>
    )
  }
  if (me.error instanceof ApiError && me.error.status === 401) return <SignIn />
  if (me.error instanceof ApiError && me.error.code === 'pending') return <Pending />
  if (me.error instanceof ApiError && me.error.code === 'suspended') return <Suspended />
  if (me.error) return <SetupNeeded message={me.error.message} code={me.error instanceof ApiError ? me.error.code : undefined} />
  return (
    <Routes>
      <Route element={<Shell />}>
        <Route index element={<Chat />} />
        <Route path="c/:id" element={<Chat />} />
        <Route path="markets" element={<Markets />} />
        <Route path="meme" element={<Meme />} />
        <Route path="memory" element={<Memory />} />
        <Route path="studio" element={<Studio />} />
        <Route path="admin" element={<Admin />} />
        <Route path="settings" element={<Settings />} />
      </Route>
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  )
}

export function App() {
  return (
    <QueryClientProvider client={client}>
      <ToastProvider>
        <BrowserRouter>
          <Gate />
        </BrowserRouter>
      </ToastProvider>
    </QueryClientProvider>
  )
}
