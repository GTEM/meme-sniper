export function initials(name: string): string {
  return name
    .split(/\s+/)
    .filter(Boolean)
    .slice(0, 2)
    .map((p) => p[0]?.toUpperCase() ?? '')
    .join('')
}

export function timeOfDay(ts: number): string {
  return new Date(ts).toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' })
}

/** Which sidebar group a conversation belongs to, by its last activity. */
export function dayGroup(ts: number, now = Date.now()): 'Today' | 'Yesterday' | 'Previous 7 days' | 'Older' {
  const start = new Date(now)
  start.setHours(0, 0, 0, 0)
  const today = start.getTime()
  if (ts >= today) return 'Today'
  if (ts >= today - 86_400_000) return 'Yesterday'
  if (ts >= today - 7 * 86_400_000) return 'Previous 7 days'
  return 'Older'
}

export const DAY_GROUPS = ['Today', 'Yesterday', 'Previous 7 days', 'Older'] as const

/** "in 3h" / "in 25m": when the daily limit resets. */
export function untilLabel(ts: number, now = Date.now()): string {
  const minutes = Math.max(1, Math.round((ts - now) / 60_000))
  if (minutes < 60) return `in ${minutes}m`
  const hours = Math.round(minutes / 60)
  return `in ${hours}h`
}

/* ---------------------------------------------------------------- numbers -- */

export function formatPrice(value: number | null): string {
  if (value == null || !Number.isFinite(value)) return '—'
  const abs = Math.abs(value)
  if (abs >= 1000) return value.toLocaleString('en-US', { maximumFractionDigits: 2 })
  if (abs >= 1) return value.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })
  if (abs >= 0.01) return value.toFixed(4)
  return value.toPrecision(4)
}

export function formatPct(value: number | null): string {
  if (value == null || !Number.isFinite(value)) return '—'
  return `${value >= 0 ? '+' : ''}${value.toFixed(2)}%`
}

export function formatCompact(value: number | null): string {
  if (value == null || !Number.isFinite(value)) return '—'
  const units: [number, string][] = [
    [1e12, 'T'],
    [1e9, 'B'],
    [1e6, 'M'],
    [1e3, 'K'],
  ]
  for (const [size, suffix] of units) if (Math.abs(value) >= size) return `$${(value / size).toFixed(2)}${suffix}`
  return `$${value.toFixed(2)}`
}

export function relativeTime(ts: number | null, now = Date.now()): string {
  if (!ts) return 'never'
  const seconds = Math.round((now - ts) / 1000)
  if (seconds < 45) return 'just now'
  if (seconds < 3_600) return `${Math.round(seconds / 60)}m ago`
  if (seconds < 86_400) return `${Math.round(seconds / 3_600)}h ago`
  return `${Math.round(seconds / 86_400)}d ago`
}
