import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'

import type {
  AdminOverview,
  AuthStatus,
  Conversation,
  MarketHit,
  MarketOverview,
  Me,
  MemeFeed,
  Memory,
  MemoryPage,
  Message,
  ModelInfo,
  Quote,
  RegistrationMode,
  Settings,
  WalletPortfolio,
  WatchItem,
} from '../../shared/types'

export class ApiError extends Error {
  constructor(
    public status: number,
    message: string,
    public code?: string,
    public resetsAt?: number,
  ) {
    super(message)
  }
}

export async function readError(response: Response): Promise<ApiError> {
  let message = response.statusText || 'Request failed.'
  let code: string | undefined
  let resetsAt: number | undefined
  try {
    const body = (await response.json()) as { error?: string; message?: string; resetsAt?: number }
    message = body.message ?? body.error ?? message
    code = body.error
    resetsAt = body.resetsAt
  } catch {
    /* no body */
  }
  return new ApiError(response.status, message, code, resetsAt)
}

export async function api<T>(path: string, init?: RequestInit & { json?: unknown }): Promise<T> {
  const { json, ...rest } = init ?? {}
  const response = await fetch(`/api${path}`, {
    credentials: 'same-origin',
    ...rest,
    headers: { accept: 'application/json', ...(json !== undefined ? { 'content-type': 'application/json' } : {}), ...(rest.headers ?? {}) },
    body: json !== undefined ? JSON.stringify(json) : rest.body,
  })
  if (!response.ok) throw await readError(response)
  return (await response.json()) as T
}

export type ConversationPage = { conversation: Conversation; messages: Message[] }

export const useMe = () =>
  useQuery({
    queryKey: ['me'],
    queryFn: () => api<Me>('/me'),
    retry: false,
    staleTime: 30_000,
    refetchOnWindowFocus: true,
    // Until an API key is configured, keep checking so the app unlocks on its
    // own once the owner adds one.
    refetchInterval: (query) => (query.state.data && !query.state.data.capabilities.ai ? 4_000 : false),
  })
export const useModels = () => useQuery({ queryKey: ['models'], queryFn: () => api<{ items: ModelInfo[] }>('/models'), staleTime: 60_000 })

/** The pump.fun leaderboard, refreshed while the page is open. */
export const useMemeFeed = (sort: 'volume' | 'new') =>
  useQuery({
    queryKey: ['meme', sort],
    queryFn: () => api<MemeFeed>(`/meme/feed?sort=${sort}`),
    staleTime: 30_000,
    refetchInterval: 60_000,
    // The server already retries a throttled feed three times in about two
    // seconds. Retrying the whole request four more times only spends more of the
    // same per-address allowance, so one extra attempt is the ceiling here.
    retry: 1,
  })

/* ----------------------------------------------------------------- studio -- */

export type StudioEngineState = {
  configured: boolean
  kind: 'a1111' | 'openai' | 'free'
  host: string | null
  gemini: boolean
  cloudflare: boolean
  pollinations: boolean
}

export type StudioKeysState = { cloudflare: boolean; pollinations: boolean; horde: boolean }

export const useStudioKeys = () => useQuery({ queryKey: ['studio-keys'], queryFn: () => api<StudioKeysState>('/studio/keys'), staleTime: 60_000 })

export type EngineModel = { title: string; name: string; file: string }

export const useEngineModels = (enabled = false) =>
  useQuery({
    queryKey: ['engine-models'],
    queryFn: () => api<{ models: EngineModel[] }>('/studio/engine/models'),
    enabled,
    staleTime: 0,
    retry: false,
  })

export const useSetEngineModel = () => {
  const client = useQueryClient()
  return useMutation<{ title: string }, Error, string>({
    mutationFn: (title) => api<{ title: string }>('/studio/engine/model', { method: 'PUT', json: { title } }),
    onSuccess: () => {
      void client.invalidateQueries({ queryKey: ['studio-engine'] })
    },
  })
}

export const useSaveStudioKeys = () => {
  const client = useQueryClient()
  return useMutation<StudioKeysState, Error, { account?: string; token?: string; pollinations?: string; horde?: string }>({
    mutationFn: (input) => api<StudioKeysState>('/studio/keys', { method: 'PUT', json: input }),
    onSuccess: (data) => {
      client.setQueryData(['studio-keys'], data)
      void client.invalidateQueries({ queryKey: ['studio-engine'] })
    },
  })
}

/** Where Studio renders: the free host, or the owner's own endpoint. */
export const useStudioEngine = () =>
  useQuery({ queryKey: ['studio-engine'], queryFn: () => api<StudioEngineState>('/studio/engine'), staleTime: 60_000 })

export const useSaveStudioEngine = () => {
  const client = useQueryClient()
  return useMutation<StudioEngineState, Error, { url: string; apiKey?: string }>({
    mutationFn: (input) => api<StudioEngineState>('/studio/engine', { method: 'PUT', json: input }),
    onSuccess: (data) => client.setQueryData(['studio-engine'], data),
  })
}

/** A public Solana wallet, priced. Disabled until an address exists. */
export const useWallet = (address: string) =>
  useQuery({
    queryKey: ['wallet', address],
    queryFn: () => api<WalletPortfolio>(`/wallet/${address}`),
    enabled: address.length > 0,
    retry: false,
    staleTime: 30_000,
  })

/** Whether a model key exists, where it came from, and its last four digits. */
export type AiCredential = {
  configured: boolean
  source: 'settings' | 'environment' | 'none'
  hint: string | null
  baseUrl: string
  /** Which provider answers, e.g. "Groq". */
  provider: string
  /** Where rate-limited turns retry, or null when there is no fallback. */
  fallback: string | null
  /** The primary provider's id, e.g. "groq". */
  providerId: string
  /** Secondary paid-free providers, each with its own quota pool. */
  extras: { provider: string; label: string; configured: boolean; source: 'settings' | 'environment' | 'none'; hint: string | null }[]
}

export type SourcesState = {
  solanaRpc: { configured: boolean; source: 'settings' | 'environment' | 'none'; hint: string | null; host: string | null }
  relay: { configured: boolean; source: 'settings' | 'environment' | 'none'; host: string | null }
}

export const useSources = (enabled = true) =>
  useQuery({ queryKey: ['sources'], queryFn: () => api<SourcesState>('/sources'), enabled, retry: false, staleTime: 15_000 })

export const useSaveSources = () => {
  const client = useQueryClient()
  return useMutation({
    mutationFn: (input: { solanaRpcUrl?: string; relayUrl?: string }) => api<SourcesState>('/sources', { method: 'PUT', json: input }),
    onSuccess: () => {
      void client.invalidateQueries({ queryKey: ['sources'] })
      void client.invalidateQueries({ queryKey: ['wallet'] })
    },
  })
}

export const useClearSource = () => {
  const client = useQueryClient()
  return useMutation({
    mutationFn: (kind: 'solana' | 'x' | 'relay') => api<SourcesState>(`/sources/${kind}`, { method: 'DELETE' }),
    onSuccess: () => {
      void client.invalidateQueries({ queryKey: ['sources'] })
    },
  })
}

export const useAiCredential = (enabled = true) =>
  useQuery({ queryKey: ['ai-credential'], queryFn: () => api<AiCredential>('/ai'), enabled, retry: false, staleTime: 15_000 })

export const useSetAiKey = () => {
  const client = useQueryClient()
  return useMutation({
    mutationFn: (input: { key: string; provider?: string }) => api<AiCredential>('/ai', { method: 'PUT', json: input }),
    onSuccess: () => {
      void client.invalidateQueries({ queryKey: ['ai-credential'] })
      void client.invalidateQueries({ queryKey: ['me'] })
      void client.invalidateQueries({ queryKey: ['models'] })
    },
  })
}

export const useRemoveAiKey = () => {
  const client = useQueryClient()
  return useMutation({
    mutationFn: (provider?: string) => api<AiCredential>(provider ? `/ai/${provider}` : '/ai', { method: 'DELETE' }),
    onSuccess: () => {
      void client.invalidateQueries({ queryKey: ['ai-credential'] })
      void client.invalidateQueries({ queryKey: ['me'] })
    },
  })
}
export const useConversations = () => useQuery({ queryKey: ['conversations'], queryFn: () => api<{ items: Conversation[] }>('/conversations') })
export const useConversation = (id: string | undefined) =>
  useQuery({
    queryKey: ['conversation', id],
    queryFn: () => api<ConversationPage>(`/conversations/${id}`),
    enabled: Boolean(id),
    staleTime: 60_000,
    // A missing chat is an answer, not a hiccup.
    retry: (count, error) => count < 1 && !(error instanceof ApiError && error.status < 500),
  })

export function useRenameConversation() {
  const client = useQueryClient()
  return useMutation({
    mutationFn: ({ id, title }: { id: string; title: string }) => api<{ conversation: Conversation }>(`/conversations/${id}`, { method: 'PATCH', json: { title } }),
    onSuccess: ({ conversation }) => {
      client.setQueryData<{ items: Conversation[] }>(['conversations'], (old) => old && { items: old.items.map((c) => (c.id === conversation.id ? conversation : c)) })
      client.setQueryData<ConversationPage>(['conversation', conversation.id], (old) => old && { ...old, conversation })
    },
  })
}

export function useSetConversationModel() {
  const client = useQueryClient()
  return useMutation({
    mutationFn: ({ id, model }: { id: string; model: string }) => api<{ conversation: Conversation }>(`/conversations/${id}`, { method: 'PATCH', json: { model } }),
    onMutate: ({ id, model }) => {
      client.setQueryData<ConversationPage>(['conversation', id], (old) => old && { ...old, conversation: { ...old.conversation, model } })
    },
  })
}

export function useDeleteConversation() {
  const client = useQueryClient()
  return useMutation({
    mutationFn: (id: string) => api(`/conversations/${id}`, { method: 'DELETE' }),
    onSuccess: (_, id) => {
      client.setQueryData<{ items: Conversation[] }>(['conversations'], (old) => old && { items: old.items.filter((c) => c.id !== id) })
      client.removeQueries({ queryKey: ['conversation', id] })
    },
  })
}

export function useDeleteAllConversations() {
  const client = useQueryClient()
  return useMutation({
    mutationFn: () => api('/account/conversations', { method: 'DELETE' }),
    onSuccess: () => {
      client.setQueryData(['conversations'], { items: [] })
      client.removeQueries({ queryKey: ['conversation'] })
    },
  })
}

/* ------------------------------------------------------------------ memory */

export const useMemory = () => useQuery({ queryKey: ['memory'], queryFn: () => api<MemoryPage>('/memory'), staleTime: 20_000 })

export function useAddMemory() {
  const client = useQueryClient()
  return useMutation({
    mutationFn: (input: { content: string; kind?: string }) => api<MemoryPage & { memory: Memory }>('/memory', { method: 'POST', json: input }),
    onSuccess: (data) => client.setQueryData(['memory'], { items: data.items, stats: data.stats }),
  })
}

export function useUpdateMemory() {
  const client = useQueryClient()
  return useMutation({
    mutationFn: ({ id, content, kind }: { id: string; content: string; kind: string }) =>
      api<MemoryPage>(`/memory/${id}`, { method: 'PATCH', json: { content, kind } }),
    onSuccess: (data) => client.setQueryData(['memory'], data),
  })
}

export function useDeleteMemory() {
  const client = useQueryClient()
  return useMutation({
    mutationFn: (id: string) => api<MemoryPage>(`/memory/${id}`, { method: 'DELETE' }),
    onSuccess: (data) => client.setQueryData(['memory'], data),
  })
}

export function useClearMemory() {
  const client = useQueryClient()
  return useMutation({
    mutationFn: () => api<MemoryPage>('/memory', { method: 'DELETE' }),
    onSuccess: (data) => client.setQueryData(['memory'], data),
  })
}

export function useReflect() {
  const client = useQueryClient()
  return useMutation({
    mutationFn: () => api<MemoryPage & { learned: Memory[]; scanned: number }>('/memory/reflect', { method: 'POST' }),
    onSuccess: (data) => client.setQueryData(['memory'], { items: data.items, stats: data.stats }),
  })
}

/* ---------------------------------------------------------------- settings */

export type SettingsResponse = Settings & { search: 'tavily' | 'brave' | 'keyless'; ai: boolean }

export const useSettings = () => useQuery({ queryKey: ['settings'], queryFn: () => api<SettingsResponse>('/settings'), staleTime: 30_000 })

export function useSaveSettings() {
  const client = useQueryClient()
  return useMutation({
    mutationFn: (input: Partial<Settings>) => api<SettingsResponse>('/settings', { method: 'PUT', json: input }),
    onSuccess: (data) => client.setQueryData(['settings'], data),
  })
}

/* ----------------------------------------------------------------- markets */

export type WatchPage = { items: WatchItem[]; quotes: Quote[] }

export const useMarketOverview = () =>
  useQuery({ queryKey: ['market-overview'], queryFn: () => api<MarketOverview>('/markets/overview'), refetchInterval: 60_000, staleTime: 30_000 })

export const useWatchlist = () =>
  useQuery({ queryKey: ['watchlist'], queryFn: () => api<WatchPage>('/markets/watchlist'), refetchInterval: 60_000, staleTime: 30_000 })

export const useMarketSearch = (query: string) =>
  useQuery({
    queryKey: ['market-search', query],
    queryFn: () => api<{ items: MarketHit[] }>(`/markets/search?q=${encodeURIComponent(query)}`),
    enabled: query.trim().length >= 2,
    staleTime: 30_000,
  })

export function useAddWatch() {
  const client = useQueryClient()
  return useMutation({
    mutationFn: (input: { ref: string; kind: string; name: string }) => api<WatchPage>('/markets/watchlist', { method: 'POST', json: input }),
    onSuccess: (data) => client.setQueryData(['watchlist'], data),
  })
}

export function useRemoveWatch() {
  const client = useQueryClient()
  return useMutation({
    mutationFn: (id: string) => api<WatchPage>(`/markets/watchlist/${id}`, { method: 'DELETE' }),
    onSuccess: (data) => client.setQueryData(['watchlist'], data),
  })
}

/* ------------------------------------------------------------------- auth -- */

export const useAuthStatus = () =>
  useQuery({ queryKey: ['auth-status'], queryFn: () => api<AuthStatus>('/auth/status'), retry: false, staleTime: 0 })

/**
 * Signing in, signing up or claiming the instance all end the same way: a
 * full reload, so no stale query from the previous identity survives.
 */
function useSessionMutation<T>(path: string) {
  return useMutation<unknown, Error, T>({
    mutationFn: (input: T) => api(path, { method: 'POST', json: input }),
    onSuccess: () => window.location.assign('/'),
  })
}

export const useSetup = () => useSessionMutation<{ name: string; email: string; password: string }>('/auth/setup')
export const useLogin = () => useSessionMutation<{ email: string; password: string }>('/auth/login')
export const useSignup = () => useSessionMutation<{ name: string; email: string; password: string; invite?: string }>('/auth/signup')

export function useLogout() {
  const client = useQueryClient()
  return useMutation({
    mutationFn: () => api('/auth/logout', { method: 'POST' }),
    onSuccess: () => {
      client.clear()
      window.location.assign('/')
    },
  })
}

/* ------------------------------------------------------------------ admin -- */

export const useAdmin = () => useQuery({ queryKey: ['admin'], queryFn: () => api<AdminOverview>('/admin/overview'), staleTime: 10_000 })

function useAdminAction<T>(action: (input: T) => Promise<AdminOverview>) {
  const client = useQueryClient()
  return useMutation<AdminOverview, Error, T>({
    mutationFn: action,
    onSuccess: (data) => client.setQueryData(['admin'], data),
  })
}

export const useUpdateAccount = () =>
  useAdminAction<{ id: string; patch: { role?: string; status?: string } }>((input) =>
    api<AdminOverview>(`/admin/accounts/${input.id}`, { method: 'PATCH', json: input.patch }),
  )

export const useDeleteAccount = () =>
  useAdminAction<string>((id) => api<AdminOverview>(`/admin/accounts/${id}`, { method: 'DELETE' }))

export const useCreateInvite = () =>
  useAdminAction<{ role: string; maxUses: number; expiresInDays: number }>((input) =>
    api<AdminOverview>('/admin/invites', { method: 'POST', json: input }),
  )

export const useRemoveInvite = () =>
  useAdminAction<string>((code) => api<AdminOverview>(`/admin/invites/${code}`, { method: 'DELETE' }))

export const useSetRegistration = () =>
  useAdminAction<RegistrationMode>((mode) => api<AdminOverview>('/admin/instance', { method: 'PUT', json: { registration: mode } }))
