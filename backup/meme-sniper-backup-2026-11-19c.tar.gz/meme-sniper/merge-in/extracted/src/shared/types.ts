// Types shared by the Worker (src/worker) and the app (src/app).

export type MessageRole = 'user' | 'assistant'

export interface Conversation {
  id: string
  title: string
  model: string
  createdAt: number
  updatedAt: number
}

export interface Message {
  id: string
  conversationId: string
  role: MessageRole
  content: string
  model: string | null
  /** True when generation stopped before the model finished. */
  interrupted: boolean
  createdAt: number
}

export interface ModelInfo {
  id: string
  name: string
  description: string
  /** Whether the configured API currently offers this model. */
  available: boolean
}

export type Role = 'owner' | 'admin' | 'member'
export type AccountStatus = 'pending' | 'active' | 'suspended'
export type RegistrationMode = 'closed' | 'approval' | 'open'

/** The signed-in identity attached to a request. Ids are `accounts.id`. */
export interface SessionUser {
  sub: string
  email: string
  name: string
  role: Role
  status: AccountStatus
}

export interface Me {
  user: { sub: string; name?: string; email?: string; picture?: string; role: Role }
  capabilities: {
    /** An API key is configured on the server. Never the key itself. */
    ai: boolean
    database: boolean
    auth: 'local'
    /** Which web search backend is active. */
    search: 'tavily' | 'brave' | 'keyless'
  }
  /** `limit` is null when the account is not capped: the owner and admins. */
  usage: { used: number; limit: number | null; resetsAt: number }
}

/* ------------------------------------------------------------------- auth -- */

export interface AuthStatus {
  /** True until the first account claims the instance. */
  setup: boolean
  registration: RegistrationMode
}

export interface AdminAccount {
  id: string
  name: string
  email: string
  role: Role
  status: AccountStatus
  createdAt: number
  lastLoginAt: number | null
}

export interface Invite {
  code: string
  role: Role
  maxUses: number
  uses: number
  expiresAt: number | null
  createdAt: number
}

export interface AdminOverview {
  instance: { registration: RegistrationMode }
  accounts: AdminAccount[]
  invites: Invite[]
  me: { role: Role; id: string }
}

/* ---------------------------------------------------------------- memory -- */

export const MEMORY_KINDS = ['fact', 'preference', 'insight', 'entity'] as const

export type MemoryKind = (typeof MEMORY_KINDS)[number]

export interface Memory {
  id: string
  kind: MemoryKind
  content: string
  tags: string[]
  source: string
  confidence: number
  uses: number
  createdAt: number
  updatedAt: number
  lastUsedAt: number | null
}

export interface MemoryStats {
  total: number
  learned7d: number
  lastRunAt: number | null
  runs: number
  byKind: Record<MemoryKind, number>
  activity: { day: string; count: number }[]
}

export interface MemoryPage {
  items: Memory[]
  stats: MemoryStats
}

export interface Settings {
  /** Free-form standing instructions from the user, appended to the prompt. */
  persona: string
  /** Consolidate conversations into memories automatically. */
  autoLearn: boolean
  /** Allow the web_search and fetch_url tools. */
  webAccess: boolean
  /** Allow the market tools. */
  marketAccess: boolean
}

/* --------------------------------------------------------------- markets -- */

export type MarketKind = 'crypto' | 'stock'

export interface WatchItem {
  id: string
  /** CoinGecko id for crypto, ticker for stocks. */
  ref: string
  kind: MarketKind
  name: string
  createdAt: number
}

export interface Quote {
  ref: string
  /** Display ticker: BTC, AAPL, ^GSPC. */
  ticker: string
  kind: MarketKind
  name: string
  price: number | null
  change: number | null
  changePct: number | null
  currency: string
  marketCap: number | null
  volume: number | null
  /** Normalised recent closes, oldest first. */
  spark: number[]
  updatedAt: number
  /** True when only a delayed secondary source answered. */
  degraded?: boolean
}

export interface MarketHit {
  ref: string
  ticker: string
  kind: MarketKind
  name: string
  exchange?: string
}

export interface MarketOverview {
  indices: Quote[]
  crypto: Quote[]
  global: { marketCap: number | null; volume: number | null; btcDominance: number | null; change24h: number | null } | null
  updatedAt: number
}

/* -------------------------------------------------------------- meme coins -- */

/** A Solana meme coin, discovered through a pump.fun or PumpSwap pool. */
export interface MemeCoin {
  /** Solana mint address. */
  mint: string
  symbol: string
  name: string
  price: number | null
  change24h: number | null
  volume24h: number | null
  /** Market cap when the indexer reports one, otherwise fully diluted value. */
  marketCap: number | null
  /** Pool reserve in USD; null when the book is too thin to report. */
  liquidity: number | null
  pool: string
  dex: string
  /** Human venue: pump.fun bonding curve or PumpSwap. */
  venue: string
  createdAt: number | null
  url: string
}

export interface MemeFeed {
  items: MemeCoin[]
  updatedAt: number
  source: string
}

export interface WalletHolding {
  mint: string
  symbol: string
  name: string
  amount: number
  price: number | null
  value: number | null
  change24h: number | null
  liquidity: number | null
}

/** A public Solana wallet, priced. Read-only: no signature is ever requested. */
export interface WalletPortfolio {
  address: string
  sol: number
  solValue: number | null
  totalValue: number | null
  holdings: WalletHolding[]
  /** Tokens held with no market to price them. */
  unpriced: number
  updatedAt: number
}

/* ------------------------------------------------------------------ chat -- */

/** One tool the agent ran during a turn, for the trace shown in the UI. */
export interface ToolStep {
  id: string
  name: string
  label: string
  state: 'running' | 'ok' | 'error'
  summary?: string
}

/** Server-sent events on POST /api/chat. */
export type ChatEvent =
  | { type: 'start'; conversation: Conversation; userMessage: Message; assistantMessageId: string }
  | { type: 'status'; label: string }
  | { type: 'tool'; id: string; name: string; label: string }
  | { type: 'tool_result'; id: string; ok: boolean; summary: string }
  | { type: 'delta'; text: string }
  | { type: 'done'; message: Message; usage: Me['usage'] }
  | { type: 'error'; code: string; message: string }
