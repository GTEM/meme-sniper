// Cross-venue quotes from keyless public APIs.
//
// One number from one exchange can be stale, regional or thin. This asks several
// venues at once and keeps whatever answers, so the model can see a spread
// instead of a single price presented as the market.

const UA = 'Mozilla/5.0 (compatible; Ulvarin/1.0)'

export type VenueQuote = {
  venue: 'Coinbase' | 'Binance' | 'Kraken'
  pair: string
  price: number
  change24h: number | null
  /** Quote-currency volume for the last 24h, when the venue reports it. */
  volume24h: number | null
  /** True when the quote came through the owner's relay, not direct. */
  viaRelay?: boolean
}

type Attempt = { venue: VenueQuote['venue']; pair: string; run: () => Promise<VenueQuote | null> }

const num = (value: unknown): number | null => {
  const parsed = typeof value === 'number' ? value : typeof value === 'string' ? Number(value) : NaN
  return Number.isFinite(parsed) ? parsed : null
}

async function getJson<T>(url: string): Promise<T | null> {
  const response = await fetch(url, { headers: { accept: 'application/json', 'user-agent': UA }, signal: AbortSignal.timeout(8_000) }).catch(() => null)
  if (!response?.ok) return null
  return (await response.json().catch(() => null)) as T | null
}

const coinbase = (ticker: string): Attempt => {
  const pair = `${ticker}-USD`
  return {
    venue: 'Coinbase',
    pair,
    run: async () => {
      const body = await getJson<{ open?: string; last?: string; volume?: string }>(`https://api.exchange.coinbase.com/products/${pair}/stats`)
      const price = num(body?.last)
      if (!body || price == null) return null
      const open = num(body.open)
      return {
        venue: 'Coinbase',
        pair,
        price,
        change24h: open ? ((price - open) / open) * 100 : null,
        volume24h: num(body.volume),
      }
    },
  }
}

const binance = (ticker: string, relayUrl?: string): Attempt => {
  const pair = `${ticker}USDT`
  const target = `https://api.binance.com/api/v3/ticker/24hr?symbol=${pair}`
  const parse = (body: { lastPrice?: string; priceChangePercent?: string; quoteVolume?: string } | null, viaRelay: boolean) => {
    const price = num(body?.lastPrice)
    if (!body || price == null) return null
    return { venue: 'Binance' as const, pair, price, change24h: num(body.priceChangePercent), volume24h: num(body.quoteVolume), viaRelay }
  }
  return {
    venue: 'Binance',
    pair,
    run: async () => {
      // Direct first: it works from allowed regions and costs no relay.
      const direct = parse(await getJson(`https://api.binance.com/api/v3/ticker/24hr?symbol=${pair}`), false)
      if (direct) return direct
      if (!relayUrl) return null
      // Binance answers 451 to blocked regions (and to Cloudflare egress in
      // some of them), so the read goes through the owner's relay instead.
      return parse(await getJson(`${relayUrl}${relayUrl.includes('?') ? '&' : '?'}url=${encodeURIComponent(target)}`), true)
    },
  }
}

// Kraken still calls Bitcoin XBT and wraps some pairs in X/Z prefixes.
const KRAKEN_ALIAS: Record<string, string> = { BTC: 'XBT', DOGE: 'XDG' }

const kraken = (ticker: string): Attempt => {
  const base = KRAKEN_ALIAS[ticker] ?? ticker
  const pair = `${base}USD`
  return {
    venue: 'Kraken',
    pair,
    run: async () => {
      const body = await getJson<{ error?: string[]; result?: Record<string, { c?: string[]; o?: string; v?: string[] }> }>(
        `https://api.kraken.com/0/public/Ticker?pair=${pair}`,
      )
      if (!body || (body.error?.length ?? 0) > 0 || !body.result) return null
      const entry = Object.entries(body.result).find(([key]) => key !== 'last')?.[1]
      const price = num(entry?.c?.[0])
      if (!entry || price == null) return null
      const open = num(entry.o)
      return {
        venue: 'Kraken',
        pair: entry ? Object.keys(body.result)[0]! : pair,
        price,
        change24h: open ? ((price - open) / open) * 100 : null,
        volume24h: num(entry.v?.[1]),
      }
    },
  }
}

/** Every venue that quotes this ticker, in parallel. Failures are dropped. */
export async function venueQuotes(ticker: string, relayUrl?: string): Promise<VenueQuote[]> {
  const symbol = ticker.trim().toUpperCase().replace(/[^A-Z0-9]/g, '')
  if (!symbol) return []
  const attempts = [coinbase(symbol), binance(symbol, relayUrl), kraken(symbol)]
  const settled = await Promise.all(attempts.map((attempt) => attempt.run().catch(() => null)))
  return settled.filter((quote): quote is VenueQuote => quote != null)
}

/** Spread across venues, as a percentage of the cheapest price. */
export function venueSpread(quotes: VenueQuote[]): number | null {
  if (quotes.length < 2) return null
  const prices = quotes.map((quote) => quote.price).filter((price) => price > 0)
  if (prices.length < 2) return null
  const low = Math.min(...prices)
  const high = Math.max(...prices)
  return low ? ((high - low) / low) * 100 : null
}

const money = (value: number | null): string => {
  if (value == null) return 'n/a'
  if (value >= 1000) return value.toLocaleString('en-US', { maximumFractionDigits: 2 })
  return value >= 1 ? value.toFixed(2) : value.toPrecision(4)
}

export function describeVenues(ticker: string, quotes: VenueQuote[]): string {
  const symbol = ticker.trim().toUpperCase()
  if (!quotes.length) return `No keyless venue returned a quote for ${symbol} (Coinbase, Binance and Kraken were asked).`
  const spread = venueSpread(quotes)
  const lines = [
    `VENUE QUOTES — ${symbol} (asked Coinbase, Binance, Kraken; only venues that answered are listed)`,
    ...quotes.map(
      (quote) =>
        `${quote.venue}${quote.viaRelay ? ' (via relay)' : ''} ${quote.pair}: ${money(quote.price)}${quote.change24h == null ? '' : ` · 24h ${quote.change24h >= 0 ? '+' : ''}${quote.change24h.toFixed(2)}%`}${quote.volume24h == null ? '' : ` · 24h volume ${money(quote.volume24h)}`}`,
    ),
  ]
  const asked: VenueQuote['venue'][] = ['Coinbase', 'Binance', 'Kraken']
  const missing = asked.filter((venue) => !quotes.some((quote) => quote.venue === venue))
  if (missing.length) lines.push(`No answer from: ${missing.join(', ')} (blocked, geo-restricted, or the pair is not listed there)`)
  if (quotes.length === 1) lines.push('Only one venue answered; this is one book, not the whole market.')
  if (spread != null) lines.push(`Spread between venues: ${spread.toFixed(2)}% of the lowest price`)
  lines.push('Prices are in the pair currency shown (USD or USDT). Never convert or relabel them.')
  return lines.join('\n').slice(0, 2_000)
}
