// Optional data-source credentials, resolved once per request.
//
// Settings win over the environment so the owner can rotate them without a
// redeploy. Values never leave the Worker: callers get booleans and a hint.

import type { Env } from './env'

export type Sources = {
  solanaRpcUrl?: string
  venueRelayUrl?: string
}

export async function resolveSources(env: Env, db: D1Database): Promise<Sources> {
  const row = await db
    .prepare(`SELECT solana_rpc_url FROM data_sources WHERE id = 1`)
    .first<{ solana_rpc_url: string | null }>()
    .catch(() => null)
  const relay = await db
    .prepare(`SELECT url FROM venue_relay WHERE id = 1`)
    .first<{ url: string }>()
    .catch(() => null)
  return {
    solanaRpcUrl: row?.solana_rpc_url || env.SOLANA_RPC_URL || undefined,
    venueRelayUrl: relay?.url || env.VENUE_RELAY_URL || undefined,
  }
}

export const hint = (value: string): string => `…${value.slice(-4)}`

/** What the browser may see: configured, where it came from, and a hint. */
export async function sourcesState(env: Env, db: D1Database) {
  const row = await db
    .prepare(`SELECT solana_rpc_url FROM data_sources WHERE id = 1`)
    .first<{ solana_rpc_url: string | null }>()
    .catch(() => null)
  const rpc = row?.solana_rpc_url || env.SOLANA_RPC_URL || null
  const relay = await db
    .prepare(`SELECT url FROM venue_relay WHERE id = 1`)
    .first<{ url: string }>()
    .catch(() => null)
  const relayUrl = relay?.url || env.VENUE_RELAY_URL || null
  return {
    relay: {
      configured: Boolean(relayUrl),
      source: relay?.url ? 'settings' : env.VENUE_RELAY_URL ? 'environment' : 'none',
      host: relayUrl ? safeHost(relayUrl) : null,
    },
    solanaRpc: {
      configured: Boolean(rpc),
      source: row?.solana_rpc_url ? 'settings' : env.SOLANA_RPC_URL ? 'environment' : 'none',
      hint: rpc ? hint(rpc) : null,
      host: rpc ? safeHost(rpc) : null,
    },
  }
}

export type SourcesState = Awaited<ReturnType<typeof sourcesState>>

function safeHost(url: string): string | null {
  try {
    return new URL(url).host
  } catch {
    return null
  }
}
