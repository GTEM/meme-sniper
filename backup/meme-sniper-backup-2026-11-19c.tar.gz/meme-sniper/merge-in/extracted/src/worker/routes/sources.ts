// Optional data-source credentials, managed by the owner in Settings.
//
// The RPC is checked with getHealth before it is stored: a saved endpoint that
// cannot answer is worse than none, because it turns "unavailable" into a
// confident-looking screen with holes.

import { Hono } from 'hono'

import { privateJson, requireOwner } from '../auth'
import { now } from '../db'
import type { AppContext } from '../env'
import { sourcesState } from '../sources'

export const sources = new Hono<AppContext>()

/** null when healthy, otherwise the reason to show the owner. */
async function checkRpc(url: string): Promise<string | null> {
  const response = await fetch(url, {
    method: 'POST',
    headers: { 'content-type': 'application/json', accept: 'application/json', 'user-agent': 'ulvarin/1.0' },
    body: JSON.stringify({ jsonrpc: '2.0', id: 1, method: 'getHealth' }),
    signal: AbortSignal.timeout(8_000),
  }).catch(() => null)
  if (!response) return 'That URL did not answer.'
  // Read once as text: the endpoint's own words are the useful part, and the
  // JSON parse below would otherwise consume the body.
  const raw = await response.text().catch(() => '')
  const detail = raw.trim().slice(0, 140)
  const shown = detail ? ` — ${detail}` : ''
  if (response.status === 401)
    return `That endpoint rejected the key (HTTP 401${shown}). Copy the complete URL from the provider dashboard: a Helius key is 36 characters, and a truncated or placeholder paste fails exactly this way.`
  if (response.status === 403)
    return `That endpoint refused this server (HTTP 403${shown}). If the same URL works in your browser, the provider is blocking this server's IP range rather than refusing the key.`
  if (response.status === 429) return 'That endpoint rate-limited the check. Try your own keyed endpoint.'
  if (!response.ok) return `That endpoint answered HTTP ${response.status}${shown}.`
  let body: { result?: string; error?: { message?: string } } | null = null
  try {
    body = JSON.parse(raw) as { result?: string; error?: { message?: string } }
  } catch {
    return `That URL answered, but not with JSON, so it is not a Solana RPC endpoint${shown}.`
  }
  if (body?.error) return `The RPC returned an error: ${body.error.message ?? 'unknown'}.`
  if (typeof body?.result !== 'string') return 'That URL answered, but not like a Solana RPC endpoint.'
  return null
}

/** null when the relay answers a live Binance read, otherwise the reason. */
async function checkRelay(url: string): Promise<string | null> {
  const target = 'https://api.binance.com/api/v3/ticker/24hr?symbol=BTCUSDT'
  const response = await fetch(`${url}${url.includes('?') ? '&' : '?'}url=${encodeURIComponent(target)}`, {
    headers: { accept: 'application/json' },
    signal: AbortSignal.timeout(10_000),
  }).catch(() => null)
  if (!response) return 'The relay did not answer.'
  if (!response.ok) return `The relay answered ${response.status}.`
  const body = (await response.json().catch(() => null)) as { lastPrice?: string } | null
  if (!body?.lastPrice) return 'The relay answered, but not with a Binance quote. Check its contract and allow-list.'
  return null
}

sources.get('/', requireOwner, async (c) => privateJson(c, await sourcesState(c.env, c.get('db'))))

sources.put('/', requireOwner, async (c) => {
  const db = c.get('db')
  const input = await c.req
    .json<{ solanaRpcUrl?: unknown; relayUrl?: unknown }>()
    .catch(() => ({} as { solanaRpcUrl?: unknown; relayUrl?: unknown }))

  let rpc: string | null | undefined
  if (input.solanaRpcUrl !== undefined) {
    const value = typeof input.solanaRpcUrl === 'string' ? input.solanaRpcUrl.trim() : ''
    if (!value) {
      rpc = null
    } else {
      let parsed: URL
      try {
        parsed = new URL(value)
      } catch {
        return c.json({ error: 'invalid', message: 'That is not a URL.' }, 400)
      }
      if (parsed.protocol !== 'https:' && parsed.protocol !== 'http:') {
        return c.json({ error: 'invalid', message: 'The RPC URL must start with https:// or http://.' }, 400)
      }
      // Catch the common failure before spending a request on it: a key pasted
      // with an ellipsis, a space, or cut short still looks like a valid URL.
      const key = parsed.searchParams.get('api-key')
      if (key != null && (key.length < 20 || /[\s\u2026]/.test(key))) {
        return c.json(
          { error: 'invalid', message: 'The api-key in that URL looks truncated or contains a placeholder. Copy the whole URL from the provider dashboard instead of retyping it.' },
          400,
        )
      }
      const failure = await checkRpc(value)
      if (failure) return c.json({ error: 'unreachable', message: failure }, 400)
      rpc = value
    }
  }

  let relay: string | null | undefined
  if (input.relayUrl !== undefined) {
    const value = typeof input.relayUrl === 'string' ? input.relayUrl.trim() : ''
    if (!value) {
      relay = null
    } else {
      let parsed: URL
      try {
        parsed = new URL(value)
      } catch {
        return c.json({ error: 'invalid', message: 'That is not a URL.' }, 400)
      }
      if (parsed.protocol !== 'https:' && parsed.protocol !== 'http:') {
        return c.json({ error: 'invalid', message: 'The relay URL must start with https:// or http://.' }, 400)
      }
      const failure = await checkRelay(value)
      if (failure) return c.json({ error: 'unreachable', message: failure }, 400)
      relay = value
    }
  }

  if (rpc === undefined && relay === undefined) return c.json({ error: 'empty', message: 'Nothing to save.' }, 400)

  await db.prepare(`INSERT INTO data_sources (id, solana_rpc_url, updated_at) VALUES (1, NULL, ?) ON CONFLICT(id) DO NOTHING`).bind(now()).run()
  if (rpc !== undefined) await db.prepare(`UPDATE data_sources SET solana_rpc_url = ?, updated_at = ? WHERE id = 1`).bind(rpc, now()).run()
  if (relay === null) await db.prepare(`DELETE FROM venue_relay WHERE id = 1`).run()
  else if (relay !== undefined)
    await db
      .prepare(`INSERT INTO venue_relay (id, url, updated_at) VALUES (1, ?, ?) ON CONFLICT(id) DO UPDATE SET url = excluded.url, updated_at = excluded.updated_at`)
      .bind(relay, now())
      .run()

  return privateJson(c, await sourcesState(c.env, db))
})

/** Clear one credential: /api/sources/solana or /api/sources/x. */
sources.delete('/:kind', requireOwner, async (c) => {
  const kind = c.req.param('kind')
  if (kind === 'relay') {
    await c.get('db').prepare(`DELETE FROM venue_relay WHERE id = 1`).run()
    return privateJson(c, await sourcesState(c.env, c.get('db')))
  }
  const column = kind === 'solana' ? 'solana_rpc_url' : null
  if (!column) return c.json({ error: 'unknown', message: 'Unknown source.' }, 404)
  await c.get('db').prepare(`UPDATE data_sources SET ${column} = NULL, updated_at = ? WHERE id = 1`).bind(now()).run()
  return privateJson(c, await sourcesState(c.env, c.get('db')))
})
