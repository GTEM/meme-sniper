// Administration: the owner's admission queue, invites, roles and the
// instance-wide registration mode. Admins can admit and manage members; only
// the owner can create admins, change roles, or reopen registration. The owner
// account itself can never be changed or deleted from here.

import { Hono } from 'hono'

import type { AccountStatus, AdminAccount, AdminOverview, Invite, RegistrationMode, Role } from '../../shared/types'
import { privateJson, requireAdmin, requireOwner } from '../auth'
import { now } from '../db'
import type { AppContext } from '../env'

export const admin = new Hono<AppContext>()
admin.use('*', requireAdmin)

const isRole = (value: unknown): value is Role => value === 'owner' || value === 'admin' || value === 'member'
const isStatus = (value: unknown): value is AccountStatus => value === 'pending' || value === 'active' || value === 'suspended'
const isMode = (value: unknown): value is RegistrationMode => value === 'closed' || value === 'approval' || value === 'open'

async function overview(db: D1Database, me: { sub: string; role: Role }): Promise<AdminOverview> {
  const [accounts, invites, instance] = await Promise.all([
    db.prepare(`SELECT id, name, email, role, status, created_at, last_login_at FROM accounts ORDER BY created_at ASC`).all<Record<string, unknown>>(),
    db.prepare(`SELECT code, role, max_uses, uses, expires_at, created_at FROM invites ORDER BY created_at DESC`).all<Record<string, unknown>>(),
    db.prepare(`SELECT registration FROM instance WHERE id = 1`).first<{ registration: RegistrationMode }>(),
  ])
  return {
    instance: { registration: instance?.registration ?? 'approval' },
    accounts: accounts.results.map(
      (row): AdminAccount => ({
        id: String(row.id),
        name: String(row.name ?? ''),
        email: String(row.email),
        role: (row.role as Role) ?? 'member',
        status: (row.status as AccountStatus) ?? 'active',
        createdAt: Number(row.created_at),
        lastLoginAt: row.last_login_at == null ? null : Number(row.last_login_at),
      }),
    ),
    invites: invites.results.map(
      (row): Invite => ({
        code: String(row.code),
        role: (row.role as Role) ?? 'member',
        maxUses: Number(row.max_uses),
        uses: Number(row.uses),
        expiresAt: row.expires_at == null ? null : Number(row.expires_at),
        createdAt: Number(row.created_at),
      }),
    ),
    me: { role: me.role, id: me.sub },
  }
}

admin.get('/overview', async (c) => privateJson(c, await overview(c.get('db'), c.get('user'))))

admin.patch('/accounts/:id', async (c) => {
  const db = c.get('db')
  const actor = c.get('user')
  const target = await db.prepare(`SELECT * FROM accounts WHERE id = ?`).bind(c.req.param('id')).first<Record<string, unknown>>()
  if (!target) return c.json({ error: 'not_found', message: 'That account no longer exists.' }, 404)
  if (target.id === actor.sub) return c.json({ error: 'forbidden', message: 'You cannot change your own account here.' }, 403)
  if (target.role === 'owner') return c.json({ error: 'forbidden', message: 'The owner account cannot be changed.' }, 403)

  const input = await c.req.json<{ role?: unknown; status?: unknown }>().catch(() => ({}) as Record<string, unknown>)
  if (input.role !== undefined && !isRole(input.role)) return c.json({ error: 'invalid', message: 'Unknown role.' }, 400)
  if (input.status !== undefined && !isStatus(input.status)) return c.json({ error: 'invalid', message: 'Unknown status.' }, 400)
  if (input.role === 'owner') return c.json({ error: 'invalid', message: 'Ownership stays with the account that claimed this instance.' }, 400)
  if (input.status === 'pending') return c.json({ error: 'invalid', message: 'Admit or suspend an account; there is no way back to pending.' }, 400)

  if (actor.role === 'admin') {
    if (target.role !== 'member') return c.json({ error: 'forbidden', message: 'Admins can only manage members.' }, 403)
    if (input.role !== undefined && input.role !== 'member') return c.json({ error: 'forbidden', message: 'Only the owner can grant admin.' }, 403)
  }

  const role = isRole(input.role) ? input.role : (target.role as Role)
  const status = isStatus(input.status) ? input.status : (target.status as AccountStatus)
  await db.prepare(`UPDATE accounts SET role = ?, status = ? WHERE id = ?`).bind(role, status, target.id).run()
  if (status === 'suspended') await db.prepare(`DELETE FROM sessions WHERE account_id = ?`).bind(target.id).run()
  return privateJson(c, await overview(db, actor))
})

admin.delete('/accounts/:id', async (c) => {
  const db = c.get('db')
  const actor = c.get('user')
  const id = c.req.param('id')
  const target = await db.prepare(`SELECT * FROM accounts WHERE id = ?`).bind(id).first<Record<string, unknown>>()
  if (!target) return c.json({ error: 'not_found', message: 'That account no longer exists.' }, 404)
  if (target.id === actor.sub) return c.json({ error: 'forbidden', message: 'You cannot delete your own account.' }, 403)
  if (target.role === 'owner') return c.json({ error: 'forbidden', message: 'The owner account cannot be deleted.' }, 403)
  if (actor.role === 'admin' && target.role !== 'member') return c.json({ error: 'forbidden', message: 'Admins can only remove members.' }, 403)

  // Removing an account removes everything it owns. Nothing is retained.
  await db.batch([
    db.prepare(`DELETE FROM sessions WHERE account_id = ?`).bind(id),
    db.prepare(`DELETE FROM messages WHERE owner_sub = ?`).bind(id),
    db.prepare(`DELETE FROM conversations WHERE owner_sub = ?`).bind(id),
    db.prepare(`DELETE FROM memories WHERE owner_sub = ?`).bind(id),
    db.prepare(`DELETE FROM learning_runs WHERE owner_sub = ?`).bind(id),
    db.prepare(`DELETE FROM watchlist WHERE owner_sub = ?`).bind(id),
    db.prepare(`DELETE FROM user_settings WHERE owner_sub = ?`).bind(id),
    db.prepare(`DELETE FROM accounts WHERE id = ?`).bind(id),
  ])
  return privateJson(c, await overview(db, actor))
})

function inviteCode(): string {
  const alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'
  return Array.from(crypto.getRandomValues(new Uint8Array(12)), (byte) => alphabet[byte % alphabet.length]).join('')
}

admin.post('/invites', async (c) => {
  const db = c.get('db')
  const actor = c.get('user')
  const input = await c.req.json<{ role?: unknown; maxUses?: unknown; expiresInDays?: unknown }>().catch(() => ({}) as Record<string, unknown>)
  const role: Role = isRole(input.role) && input.role !== 'owner' ? input.role : 'member'
  if (role === 'admin' && actor.role !== 'owner') return c.json({ error: 'forbidden', message: 'Only the owner can invite an admin.' }, 403)
  const maxUses = Math.min(50, Math.max(1, Number.isFinite(Number(input.maxUses)) ? Math.round(Number(input.maxUses)) : 1))
  const days = Math.min(90, Math.max(0, Number.isFinite(Number(input.expiresInDays)) ? Math.round(Number(input.expiresInDays)) : 7))
  const at = now()
  let code = inviteCode()
  for (let attempt = 0; attempt < 3; attempt++) {
    const clash = await db.prepare(`SELECT 1 FROM invites WHERE code = ?`).bind(code).first()
    if (!clash) break
    code = inviteCode()
  }
  await db
    .prepare(`INSERT INTO invites (code, role, max_uses, uses, expires_at, created_by, created_at) VALUES (?, ?, ?, 0, ?, ?, ?)`)
    .bind(code, role, maxUses, days ? at + days * 86_400_000 : null, actor.sub, at)
    .run()
  return privateJson(c, await overview(db, actor))
})

admin.delete('/invites/:code', async (c) => {
  const db = c.get('db')
  const actor = c.get('user')
  await db.prepare(`DELETE FROM invites WHERE code = ?`).bind(c.req.param('code').toUpperCase()).run()
  return privateJson(c, await overview(db, actor))
})

admin.put('/instance', requireOwner, async (c) => {
  const db = c.get('db')
  const actor = c.get('user')
  const input = await c.req.json<{ registration?: unknown }>().catch(() => ({}) as Record<string, unknown>)
  if (!isMode(input.registration)) return c.json({ error: 'invalid', message: 'Unknown registration mode.' }, 400)
  await db.prepare(`UPDATE instance SET registration = ? WHERE id = 1`).bind(input.registration).run()
  return privateJson(c, await overview(db, actor))
})
