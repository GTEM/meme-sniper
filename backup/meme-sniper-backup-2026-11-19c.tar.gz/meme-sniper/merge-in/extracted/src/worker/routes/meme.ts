import { Hono } from 'hono'

import { privateJson } from '../auth'
import type { AppContext } from '../env'
import { isSolanaAddress, memeFeed, walletPortfolio, WALLET_RPC_REQUIRED } from '../solana'
import { resolveSources } from '../sources'

export const meme = new Hono<AppContext>()

meme.get('/feed', async (c) => {
  const sort = c.req.query('sort') === 'new' ? 'new' : 'volume'
  try {
    return privateJson(c, await memeFeed(sort))
  } catch (error) {
    return c.json(
      { error: 'upstream', message: error instanceof Error ? error.message : 'The pump.fun feed is unavailable right now.' },
      502,
    )
  }
})

export const wallet = new Hono<AppContext>()

wallet.get('/:address', async (c) => {
  const address = c.req.param('address')
  if (!isSolanaAddress(address)) return c.json({ error: 'invalid', message: 'That is not a Solana wallet address.' }, 400)
  try {
    const { solanaRpcUrl } = await resolveSources(c.env, c.get('db'))
    return privateJson(c, await walletPortfolio(address, solanaRpcUrl))
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Could not read that wallet.'
    if (message.includes(WALLET_RPC_REQUIRED)) {
      return c.json({ error: 'rpc-required', message: message.replace(`${WALLET_RPC_REQUIRED}: `, '') }, 503)
    }
    return c.json({ error: 'upstream', message }, 502)
  }
})
