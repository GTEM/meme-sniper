// POST /api/chat: one user turn in, one streamed answer out.
//
// A turn is an agent loop. The model may ask for tools (web search, page
// reads, live quotes, arithmetic, memory) for up to MAX_TOOL_ROUNDS; each call
// is streamed to the browser as a step in the trace. When it stops asking for
// tools, its answer is streamed to the browser in chunks, saved, and — every
// few replies — folded into long-term memory in the background.

import { Hono } from 'hono'
import { streamSSE, type SSEStreamingApi } from 'hono/streaming'

import {
  DAILY_MESSAGE_LIMIT,
  EXTRA_PROVIDERS,
  MAX_CONTEXT_MESSAGES,
  MAX_MESSAGE_CHARS,
  MAX_OUTPUT_TOKENS,
  MAX_TOOL_CALLS,
  MAX_TOOL_ROUNDS,
  SYSTEM_PROMPT,
  TOOL_MAX_TOKENS,
  unlimitedReplies,
  type ModelId,
  type ProviderId,
} from '../../shared/config'
import type { ChatEvent, Message } from '../../shared/types'
import { AiError, aiConfigured, chatTurn, defaultModel, isModelId, providerKey, resolveKey, type ChatMessage, type ToolReply } from '../ai'
import { getSettings, id, mapConversation, mapMessage, now, repliesToday, titleFrom, utcDay } from '../db'
import type { AppContext } from '../env'
import { maybeLearn, recallMemories } from '../memory'
import { POLICY_REFUSAL, violatesPolicy } from '../policy'
import { buildSystemPrompt } from '../prompt'
import { resolveSources } from '../sources'
import { parseToolCalls, runTool, stripToolBlocks, toolLabel, TOOL_NAMES, TOOL_SCHEMAS, type ToolContext, type ToolName } from '../tools'

export const chat = new Hono<AppContext>()

type Input = { conversationId?: unknown; content?: unknown; model?: unknown; regenerate?: unknown; context?: unknown }

// Replies in flight per user in this isolate (start times, so a slot that was
// never released still expires). A cheap brake on a tab that fires requests
// in parallel; the daily limit and the key's own spend limits are the real
// ceilings.
const inflight = new Map<string, number[]>()
const MAX_INFLIGHT = 2
const INFLIGHT_TTL = 8 * 60_000
const inflightCount = (owner: string) => {
  const live = (inflight.get(owner) ?? []).filter((at) => Date.now() - at < INFLIGHT_TTL)
  if (live.length) inflight.set(owner, live)
  else inflight.delete(owner)
  return live.length
}

// A write that does not complete in this long means the reader is gone:
// runtimes do not all report a closed connection, and a blocked write would
// otherwise hold the upstream request (and the credits it spends) open.
const WRITE_TIMEOUT = 10_000
const sleep = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms))

/** Splits a finished answer into word-ish chunks so the UI streams it. */
function chunks(text: string, size: number): string[] {
  const out: string[] = []
  let index = 0
  while (index < text.length) {
    let end = Math.min(text.length, index + size)
    const space = text.lastIndexOf(' ', end)
    if (space > index + size / 2) end = space + 1
    out.push(text.slice(index, end))
    index = end
  }
  return out
}

chat.post('/', async (c) => {
  const db = c.get('db')
  const owner = c.get('user').sub
  if (!(await aiConfigured(c.env, db))) return c.json({ error: 'not_configured', message: 'No API key is configured yet.' }, 503)
  const apiKey = (await resolveKey(c.env, db)) ?? undefined
  // Secondary providers are only used when their key exists, so a turn keeps
  // going on a different quota instead of ending at the first rate limit.
  const extraKeys: Partial<Record<ProviderId, string>> = {}
  for (const id of EXTRA_PROVIDERS) {
    const resolved = await providerKey(c.env, db, id)
    if (resolved.key) extraKeys[id] = resolved.key
  }

  const input = await c.req.json<Input>().catch(() => ({}) as Input)
  const regenerate = input.regenerate === true
  const content = typeof input.content === 'string' ? input.content.replace(/\r\n?/g, '\n').trim() : ''
  if (!regenerate && !content) return c.json({ error: 'empty', message: 'Write a message first.' }, 400)
  if (content.length > MAX_MESSAGE_CHARS) return c.json({ error: 'too_long', message: `Messages can be up to ${MAX_MESSAGE_CHARS.toLocaleString()} characters.` }, 400)
  if (input.model !== undefined && !isModelId(c.env, input.model)) return c.json({ error: 'model', message: 'Unknown model.' }, 400)
  if (input.conversationId !== undefined && typeof input.conversationId !== 'string') return c.json({ error: 'conversation', message: 'Invalid conversation.' }, 400)
  if (!regenerate && violatesPolicy(content)) return c.json({ error: 'policy', message: POLICY_REFUSAL }, 400)

  if (inflightCount(owner) >= MAX_INFLIGHT) return c.json({ error: 'busy', message: 'Wait for the current reply to finish.' }, 429)
  // The owner and admins are uncapped; everyone else is counted per UTC day.
  const unlimited = unlimitedReplies(c.get('user').role)
  const used = await repliesToday(db, owner)
  if (!unlimited && used >= DAILY_MESSAGE_LIMIT) {
    return c.json({ error: 'limit', message: `You have reached today's limit of ${DAILY_MESSAGE_LIMIT} replies.`, resetsAt: utcDay().end }, 429)
  }

  const t = now()
  let conversationRow = input.conversationId
    ? await db.prepare(`SELECT * FROM conversations WHERE owner_sub = ? AND id = ?`).bind(owner, input.conversationId).first<Record<string, unknown>>()
    : null
  if (input.conversationId && !conversationRow) return c.json({ error: 'not_found', message: 'This chat no longer exists.' }, 404)
  if (regenerate && !conversationRow) return c.json({ error: 'conversation', message: 'Nothing to regenerate.' }, 400)
  const existingModel = conversationRow?.model
  const model: ModelId = isModelId(c.env, input.model) ? input.model : isModelId(c.env, existingModel) ? existingModel : defaultModel(c.env)
  const statements: D1PreparedStatement[] = []
  if (!conversationRow) {
    conversationRow = { id: id(), owner_sub: owner, title: titleFrom(content), model, created_at: t, updated_at: t }
    statements.push(
      db
        .prepare(`INSERT INTO conversations (id, owner_sub, title, model, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?)`)
        .bind(conversationRow.id, owner, conversationRow.title, model, t, t),
    )
  } else {
    conversationRow.model = model
    conversationRow.updated_at = t
    statements.push(db.prepare(`UPDATE conversations SET model = ?, updated_at = ? WHERE owner_sub = ? AND id = ?`).bind(model, t, owner, conversationRow.id))
  }
  const conversation = mapConversation(conversationRow)

  // History the model sees, oldest first, bounded.
  const history = (
    await db
      .prepare(`SELECT * FROM messages WHERE owner_sub = ? AND conversation_id = ? ORDER BY created_at DESC LIMIT ?`)
      .bind(owner, conversation.id, MAX_CONTEXT_MESSAGES)
      .all()
  ).results.map((r) => mapMessage(r as Record<string, unknown>)).reverse()

  let userMessage: Message
  if (regenerate) {
    const lastUser = [...history].reverse().find((m) => m.role === 'user')
    if (!lastUser) return c.json({ error: 'conversation', message: 'Nothing to regenerate.' }, 400)
    userMessage = lastUser
    statements.push(db.prepare(`DELETE FROM messages WHERE owner_sub = ? AND conversation_id = ? AND created_at > ?`).bind(owner, conversation.id, lastUser.createdAt))
    history.splice(history.indexOf(lastUser) + 1)
  } else {
    userMessage = { id: id(), conversationId: conversation.id, role: 'user', content, model: null, interrupted: false, createdAt: t }
    statements.push(
      db
        .prepare(`INSERT INTO messages (id, owner_sub, conversation_id, role, content, model, created_at) VALUES (?, ?, ?, 'user', ?, NULL, ?)`)
        .bind(userMessage.id, owner, conversation.id, content, t),
    )
    history.push(userMessage)
  }

  // The reply's row exists from the start (empty), so it counts toward today's
  // limit while streaming and the app knows its id before the first token.
  const assistantMessageId = id()
  const replyAt = t + 1
  statements.push(
    db
      .prepare(`INSERT INTO messages (id, owner_sub, conversation_id, role, content, model, created_at) VALUES (?, ?, ?, 'assistant', '', ?, ?)`)
      .bind(assistantMessageId, owner, conversation.id, model, replyAt),
  )
  await db.batch(statements)

  const settings = await getSettings(db, owner)
  const memoryQuery = content || [...history].reverse().find((m) => m.role === 'user')?.content || ''
  const memories = await recallMemories(db, owner, memoryQuery).catch(() => [])
  const system = buildSystemPrompt({
    persona: settings.persona,
    memories,
    allowWeb: settings.webAccess,
    allowMarkets: settings.marketAccess,
    // Keeps the list formatting the page sent; bounded so it cannot dominate the prompt.
    screen: typeof input.context === 'string' ? input.context.replace(/\r\n?/g, '\n').trim().slice(0, 2_000) : '',
  })
  const prompt: ChatMessage[] = [
    { role: 'system', content: system || SYSTEM_PROMPT },
    ...history.slice(-MAX_CONTEXT_MESSAGES).map((m) => ({ role: m.role, content: m.content })),
  ]

  const startedAt = Date.now()
  inflight.set(owner, [...(inflight.get(owner) ?? []), startedAt])
  const release = () => {
    const rest = (inflight.get(owner) ?? []).filter((at) => at !== startedAt)
    if (rest.length) inflight.set(owner, rest)
    else inflight.delete(owner)
  }

  c.header('Cache-Control', 'private, no-store')
  return streamSSE(c, async (stream) => {
    // The whole reply runs under waitUntil: when the reader goes away the
    // runtime drops the request's other work, and this is what stops the
    // upstream request and records what arrived. It is registered before
    // the first byte is sent.
    const work = generate(stream)
    c.executionCtx.waitUntil(work)
    await work
  })

  async function generate(stream: SSEStreamingApi) {
    const controller = new AbortController()
    let text = ''
    let gone = false
    // Resolves false once the reader has stopped taking data: the runtime
    // cancelled the stream, or a write sat unanswered for WRITE_TIMEOUT.
    const send = (event: ChatEvent) => {
      let timer: ReturnType<typeof setTimeout> | undefined
      return Promise.race([
        stream.writeSSE({ data: JSON.stringify(event) }).then(() => !stream.aborted),
        new Promise<boolean>((resolve) => {
          timer = setTimeout(() => resolve(false), WRITE_TIMEOUT)
        }),
      ]).finally(() => clearTimeout(timer))
    }
    const save = (interrupted: boolean) =>
      db.prepare(`UPDATE messages SET content = ?, interrupted = ? WHERE owner_sub = ? AND id = ?`).bind(text, interrupted ? 1 : 0, owner, assistantMessageId).run()
    const discard = () => db.prepare(`DELETE FROM messages WHERE owner_sub = ? AND id = ?`).bind(owner, assistantMessageId).run()
    const abandon = async () => {
      if (gone) return
      gone = true
      controller.abort()
      await (text ? save(true) : discard())
    }
    stream.onAbort(() => void abandon())

    try {
      if (!(await send({ type: 'start', conversation, userMessage, assistantMessageId }))) return await abandon()
      await send({ type: 'status', label: 'Thinking' })

      const sources = await resolveSources(c.env, db)
      const toolCtx: ToolContext = {
        env: c.env,
        db,
        owner,
        conversationId: conversation.id,
        allowWeb: settings.webAccess,
        allowMarkets: settings.marketAccess,
        solanaRpcUrl: sources.solanaRpcUrl,
        venueRelayUrl: sources.venueRelayUrl,
      }
      const messages: ChatMessage[] = [...prompt]
      let usedTools = 0
      let answer = ''

      for (let round = 0; round <= MAX_TOOL_ROUNDS; round++) {
        if (gone) return
        const budget = MAX_TOOL_CALLS - usedTools
        const forceAnswer = budget <= 0 || round === MAX_TOOL_ROUNDS
        const turnMessages: ChatMessage[] = forceAnswer
          ? [...messages, { role: 'user', content: 'TOOL BUDGET EXHAUSTED. Answer now from what you have, say what is missing, and do not request more tools.' }]
          : messages
        const tools = forceAnswer ? undefined : TOOL_SCHEMAS
        let reply: ToolReply
        try {
          reply = await chatTurn(c.env, {
            model,
            messages: turnMessages,
            tools,
            maxTokens: forceAnswer ? MAX_OUTPUT_TOKENS : TOOL_MAX_TOKENS,
            signal: controller.signal,
            apiKey,
            extraKeys,
          })
        } catch (error) {
          // The model invented a tool name and the provider threw away the whole
          // completion. Answer that round without tools instead of handing the
          // user a validation error they cannot act on.
          if (!(error instanceof AiError) || error.code !== 'tool_misuse') throw error
          console.warn('Invalid tool call from the model, answering without tools')
          await send({ type: 'status', label: 'Answering without that tool' })
          reply = await chatTurn(c.env, { model, messages: turnMessages, maxTokens: MAX_OUTPUT_TOKENS, signal: controller.signal, apiKey, extraKeys })
        }
        // A reasoning model can spend the entire budget thinking and return no
        // content at all. One retry with the full output budget beats replying
        // to the user with silence.
        if (!reply.content.trim() && !reply.calls.length) {
          console.warn('Empty model reply, retrying with the full output budget')
          reply = await chatTurn(c.env, { model, messages: turnMessages, tools, maxTokens: MAX_OUTPUT_TOKENS, signal: controller.signal, apiKey, extraKeys })
        }
        if (gone) return

        // Native function calls first: the provider validated the shape, so the
        // arguments arrive as JSON we can run. The text protocol stays as a
        // fallback for models that do not support function calling.
        const native = forceAnswer
          ? []
          : reply.calls
              .filter((call) => (TOOL_NAMES as readonly string[]).includes(call.name))
              .slice(0, Math.max(0, Math.min(2, budget)))
              .map((call) => {
                let args: Record<string, unknown> = {}
                try {
                  const parsed = JSON.parse(call.arguments || '{}') as unknown
                  if (parsed && typeof parsed === 'object' && !Array.isArray(parsed)) args = parsed as Record<string, unknown>
                } catch {
                  /* the tool will report which argument it needs */
                }
                return { id: call.id, name: call.name as ToolName, args }
              })

        const calls = native.length
          ? native
          : forceAnswer
            ? []
            : parseToolCalls(reply.content)
                .slice(0, Math.max(0, Math.min(2, budget)))
                .map((call) => ({ id: id(), ...call }))

        if (!calls.length) {
          answer = stripToolBlocks(reply.content)
          // A reply that is nothing but stripped blocks means the model tried to
          // call a tool in a shape nothing recognised. Surface it in the log
          // rather than answering the user with silence.
          if (!answer.trim() && reply.content.trim()) console.warn('Unparsed model output:', JSON.stringify(reply.content.slice(0, 500)))
          break
        }

        if (native.length) {
          messages.push({
            role: 'assistant',
            content: reply.content || '',
            tool_calls: native.map((call) => ({ id: call.id, type: 'function' as const, function: { name: call.name, arguments: JSON.stringify(call.args) } })),
          })
        } else {
          messages.push({ role: 'assistant', content: stripToolBlocks(reply.content) || '(requesting tool results)' })
        }

        for (const call of calls) {
          if (gone) return
          usedTools++
          const stepId = id()
          if (!(await send({ type: 'tool', id: stepId, name: call.name, label: toolLabel(call.name, call.args) }))) return await abandon()
          const result = await runTool(toolCtx, call.name, call.args)
          if (gone) return
          await send({ type: 'tool_result', id: stepId, ok: result.ok, summary: result.summary.slice(0, 240) })
          messages.push(
            native.length
              ? { role: 'tool', tool_call_id: call.id, content: result.summary }
              : { role: 'user', content: `TOOL RESULT ${call.name}\n${result.summary}` },
          )
        }
        await send({ type: 'status', label: 'Thinking' })
      }

      if (!answer.trim()) {
        answer = 'I ran out of tool calls before I could finish that. Ask for the smallest next piece and I will pick it up from there.'
      }

      for (const chunk of chunks(answer, 140)) {
        if (gone) return
        text += chunk
        if (!(await send({ type: 'delta', text: chunk }))) return await abandon()
        await sleep(8)
      }
      if (gone) return
      await save(false)
      const message: Message = { id: assistantMessageId, conversationId: conversation.id, role: 'assistant', content: text, model, interrupted: false, createdAt: replyAt }
      await send({ type: 'done', message, usage: { used: used + 1, limit: unlimited ? null : DAILY_MESSAGE_LIMIT, resetsAt: utcDay().end } })

      // Self-learning runs after the reply, off the request's critical path.
      c.executionCtx.waitUntil(maybeLearn(c.env, db, owner, settings.autoLearn))
    } catch (error) {
      if (gone) return
      const failure = error instanceof AiError ? error : new AiError('unavailable', 'Something went wrong. Try again.', 502)
      if (!(error instanceof AiError)) console.error(error)
      await (text ? save(true) : discard())
      await send({ type: 'error', code: failure.code, message: failure.message })
    } finally {
      release()
    }
  }
})
