import { Hono } from 'hono'

import type { MarketKind, WatchItem } from '../../shared/types'
import { privateJson } from '../auth'
import { id, now } from '../db'
import type { AppContext } from '../env'
import { marketOverview, quotesForWatchlist, searchMarkets } from '../markets'

export const markets = new Hono<AppContext>()

const MAX_WATCH = 20

type WatchRow = { id: string; symbol: string; kind: string; name: string; created_at: number }

const mapWatch = (row: WatchRow): WatchItem => ({
  id: row.id,
  ref: row.symbol,
  kind: row.kind === 'crypto' ? 'crypto' : 'stock',
  name: row.name,
  createdAt: Number(row.created_at),
})

markets.get('/overview', async (c) => {
  const overview = await marketOverview()
  return privateJson(c, overview)
})

markets.get('/search', async (c) => {
  const query = (c.req.query('q') ?? '').trim().slice(0, 80)
  if (!query) return privateJson(c, { items: [] })
  return privateJson(c, { items: await searchMarkets(query) })
})

markets.get('/watchlist', async (c) => {
  const db = c.get('db')
  const rows = await db.prepare(`SELECT * FROM watchlist WHERE owner_sub = ? ORDER BY created_at ASC`).bind(c.get('user').sub).all<WatchRow>()
  const items = rows.results.map(mapWatch)
  return privateJson(c, { items, quotes: await quotesForWatchlist(items) })
})

markets.post('/watchlist', async (c) => {
  const db = c.get('db')
  const owner = c.get('user').sub
  const input = await c.req.json<{ ref?: unknown; kind?: unknown; name?: unknown }>().catch(() => ({}) as { ref?: unknown; kind?: unknown; name?: unknown })
  if (typeof input.ref !== 'string' || !input.ref.trim()) return c.json({ error: 'invalid', message: 'Pick a symbol first.' }, 400)
  if (input.kind !== 'crypto' && input.kind !== 'stock') return c.json({ error: 'invalid', message: 'Unknown instrument type.' }, 400)
  const kind: MarketKind = input.kind
  const ref = input.ref.trim().slice(0, 80)
  const name = (typeof input.name === 'string' ? input.name.trim().slice(0, 80) : ref) || ref

  const count = await db.prepare(`SELECT COUNT(*) AS n FROM watchlist WHERE owner_sub = ?`).bind(owner).first<{ n: number }>()
  if (Number(count?.n ?? 0) >= MAX_WATCH) return c.json({ error: 'limit', message: `The watchlist holds ${MAX_WATCH} instruments. Remove one first.` }, 400)

  await db
    .prepare(`INSERT OR IGNORE INTO watchlist (id, owner_sub, symbol, kind, name, created_at) VALUES (?, ?, ?, ?, ?, ?)`)
    .bind(id(), owner, kind === 'stock' ? ref.toUpperCase() : ref.toLowerCase(), kind, name, now())
    .run()

  const rows = await db.prepare(`SELECT * FROM watchlist WHERE owner_sub = ? ORDER BY created_at ASC`).bind(owner).all<WatchRow>()
  const items = rows.results.map(mapWatch)
  return privateJson(c, { items, quotes: await quotesForWatchlist(items) })
})

markets.delete('/watchlist/:id', async (c) => {
  const db = c.get('db')
  const owner = c.get('user').sub
  await db.prepare(`DELETE FROM watchlist WHERE owner_sub = ? AND id = ?`).bind(owner, c.req.param('id')).run()
  const rows = await db.prepare(`SELECT * FROM watchlist WHERE owner_sub = ? ORDER BY created_at ASC`).bind(owner).all<WatchRow>()
  const items = rows.results.map(mapWatch)
  return privateJson(c, { items, quotes: await quotesForWatchlist(items) })
})
