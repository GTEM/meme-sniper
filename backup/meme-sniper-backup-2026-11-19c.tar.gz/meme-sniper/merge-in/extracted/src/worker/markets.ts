// Live market data for the markets workspace and the agent's market tools.
// Crypto comes from CoinGecko, equities and indices from Yahoo Finance, with
// Stooq as a delayed fallback. Everything is cached in the isolate for under a
// minute, and every call degrades to null instead of failing a page.

import type { MarketHit, MarketKind, MarketOverview, Quote, WatchItem } from '../shared/types'

const CG = 'https://api.coingecko.com/api/v3'
const YF = 'https://query1.finance.yahoo.com'
const UA =
  'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36'

const INDEX_NAMES: Record<string, string> = {
  '^GSPC': 'S&P 500',
  '^IXIC': 'Nasdaq Composite',
  '^DJI': 'Dow Jones',
  '^RUT': 'Russell 2000',
  '^VIX': 'VIX',
  '^TNX': 'US 10Y yield',
  'DX-Y.NYB': 'Dollar index',
  'GC=F': 'Gold',
  'CL=F': 'Crude oil',
}

const TTL = 45_000
type CacheEntry = { at: number; value: unknown; ttl: number }
const cache = new Map<string, CacheEntry>()

async function cached<T>(key: string, ttl: number, load: () => Promise<T>): Promise<T> {
  const hit = cache.get(key)
  if (hit && Date.now() - hit.at < hit.ttl) return hit.value as T
  const value = await load()
  if (cache.size > 400) {
    for (const [entryKey, entry] of cache) if (Date.now() - entry.at > 5 * 60_000) cache.delete(entryKey)
  }
  cache.set(key, { at: Date.now(), value, ttl })
  return value
}

async function getJson<T>(url: string, timeout = 12_000): Promise<T> {
  const response = await fetch(url, {
    headers: { 'user-agent': UA, accept: 'application/json' },
    signal: AbortSignal.timeout(timeout),
  })
  if (!response.ok) throw new Error(`${new URL(url).hostname} responded ${response.status}`)
  return (await response.json()) as T
}

const num = (value: unknown): number | null => (typeof value === 'number' && Number.isFinite(value) ? value : null)

function downsample(values: number[], size = 44): number[] {
  const clean = values.filter((value) => Number.isFinite(value))
  if (clean.length <= size) return clean
  const step = clean.length / size
  return Array.from({ length: size }, (_, index) => clean[Math.min(clean.length - 1, Math.floor(index * step))]!)
}

export const usd = (value: number | null): string => {
  if (value == null) return '—'
  if (Math.abs(value) >= 1) return `$${value.toLocaleString('en-US', { maximumFractionDigits: 2 })}`
  return `$${value.toPrecision(4)}`
}

/** A bare number, no currency symbol: use with `quote.currency`. */
export const amount = (value: number | null): string => {
  if (value == null) return '—'
  if (Math.abs(value) >= 1) return value.toLocaleString('en-US', { maximumFractionDigits: 2 })
  return value.toPrecision(4)
}

export const compact = (value: number | null): string => {
  if (value == null) return '—'
  const units: [number, string][] = [
    [1e12, 'T'],
    [1e9, 'B'],
    [1e6, 'M'],
    [1e3, 'K'],
  ]
  for (const [size, suffix] of units) if (Math.abs(value) >= size) return `$${(value / size).toFixed(2)}${suffix}`
  return `$${value.toFixed(2)}`
}

/* ------------------------------------------------------------------ crypto */

type CgCoin = {
  id: string
  symbol: string
  name: string
  current_price: number | null
  market_cap: number | null
  total_volume: number | null
  price_change_percentage_24h: number | null
  sparkline_in_7d?: { price?: number[] }
}

function cryptoQuote(coin: CgCoin): Quote {
  const pct = num(coin.price_change_percentage_24h)
  const price = num(coin.current_price)
  return {
    ref: coin.id,
    ticker: coin.symbol.toUpperCase(),
    kind: 'crypto',
    name: coin.name,
    price,
    change: price != null && pct != null ? (price * pct) / 100 : null,
    changePct: pct,
    currency: 'USD',
    marketCap: num(coin.market_cap),
    volume: num(coin.total_volume),
    spark: downsample(coin.sparkline_in_7d?.price ?? []),
    updatedAt: Date.now(),
  }
}

const marketsUrl = (ids: string[] | null, perPage: number, order: 'market_cap_desc' | 'id_asc') =>
  `${CG}/coins/markets?vs_currency=usd&order=${order}&per_page=${perPage}&page=1&sparkline=true&price_change_percentage=24h${
    ids ? `&ids=${ids.map(encodeURIComponent).join('%2C')}` : ''
  }`

export async function cryptoMarkets(refs: string[]): Promise<Quote[]> {
  if (!refs.length) return []
  const key = `cg:${[...refs].sort().join(',')}`
  return cached(key, TTL, async () => {
    try {
      const coins = await getJson<CgCoin[]>(marketsUrl(refs, 250, 'market_cap_desc'))
      return coins.map(cryptoQuote)
    } catch {
      return []
    }
  })
}

export async function topCrypto(limit = 8): Promise<Quote[]> {
  return cached(`cg:top:${limit}`, TTL, async () => {
    try {
      const coins = await getJson<CgCoin[]>(marketsUrl(null, limit, 'market_cap_desc'))
      return coins.map(cryptoQuote)
    } catch {
      return []
    }
  })
}

type CgSearch = { coins?: { id: string; symbol: string; name: string; market_cap_rank?: number | null }[] }

export async function searchCoins(query: string, limit = 6): Promise<MarketHit[]> {
  if (!query.trim()) return []
  try {
    const body = await getJson<CgSearch>(`${CG}/search?query=${encodeURIComponent(query.trim())}`)
    return (body.coins ?? []).slice(0, limit).map((coin) => ({
      ref: coin.id,
      ticker: coin.symbol.toUpperCase(),
      kind: 'crypto' as const,
      name: coin.name,
      exchange: 'Crypto',
    }))
  } catch {
    return []
  }
}

async function resolveCoin(query: string): Promise<MarketHit | null> {
  const hits = await searchCoins(query, 8)
  if (!hits.length) return null
  const wanted = query.trim().toLowerCase()
  return (
    hits.find((hit) => hit.ticker.toLowerCase() === wanted) ??
    hits.find((hit) => hit.name.toLowerCase() === wanted) ??
    hits.find((hit) => hit.name.toLowerCase().includes(wanted)) ??
    hits[0]!
  )
}

/* ------------------------------------------------------------------ stocks */

type YChart = {
  chart?: {
    result?: {
      meta?: Record<string, unknown>
      indicators?: { quote?: { close?: (number | null)[] }[] }
    }[]
  }
}

async function stockFallback(ticker: string): Promise<Quote | null> {
  if (ticker.startsWith('^') || ticker.includes('=')) return null
  try {
    const response = await fetch(`https://stooq.com/q/l/?s=${encodeURIComponent(ticker.toLowerCase())}.us&f=sd2t2ohlcv&h&e=csv`, {
      headers: { 'user-agent': UA },
      signal: AbortSignal.timeout(10_000),
    })
    if (!response.ok) return null
    const lines = (await response.text()).trim().split('\n')
    const cells = lines[lines.length - 1]?.split(',') ?? []
    const close = Number(cells[6])
    if (!Number.isFinite(close) || close <= 0) return null
    return {
      ref: ticker,
      ticker,
      kind: 'stock',
      name: INDEX_NAMES[ticker] ?? ticker,
      price: close,
      change: null,
      changePct: null,
      currency: 'USD',
      marketCap: null,
      volume: Number(cells[7]) || null,
      spark: [],
      updatedAt: Date.now(),
      degraded: true,
    }
  } catch {
    return null
  }
}

async function stockQuote(ticker: string): Promise<Quote | null> {
  const symbol = ticker.trim().toUpperCase()
  if (!symbol) return null
  return cached(`stock:${symbol}`, TTL, async () => {
    try {
      const body = await getJson<YChart>(
        `${YF}/v8/finance/chart/${encodeURIComponent(symbol)}?range=1mo&interval=1d&includePrePost=false`,
      )
      const result = body.chart?.result?.[0]
      if (!result) return stockFallback(symbol)
      const meta = result.meta ?? {}
      const closes = (result.indicators?.quote?.[0]?.close ?? []).filter((value): value is number => typeof value === 'number')
      const price = num(meta.regularMarketPrice) ?? closes[closes.length - 1] ?? null
      // Yesterday's close: the second-last daily close. chartPreviousClose is
      // the close before the whole window, which would make this a monthly move.
      const previous =
        (closes.length > 1 ? closes[closes.length - 2]! : null) ?? num(meta.previousClose) ?? num(meta.chartPreviousClose)
      const change = price != null && previous != null ? price - previous : null
      return {
        ref: symbol,
        ticker: symbol,
        kind: 'stock',
        name: INDEX_NAMES[symbol] ?? String(meta.shortName ?? meta.longName ?? symbol),
        price,
        change,
        changePct: change != null && previous ? (change / previous) * 100 : null,
        currency: String(meta.currency ?? 'USD'),
        marketCap: null,
        volume: num(meta.regularMarketVolume),
        spark: downsample(closes),
        updatedAt: Date.now(),
      }
    } catch {
      return stockFallback(symbol)
    }
  })
}

export async function stockQuotes(tickers: string[]): Promise<Quote[]> {
  const results = await Promise.all(tickers.map((ticker) => stockQuote(ticker)))
  return results.filter((quote): quote is Quote => quote != null)
}

type YSearch = {
  quotes?: {
    symbol?: string
    shortname?: string
    longname?: string
    quoteType?: string
    exchDisp?: string
    exchange?: string
  }[]
}

export async function searchStocks(query: string, limit = 8): Promise<MarketHit[]> {
  if (!query.trim()) return []
  try {
    const body = await getJson<YSearch>(
      `${YF}/v1/finance/search?q=${encodeURIComponent(query.trim())}&quotesCount=${limit}&newsCount=0&listsCount=0`,
    )
    return (body.quotes ?? [])
      .filter((item) => item.symbol && ['EQUITY', 'ETF', 'INDEX', 'MUTUALFUND', 'CURRENCY', 'FUTURE'].includes(item.quoteType ?? ''))
      .slice(0, limit)
      .map((item) => ({
        ref: item.symbol!,
        ticker: item.symbol!,
        kind: 'stock' as const,
        name: item.longname ?? item.shortname ?? item.symbol!,
        exchange: item.exchDisp ?? item.exchange,
      }))
  } catch {
    return []
  }
}

/* ---------------------------------------------------------------- composed */

export async function searchMarkets(query: string): Promise<MarketHit[]> {
  const [coins, stocks] = await Promise.all([searchCoins(query, 6), searchStocks(query, 8)])
  const seen = new Set<string>()
  return [...coins, ...stocks].filter((hit) => {
    const key = `${hit.kind}:${hit.ref}`
    if (seen.has(key)) return false
    seen.add(key)
    return true
  })
}

export async function quotesForWatchlist(items: WatchItem[]): Promise<Quote[]> {
  const [coins, stocks] = await Promise.all([
    cryptoMarkets(items.filter((item) => item.kind === 'crypto').map((item) => item.ref)),
    stockQuotes(items.filter((item) => item.kind === 'stock').map((item) => item.ref)),
  ])
  const byRef = new Map<string, Quote>()
  for (const quote of coins) byRef.set(`crypto:${quote.ref}`, quote)
  for (const quote of stocks) byRef.set(`stock:${quote.ref.toUpperCase()}`, quote)
  return items.map(
    (item) =>
      byRef.get(`${item.kind}:${item.ref.toUpperCase()}`) ??
      byRef.get(`${item.kind}:${item.ref}`) ?? {
        ref: item.ref,
        ticker: item.kind === 'stock' ? item.ref.toUpperCase() : item.name,
        kind: item.kind,
        name: item.name,
        price: null,
        change: null,
        changePct: null,
        currency: 'USD',
        marketCap: null,
        volume: null,
        spark: [],
        updatedAt: Date.now(),
        degraded: true,
      },
  )
}

export async function quoteFor(symbol: string, kind?: MarketKind): Promise<Quote | null> {
  const query = symbol.trim()
  if (!query) return null
  if (kind !== 'stock') {
    const coin = await resolveCoin(query)
    const wanted = query.toLowerCase()
    const match = coin && (coin.ticker.toLowerCase() === wanted || coin.name.toLowerCase() === wanted || kind === 'crypto')
    if (match) {
      const quotes = await cryptoMarkets([coin.ref])
      if (quotes[0]) return quotes[0]
    }
  }
  if (kind === 'crypto') return null
  return (await stockQuotes([query.toUpperCase()]))[0] ?? null
}

type CgGlobal = {
  data?: {
    total_market_cap?: Record<string, number>
    total_volume?: Record<string, number>
    market_cap_percentage?: Record<string, number>
    market_cap_change_percentage_24h_usd?: number
  }
}

export async function marketOverview(): Promise<MarketOverview> {
  return cached('overview', TTL, async () => {
    const [indices, crypto, global] = await Promise.all([
      stockQuotes(['^GSPC', '^IXIC', '^DJI', '^RUT', '^VIX', '^TNX']),
      topCrypto(8),
      getJson<CgGlobal>(`${CG}/global`).catch(() => null),
    ])
    return {
      indices,
      crypto,
      global: global?.data
        ? {
            marketCap: num(global.data.total_market_cap?.usd),
            volume: num(global.data.total_volume?.usd),
            btcDominance: num(global.data.market_cap_percentage?.btc),
            change24h: num(global.data.market_cap_change_percentage_24h_usd),
          }
        : null,
      updatedAt: Date.now(),
    }
  })
}

/** One quote as a compact paragraph the model can reason over. */
export function describeQuote(quote: Quote): string {
  const pct = quote.changePct == null ? '—' : `${quote.changePct >= 0 ? '+' : ''}${quote.changePct.toFixed(2)}%`
  // The spark series is sampled before the live price (CoinGecko's 7-day series
  // for crypto, a month of daily closes for stocks), so a fast move can leave the
  // price outside its own series. Include it in the bounds: a range that excludes
  // the current price reads as a contradiction, and the model repeats it.
  // No series means no range at all: one price point is a range of zero width.
  const samples = quote.spark.length ? (quote.price == null ? quote.spark : [...quote.spark, quote.price]) : []
  const low = samples.length ? Math.min(...samples) : null
  const high = samples.length ? Math.max(...samples) : null
  const window = quote.kind === 'stock' ? '1mo range' : '7d range'
  // The quote carries its own currency: a London listing is GBp, a Paris one
  // EUR. Printing a dollar sign on those would be a false figure.
  const money = (value: number | null) => `${amount(value)} ${quote.currency}`
  return [
    `${quote.name} (${quote.ticker}) — ${quote.kind}`,
    `price ${money(quote.price)}`,
    `24h ${pct}`,
    quote.marketCap ? `market cap ${compact(quote.marketCap)}` : null,
    quote.volume ? `volume ${compact(quote.volume)}` : null,
    low != null && high != null ? `${window} ${money(low)}–${money(high)}` : null,
    quote.degraded ? 'source delayed' : null,
  ]
    .filter(Boolean)
    .join(' · ')
}
