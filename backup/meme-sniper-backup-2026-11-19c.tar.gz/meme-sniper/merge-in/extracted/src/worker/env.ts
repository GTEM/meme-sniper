import type { SessionUser } from '../shared/types'

export interface Env {
  ASSETS: Fetcher
  // Attached by Freebuff Sites once provisioned (sites_add_storage). Optional so
  // the app can explain what is missing instead of crashing.
  DB?: D1Database
  // The model API key. Locally from `.env`; on Sites from Sites → Secrets.
  // It is read here and nowhere else, and never leaves the Worker.
  OPENAI_API_KEY?: string
  // Optional override of the API origin; defaults to Groq's free tier.
  OPENAI_BASE_URL?: string
  // A second hosted provider, tried when the primary is rate-limited or out of
  // quota. Its own free tier, its own key.
  GEMINI_API_KEY?: string
  // Which provider the app talks to: 'groq' (default) or 'ollama'.
  AI_PROVIDER?: string
  // Where a rate-limited turn retries: 'ollama' (default, local, uncapped) or
  // 'none' to disable the fallback.
  FALLBACK_PROVIDER?: string
  // A local OpenAI-compatible runtime. No key needed unless it sits behind auth.
  OLLAMA_BASE_URL?: string
  OLLAMA_MODEL?: string
  OLLAMA_API_KEY?: string
  // Optional web search keys. Without either, search falls back to a keyless
  // DuckDuckGo/Wikipedia lookup.
  TAVILY_API_KEY?: string
  BRAVE_SEARCH_API_KEY?: string
  // Solana RPC for the Phantom wallet read. Defaults to the public mainnet
  // endpoint, which rate-limits; point this at your own node if you have one.
  SOLANA_RPC_URL?: string
  // Owner-run HTTP relay used when a venue blocks this Worker's region
  // (Binance answers 451 here). Contract: GET <relay>?url=<encoded target>.
  VENUE_RELAY_URL?: string
}

export type Variables = {
  /** The signed-in account, resolved from its session on every request. */
  user: SessionUser
  db: D1Database
}

export type AppContext = { Bindings: Env; Variables: Variables }
