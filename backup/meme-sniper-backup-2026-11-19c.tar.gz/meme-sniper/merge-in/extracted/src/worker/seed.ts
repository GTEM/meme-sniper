// A sample conversation for the local development user, so the app has
// something to show before an API key is configured. It is only ever written
// in development mode (see routes/account.ts); real accounts start empty.

import { DEFAULT_MODEL } from '../shared/config'
import { id, now, titleFrom } from './db'



const turns: [string, string][] = [
  [
    'What can you actually do that a normal chatbot cannot?',
    `Three things worth knowing.

**1. It reaches the live internet.** Ask for a specific page, a filing, a release or a breaking story and I search for it and read it, then answer from what I actually read. Sources come back as links.

**2. It has the tape.** Live equities, indices and crypto: prices, 24h moves, 30-day ranges, market cap, volume and dominance. Open **Markets**, add a ticker, and the row has a one-click analysis that hands the numbers to me.

**3. It remembers.** After a few replies I read the conversation back and keep the durable parts: your book, your risk appetite, the way you want answers. That lives in **Memory**, where you can read, edit or delete every line of it.

One limit only: no sexual content involving minors. Everything else is in scope.`,
  ],
  [
    'Give me the shape of a crypto trade you would actually take.',
    `Here is a structure rather than a prediction.

**The setup:** a large-cap with a clean 30-day range, an obvious invalidation level, and a catalyst inside two weeks.

**The trade:** half size at the range low, half on a reclaim of the mid. Stop under the range low, not under your entry. If the range is 12% wide, a 1.5% account risk gives you roughly an eighth of the book at the first entry.

**The invalidation:** not "it went down" — a close below the level that made the setup. If that prints, the thesis is wrong and the size comes off.

**What to watch:** funding, open interest and whether the move is spot-led. Ask me on the Markets page and I will pull the live numbers before we size it.`,
  ],
]

export function seedStatements(db: D1Database, owner: string) {
  // Dated yesterday, so it does not count toward today's replies. The id is
  // per account: a constant would collide with the sample chat of any other
  // account on the same database.
  const start = now() - 26 * 60 * 60_000
  const content = turns[0]![0]
  const conversationId = id()
  const statements = [
    db
      .prepare(`INSERT INTO conversations (id, owner_sub, title, model, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?)`)
      .bind(conversationId, owner, titleFrom(content), DEFAULT_MODEL, start, start + turns.length * 2 * 60_000),
  ]
  turns.forEach(([question, answer], i) => {
    const at = start + i * 2 * 60_000
    statements.push(
      db
        .prepare(`INSERT INTO messages (id, owner_sub, conversation_id, role, content, model, created_at) VALUES (?, ?, ?, 'user', ?, NULL, ?)`)
        .bind(id(), owner, conversationId, question, at),
      db
        .prepare(`INSERT INTO messages (id, owner_sub, conversation_id, role, content, model, created_at) VALUES (?, ?, ?, 'assistant', ?, ?, ?)`)
        .bind(id(), owner, conversationId, answer, DEFAULT_MODEL, at + 9_000),
    )
  })
  return statements
}
