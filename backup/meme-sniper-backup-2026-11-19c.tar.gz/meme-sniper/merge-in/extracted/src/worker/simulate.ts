// Walk-forward simulation of the fixed forecast scorecard on real candles.
//
// This answers "how would entering on my own rule have ended?" — every trade is
// decided at a bar close using only candles up to that bar, so nothing here
// peeks at the future. It is deliberately the same scorecard the forecasts use,
// not a tuned strategy: if it looks bad, that is the point of testing it.

import { analyseCandles, type Analysis } from './forecast'
import { memeSeries, type MemeSeries } from './solana'

export type SimReason = 'target' | 'stop' | 'signal' | 'timeout'

export type SimTrade = {
  entryAt: number
  exitAt: number
  entry: number
  exit: number
  /** Net of the round-trip cost below. */
  pct: number
  bars: number
  reason: SimReason
}

export type Simulation = {
  symbol: string
  timeframe: 'daily' | 'hourly'
  bars: number
  trades: SimTrade[]
  wins: number
  winRate: number | null
  avgPct: number | null
  totalPct: number
  avgBars: number | null
  medianBars: number | null
  bestPct: number | null
  worstPct: number | null
  maxDrawdownPct: number
  feePct: number
  current: {
    direction: Analysis['bias']['direction']
    score: number
    agree: number
    confidence: Analysis['bias']['confidence']
    price: number
    currency: string
    atrPct: number | null
    target: number | null
    stop: number | null
    expectedBars: number | null
  }
  note: string
}

export type SimOptions = {
  /** Exit multiple of ATR above entry. */
  targetAtr?: number
  /** Exit multiple of ATR below entry. */
  stopAtr?: number
  /** Bars before the position is closed regardless. */
  maxBars?: number
}

// Pool fee plus slippage on a thin Solana pool. Round trip, not per side.
const FEE_PCT = 1

const median = (values: number[]): number | null => {
  if (!values.length) return null
  const sorted = [...values].sort((a, b) => a - b)
  const middle = Math.floor(sorted.length / 2)
  return sorted.length % 2 ? sorted[middle]! : (sorted[middle - 1]! + sorted[middle]!) / 2
}

/**
 * Enter when the scorecard leans up by two or more points; leave on a fixed
 * ATR target, a fixed ATR stop, a flip to a down bias, or after `maxBars`.
 * Long only: the product does not offer shorts.
 */
export function simulateSeries(series: MemeSeries, options: SimOptions = {}): Simulation {
  const targetAtr = options.targetAtr ?? 2
  const stopAtr = options.stopAtr ?? 1
  const maxBars = options.maxBars ?? 20
  const { candles } = series

  const trades: SimTrade[] = []
  let open: { index: number; price: number } | null = null
  let equity = 100
  let peak = 100
  let maxDrawdownPct = 0

  // 60 bars is the earliest point where the 50-bar average and the roc20 are
  // both defined, so the rule is evaluated on the same inputs every time.
  for (let index = 60; index < candles.length; index++) {
    const candle = candles[index]!
    const analysis = analyseCandles({
      symbol: series.symbol,
      name: series.symbol,
      kind: 'crypto',
      currency: 'USD',
      price: candle.c,
      candles: candles.slice(0, index + 1),
      timeframe: series.timeframe,
      source: 'simulation',
    })
    const atrPct = analysis.volatility.atrPct ?? 2

    if (open) {
      const bars = index - open.index
      const target = open.price * (1 + (targetAtr * atrPct) / 100)
      const stop = open.price * (1 - (stopAtr * atrPct) / 100)
      let exit: { price: number; reason: SimReason } | null = null
      // When a single bar touches both levels, assume the stop filled first:
      // the pessimistic reading is the only honest one without tick data.
      if (candle.l <= stop) exit = { price: stop, reason: 'stop' }
      else if (candle.h >= target) exit = { price: target, reason: 'target' }
      else if (analysis.bias.direction === 'down') exit = { price: candle.c, reason: 'signal' }
      else if (bars >= maxBars) exit = { price: candle.c, reason: 'timeout' }

      if (exit) {
        const pct = ((exit.price - open.price) / open.price) * 100 - FEE_PCT
        trades.push({ entryAt: candles[open.index]!.t, exitAt: candle.t, entry: open.price, exit: exit.price, pct, bars, reason: exit.reason })
        equity *= 1 + pct / 100
        peak = Math.max(peak, equity)
        maxDrawdownPct = Math.min(maxDrawdownPct, ((equity - peak) / peak) * 100)
        open = null
      }
    } else if (analysis.bias.direction === 'up' && analysis.bias.score >= 2) {
      open = { index, price: candle.c }
    }
  }

  const latest = analyseCandles({
    symbol: series.symbol,
    name: `${series.symbol} (Solana)`,
    kind: 'crypto',
    currency: 'USD',
    price: series.price,
    candles,
    timeframe: series.timeframe,
    source: series.source,
  })
  const atrPct = latest.volatility.atrPct
  const bars = trades.map((trade) => trade.bars)
  const wins = trades.filter((trade) => trade.pct > 0).length

  return {
    symbol: series.symbol,
    timeframe: series.timeframe,
    bars: candles.length,
    trades,
    wins,
    winRate: trades.length ? (wins / trades.length) * 100 : null,
    avgPct: trades.length ? trades.reduce((sum, trade) => sum + trade.pct, 0) / trades.length : null,
    totalPct: equity - 100,
    avgBars: bars.length ? bars.reduce((sum, value) => sum + value, 0) / bars.length : null,
    medianBars: median(bars),
    bestPct: trades.length ? Math.max(...trades.map((trade) => trade.pct)) : null,
    worstPct: trades.length ? Math.min(...trades.map((trade) => trade.pct)) : null,
    maxDrawdownPct,
    feePct: FEE_PCT,
    current: {
      direction: latest.bias.direction,
      score: latest.bias.score,
      agree: latest.bias.agree,
      confidence: latest.bias.confidence,
      price: latest.price,
      currency: latest.currency,
      atrPct,
      target: atrPct == null ? null : latest.price * (1 + (targetAtr * atrPct) / 100),
      stop: atrPct == null ? null : latest.price * (1 - (stopAtr * atrPct) / 100),
      expectedBars: median(bars),
    },
    note: series.note,
  }
}

export async function simulateMeme(mint: string, options: SimOptions = {}): Promise<Simulation> {
  return simulateSeries(await memeSeries(mint), options)
}

const money = (value: number | null): string => (value == null ? 'n/a' : value < 0.01 ? value.toPrecision(4) : value.toFixed(6).replace(/0+$/, ''))
const pct = (value: number | null): string => (value == null ? 'n/a' : `${value >= 0 ? '+' : ''}${value.toFixed(2)}%`)

/** The block the model receives. Results first, then the current read. */
export function describeSimulation(sim: Simulation): string {
  const unit = sim.timeframe === 'hourly' ? 'hours' : 'days'
  const lines = [
    `BACKTEST — ${sim.symbol}, ${sim.bars} ${sim.timeframe} candles, ${sim.feePct}% round-trip cost`,
    'rule: enter when the fixed scorecard is up by 2+ points; exit on a 2×ATR target, a 1×ATR stop, a flip to a down scorecard, or 20 bars',
    `trades ${sim.trades.length} · wins ${sim.wins}${sim.winRate == null ? '' : ` (${sim.winRate.toFixed(0)}%)`} · average ${pct(sim.avgPct)} · total ${pct(sim.totalPct)} · max drawdown ${pct(sim.maxDrawdownPct)}`,
    `best ${pct(sim.bestPct)} · worst ${pct(sim.worstPct)} · average hold ${sim.avgBars == null ? 'n/a' : sim.avgBars.toFixed(1)} ${unit} · median hold ${sim.medianBars == null ? 'n/a' : sim.medianBars} ${unit}`,
    '',
    'CURRENT READ (same rule, latest candle)',
    `scorecard ${sim.current.direction.toUpperCase()} · ${sim.current.score > 0 ? '+' : ''}${sim.current.score} of ${sim.current.agree} scored · confidence ${sim.current.confidence}`,
    `price ${money(sim.current.price)} ${sim.current.currency} · ATR ${pct(sim.current.atrPct)} of price`,
    `mechanical target ${money(sim.current.target)} · mechanical stop ${money(sim.current.stop)}`,
    `expected hold ${sim.current.expectedBars == null ? 'n/a' : `${sim.current.expectedBars} ${unit}`} (median of the simulated trades)`,
  ]
  if (sim.trades.length < 5) lines.push('', `NOTE: only ${sim.trades.length} trades in ${sim.bars} candles — too small a sample to draw a conclusion from.`)
  if (sim.note) lines.push('', `NOTE: ${sim.note}`)
  lines.push('', 'Say plainly that this is a historical simulation, not a prediction, and that the sample is small.')
  return lines.join('\n').slice(0, 2_400)
}
