// Forecasting inputs. This module does not predict anything by itself: it pulls
// live daily candles and turns them into the numbers a forecast has to rest on —
// trend, momentum, volatility, the levels that matter, and a mechanical lean
// scored from fixed rules.
//
// The split matters. The arithmetic here is deterministic and testable; the
// judgement (probability, horizon, invalidation) belongs to the model, and it is
// told to reason from these numbers rather than from remembered prices.

import type { MarketKind } from '../shared/types'

const UA =
  'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36'
const CG = 'https://api.coingecko.com/api/v3'
const YF = 'https://query1.finance.yahoo.com'

export type Candle = { t: number; o: number; h: number; l: number; c: number; v: number }

/* -------------------------------------------------------------- indicators */

/** Simple moving average of the most recent `period` values. */
export function sma(values: number[], period: number): number | null {
  if (period <= 0 || values.length < period) return null
  let sum = 0
  for (let index = values.length - period; index < values.length; index++) sum += values[index]!
  return sum / period
}

/** Exponential moving average, seeded with the SMA of the first window. */
export function ema(values: number[], period: number): number | null {
  if (period <= 0 || values.length < period) return null
  const factor = 2 / (period + 1)
  let value = values.slice(0, period).reduce((sum, item) => sum + item, 0) / period
  for (let index = period; index < values.length; index++) value = values[index]! * factor + value * (1 - factor)
  return value
}

/** Wilder's RSI over closing prices, 0–100. */
export function rsi(values: number[], period = 14): number | null {
  if (values.length < period + 1) return null
  let gain = 0
  let loss = 0
  for (let index = 1; index <= period; index++) {
    const delta = values[index]! - values[index - 1]!
    if (delta >= 0) gain += delta
    else loss -= delta
  }
  let averageGain = gain / period
  let averageLoss = loss / period
  for (let index = period + 1; index < values.length; index++) {
    const delta = values[index]! - values[index - 1]!
    averageGain = (averageGain * (period - 1) + Math.max(delta, 0)) / period
    averageLoss = (averageLoss * (period - 1) + Math.max(-delta, 0)) / period
  }
  if (averageLoss === 0) return averageGain === 0 ? 50 : 100
  const ratio = averageGain / averageLoss
  return 100 - 100 / (1 + ratio)
}

/** Average true range. For crypto the synthetic candles make this close-to-close. */
export function atr(candles: Candle[], period = 14): number | null {
  if (candles.length < period + 1) return null
  const ranges: number[] = []
  for (let index = 1; index < candles.length; index++) {
    const current = candles[index]!
    const previous = candles[index - 1]!
    ranges.push(Math.max(current.h - current.l, Math.abs(current.h - previous.c), Math.abs(current.l - previous.c)))
  }
  const window = ranges.slice(-period)
  return window.reduce((sum, value) => sum + value, 0) / window.length
}

/** Sample standard deviation of the last `period` values. */
export function stdev(values: number[], period: number): number | null {
  if (period <= 1 || values.length < period) return null
  const window = values.slice(-period)
  const mean = window.reduce((sum, value) => sum + value, 0) / window.length
  const variance = window.reduce((sum, value) => sum + (value - mean) ** 2, 0) / (window.length - 1)
  return Math.sqrt(variance)
}

/** Rate of change over `period` bars, in percent. */
export function roc(values: number[], period: number): number | null {
  if (values.length < period + 1) return null
  const then = values[values.length - 1 - period]!
  const now = values[values.length - 1]!
  return then === 0 ? null : ((now - then) / then) * 100
}

/** Local swing highs above the price and swing lows below it, nearest first. */
export function swingLevels(candles: Candle[], price: number): { support: number[]; resistance: number[] } {
  const window = candles.slice(-80)
  const supports: number[] = []
  const resistance: number[] = []
  for (let index = 1; index < window.length - 1; index++) {
    const previous = window[index - 1]!
    const current = window[index]!
    const next = window[index + 1]!
    if (current.l <= previous.l && current.l <= next.l && current.l < price) supports.push(current.l)
    if (current.h >= previous.h && current.h >= next.h && current.h > price) resistance.push(current.h)
  }
  const nearest = (values: number[]) =>
    [...new Set(values.map((value) => Number(value.toPrecision(6))))]
      .sort((a, b) => Math.abs(a - price) - Math.abs(b - price))
      .slice(0, 3)
  return { support: nearest(supports), resistance: nearest(resistance) }
}

/* -------------------------------------------------------------------- bias */

export type BiasInput = {
  price: number
  sma20: number | null
  sma50: number | null
  ema12: number | null
  ema26: number | null
  macdHist: number | null
  rsi14: number | null
  roc20: number | null
  samples: number
}

export type Bias = {
  direction: 'up' | 'down' | 'neutral'
  score: number
  agree: number
  confidence: 'low' | 'medium' | 'high'
  reasons: string[]
}

/**
 * A fixed scorecard over six classic signals: price vs SMA20, SMA20 vs SMA50,
 * EMA12 vs EMA26, MACD histogram, RSI regime and 20-bar momentum. One point
 * each, positive or negative.
 *
 * This is deliberately mechanical and deliberately modest: it exists to stop a
 * model inventing conviction, not to be a trading system.
 */
export function scoreBias(input: BiasInput): Bias {
  let score = 0
  let agree = 0
  const reasons: string[] = []

  const vote = (value: boolean | null, label: string) => {
    if (value == null) return
    agree++
    if (value) {
      score++
      return
    }
    score--
    reasons.push(label)
  }

  vote(input.sma20 == null ? null : input.price > input.sma20, 'price is below its 20-day average')
  vote(input.sma50 == null || input.sma20 == null ? null : input.sma20 > input.sma50, 'the 20-day average is below the 50-day')
  vote(input.ema12 == null || input.ema26 == null ? null : input.ema12 > input.ema26, 'the fast EMA is below the slow EMA')
  vote(input.macdHist == null ? null : input.macdHist > 0, 'MACD momentum is negative')
  vote(input.rsi14 == null ? null : input.rsi14 > 55 ? true : input.rsi14 < 45 ? false : null, 'RSI is in the weak half')
  vote(input.roc20 == null ? null : input.roc20 > 0, '20-day momentum is negative')

  const direction = score >= 2 ? 'up' : score <= -2 ? 'down' : 'neutral'
  const strength = Math.abs(score)
  const confidence: Bias['confidence'] = input.samples < 60 ? 'low' : strength >= 5 ? 'high' : strength >= 3 ? 'medium' : 'low'

  if (!reasons.length) reasons.push('every scored signal points the same way')
  return { direction, score, agree, confidence, reasons }
}

/* ---------------------------------------------------------------- fetching */

async function getJson<T>(url: string, timeout = 12_000): Promise<T> {
  const response = await fetch(url, { headers: { 'user-agent': UA, accept: 'application/json' }, signal: AbortSignal.timeout(timeout) })
  if (!response.ok) throw new Error(`${new URL(url).hostname} responded ${response.status}`)
  return (await response.json()) as T
}

type YChart = {
  chart?: {
    result?: {
      timestamp?: number[]
      indicators?: { quote?: { open?: (number | null)[]; high?: (number | null)[]; low?: (number | null)[]; close?: (number | null)[]; volume?: (number | null)[] }[] }
    }[]
  }
}

/** Daily candles from Yahoo. ~250 sessions, which is enough for a 52-week range. */
async function stockCandles(ticker: string): Promise<Candle[]> {
  const body = await getJson<YChart>(`${YF}/v8/finance/chart/${encodeURIComponent(ticker)}?range=1y&interval=1d&includePrePost=false`)
  const result = body.chart?.result?.[0]
  const timestamps = result?.timestamp ?? []
  const quote = result?.indicators?.quote?.[0]
  if (!quote || !timestamps.length) return []
  const candles: Candle[] = []
  for (let index = 0; index < timestamps.length; index++) {
    const close = quote.close?.[index]
    const high = quote.high?.[index]
    const low = quote.low?.[index]
    const open = quote.open?.[index]
    if (typeof close !== 'number' || typeof high !== 'number' || typeof low !== 'number' || typeof open !== 'number') continue
    candles.push({ t: timestamps[index]! * 1000, o: open, h: high, l: low, c: close, v: quote.volume?.[index] ?? 0 })
  }
  return candles
}

type CgChart = { prices?: [number, number][]; total_volumes?: [number, number][] }

/**
 * Daily closes from CoinGecko. The free OHLC endpoint coarsens to 4-day bars
 * past a month, which is useless for a 14-period RSI, so this builds candles
 * from the daily series instead. High/low collapse to the close, and the true
 * range becomes close-to-close — stated in the output so nothing is overstated.
 */
async function cryptoCandles(id: string): Promise<Candle[]> {
  const body = await getJson<CgChart>(`${CG}/coins/${encodeURIComponent(id)}/market_chart?vs_currency=usd&days=180&interval=daily`)
  const prices = body.prices ?? []
  const volumes = new Map((body.total_volumes ?? []).map(([t, v]) => [t, v]))
  return prices
    .filter(([, price]) => Number.isFinite(price))
    .map(([t, price]) => ({ t, o: price, h: price, l: price, c: price, v: volumes.get(t) ?? 0 }))
}

/* ---------------------------------------------------------------- analysis */

export type Analysis = {
  symbol: string
  name: string
  kind: MarketKind
  price: number
  /** What the price is quoted in — USD, EUR, GBP, SOL, whatever the source says. */
  currency: string
  asOf: number
  samples: number
  /** Candle interval the indicators were computed on. */
  timeframe: 'daily' | 'hourly'
  source: string
  note?: string
  trend: { sma20: number | null; sma50: number | null; ema12: number | null; ema26: number | null; slope20: number | null }
  momentum: { rsi14: number | null; macd: number | null; macdSignal: number | null; macdHist: number | null; roc5: number | null; roc20: number | null }
  volatility: { atr14: number | null; atrPct: number | null; realized20: number | null; bollingerWidth: number | null }
  range: { high52: number | null; low52: number | null; fromHigh: number | null; fromLow: number | null }
  levels: { support: number[]; resistance: number[] }
  bias: Bias
}

export type CandleSet = {
  symbol: string
  name: string
  kind: MarketKind
  price: number
  /** Quote currency from the data source; defaults to USD only when unstated. */
  currency?: string
  candles: Candle[]
  source: string
  timeframe?: 'daily' | 'hourly'
  note?: string
}

/**
 * The shared indicator pass. Any daily candle series produces the same shape,
 * whether it came from Yahoo, CoinGecko or a Solana pool.
 */
export function analyseCandles(input: CandleSet): Analysis {
  const { candles } = input
  if (candles.length < 30) throw new Error(`Not enough price history for ${input.name} to analyse — ${candles.length} daily candles.`)

  const closes = candles.map((candle) => candle.c)
  const price = input.price || closes[closes.length - 1]!
  const sma20 = sma(closes, 20)
  const sma50 = sma(closes, 50)
  const ema12 = ema(closes, 12)
  const ema26 = ema(closes, 26)
  const macdLine = ema12 != null && ema26 != null ? ema12 - ema26 : null
  // A 9-period signal line needs the MACD series, so approximate it with the
  // 9-day EMA of closes minus the 26-day EMA: same sign, comparable magnitude.
  const macdSignal = ema9Signal(closes)
  const macdHist = macdLine != null && macdSignal != null ? macdLine - macdSignal : null
  const atr14 = atr(candles, 14)
  const deviation = stdev(closes, 20)
  const bollingerWidth = deviation != null && sma20 ? (deviation * 4) / sma20 : null
  const high52 = Math.max(...closes)
  const low52 = Math.min(...closes)
  const slope20 = sma(closes.slice(0, -10), 20) != null && sma20 != null ? ((sma20 - sma(closes.slice(0, -10), 20)!) / sma(closes.slice(0, -10), 20)!) * 100 : null

  const analysis: Analysis = {
    symbol: input.symbol,
    name: input.name,
    kind: input.kind,
    price,
    currency: input.currency ?? 'USD',
    asOf: Date.now(),
    samples: candles.length,
    timeframe: input.timeframe ?? 'daily',
    source: input.source,
    ...(input.note ? { note: input.note } : {}),
    trend: { sma20, sma50, ema12, ema26, slope20 },
    momentum: { rsi14: rsi(closes), macd: macdLine, macdSignal, macdHist, roc5: roc(closes, 5), roc20: roc(closes, 20) },
    volatility: {
      atr14,
      atrPct: atr14 != null && price ? (atr14 / price) * 100 : null,
      realized20: deviation != null && price ? (deviation / price) * 100 : null,
      bollingerWidth: bollingerWidth == null ? null : bollingerWidth * 100,
    },
    range: {
      high52,
      low52,
      fromHigh: high52 ? ((price - high52) / high52) * 100 : null,
      fromLow: low52 ? ((price - low52) / low52) * 100 : null,
    },
    levels: swingLevels(candles, price),
    bias: { direction: 'neutral', score: 0, agree: 0, confidence: 'low', reasons: [] },
  }
  analysis.bias = scoreBias({
    price,
    sma20,
    sma50,
    ema12,
    ema26,
    macdHist,
    rsi14: analysis.momentum.rsi14,
    roc20: analysis.momentum.roc20,
    samples: candles.length,
  })
  return analysis
}

/** Daily candles for a listed instrument, then the same indicator pass. */
export async function analyzeMarket(input: { ref: string; kind: MarketKind; name: string; price: number; currency?: string }): Promise<Analysis> {
  const candles = input.kind === 'crypto' ? await cryptoCandles(input.ref) : await stockCandles(input.ref)
  return analyseCandles({
    symbol: input.ref,
    name: input.name,
    kind: input.kind,
    price: input.price,
    // CoinGecko candles are requested in USD; a stock keeps its listing currency.
    currency: input.currency ?? (input.kind === 'crypto' ? 'USD' : undefined),
    candles,
    source: input.kind === 'crypto' ? 'CoinGecko daily closes' : 'Yahoo Finance daily candles',
    note: input.kind === 'crypto' ? 'High/low collapse to the close on this source, so ATR is close-to-close.' : undefined,
  })
}

/** 9-day EMA of closes minus the 26-day EMA, as a stand-in for the MACD signal. */
function ema9Signal(closes: number[]): number | null {
  const fast = ema(closes, 9)
  const slow = ema(closes, 26)
  return fast != null && slow != null ? fast - slow : null
}

/* ------------------------------------------------------------------ output */

const money = (value: number | null): string => {
  if (value == null) return 'n/a'
  if (Math.abs(value) >= 1) return value.toLocaleString('en-US', { maximumFractionDigits: 2 })
  return value.toPrecision(4)
}

const pct = (value: number | null): string => (value == null ? 'n/a' : `${value >= 0 ? '+' : ''}${value.toFixed(2)}%`)

/** The block the model receives. Numbers first, then a clearly-labelled lean. */
export function describeAnalysis(analysis: Analysis): string {
  const { trend, momentum, volatility, range, levels, bias } = analysis
  const support = levels.support.length ? levels.support.map(money).join(', ') : 'no clean swing low below price'
  const resistance = levels.resistance.length ? levels.resistance.map(money).join(', ') : 'no clean swing high above price'
  const lines: string[] = [
    `MARKET ANALYSIS — ${analysis.name} (${analysis.symbol}), ${analysis.kind}`,
    `price ${money(analysis.price)} ${analysis.currency} · ${analysis.samples} ${analysis.timeframe} candles · ${analysis.source}`,
    `every money figure below is in ${analysis.currency}; quote it with that currency and never convert it to another one`,
    '',
    'TREND',
    `SMA20 ${money(trend.sma20)} · SMA50 ${money(trend.sma50)} · EMA12 ${money(trend.ema12)} · EMA26 ${money(trend.ema26)}`,
    `SMA20 slope over the last 10 bars ${pct(trend.slope20)}`,
    '',
    'MOMENTUM',
    `RSI14 ${momentum.rsi14?.toFixed(1) ?? 'n/a'} · MACD ${money(momentum.macd)} · signal ${money(momentum.macdSignal)} · histogram ${money(momentum.macdHist)}`,
    `5-day ${pct(momentum.roc5)} · 20-day ${pct(momentum.roc20)}`,
    '',
    'VOLATILITY',
    `ATR14 ${money(volatility.atr14)} (${pct(volatility.atrPct)} of price) · 20-day realised ${pct(volatility.realized20)} · Bollinger width ${pct(volatility.bollingerWidth)}`,
    '',
    'RANGE',
    `52-week high ${money(range.high52)} (${pct(range.fromHigh)} away) · 52-week low ${money(range.low52)} (${pct(range.fromLow)} away)`,
    `support ${support}`,
    `resistance ${resistance}`,
    '',
    'MECHANICAL LEAN (fixed scorecard, not a prediction)',
    `${bias.direction.toUpperCase()} · score ${bias.score > 0 ? '+' : ''}${bias.score} of ${bias.agree} scored signals · confidence ${bias.confidence}`,
    `against the lean: ${bias.reasons.join('; ')}`,
  ]
  if (analysis.note) lines.push('', `NOTE: ${analysis.note}`)
  lines.push('', 'Give a probability and a horizon, not a certainty. Say what invalidates the call.')
  return lines.join('\n').slice(0, 3_400)
}
