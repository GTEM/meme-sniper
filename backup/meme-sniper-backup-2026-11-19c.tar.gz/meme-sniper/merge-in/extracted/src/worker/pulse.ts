// Live order flow for a Solana token, including ones too young to chart.
//
// A fresh launch has no candle series worth analysing, but it does have buy and
// sell counts, volume in short windows, pool depth and age. This reports those,
// and it separates three states that look alike in a 24h summary but mean very
// different things: a launch still trading, a launch that already died, and a
// pool that never had depth to begin with.

const DEX = 'https://api.dexscreener.com'
const UA = 'Mozilla/5.0 (compatible; Ulvarin/1.0)'

type TxnWindow = { buys?: number; sells?: number }

type Pair = {
  dexId?: string
  pairAddress?: string
  baseToken?: { address?: string; symbol?: string; name?: string }
  priceUsd?: string
  priceChange?: { m5?: number; h1?: number; h6?: number; h24?: number }
  volume?: { m5?: number; h1?: number; h6?: number; h24?: number }
  txns?: { m5?: TxnWindow; h1?: TxnWindow; h6?: TxnWindow; h24?: TxnWindow }
  liquidity?: { usd?: number }
  fdv?: number
  marketCap?: number
  pairCreatedAt?: number
}

export type Window = { buys: number; sells: number }

export type Pulse = {
  mint: string
  symbol: string
  name: string | null
  dexId: string | null
  pool: string | null
  price: number | null
  ageHours: number | null
  /** Summed across every indexed pool. 0 means the pools hold nothing, not "unknown". */
  liquidityUsd: number | null
  /** Where the depth figure came from, so the number carries its own caveat. */
  liquiditySource: string
  poolCount: number
  marketCapUsd: number | null
  liquidityToMarketCapPct: number | null
  change: { m5: number | null; h1: number | null; h6: number | null; h24: number | null }
  volume: { m5: number | null; h1: number | null; h6: number | null; h24: number | null }
  txns: { m5: Window | null; h1: Window | null; h24: Window | null }
}

const num = (value: unknown): number | null => {
  const parsed = typeof value === 'number' ? value : typeof value === 'string' ? Number(value) : NaN
  return Number.isFinite(parsed) ? parsed : null
}

/** A window with no trades is `null`, not a zeroed window: no trade is data too. */
const window = (txn: TxnWindow | undefined): Window | null => {
  if (!txn) return null
  const buys = num(txn.buys) ?? 0
  const sells = num(txn.sells) ?? 0
  return buys + sells > 0 ? { buys, sells } : null
}

/**
 * Total reserve across every indexed pool. DexScreener's token endpoint only
 * returns the pools it chooses to, so reading depth from it can call a deep token
 * thin because its deepest book was not in the list.
 */
async function geckoDepth(mint: string): Promise<number | null> {
  const response = await fetch(`https://api.geckoterminal.com/api/v2/networks/solana/tokens/${mint}`, {
    headers: { accept: 'application/json', 'user-agent': UA },
    signal: AbortSignal.timeout(10_000),
  }).catch(() => null)
  if (!response?.ok) return null
  const body = (await response.json().catch(() => null)) as { data?: { attributes?: Record<string, unknown> } } | null
  return num(body?.data?.attributes?.total_reserve_in_usd)
}

/** Live flow for one mint, summed across every pool it trades in. */
export async function memePulse(mint: string): Promise<Pulse> {
  const response = await fetch(`${DEX}/tokens/v1/solana/${encodeURIComponent(mint)}`, {
    headers: { accept: 'application/json', 'user-agent': UA },
    signal: AbortSignal.timeout(12_000),
  }).catch(() => null)
  if (!response?.ok) throw new Error(`DexScreener did not answer for that mint (HTTP ${response?.status ?? 'no response'}).`)
  const pairs = ((await response.json().catch(() => [])) as Pair[]) ?? []
  const own = pairs
    .filter((pair) => pair.baseToken?.address === mint)
    .sort((a, b) => (num(b.liquidity?.usd) ?? 0) - (num(a.liquidity?.usd) ?? 0))
  const best = own[0]
  if (!best) throw new Error('No trading pair on DexScreener lists that mint as its base token.')

  // Depth is what an exit actually meets, so it is summed across pools. A pool
  // reporting 0 is reported as 0: calling it "unknown" would hide a pool that
  // cannot be exited at all.
  const reported = own.map((pair) => num(pair.liquidity?.usd)).filter((value): value is number => value != null)
  const pooled = reported.length ? reported.reduce((sum, value) => sum + value, 0) : null
  const aggregate = await geckoDepth(mint).catch(() => null)
  const liquidityUsd = aggregate ?? pooled
  const liquiditySource = aggregate != null ? 'GeckoTerminal, all indexed pools' : 'DexScreener, the pools it returned'
  const marketCapUsd = num(best.marketCap) ?? num(best.fdv)
  const created = num(best.pairCreatedAt)
  return {
    mint,
    symbol: best.baseToken?.symbol ?? mint.slice(0, 4),
    name: best.baseToken?.name ?? null,
    dexId: best.dexId ?? null,
    pool: best.pairAddress ?? null,
    price: num(best.priceUsd),
    ageHours: created == null ? null : (Date.now() - created) / 3_600_000,
    liquidityUsd,
    liquiditySource,
    poolCount: own.length,
    marketCapUsd,
    liquidityToMarketCapPct: liquidityUsd != null && marketCapUsd ? (liquidityUsd / marketCapUsd) * 100 : null,
    change: {
      m5: num(best.priceChange?.m5),
      h1: num(best.priceChange?.h1),
      h6: num(best.priceChange?.h6),
      h24: num(best.priceChange?.h24),
    },
    volume: {
      m5: num(best.volume?.m5),
      h1: num(best.volume?.h1),
      h6: num(best.volume?.h6),
      h24: num(best.volume?.h24),
    },
    txns: { m5: window(best.txns?.m5), h1: window(best.txns?.h1), h24: window(best.txns?.h24) },
  }
}

export type FlowRead = {
  pressure: 'buyers' | 'sellers' | 'balanced' | 'none'
  /** Which window the pressure was measured over. */
  basis: '1h' | '24h' | null
  acceleration: number | null
  dormant: boolean
  note: string
}

/**
 * Who is in control and whether volume is behind them. Acceleration compares the
 * last hour with the token's own 24-hour hourly average, so a launch is measured
 * against itself rather than an arbitrary figure. When there is no recent trade,
 * the 24h split is reported as history rather than as current pressure.
 */
export function flowRead(pulse: Pulse): FlowRead {
  const h1 = pulse.txns.h1
  const h24 = pulse.txns.h24
  const h1Volume = pulse.volume.h1 ?? 0
  const h6Volume = pulse.volume.h6 ?? 0
  const h24Volume = pulse.volume.h24
  const acceleration = pulse.volume.h1 != null && h24Volume != null && h24Volume > 0 ? h1Volume / (h24Volume / 24) : null
  const dormant = h1Volume === 0 && h6Volume === 0 && (h24Volume ?? 0) > 0

  if (!h1 && !h24) {
    return { pressure: 'none', basis: null, acceleration, dormant, note: 'no trades are reported for this pair at all' }
  }

  const basis: '1h' | '24h' = h1 ? '1h' : '24h'
  const book = (h1 ?? h24)!
  const share = book.buys / (book.buys + book.sells)
  const pressure: FlowRead['pressure'] = share >= 0.6 ? 'buyers' : share <= 0.4 ? 'sellers' : 'balanced'

  if (dormant) {
    return {
      pressure,
      basis,
      acceleration,
      dormant,
      note: `no volume in the last 6 hours — this pool has gone quiet, and the 24h move is already over (24h split: ${h24!.buys} buys / ${h24!.sells} sells)`,
    }
  }
  if (!h1) {
    return {
      pressure,
      basis,
      acceleration,
      dormant,
      note: `no trades in the last hour, so there is no live pressure; the 24h split was ${h24!.buys} buys / ${h24!.sells} sells`,
    }
  }

  let note: string
  if (pressure === 'buyers' && acceleration != null && acceleration >= 1.5) note = 'buyers are in control and volume is accelerating'
  else if (pressure === 'sellers' && acceleration != null && acceleration >= 1.5) note = 'sellers dominate while volume accelerates — that is distribution, not accumulation'
  else if (pressure === 'buyers') note = 'buyers dominate, but volume is not accelerating'
  else if (pressure === 'sellers') note = 'sellers dominate'
  else note = 'flow is balanced — neither side has control'
  if (acceleration != null && acceleration < 0.5) note += '; volume is fading against its own hourly average'

  return { pressure, basis, acceleration, dormant, note }
}

export function describePulse(pulse: Pulse): string {
  const read = flowRead(pulse)
  // A sub-cent price rounded to two decimals reads as zero, which would make a
  // live quote look like a dead one.
  const money = (value: number | null) =>
    value == null
      ? 'n/a'
      : value >= 1_000_000
        ? `$${(value / 1_000_000).toFixed(2)}M`
        : value >= 1_000
          ? `$${(value / 1_000).toFixed(1)}K`
          : value >= 1
            ? `$${value.toFixed(2)}`
            : `$${value.toPrecision(3)}`
  const pct = (value: number | null) => (value == null ? 'n/a' : `${value >= 0 ? '+' : ''}${value.toFixed(1)}%`)
  const age = pulse.ageHours == null ? 'age unknown' : pulse.ageHours < 48 ? `${pulse.ageHours.toFixed(1)}h old` : `${(pulse.ageHours / 24).toFixed(1)}d old`
  const trades = pulse.txns.h1
    ? `trades 1h: ${pulse.txns.h1.buys} buys / ${pulse.txns.h1.sells} sells`
    : pulse.txns.h24
      ? `trades 1h: none · 24h: ${pulse.txns.h24.buys} buys / ${pulse.txns.h24.sells} sells`
      : 'trade counts: not reported by the feed'
  const lines = [
    `ORDER FLOW — ${pulse.symbol}${pulse.name && pulse.name !== pulse.symbol ? ` (${pulse.name})` : ''} · ${age} · ${pulse.dexId ?? 'unknown venue'}`,
    `price ${money(pulse.price)} USD · liquidity ${money(pulse.liquidityUsd)} (${pulse.liquiditySource})${
      pulse.liquidityToMarketCapPct == null ? '' : ` · ${pulse.liquidityToMarketCapPct.toFixed(2)}% of market cap`
    } · market cap ${money(pulse.marketCapUsd)}`,
    `moves: 5m ${pct(pulse.change.m5)} · 1h ${pct(pulse.change.h1)} · 6h ${pct(pulse.change.h6)} · 24h ${pct(pulse.change.h24)}`,
    `volume: 5m ${money(pulse.volume.m5)} · 1h ${money(pulse.volume.h1)} · 24h ${money(pulse.volume.h24)}`,
    trades,
    `READ — ${read.note}${read.acceleration == null || read.dormant ? '' : ` (1h volume is ${read.acceleration.toFixed(1)}× the token's own 24h hourly average)`}`,
  ]
  if (pulse.liquidityUsd === 0) lines.push('CAUTION — the pools report $0 of liquidity: there is no bid to exit into, whatever the price says.')
  else if (pulse.liquidityToMarketCapPct != null && pulse.liquidityToMarketCapPct < 2)
    lines.push('CAUTION — liquidity is under 2% of market cap: one exit can move the price hard.')
  if (read.dormant) lines.push('CAUTION — do not buy a quiet pool on the strength of its 24h figure; the volume that produced it has stopped.')
  if (pulse.ageHours != null && pulse.ageHours < 24) lines.push('NOTE — this pool is under a day old, so there is no candle series to chart. This is a flow read, not a trend read.')
  lines.push('', 'Build the call from these numbers and say it is flow-based. A scalp here invalidates quickly. Never describe a token as safe.')
  return lines.join('\n').slice(0, 2_400)
}
