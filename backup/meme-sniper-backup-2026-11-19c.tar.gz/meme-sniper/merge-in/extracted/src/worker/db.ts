import type { MiddlewareHandler } from 'hono'

import type { Conversation, Memory, MemoryKind, Message, Settings } from '../shared/types'
import type { AppContext } from './env'

// Schema lives with the Worker: D1 has no migration tool on Freebuff Sites, so
// tables are created on the first request of each isolate. Add new statements
// at the end; never edit existing ones in place once deployed.
const SCHEMA = [
  `CREATE TABLE IF NOT EXISTS users (
    owner_sub TEXT PRIMARY KEY,
    created_at INTEGER NOT NULL
  )`,
  `CREATE TABLE IF NOT EXISTS conversations (
    id TEXT PRIMARY KEY,
    owner_sub TEXT NOT NULL,
    title TEXT NOT NULL,
    model TEXT NOT NULL,
    created_at INTEGER NOT NULL,
    updated_at INTEGER NOT NULL
  )`,
  `CREATE INDEX IF NOT EXISTS conversations_owner ON conversations(owner_sub, updated_at DESC)`,
  `CREATE TABLE IF NOT EXISTS messages (
    id TEXT PRIMARY KEY,
    owner_sub TEXT NOT NULL,
    conversation_id TEXT NOT NULL,
    role TEXT NOT NULL,
    content TEXT NOT NULL,
    model TEXT,
    interrupted INTEGER NOT NULL DEFAULT 0,
    created_at INTEGER NOT NULL
  )`,
  `CREATE INDEX IF NOT EXISTS messages_conversation ON messages(owner_sub, conversation_id, created_at)`,
  // The daily usage count: replies generated per owner per day.
  `CREATE INDEX IF NOT EXISTS messages_owner_role_created ON messages(owner_sub, role, created_at)`,
  // Long-term memory: what the platform has learned about its user.
  `CREATE TABLE IF NOT EXISTS memories (
    id TEXT PRIMARY KEY,
    owner_sub TEXT NOT NULL,
    kind TEXT NOT NULL,
    content TEXT NOT NULL,
    tags TEXT NOT NULL DEFAULT '',
    source TEXT NOT NULL DEFAULT 'chat',
    conversation_id TEXT,
    confidence REAL NOT NULL DEFAULT 0.7,
    uses INTEGER NOT NULL DEFAULT 0,
    created_at INTEGER NOT NULL,
    updated_at INTEGER NOT NULL,
    last_used_at INTEGER
  )`,
  `CREATE INDEX IF NOT EXISTS memories_owner ON memories(owner_sub, updated_at DESC)`,
  `CREATE TABLE IF NOT EXISTS user_settings (
    owner_sub TEXT PRIMARY KEY,
    persona TEXT NOT NULL DEFAULT '',
    auto_learn INTEGER NOT NULL DEFAULT 1,
    web_access INTEGER NOT NULL DEFAULT 1,
    market_access INTEGER NOT NULL DEFAULT 1,
    created_at INTEGER NOT NULL,
    updated_at INTEGER NOT NULL
  )`,
  `CREATE TABLE IF NOT EXISTS watchlist (
    id TEXT PRIMARY KEY,
    owner_sub TEXT NOT NULL,
    symbol TEXT NOT NULL,
    kind TEXT NOT NULL,
    name TEXT NOT NULL,
    created_at INTEGER NOT NULL,
    UNIQUE(owner_sub, symbol)
  )`,
  `CREATE TABLE IF NOT EXISTS learning_runs (
    id TEXT PRIMARY KEY,
    owner_sub TEXT NOT NULL,
    learned INTEGER NOT NULL,
    scanned INTEGER NOT NULL,
    created_at INTEGER NOT NULL
  )`,
  `CREATE INDEX IF NOT EXISTS learning_runs_owner ON learning_runs(owner_sub, created_at DESC)`,
  // Local accounts. The first account created is the owner and admits the rest.
  `CREATE TABLE IF NOT EXISTS accounts (
    id TEXT PRIMARY KEY,
    email TEXT NOT NULL UNIQUE,
    name TEXT NOT NULL,
    password_hash TEXT NOT NULL,
    password_salt TEXT NOT NULL,
    role TEXT NOT NULL DEFAULT 'member',
    status TEXT NOT NULL DEFAULT 'active',
    created_at INTEGER NOT NULL,
    last_login_at INTEGER
  )`,
  `CREATE TABLE IF NOT EXISTS sessions (
    id TEXT PRIMARY KEY,
    account_id TEXT NOT NULL,
    token_hash TEXT NOT NULL UNIQUE,
    user_agent TEXT,
    created_at INTEGER NOT NULL,
    expires_at INTEGER NOT NULL
  )`,
  `CREATE INDEX IF NOT EXISTS sessions_account ON sessions(account_id, expires_at)`,
  `CREATE TABLE IF NOT EXISTS invites (
    code TEXT PRIMARY KEY,
    role TEXT NOT NULL DEFAULT 'member',
    max_uses INTEGER NOT NULL DEFAULT 1,
    uses INTEGER NOT NULL DEFAULT 0,
    expires_at INTEGER,
    created_by TEXT NOT NULL,
    created_at INTEGER NOT NULL
  )`,
  // Exactly one row: instance-level settings, created when the owner claims it.
  `CREATE TABLE IF NOT EXISTS instance (
    id INTEGER PRIMARY KEY CHECK (id = 1),
    owner_id TEXT,
    registration TEXT NOT NULL DEFAULT 'approval',
    created_at INTEGER NOT NULL
  )`,
  // The model API key, set by the owner in Settings. One row. It never leaves
  // the Worker: routes report only whether it exists and its last four digits.
  `CREATE TABLE IF NOT EXISTS ai_credentials (
    id INTEGER PRIMARY KEY CHECK (id = 1),
    api_key TEXT NOT NULL,
    updated_at INTEGER NOT NULL
  )`,
  // Optional data sources the owner connects: a Solana RPC for holder reads and
  // an X bearer token for live posts. Both stay in the Worker.
  `CREATE TABLE IF NOT EXISTS data_sources (
    id INTEGER PRIMARY KEY CHECK (id = 1),
    solana_rpc_url TEXT,
    x_bearer_token TEXT,
    updated_at INTEGER NOT NULL
  )`,
  // Keys for the secondary hosted providers. One row per provider, so saving a
  // Gemini key cannot overwrite the primary key in ai_credentials.
  `CREATE TABLE IF NOT EXISTS provider_keys (
    provider TEXT PRIMARY KEY,
    api_key TEXT NOT NULL,
    updated_at INTEGER NOT NULL
  )`,
  // An owner-run HTTP relay for venues that block this Worker's region.
  // Kept separate so adding it cannot disturb the credentials table.
  `CREATE TABLE IF NOT EXISTS venue_relay (
    id INTEGER PRIMARY KEY CHECK (id = 1),
    url TEXT NOT NULL,
    updated_at INTEGER NOT NULL
  )`,
  // An optional owner-run image renderer for Studio (Automatic1111/Forge or an
  // OpenAI-compatible images API). The free host applies its own filters; a
  // renderer the owner controls is the only way to serve adult prompts reliably.
  `CREATE TABLE IF NOT EXISTS studio_engine (
    id INTEGER PRIMARY KEY CHECK (id = 1),
    url TEXT NOT NULL,
    api_key TEXT,
    updated_at INTEGER NOT NULL
  )`,
]

const ready = new WeakMap<D1Database, Promise<void>>()

export function ensureSchema(db: D1Database): Promise<void> {
  let pending = ready.get(db)
  if (!pending) {
    pending = db.batch(SCHEMA.map((sql) => db.prepare(sql))).then(() => undefined).catch((error) => {
      ready.delete(db)
      throw error
    })
    ready.set(db, pending)
  }
  return pending
}

export const requireDb: MiddlewareHandler<AppContext> = async (c, next) => {
  const db = c.env.DB
  if (!db) {
    return c.json({ error: 'database_missing', message: 'No database is attached yet. Add D1 storage named DB and redeploy.' }, 503)
  }
  await ensureSchema(db)
  c.set('db', db)
  await next()
}

export const id = () => crypto.randomUUID()
export const now = () => Date.now()

type Row = Record<string, unknown>

export function mapConversation(r: Row): Conversation {
  return {
    id: r.id as string,
    title: r.title as string,
    model: r.model as string,
    createdAt: Number(r.created_at),
    updatedAt: Number(r.updated_at),
  }
}

export function mapMessage(r: Row): Message {
  return {
    id: r.id as string,
    conversationId: r.conversation_id as string,
    role: r.role as Message['role'],
    content: r.content as string,
    model: (r.model as string | null) ?? null,
    interrupted: Boolean(r.interrupted),
    createdAt: Number(r.created_at),
  }
}

export function mapMemory(r: Row): Memory {
  return {
    id: r.id as string,
    kind: r.kind as MemoryKind,
    content: r.content as string,
    tags: String(r.tags ?? '')
      .split(',')
      .map((tag) => tag.trim())
      .filter(Boolean),
    source: String(r.source ?? 'chat'),
    confidence: Number(r.confidence ?? 0.7),
    uses: Number(r.uses ?? 0),
    createdAt: Number(r.created_at),
    updatedAt: Number(r.updated_at),
    lastUsedAt: r.last_used_at == null ? null : Number(r.last_used_at),
  }
}

/** Midnight UTC that started the current day, and the next one. */
export function utcDay(at = now()): { start: number; end: number } {
  const start = new Date(at)
  start.setUTCHours(0, 0, 0, 0)
  return { start: start.getTime(), end: start.getTime() + 86_400_000 }
}

/**
 * Replies generated today, including ones still streaming and ones the user
 * stopped: each one spent API credits. Regenerating counts; a request the API
 * refused does not.
 */
export async function repliesToday(db: D1Database, owner: string): Promise<number> {
  const { start } = utcDay()
  const row = await db
    .prepare(`SELECT COUNT(*) AS n FROM messages WHERE owner_sub = ? AND role = 'assistant' AND created_at >= ?`)
    .bind(owner, start)
    .first<{ n: number }>()
  return Number(row?.n ?? 0)
}

/** A conversation title from its first message: the first line, cut at a word. */
export function titleFrom(content: string): string {
  const line = content.trim().split(/\r?\n/)[0]?.replace(/\s+/g, ' ').trim() ?? ''
  if (line.length <= 48) return line || 'New chat'
  const cut = line.slice(0, 48)
  const space = cut.lastIndexOf(' ')
  return `${(space > 24 ? cut.slice(0, space) : cut).replace(/[\s,.;:!?-]+$/, '')}…`
}

export const DEFAULT_SETTINGS: Settings = { persona: '', autoLearn: true, webAccess: true, marketAccess: true }

export async function getSettings(db: D1Database, owner: string): Promise<Settings> {
  const row = await db.prepare(`SELECT * FROM user_settings WHERE owner_sub = ?`).bind(owner).first<Row>()
  if (!row) {
    const t = now()
    await db
      .prepare(`INSERT OR IGNORE INTO user_settings (owner_sub, persona, auto_learn, web_access, market_access, created_at, updated_at) VALUES (?, '', 1, 1, 1, ?, ?)`)
      .bind(owner, t, t)
      .run()
    return DEFAULT_SETTINGS
  }
  return {
    persona: String(row.persona ?? ''),
    autoLearn: Boolean(row.auto_learn),
    webAccess: Boolean(row.web_access),
    marketAccess: Boolean(row.market_access),
  }
}
