// The agent's hands: live web search, page reading, market data, arithmetic
// and memory. Every tool returns text for the model, is bounded in size and
// time, and fails soft so one dead endpoint cannot break a conversation.
//
// Server-side fetching is a real capability, so fetch_url refuses private and
// link-local addresses (SSRF) and re-checks the final URL after redirects.

import type { MarketKind } from '../shared/types'
import { analyzeMarket, describeAnalysis } from './forecast'
import { addMemory, recallMemories } from './memory'
import { isSolanaAddress, memeFeed, memeForecast, RATE_LIMITED, walletPortfolio } from './solana'
import { describePulse, memePulse } from './pulse'
import { describeSimulation, simulateMeme } from './simulate'
import { describeRisk, assessToken } from './risk'
import { describeVenues, venueQuotes } from './venues'
import { compact, describeQuote, marketOverview, quoteFor } from './markets'
import { POLICY_REFUSAL, violatesPolicy } from './policy'
import type { Env } from './env'

const UA =
  'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36'

export type ToolContext = {
  env: Env
  db: D1Database
  owner: string
  conversationId: string | null
  allowWeb: boolean
  allowMarkets: boolean
  /** Owner-configured Solana RPC, if any: enables on-chain holder reads. */
  solanaRpcUrl?: string
  /** Owner-run relay for venues that block this Worker's region. */
  venueRelayUrl?: string
}

export type ToolResult = { ok: boolean; summary: string }

export const TOOL_NAMES = [
  'web_search',
  'fetch_url',
  'market_quote',
  'market_overview',
  'market_forecast',
  'meme_scan',
  'meme_forecast',
  'meme_backtest',
  'meme_pulse',
  'venue_quotes',
  'token_risk',
  'token_research',
  'wallet_holdings',
  'calculate',
  'remember',
  'recall',
] as const
export type ToolName = (typeof TOOL_NAMES)[number]
const isToolName = (value: string): value is ToolName => (TOOL_NAMES as readonly string[]).includes(value)

export type ParsedToolCall = { name: ToolName; args: Record<string, unknown> }

/* --------------------------------------------------------------- schemas -- */

const params = (properties: Record<string, unknown>, required: string[] = []) => ({
  type: 'object',
  properties,
  required,
  additionalProperties: false,
})

/**
 * Native function schemas. Passing these to the provider is what makes tool use
 * reliable: the model fills structured arguments instead of remembering a
 * bespoke text format, and a malformed call is rejected at the API boundary.
 */
export const TOOL_SCHEMAS = [
  {
    type: 'function',
    function: {
      name: 'web_search',
      description: 'Search the live web. Use for news, filings, prices and anything that may have changed since training.',
      parameters: params({ query: { type: 'string', description: 'What to search for.' }, max_results: { type: 'integer', minimum: 1, maximum: 8 } }, ['query']),
    },
  },
  {
    type: 'function',
    function: {
      name: 'fetch_url',
      description: 'Read one public page as plain text.',
      parameters: params({ url: { type: 'string', description: 'Absolute http(s) URL.' } }, ['url']),
    },
  },
  {
    type: 'function',
    function: {
      name: 'market_quote',
      description: 'A live quote for one listed instrument: price, daily move, range, volume.',
      parameters: params({ symbol: { type: 'string', description: 'Ticker or CoinGecko id, e.g. NVDA or bitcoin.' }, kind: { type: 'string', enum: ['crypto', 'stock'] } }, ['symbol']),
    },
  },
  {
    type: 'function',
    function: {
      name: 'market_overview',
      description: 'Major indices, top coins, total market cap and BTC dominance.',
      parameters: params({}),
    },
  },
  {
    type: 'function',
    function: {
      name: 'market_forecast',
      description:
        'Trend, momentum, volatility, support/resistance and a mechanical lean for a listed instrument or Solana meme coin. Use before any prediction.',
      parameters: params({ symbol: { type: 'string', description: 'Ticker or CoinGecko id.' }, kind: { type: 'string', enum: ['crypto', 'stock'] } }, ['symbol']),
    },
  },
  {
    type: 'function',
    function: {
      name: 'meme_backtest',
      description:
        'Walk-forward test of the forecast rule on a meme coin\'s real candles: trades, win rate, average holding time, drawdown, plus the current target and stop. Use before advising how long to hold or when to sell.',
      parameters: params({ mint: { type: 'string', description: 'Solana mint address.' } }, ['mint']),
    },
  },
  {
    type: 'function',
    function: {
      name: 'meme_pulse',
      description:
        'Live order flow for a Solana coin, including one too young to chart: 5m/1h/6h/24h moves, volume, buy and sell counts, pool depth, age, and who is in control. Use it before a scalp call on a fresh launch.',
      parameters: params({ mint: { type: 'string', description: 'Solana mint address.' } }, ['mint']),
    },
  },
  {
    type: 'function',
    function: {
      name: 'meme_scan',
      description: 'The pump.fun and PumpSwap leaderboard: newest launches, or movers by 24h volume.',
      parameters: params({ sort: { type: 'string', enum: ['volume', 'new'] }, limit: { type: 'integer', minimum: 1, maximum: 24 } }),
    },
  },
  {
    type: 'function',
    function: {
      name: 'venue_quotes',
      description:
        'The same asset priced on several exchanges at once (Coinbase, Binance, Kraken) with the spread between them. Use to check a single quote against the wider market.',
      parameters: params({ ticker: { type: 'string', description: 'Ticker such as BTC, ETH, SOL, XRP.' } }, ['ticker']),
    },
  },
  {
    type: 'function',
    function: {
      name: 'token_risk',
      description:
        'Rug-pull screen for a Solana token: pool liquidity versus market cap, pool age, mint and freeze authority, top-holder concentration, and which checks could not run. Needs the mint: if you only have a ticker, call meme_scan first. Never returns a verdict of safe.',
      parameters: params({ mint: { type: 'string', description: 'Solana mint address.' } }, ['mint']),
    },
  },
  {
    type: 'function',
    function: {
      name: 'token_research',
      description:
        'Search for a token\'s whitepaper, docs, X and Reddit discussion and any rug or exploit claims, returning links and snippets to read with fetch_url.',
      parameters: params(
        {
          symbol: { type: 'string', description: 'Token ticker or name.' },
          focus: { type: 'string', enum: ['whitepaper', 'social', 'risk'], description: 'Narrow the sweep; omit for all three.' },
        },
        ['symbol'],
      ),
    },
  },
  {
    type: 'function',
    function: {
      name: 'meme_forecast',
      description: 'Indicators and a lean for one Solana meme coin, from its pool candles. Needs the mint address.',
      parameters: params({ mint: { type: 'string', description: 'Solana mint address.' } }, ['mint']),
    },
  },
  {
    type: 'function',
    function: {
      name: 'wallet_holdings',
      description: 'Public Solana balances for an address, priced. Read-only.',
      parameters: params({ address: { type: 'string', description: 'Solana wallet address.' } }, ['address']),
    },
  },
  {
    type: 'function',
    function: { name: 'calculate', description: 'Exact arithmetic, including position sizing.', parameters: params({ expression: { type: 'string' } }, ['expression']) },
  },
  {
    type: 'function',
    function: {
      name: 'remember',
      description: 'Store something durable about this user.',
      parameters: params(
        {
          content: { type: 'string' },
          kind: { type: 'string', enum: ['fact', 'preference', 'insight', 'entity'] },
          tags: { type: 'array', items: { type: 'string' } },
        },
        ['content'],
      ),
    },
  },
  {
    type: 'function',
    function: { name: 'recall', description: 'Search your stored memories of this user.', parameters: params({ query: { type: 'string' } }, ['query']) },
  },
] as const

/* ----------------------------------------------------------------- parsing */

/** Finds the tool blocks a model emitted, in `<tool>…</tool>` or ```tool form. */
export function parseToolCalls(text: string): ParsedToolCall[] {
  const candidates: string[] = []
  for (const match of text.matchAll(/<tool>([\s\S]*?)<\/tool>/gi)) candidates.push(match[1] ?? '')
  if (!candidates.length) for (const match of text.matchAll(/```tool\s*([\s\S]*?)```/gi)) candidates.push(match[1] ?? '')
  const calls: ParsedToolCall[] = []
  for (const candidate of candidates) {
    let value: unknown
    try {
      value = JSON.parse(candidate.trim().replace(/^```(?:json)?|```$/g, '').trim())
    } catch {
      continue
    }
    const list = Array.isArray(value) ? value : [value]
    for (const entry of list) {
      if (!entry || typeof entry !== 'object') continue
      const record = entry as Record<string, unknown>
      const name = typeof record.name === 'string' ? record.name.trim() : ''
      if (!isToolName(name)) continue
      const rawArgs = record.arguments ?? record.args ?? {}
      const args = rawArgs && typeof rawArgs === 'object' && !Array.isArray(rawArgs) ? (rawArgs as Record<string, unknown>) : {}
      calls.push({ name, args })
    }
  }
  return calls
}

/** The model's prose with any tool blocks removed. */
export function stripToolBlocks(text: string): string {
  return text.replace(/<tool>[\s\S]*?<\/tool>/gi, '').replace(/```tool\s*[\s\S]*?```/gi, '').trim()
}

export function toolLabel(name: string, args: Record<string, unknown>): string {
  const text = (key: string) => (typeof args[key] === 'string' ? String(args[key]) : '')
  switch (name) {
    case 'web_search':
      return `Searching the web${text('query') ? ` for “${text('query').slice(0, 80)}”` : ''}`
    case 'fetch_url': {
      try {
        return `Reading ${new URL(text('url').match(/^https?:/) ? text('url') : `https://${text('url')}`).hostname}`
      } catch {
        return 'Reading a page'
      }
    }
    case 'market_quote':
      return `Pulling the live quote for ${text('symbol').toUpperCase() || 'the market'}`
    case 'market_overview':
      return 'Reading the market tape'
    case 'market_forecast':
      return 'Reading the chart for a forecast'
    case 'meme_scan':
      return 'Scanning pump.fun for meme coins'
    case 'meme_forecast':
      return 'Reading the meme coin chart'
    case 'meme_backtest':
      return 'Testing the rule on real candles'
    case 'meme_pulse':
      return 'Reading the live order flow'
    case 'venue_quotes':
      return `Comparing venues for ${text('ticker').toUpperCase() || 'the asset'}`
    case 'token_risk':
      return 'Screening holders, authorities and liquidity'
    case 'token_research':
      return `Researching ${text('symbol').toUpperCase() || 'the token'} on the web`
    case 'wallet_holdings':
      return 'Reading the Solana wallet'
    case 'calculate':
      return `Calculating ${text('expression').slice(0, 60)}`
    case 'remember':
      return 'Saving to memory'
    case 'recall':
      return 'Searching memory'
    default:
      return `Running ${name}`
  }
}

/* -------------------------------------------------------------- fetching -- */

const PRIVATE_HOSTS = /(^|\.)(localhost|local|internal|lan)$/i

function isPrivateHost(hostname: string): boolean {
  const host = hostname.toLowerCase().replace(/^\[|\]$/g, '')
  if (!host || PRIVATE_HOSTS.test(host) || host === 'metadata.google.internal' || host.endsWith('.metadata.google.internal')) return true
  const v4 = /^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/.exec(host)
  if (v4) {
    const a = Number(v4[1])
    const b = Number(v4[2])
    if (a === 0 || a === 10 || a === 127) return true
    if (a === 169 && b === 254) return true
    if (a === 172 && b >= 16 && b <= 31) return true
    if (a === 192 && b === 168) return true
    if (a === 100 && b >= 64 && b <= 127) return true
    return false
  }
  if (host.includes(':')) return host === '::1' || host === '::' || host.startsWith('fc') || host.startsWith('fd') || host.startsWith('fe80')
  return false
}

function decodeEntities(value: string): string {
  return value
    .replace(/&nbsp;/gi, ' ')
    .replace(/&amp;/gi, '&')
    .replace(/&lt;/gi, '<')
    .replace(/&gt;/gi, '>')
    .replace(/&quot;/gi, '"')
    .replace(/&#39;|&#x27;/gi, "'")
    .replace(/&mdash;/gi, '—')
    .replace(/&ndash;/gi, '–')
    .replace(/&hellip;/gi, '…')
    .replace(/&#(\d+);/g, (_, code: string) => String.fromCharCode(Number(code)))
}

function stripTags(value: string): string {
  return decodeEntities(value.replace(/<[^>]+>/g, ' ')).replace(/\s+/g, ' ').trim()
}

function htmlToText(html: string): string {
  return decodeEntities(
    html
      .replace(/<script[\s\S]*?<\/script>/gi, ' ')
      .replace(/<style[\s\S]*?<\/style>/gi, ' ')
      .replace(/<noscript[\s\S]*?<\/noscript>/gi, ' ')
      .replace(/<svg[\s\S]*?<\/svg>/gi, ' ')
      .replace(/<!--[\s\S]*?-->/g, ' ')
      .replace(/<\/(p|div|li|ul|ol|h[1-6]|tr|section|article|table|blockquote)>/gi, '\n')
      .replace(/<br\s*\/?>/gi, '\n')
      .replace(/<[^>]+>/g, ' '),
  )
    .replace(/[ \t\f\v]+/g, ' ')
    .replace(/\n[ \t]+/g, '\n')
    .replace(/\n{3,}/g, '\n\n')
    .trim()
}

async function readCapped(response: Response, limit: number): Promise<string> {
  if (!response.body) return ''
  const reader = response.body.getReader()
  const decoder = new TextDecoder()
  let text = ''
  let received = 0
  try {
    while (received < limit) {
      const { value, done } = await reader.read()
      if (done) break
      received += value.byteLength
      text += decoder.decode(value, { stream: true })
      if (text.length >= limit) break
    }
    text += decoder.decode()
  } finally {
    reader.releaseLock()
  }
  return text
}

export async function fetchPage(rawUrl: string, maxChars = 8_000): Promise<{ url: string; status: number; title: string; text: string }> {
  const withScheme = /^https?:\/\//i.test(rawUrl.trim()) ? rawUrl.trim() : `https://${rawUrl.trim()}`
  const parsed = new URL(withScheme)
  if (!/^https?:$/.test(parsed.protocol)) throw new Error('Only http and https URLs can be read.')
  if (isPrivateHost(parsed.hostname)) throw new Error('Private and local network addresses are not reachable.')
  const response = await fetch(parsed.toString(), {
    headers: {
      'user-agent': UA,
      accept: 'text/html,application/xhtml+xml,application/json;q=0.9,text/plain;q=0.8,*/*;q=0.5',
      'accept-language': 'en-US,en;q=0.9',
    },
    redirect: 'follow',
    signal: AbortSignal.timeout(15_000),
  })
  if (isPrivateHost(new URL(response.url).hostname)) throw new Error('Private and local network addresses are not reachable.')
  const type = response.headers.get('content-type') ?? ''
  const raw = await readCapped(response, 600_000)
  const isHtml = type.includes('html') || /^\s*(<!doctype html|<html)/i.test(raw)
  const title = isHtml ? stripTags(/<title[^>]*>([\s\S]*?)<\/title>/i.exec(raw)?.[1] ?? '') : ''
  const body = isHtml ? htmlToText(raw) : raw
  const text = body.slice(0, maxChars)
  return {
    url: response.url,
    status: response.status,
    title,
    text: text.length < body.length ? `${text}\n…[truncated at ${maxChars.toLocaleString()} characters]` : text,
  }
}

/* ----------------------------------------------------------------- search -- */

export type SearchHit = { title: string; url: string; snippet: string }

function cleanDdgUrl(href: string): string {
  try {
    const absolute = href.startsWith('//') ? `https:${href}` : href
    const url = new URL(absolute)
    const target = url.searchParams.get('uddg')
    if (url.hostname.endsWith('duckduckgo.com') && target) return decodeURIComponent(target)
    return url.toString()
  } catch {
    return href
  }
}

async function ddgSearch(query: string, max: number): Promise<SearchHit[]> {
  const response = await fetch(`https://html.duckduckgo.com/html/?q=${encodeURIComponent(query)}&kl=us-en`, {
    headers: { 'user-agent': UA, accept: 'text/html', 'accept-language': 'en-US,en;q=0.9' },
    signal: AbortSignal.timeout(14_000),
  })
  if (!response.ok) return []
  const html = await response.text()
  const hits: SearchHit[] = []
  const blocks = [...html.matchAll(/<a[^>]+class="[^"]*result__a[^"]*"[^>]*href="([^"]+)"[^>]*>([\s\S]*?)<\/a>/gi)]
  const snippets = [...html.matchAll(/class="result__snippet"[^>]*>([\s\S]*?)<\/(?:a|div|td)>/gi)].map((match) => stripTags(match[1] ?? ''))
  blocks.forEach((block, index) => {
    if (hits.length >= max) return
    const url = cleanDdgUrl(decodeEntities(block[1] ?? ''))
    const title = stripTags(block[2] ?? '')
    if (!url.startsWith('http') || !title) return
    hits.push({ title, url, snippet: snippets[index] ?? '' })
  })
  return hits
}

async function searchWithTavily(env: Env, query: string, max: number): Promise<SearchHit[]> {
  const response = await fetch('https://api.tavily.com/search', {
    method: 'POST',
    headers: { 'content-type': 'application/json', accept: 'application/json' },
    body: JSON.stringify({ api_key: env.TAVILY_API_KEY, query, max_results: max, search_depth: 'basic', include_answer: false }),
    signal: AbortSignal.timeout(15_000),
  })
  if (!response.ok) throw new Error(`Tavily responded ${response.status}`)
  const body = (await response.json()) as { results?: { title?: string; url?: string; content?: string }[] }
  return (body.results ?? []).slice(0, max).map((item) => ({
    title: item.title ?? item.url ?? '',
    url: item.url ?? '',
    snippet: (item.content ?? '').slice(0, 400),
  }))
}

async function searchWithBrave(env: Env, query: string, max: number): Promise<SearchHit[]> {
  const response = await fetch(`https://api.search.brave.com/res/v1/web/search?q=${encodeURIComponent(query)}&count=${max}`, {
    headers: { accept: 'application/json', 'x-subscription-token': env.BRAVE_SEARCH_API_KEY ?? '' },
    signal: AbortSignal.timeout(15_000),
  })
  if (!response.ok) throw new Error(`Brave responded ${response.status}`)
  const body = (await response.json()) as { web?: { results?: { title?: string; url?: string; description?: string }[] } }
  return (body.web?.results ?? []).slice(0, max).map((item) => ({
    title: stripTags(item.title ?? ''),
    url: item.url ?? '',
    snippet: stripTags(item.description ?? '').slice(0, 400),
  }))
}

async function searchFallback(query: string, max: number): Promise<SearchHit[]> {
  const [instant, wiki] = await Promise.all([
    fetch(`https://api.duckduckgo.com/?q=${encodeURIComponent(query)}&format=json&no_html=1&skip_disambig=1`, {
      headers: { 'user-agent': UA },
      signal: AbortSignal.timeout(10_000),
    })
      .then((response) => (response.ok ? response.json() : null))
      .catch(() => null) as Promise<{ AbstractText?: string; AbstractURL?: string; Heading?: string; RelatedTopics?: { Text?: string; FirstURL?: string }[] } | null>,
    fetch(`https://en.wikipedia.org/w/api.php?action=query&list=search&srsearch=${encodeURIComponent(query)}&format=json&srlimit=${max}`, {
      headers: { 'user-agent': UA },
      signal: AbortSignal.timeout(10_000),
    })
      .then((response) => (response.ok ? response.json() : null))
      .catch(() => null) as Promise<{ query?: { search?: { title?: string; snippet?: string }[] } } | null>,
  ])
  const hits: SearchHit[] = []
  if (instant?.AbstractText && instant.AbstractURL) {
    hits.push({ title: instant.Heading ?? query, url: instant.AbstractURL, snippet: instant.AbstractText.slice(0, 400) })
  }
  for (const topic of instant?.RelatedTopics ?? []) {
    if (hits.length >= max) break
    if (topic.FirstURL && topic.Text) hits.push({ title: topic.Text.slice(0, 90), url: topic.FirstURL, snippet: topic.Text.slice(0, 300) })
  }
  for (const item of wiki?.query?.search ?? []) {
    if (hits.length >= max) break
    if (!item.title) continue
    hits.push({
      title: item.title,
      url: `https://en.wikipedia.org/wiki/${encodeURIComponent(item.title.replace(/ /g, '_'))}`,
      snippet: stripTags(item.snippet ?? ''),
    })
  }
  return hits
}

export async function webSearch(env: Env, query: string, max = 5): Promise<{ hits: SearchHit[]; provider: string; note?: string }> {
  if (env.TAVILY_API_KEY) {
    try {
      const hits = await searchWithTavily(env, query, max)
      if (hits.length) return { hits, provider: 'Tavily' }
    } catch {
      /* fall through */
    }
  }
  if (env.BRAVE_SEARCH_API_KEY) {
    try {
      const hits = await searchWithBrave(env, query, max)
      if (hits.length) return { hits, provider: 'Brave' }
    } catch {
      /* fall through */
    }
  }
  const ddg = await ddgSearch(query, max).catch(() => [])
  if (ddg.length) return { hits: ddg, provider: 'DuckDuckGo', note: 'Keyless search. Add TAVILY_API_KEY or BRAVE_SEARCH_API_KEY for broader coverage.' }
  const fallback = await searchFallback(query, max).catch(() => [])
  return {
    hits: fallback,
    provider: fallback.length ? 'DuckDuckGo Instant Answers / Wikipedia' : 'none',
    note: fallback.length
      ? 'Direct search was unavailable, so these are reference results. Verify anything time-sensitive with fetch_url.'
      : 'No results. The search backends refused this request; try a different query or fetch a known URL directly.',
  }
}

/* --------------------------------------------------------------- calculate */

type Func = (args: number[]) => number

const FUNCS: Record<string, Func> = {
  abs: ([a]) => Math.abs(a!),
  sqrt: ([a]) => Math.sqrt(a!),
  ln: ([a]) => Math.log(a!),
  log: ([a]) => Math.log10(a!),
  exp: ([a]) => Math.exp(a!),
  round: ([a, digits]) => {
    const factor = 10 ** (digits ?? 0)
    return Math.round(a! * factor) / factor
  },
  floor: ([a]) => Math.floor(a!),
  ceil: ([a]) => Math.ceil(a!),
  min: (args) => Math.min(...args),
  max: (args) => Math.max(...args),
  pow: ([a, b]) => a! ** b!,
  avg: (args) => args.reduce((sum, value) => sum + value, 0) / args.length,
}

/** A small arithmetic evaluator: no eval, no globals, bounded input. */
export function calculate(expression: string): number {
  const source = expression.replace(/\s+/g, '')
  if (!source) throw new Error('Empty expression.')
  if (source.length > 240) throw new Error('Expression is too long.')
  let at = 0
  const peek = () => source[at]

  function expr(): number {
    let value = term()
    while (peek() === '+' || peek() === '-') {
      const op = source[at++]
      const right = term()
      value = op === '+' ? value + right : value - right
    }
    return value
  }

  function term(): number {
    let value = unary()
    while (peek() === '*' || peek() === '/' || peek() === '%') {
      const op = source[at++]
      const right = unary()
      value = op === '*' ? value * right : op === '/' ? value / right : value % right
    }
    return value
  }

  function unary(): number {
    if (peek() === '-') {
      at++
      return -unary()
    }
    if (peek() === '+') {
      at++
      return unary()
    }
    return power()
  }

  function power(): number {
    const base = atom()
    if (peek() === '^') {
      at++
      return base ** unary()
    }
    return base
  }

  function atom(): number {
    if (peek() === '(') {
      at++
      const value = expr()
      if (peek() !== ')') throw new Error('Missing closing parenthesis.')
      at++
      return value
    }
    if (peek() && /[0-9.]/.test(peek()!)) {
      const match = /^\d*\.?\d+(?:e[+-]?\d+)?/i.exec(source.slice(at))
      if (!match) throw new Error('Malformed number.')
      at += match[0].length
      return Number(match[0])
    }
    const name = /^[a-z]+/i.exec(source.slice(at))?.[0]
    if (name) {
      at += name.length
      const fn = FUNCS[name.toLowerCase()]
      if (!fn) throw new Error(`Unknown function "${name}".`)
      if (peek() !== '(') throw new Error(`${name} needs parentheses.`)
      at++
      const args: number[] = []
      if (peek() !== ')') {
        args.push(expr())
        while (peek() === ',') {
          at++
          args.push(expr())
        }
      }
      if (peek() !== ')') throw new Error('Missing closing parenthesis.')
      at++
      return fn(args)
    }
    throw new Error('Unexpected input.')
  }

  const value = expr()
  if (at < source.length) throw new Error('Unexpected trailing input.')
  if (!Number.isFinite(value)) throw new Error('Result is not a finite number.')
  return value
}

/* ------------------------------------------------------------------- tools */

const formatNumber = (value: number | null): string =>
  value == null ? '—' : value >= 1 ? value.toLocaleString('en-US', { maximumFractionDigits: 2 }) : value.toPrecision(4)

const textOf = (value: unknown): string => (typeof value === 'string' ? value.trim() : typeof value === 'number' ? String(value) : '')

const clampInt = (value: unknown, min: number, max: number, fallback: number): number => {
  const parsed = typeof value === 'number' ? value : Number.parseInt(textOf(value), 10)
  if (!Number.isFinite(parsed)) return fallback
  return Math.min(max, Math.max(min, Math.round(parsed)))
}

function formatSearch(query: string, result: Awaited<ReturnType<typeof webSearch>>): string {
  const lines = result.hits.map((hit, index) => `${index + 1}. ${hit.title}\n   ${hit.url}${hit.snippet ? `\n   ${hit.snippet}` : ''}`)
  return [`Web search "${query}" via ${result.provider}:`, ...lines, result.note ? `Note: ${result.note}` : '']
    .filter(Boolean)
    .join('\n')
    .slice(0, 7_000)
}

export async function runTool(ctx: ToolContext, name: ToolName, args: Record<string, unknown>): Promise<ToolResult> {
  if (violatesPolicy(Object.values(args).filter((value): value is string => typeof value === 'string').join(' '))) {
    return { ok: false, summary: POLICY_REFUSAL }
  }
  try {
    switch (name) {
      case 'web_search': {
        if (!ctx.allowWeb) return { ok: false, summary: 'Web access is switched off in settings.' }
        const query = textOf(args.query)
        if (!query) return { ok: false, summary: 'web_search needs a query.' }
        const result = await webSearch(ctx.env, query, clampInt(args.max_results, 1, 8, 5))
        return { ok: result.hits.length > 0, summary: formatSearch(query, result) }
      }
      case 'fetch_url': {
        if (!ctx.allowWeb) return { ok: false, summary: 'Web access is switched off in settings.' }
        const url = textOf(args.url)
        if (!url) return { ok: false, summary: 'fetch_url needs a url.' }
        const page = await fetchPage(url, 9_000)
        return {
          ok: page.status < 400,
          summary: [`Fetched ${page.url} (HTTP ${page.status})${page.title ? ` — ${page.title}` : ''}`, page.text].join('\n').slice(0, 10_000),
        }
      }
      case 'market_quote': {
        if (!ctx.allowMarkets) return { ok: false, summary: 'Market data is switched off in settings.' }
        const symbol = textOf(args.symbol)
        if (!symbol) return { ok: false, summary: 'market_quote needs a symbol, e.g. BTC or NVDA.' }
        const kind = args.kind === 'crypto' || args.kind === 'stock' ? (args.kind as MarketKind) : undefined
        const quote = await quoteFor(symbol, kind)
        return quote ? { ok: true, summary: describeQuote(quote) } : { ok: false, summary: `No live quote found for "${symbol}".` }
      }
      case 'market_overview': {
        if (!ctx.allowMarkets) return { ok: false, summary: 'Market data is switched off in settings.' }
        const overview = await marketOverview()
        const indices = overview.indices.map((quote) => describeQuote(quote)).join('\n')
        const coins = overview.crypto.map((quote) => describeQuote(quote)).join('\n')
        const global = overview.global
        return {
          ok: true,
          summary: [
            'INDICES',
            indices || 'unavailable',
            '',
            'CRYPTO',
            coins || 'unavailable',
            '',
            global
              ? `Total crypto market cap ${compact(global.marketCap)} · 24h volume ${compact(global.volume)} · BTC dominance ${
                  global.btcDominance?.toFixed(1) ?? '—'
                }% · market cap 24h ${global.change24h?.toFixed(2) ?? '—'}%`
              : 'Global crypto stats unavailable.',
            `Prices are indicative and may be delayed. ${new Date(overview.updatedAt).toISOString()}`,
          ].join('\n'),
        }
      }
      case 'market_forecast': {
        if (!ctx.allowMarkets) return { ok: false, summary: 'Market data is switched off in settings.' }
        const symbol = textOf(args.symbol)
        if (!symbol) return { ok: false, summary: 'market_forecast needs a symbol, e.g. BTC or NVDA.' }
        const kind = args.kind === 'crypto' || args.kind === 'stock' ? (args.kind as MarketKind) : undefined
        const quote = await quoteFor(symbol, kind)
        if (!quote) return { ok: false, summary: `No live quote found for "${symbol}".` }
        try {
          const analysis = await analyzeMarket({ ref: quote.ref, kind: quote.kind, name: quote.name, price: quote.price ?? 0, currency: quote.currency })
          return { ok: true, summary: describeAnalysis(analysis) }
        } catch (error) {
          return { ok: false, summary: `Could not build the analysis: ${error instanceof Error ? error.message : 'unknown error'}` }
        }
      }
      case 'venue_quotes': {
        if (!ctx.allowMarkets) return { ok: false, summary: 'Market data is switched off in settings.' }
        const ticker = textOf(args.ticker)
        if (!ticker) return { ok: false, summary: 'venue_quotes needs a ticker, e.g. BTC.' }
        const quotes = await venueQuotes(ticker, ctx.venueRelayUrl)
        return { ok: quotes.length > 0, summary: describeVenues(ticker, quotes) }
      }
      case 'token_risk': {
        if (!ctx.allowMarkets) return { ok: false, summary: 'Market data is switched off in settings.' }
        const mint = textOf(args.mint)
        if (!mint) return { ok: false, summary: 'token_risk needs a Solana mint address.' }
        if (!isSolanaAddress(mint)) return { ok: false, summary: `"${mint}" is not a Solana mint address.` }
        try {
          return { ok: true, summary: describeRisk(await assessToken(mint, ctx.solanaRpcUrl)) }
        } catch (error) {
          return { ok: false, summary: error instanceof Error ? error.message : 'Could not screen that token.' }
        }
      }
      case 'token_research': {
        if (!ctx.allowWeb) return { ok: false, summary: 'Web access is switched off in settings.' }
        const symbol = textOf(args.symbol)
        if (!symbol) return { ok: false, summary: 'token_research needs a token ticker or name.' }
        const focus = args.focus === 'whitepaper' || args.focus === 'social' || args.focus === 'risk' ? (args.focus as string) : null
        const sweeps: { label: string; query: string }[] = [
          { label: 'whitepaper and tokenomics', query: `${symbol} whitepaper tokenomics` },
          { label: 'social discussion', query: `${symbol} crypto sentiment discussion` },
          { label: 'Reddit and community', query: `${symbol} reddit discussion` },
          { label: 'rug pull and exploit claims', query: `${symbol} rug pull scam exploit` },
        ].filter((sweep) => !focus || (focus === 'whitepaper' ? sweep.label.startsWith('whitepaper') : focus === 'social' ? sweep.label.startsWith('social') || sweep.label.startsWith('Reddit') : sweep.label.startsWith('rug')))
        const lines: string[] = [`RESEARCH SWEEP — ${symbol.toUpperCase()}`]
        let total = 0
        let provider = 'none'
        for (const sweep of sweeps) {
          const found = await webSearch(ctx.env, sweep.query, 4).catch(() => ({ hits: [], provider: 'none' }))
          provider = found.provider !== 'none' ? found.provider : provider
          if (!found.hits.length) {
            lines.push('', `${sweep.label}: nothing found`)
            continue
          }
          lines.push('', `${sweep.label}:`)
          for (const hit of found.hits) {
            total++
            lines.push(`- ${hit.title}\n  ${hit.url}${hit.snippet ? `\n  ${hit.snippet.slice(0, 200)}` : ''}`)
          }
        }
        lines.push(
          '',
          `Searches run: ${sweeps.length} · results: ${total} · search provider: ${provider}`,
          'These are raw search hits: check each one is about this token and not a same-named project before relying on it.',
          'Whitepapers and docs are links here — use fetch_url to read them before making claims about tokenomics.',
        )
        return { ok: total > 0, summary: lines.join('\n').slice(0, 6_000) }
      }
      case 'meme_pulse': {
        if (!ctx.allowMarkets) return { ok: false, summary: 'Market data is switched off in settings.' }
        const mint = textOf(args.mint)
        if (!mint) return { ok: false, summary: 'meme_pulse needs a Solana mint address.' }
        if (!isSolanaAddress(mint)) return { ok: false, summary: `"${mint}" is not a Solana mint address.` }
        try {
          return { ok: true, summary: describePulse(await memePulse(mint)) }
        } catch (error) {
          return { ok: false, summary: error instanceof Error ? error.message : 'Could not read that token.' }
        }
      }
      case 'meme_backtest': {
        if (!ctx.allowMarkets) return { ok: false, summary: 'Market data is switched off in settings.' }
        const mint = textOf(args.mint)
        if (!mint) return { ok: false, summary: 'meme_backtest needs a mint address.' }
        if (!isSolanaAddress(mint)) return { ok: false, summary: `"${mint}" is not a Solana mint address.` }
        try {
          const simulation = await simulateMeme(mint)
          return { ok: true, summary: describeSimulation(simulation) }
        } catch (error) {
          return { ok: false, summary: `Could not simulate that mint: ${error instanceof Error ? error.message : 'unknown error'}` }
        }
      }
      case 'meme_scan': {
        if (!ctx.allowMarkets) return { ok: false, summary: 'Market data is switched off in settings.' }
        const sort = args.sort === 'new' ? ('new' as const) : ('volume' as const)
        const feed = await memeFeed(sort)
        const rows = feed.items.slice(0, clampInt(args.limit, 1, 24, 12)).map((coin, index) => {
          const line = `${index + 1}. ${coin.symbol} — $${formatNumber(coin.price)} · 24h ${coin.change24h == null ? '—' : `${coin.change24h.toFixed(1)}%`} · vol ${compact(coin.volume24h)} · cap ${compact(coin.marketCap)} · ${coin.venue}`
          return `${line}\n   mint ${coin.mint}`
        })
        return {
          ok: rows.length > 0,
          summary: [
            `PUMP.FUN ${sort === 'new' ? 'NEW LAUNCHES' : 'MOVERS BY 24H VOLUME'} — ${feed.source}`,
            ...rows,
            '',
            'Thin pools move on single trades. Prefer the ones with real volume and say how thin the book is.',
          ].join('\n').slice(0, 4_000),
        }
      }
      case 'meme_forecast': {
        if (!ctx.allowMarkets) return { ok: false, summary: 'Market data is switched off in settings.' }
        const mint = textOf(args.mint)
        if (!mint) return { ok: false, summary: 'meme_forecast needs a Solana mint address.' }
        if (!isSolanaAddress(mint)) return { ok: false, summary: `"${mint}" is not a Solana mint address.` }
        try {
          return { ok: true, summary: describeAnalysis(await memeForecast(mint)) }
        } catch (error) {
          const message = error instanceof Error ? error.message : 'Could not analyse that token.'
          // A throttled feed is not a dead token. Returning the live flow keeps the
          // turn useful while making clear no candle series was read, which is the
          // difference between a flow read and an invented chart.
          if (message === RATE_LIMITED) {
            try {
              return {
                ok: true,
                summary: [
                  `NO CANDLE FORECAST — the candle feed throttled this request, so no trend, probability or level was computed for ${mint}.`,
                  '',
                  describePulse(await memePulse(mint)),
                  '',
                  'Answer from this flow read only, and say it is flow-based. Do not present candle levels, a probability or a horizon as if the chart had been read.',
                ].join('\n').slice(0, 2_600),
              }
            } catch {
              /* the pulse failed too: report the original throttle below */
            }
          }
          return { ok: false, summary: message }
        }
      }
      case 'wallet_holdings': {
        if (!ctx.allowMarkets) return { ok: false, summary: 'Market data is switched off in settings.' }
        const address = textOf(args.address)
        if (!address) return { ok: false, summary: 'wallet_holdings needs a Solana wallet address.' }
        if (!isSolanaAddress(address)) return { ok: false, summary: `"${address}" is not a Solana wallet address.` }
        const portfolio = await walletPortfolio(address, ctx.solanaRpcUrl)
        const rows = portfolio.holdings.slice(0, 25).map((holding) => {
          const value = holding.value == null ? 'no market' : `$${holding.value.toFixed(2)}`
          const change = holding.change24h == null ? '' : ` · 24h ${holding.change24h.toFixed(1)}%`
          return `- ${holding.symbol}: ${holding.amount.toLocaleString('en-US', { maximumFractionDigits: 4 })} (${value})${change}`
        })
        return {
          ok: true,
          summary: [
            `SOLANA WALLET ${address}`,
            `SOL ${portfolio.sol.toFixed(4)}${portfolio.solValue == null ? '' : ` ($${portfolio.solValue.toFixed(2)})`}`,
            `Total ${portfolio.totalValue == null ? 'unavailable' : `$${portfolio.totalValue.toFixed(2)}`} across ${portfolio.holdings.length} tokens${
              portfolio.unpriced ? `, ${portfolio.unpriced} unpriced` : ''
            }`,
            '',
            ...(rows.length ? rows : ['No SPL tokens held in this wallet.']),
            '',
            'This is a public, read-only balance snapshot. Never ask for a seed phrase or a signature.',
          ].join('\n').slice(0, 3_000),
        }
      }
      case 'calculate': {
        const expression = textOf(args.expression)
        if (!expression) return { ok: false, summary: 'calculate needs an expression.' }
        const value = calculate(expression)
        return { ok: true, summary: `${expression} = ${value.toLocaleString('en-US', { maximumFractionDigits: 8 })}` }
      }
      case 'remember': {
        const content = textOf(args.content)
        if (!content) return { ok: false, summary: 'remember needs content.' }
        const memory = await addMemory(ctx.db, ctx.owner, {
          content,
          kind: args.kind,
          tags: Array.isArray(args.tags) ? args.tags : [],
          source: 'chat',
          conversationId: ctx.conversationId,
        })
        return { ok: true, summary: `Saved to memory (${memory.kind}): ${memory.content}` }
      }
      case 'recall': {
        const query = textOf(args.query) || 'recent preferences'
        const memories = await recallMemories(ctx.db, ctx.owner, query, 6)
        return {
          ok: true,
          summary: memories.length
            ? ['Relevant memory:', ...memories.map((memory) => `- (${memory.kind}) ${memory.content}`)].join('\n')
            : 'No stored memory matches that.',
        }
      }
    }
  } catch (error) {
    return { ok: false, summary: `The tool failed: ${error instanceof Error ? error.message : 'unknown error'}` }
  }
}
