// Solana meme coins: discovery on pump.fun, pool candles for forecasting, and
// read-only wallet balances.
//
// Two notes on the data. pump.fun's own frontend API answers servers with a
// Cloudflare challenge, and its official developer API needs an approved
// organisation key and serves social data, not prices. GeckoTerminal indexes
// the pump.fun bonding curve (`pump-fun`) and PumpSwap (`pumpswap`) pools
// directly, so that is the source here, labelled as such in every response.
//
// Wallets are read-only: an address is enough to price the tokens someone
// holds, and nothing in this file asks for, or could use, a signature.

import type { MemeCoin, MemeFeed, WalletHolding, WalletPortfolio } from '../shared/types'
import { analyseCandles, type Analysis, type Candle } from './forecast'

const GT = 'https://api.geckoterminal.com/api/v2'
const DS = 'https://api.dexscreener.com'
// No keyless endpoint will do this job: publicnode blocks getTokenAccountsByOwner
// outright, mainnet-beta blocks Worker egress, and mainnet-beta also refuses any
// request carrying a browser Origin. Wallet reads therefore need a configured
// endpoint, and say so instead of pretending to fail for an unexplained reason.
export const WALLET_RPC_REQUIRED = 'WALLET_RPC_REQUIRED'
const SOL_MINT = 'So11111111111111111111111111111111111111112'
const TOKEN_PROGRAM = 'TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA'
const TOKEN_2022_PROGRAM = 'TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb'
const UA =
  'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36'

/* ------------------------------------------------------------------ cache -- */

const cache = new Map<string, { at: number; value: unknown }>()

/** The last good value, however old: a throttled feed can still show it. */
function peek<T>(key: string): { at: number; value: T } | null {
  const hit = cache.get(key)
  return hit ? { at: hit.at, value: hit.value as T } : null
}

async function cached<T>(key: string, ttlMs: number, load: () => Promise<T>): Promise<T> {
  const hit = cache.get(key)
  if (hit && Date.now() - hit.at < ttlMs) return hit.value as T
  const value = await load()
  cache.set(key, { at: Date.now(), value })
  if (cache.size > 150) cache.delete(cache.keys().next().value as string)
  return value
}

/**
 * GeckoTerminal allows 30 requests a minute per address, and a Worker shares its
 * egress with other tenants, so a 429 from it is routine and usually clears on a
 * retry. That retry is the difference between a working leaderboard and an empty
 * card. A 4xx that will not change is not retried.
 */
async function getJson<T>(url: string, timeout = 15_000): Promise<T> {
  const host = new URL(url).hostname
  let wait = 500
  for (let attempt = 0; attempt < 3; attempt++) {
    const response = await fetch(url, {
      headers: { accept: 'application/json', 'user-agent': UA },
      signal: AbortSignal.timeout(timeout),
    }).catch(() => null)
    if (response?.ok) return (await response.json()) as T
    const status = response?.status ?? 0
    if (status !== 0 && status !== 429 && status < 500) throw new Error(`${host} responded ${status}`)
    if (attempt === 2) {
      if (status === 429) throw new Error(`${host} is throttling this server (HTTP 429). It allows 30 requests a minute per address and this server shares one — another refresh usually gets through.`)
      throw new Error(status === 0 ? `${host} did not answer.` : `${host} responded ${status}.`)
    }
    const header = Number(response?.headers.get('retry-after'))
    await new Promise((resolve) => setTimeout(resolve, Number.isFinite(header) && header > 0 ? Math.min(header * 1_000, 2_000) : wait))
    wait *= 3
  }
  throw new Error(`${host} did not answer.`)
}

const num = (value: unknown): number | null => {
  const parsed = typeof value === 'number' ? value : Number.parseFloat(String(value ?? ''))
  return Number.isFinite(parsed) ? parsed : null
}

/* ------------------------------------------------------------- pump.fun feed */

type GtPool = {
  id: string
  attributes?: {
    name?: string
    base_token_price_usd?: string
    fdv_usd?: string
    market_cap_usd?: string | null
    reserve_in_usd?: string
    pool_created_at?: string
    volume_usd?: Record<string, string>
    price_change_percentage?: Record<string, string>
  }
  relationships?: { base_token?: { data?: { id?: string } }; dex?: { data?: { id?: string } } }
}

type DsPair = {
  dexId?: string
  pairAddress?: string
  priceUsd?: string
  fdv?: number
  marketCap?: number
  baseToken?: { address?: string; name?: string; symbol?: string }
  quoteToken?: { address?: string; symbol?: string }
  liquidity?: { usd?: number }
  volume?: { h24?: number }
  priceChange?: { h24?: number }
}

/** Symbol out of a GeckoTerminal pool name like "COOKED / SOL". */
export const symbolFromPoolName = (name?: string): string => (name ?? '').split(' / ')[0]!.trim()

function toCoin(pool: GtPool): MemeCoin | null {
  const mint = (pool.relationships?.base_token?.data?.id ?? '').replace(/^solana_/, '')
  if (!mint) return null
  const attributes = pool.attributes ?? {}
  const dex = pool.relationships?.dex?.data?.id ?? 'unknown'
  const symbol = symbolFromPoolName(attributes.name) || `${mint.slice(0, 4)}…`
  const created = attributes.pool_created_at ? Date.parse(attributes.pool_created_at) : Number.NaN
  const reserve = num(attributes.reserve_in_usd)
  return {
    mint,
    symbol,
    name: symbol,
    price: num(attributes.base_token_price_usd),
    change24h: num(attributes.price_change_percentage?.h24),
    volume24h: num(attributes.volume_usd?.h24),
    marketCap: num(attributes.market_cap_usd) ?? num(attributes.fdv_usd),
    liquidity: reserve != null && reserve > 1 ? reserve : null,
    pool: pool.id.replace(/^solana_/, ''),
    dex,
    venue: dex === 'pump-fun' ? 'pump.fun' : dex === 'pumpswap' ? 'PumpSwap' : dex,
    createdAt: Number.isFinite(created) ? created : null,
    url: `https://pump.fun/coin/${mint}`,
  }
}

/** One row per mint, keeping whichever pool carries the most volume. */
function mergePools(lists: (GtPool[] | undefined)[]): MemeCoin[] {
  const seen = new Map<string, MemeCoin>()
  for (const list of lists) {
    for (const pool of list ?? []) {
      const coin = toCoin(pool)
      if (!coin) continue
      const existing = seen.get(coin.mint)
      if (!existing || (coin.volume24h ?? 0) > (existing.volume24h ?? 0)) seen.set(coin.mint, coin)
    }
  }
  return [...seen.values()]
}

/**
 * GeckoTerminal's `reserve_in_usd` collapses on bonding-curve pools, so the
 * pool depth shown to users comes from DexScreener, which measures the pair's
 * actual liquidity. One batched request covers the whole page.
 */
async function withLiquidity(items: MemeCoin[]): Promise<MemeCoin[]> {
  if (!items.length) return items
  const prices = await pricesFor(items.map((coin) => coin.mint))
  return items.map((coin) => {
    const market = prices.get(coin.mint)
    if (!market) return coin
    const liquidity = market.liquidity != null && market.liquidity > 1 ? market.liquidity : null
    return {
      ...coin,
      price: coin.price ?? market.price,
      change24h: coin.change24h ?? market.change24h,
      liquidity: coin.liquidity ?? liquidity,
    }
  })
}

export type MemeSort = 'volume' | 'new'

/**
 * The pump.fun leaderboard: movers by 24h volume (bonding curve plus graduated
 * PumpSwap pools), or the freshest launches.
 */
export async function memeFeed(sort: MemeSort = 'volume'): Promise<MemeFeed> {
  const key = `feed:${sort}`
  const load = async (): Promise<MemeFeed> => {
    if (sort === 'new') {
      const fresh = await getJson<{ data?: GtPool[] }>(`${GT}/networks/solana/new_pools?page=1`)
      const items = mergePools([fresh.data])
        .filter((coin) => coin.dex === 'pump-fun' || coin.dex === 'pumpswap')
        .sort((a, b) => (b.createdAt ?? 0) - (a.createdAt ?? 0))
      return {
        items: await withLiquidity(items.slice(0, 24)),
        updatedAt: Date.now(),
        source: 'GeckoTerminal · new pump.fun launches',
      }
    }
    const [curve, graduated] = await Promise.all([
      getJson<{ data?: GtPool[] }>(`${GT}/networks/solana/dexes/pump-fun/pools?page=1&sort=h24_volume_usd_desc`),
      getJson<{ data?: GtPool[] }>(`${GT}/networks/solana/dexes/pumpswap/pools?page=1&sort=h24_volume_usd_desc`),
    ])
    const items = mergePools([curve.data, graduated.data]).sort((a, b) => (b.volume24h ?? 0) - (a.volume24h ?? 0))
    return {
      items: await withLiquidity(items.slice(0, 24)),
      updatedAt: Date.now(),
      source: 'GeckoTerminal · pump.fun + PumpSwap by 24h volume',
    }
  }

  try {
    return await cached(key, 60_000, load)
  } catch (error) {
    // A throttle must not blank a card that was working a minute ago, and the last
    // snapshot must not pass as live: its age goes into the source line.
    const previous = peek<MemeFeed>(key)
    if (!previous) throw error
    const at = new Date(previous.at).toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' })
    return { ...previous.value, source: `${previous.value.source} · snapshot from ${at} while the feed is throttled` }
  }
}

/* ----------------------------------------------------------- token forecast */

/** Newest-first OHLCV from GeckoTerminal, oldest first for the indicators. */
export const RATE_LIMITED = 'Candle data is rate limited right now. Try again in a minute — this is a feed limit, not a problem with the token.'

// GeckoTerminal allows 30 requests a minute per address, and a Worker shares its
// egress with other tenants, so one 429 is common and clears on its own. The read
// is cached briefly for the same reason: two tools in one turn ask for it twice.
async function poolCandles(pool: string, interval: 'day' | 'hour'): Promise<Candle[]> {
  return cached(`ohlcv:${pool}:${interval}`, 45_000, async () => {
    let wait = 400
    for (let attempt = 0; attempt < 3; attempt++) {
      const response = await fetch(`${GT}/networks/solana/pools/${pool}/ohlcv/${interval}?limit=180&currency=usd`, {
        headers: { accept: 'application/json', 'user-agent': 'Mozilla/5.0 (compatible; Ulvarin/1.0)' },
        signal: AbortSignal.timeout(12_000),
      }).catch(() => null)
      if (response?.status === 429) {
        // A throttle is not "this pool has no history". Reporting it as missing
        // data would be a false statement about the token, so after the last
        // attempt it is raised instead.
        if (attempt === 2) throw new Error(RATE_LIMITED)
        const header = Number(response.headers.get('retry-after'))
        const delay = Number.isFinite(header) && header > 0 ? Math.min(header * 1_000, 2_000) : wait
        await new Promise((resolve) => setTimeout(resolve, delay))
        wait *= 3
        continue
      }
      if (!response?.ok) return []
      const body = (await response.json().catch(() => null)) as { data?: { attributes?: { ohlcv_list?: number[][] } } } | null
      return (body?.data?.attributes?.ohlcv_list ?? [])
        .map(([t, o, h, l, c, v]) => ({ t: (t ?? 0) * 1000, o: o ?? 0, h: h ?? 0, l: l ?? 0, c: c ?? 0, v: v ?? 0 }))
        .reverse()
    }
    return []
  })
}

/**
 * The same indicator pass as listed markets, on a Solana pool's daily candles.
 * Pool candles are the only honest series for a token this young; a token with
 * a few hours of history is refused rather than forecast from noise.
 */
export type MemeSeries = {
  symbol: string
  price: number
  candles: Candle[]
  timeframe: 'daily' | 'hourly'
  source: string
  note: string
}

/** The best candle series a mint has, plus where it came from. */
export async function memeSeries(mint: string): Promise<MemeSeries> {
  const pairs = await getJson<DsPair[]>(`${DS}/tokens/v1/solana/${mint}`).catch(() => [] as DsPair[])
  // Highest-liquidity first, but try several: a dead pool can outrank the one
  // that actually trades, and an empty pool has no candles to read.
  const candidates = pairs
    .filter((pair) => pair.pairAddress && pair.priceUsd && pair.baseToken?.address === mint)
    .sort((a, b) => (b.liquidity?.usd ?? 0) - (a.liquidity?.usd ?? 0))
    .slice(0, 3)
  if (!candidates.length) throw new Error('That mint has no trading pair with a price yet.')

  const symbol = candidates[0]!.baseToken?.symbol ?? `${mint.slice(0, 4)}…`
  let best: { candles: Candle[]; pair: DsPair; hourly: boolean } | null = null
  for (const pair of candidates) {
    // A pump.fun launch is often hours old: no daily series exists yet, so an
    // hourly series is the honest fallback before refusing to forecast at all.
    const daily = await poolCandles(pair.pairAddress!, 'day')
    if (daily.length >= 30) {
      best = { candles: daily, pair, hourly: false }
      break
    }
    const hourly = await poolCandles(pair.pairAddress!, 'hour')
    if (hourly.length >= 30) {
      best = { candles: hourly, pair, hourly: true }
      break
    }
  }
  if (!best) {
    throw new Error(`No pool for ${symbol} has enough candle history to forecast — pump.fun launches are often only hours old. Give it a few days, or ask for the quote and volume instead.`)
  }

  return {
    symbol,
    price: num(best.pair.priceUsd) ?? best.candles.at(-1)?.c ?? 0,
    candles: best.candles,
    timeframe: best.hourly ? 'hourly' : 'daily',
    // GeckoTerminal OHLCV is requested with currency=usd above.
    source: `GeckoTerminal ${best.hourly ? 'hourly' : 'daily'} candles · ${best.pair.dexId ?? 'unknown venue'}`,
    note: [
      best.hourly ? 'Hourly candles because the pool is young, so levels are intraday, not multi-week.' : '',
      best.pair.dexId === 'pump-fun'
        ? 'Bonding-curve pool: liquidity is thin and can be pulled, so treat levels as approximate.'
        : 'Pool-level candles: wicks reflect one venue, not the whole market.',
    ]
      .filter(Boolean)
      .join(' '),
  }
}

/**
 * The same indicator pass as listed markets, on a Solana pool's daily candles.
 * Pool candles are the only honest series for a token this young; a token with
 * a few hours of history is refused rather than forecast from noise.
 */
export async function memeForecast(mint: string): Promise<Analysis> {
  const series = await memeSeries(mint)
  return analyseCandles({
    symbol: series.symbol,
    name: `${series.symbol} (Solana)`,
    kind: 'crypto',
    price: series.price,
    currency: 'USD',
    candles: series.candles,
    timeframe: series.timeframe,
    source: series.source,
    note: series.note,
  })
}

/* -------------------------------------------------------------- wallet read */

export const isSolanaAddress = (value: string): boolean => /^[1-9A-HJ-NP-Za-km-z]{32,44}$/.test(value)

type RpcAccount = {
  account?: {
    data?: {
      parsed?: {
        info?: { mint?: string; tokenAmount?: { uiAmount?: number | null; amount?: string; decimals?: number } }
      }
    }
  }
}

/** A wallet with a pathological number of token accounts is refused early. */
class RpcTooLarge extends Error {}

/** An endpoint said no. 4xx failures are not retried; another host might work. */
class RpcHttpError extends Error {
  constructor(
    public status: number,
    detail = '',
  ) {
    super(`The Solana RPC responded ${status}${detail ? `: ${detail}` : ''}`)
  }
}

const MAX_RPC_BYTES = 6 * 1024 * 1024

async function readBounded(response: Response, limit: number): Promise<string> {
  if (!response.body) return ''
  const reader = response.body.getReader()
  const decoder = new TextDecoder()
  let text = ''
  let received = 0
  try {
    for (;;) {
      const { value, done } = await reader.read()
      if (done) break
      received += value.byteLength
      if (received > limit) {
        throw new RpcTooLarge(
          'That wallet has far more token accounts than the app will read in one request. Point SOLANA_RPC_URL at your own node, or check a smaller wallet.',
        )
      }
      text += decoder.decode(value, { stream: true })
    }
    text += decoder.decode()
    return text
  } finally {
    void reader.cancel().catch(() => {})
  }
}

async function rpc<T>(url: string, body: unknown, timeout = 20_000): Promise<T> {
  const response = await fetch(url, {
    method: 'POST',
    // An honest custom agent, not a browser one: impersonating Chrome from a
    // Worker trips bot detection, because the TLS fingerprint does not match.
    headers: { 'content-type': 'application/json', accept: 'application/json', 'user-agent': 'ulvarin/1.0' },
    body: JSON.stringify(body),
    signal: AbortSignal.timeout(timeout),
  })
  if (!response.ok) throw new RpcHttpError(response.status, (await response.text()).replace(/\s+/g, ' ').slice(0, 140))
  const payload = JSON.parse(await readBounded(response, MAX_RPC_BYTES)) as { result?: T; error?: { message?: string } }
  if (payload.error) throw new Error(payload.error.message ?? 'The Solana RPC returned an error.')
  return payload.result as T
}

/** The public RPC rate-limits bursts, so every wallet call gets one retry. */
async function rpcWithRetry<T>(url: string, body: unknown): Promise<T | null> {
  for (let attempt = 0; attempt < 2; attempt++) {
    try {
      return await rpc<T>(url, body)
    } catch (error) {
      if (error instanceof RpcTooLarge) throw error
      // A 403/401/400 will not improve by waiting; let the next host be tried.
      if (error instanceof RpcHttpError && error.status !== 429 && error.status < 500) throw error
      console.error('Solana RPC call failed:', error instanceof Error ? error.message : error)
      if (attempt === 0) await new Promise((resolve) => setTimeout(resolve, 600))
    }
  }
  return null
}

type PriceInfo = { price: number | null; change24h: number | null; liquidity: number | null; symbol: string | null }

function chunks<T>(items: T[], size: number): T[][] {
  const out: T[][] = []
  for (let index = 0; index < items.length; index += size) out.push(items.slice(index, index + size))
  return out
}

/** DexScreener prices for up to 30 mints per call, best-liquidity pair wins. */
async function pricesFor(mints: string[]): Promise<Map<string, PriceInfo>> {
  const prices = new Map<string, PriceInfo>()
  const wanted = new Set(mints)
  const groups = await Promise.all(
    chunks(mints, 30).map((group) => getJson<DsPair[]>(`${DS}/tokens/v1/solana/${group.join(',')}`).catch(() => [] as DsPair[])),
  )
  for (const pairs of groups) {
    for (const pair of pairs) {
      const mint = pair.baseToken?.address
      if (!mint || !wanted.has(mint)) continue
      const liquidity = pair.liquidity?.usd ?? 0
      const existing = prices.get(mint)
      if (existing && (existing.liquidity ?? 0) >= liquidity) continue
      prices.set(mint, {
        price: num(pair.priceUsd),
        change24h: num(pair.priceChange?.h24),
        liquidity,
        symbol: pair.baseToken?.symbol ?? null,
      })
    }
  }
  return prices
}

/**
 * Public balances for a Solana address, priced in USD. Both token programs are
 * read, because pump.fun tokens can be issued under either. Tokens with no
 * market are reported as unpriced instead of being valued at zero.
 */
type RawAccounts = {
  balance: { value: number } | null
  classic: { value: RpcAccount[] } | null
  token2022: { value: RpcAccount[] } | null
}

/**
 * Reads the three account sets from the first endpoint that answers. The calls
 * are sequential because the shared endpoints reject bursts, and a configured
 * endpoint is tried before the defaults rather than instead of them.
 */
async function readAccounts(rpcUrl: string | undefined, address: string): Promise<RawAccounts> {
  if (!rpcUrl) {
    throw new Error(
      `${WALLET_RPC_REQUIRED}: reading a Solana wallet needs an RPC endpoint. Set SOLANA_RPC_URL to a node you control — a free Helius or QuickNode URL takes a minute — then reload. The pump.fun feed works without it.`,
    )
  }
  const endpoints = [rpcUrl]
  let failure: Error | null = null
  for (const endpoint of endpoints) {
    try {
      const balance = await rpcWithRetry<{ value: number }>(endpoint, { jsonrpc: '2.0', id: 1, method: 'getBalance', params: [address] })
      const classic = await rpcWithRetry<{ value: RpcAccount[] }>(endpoint, {
        jsonrpc: '2.0',
        id: 2,
        method: 'getTokenAccountsByOwner',
        params: [address, { programId: TOKEN_PROGRAM }, { encoding: 'jsonParsed' }],
      })
      const token2022 = await rpcWithRetry<{ value: RpcAccount[] }>(endpoint, {
        jsonrpc: '2.0',
        id: 3,
        method: 'getTokenAccountsByOwner',
        params: [address, { programId: TOKEN_2022_PROGRAM }, { encoding: 'jsonParsed' }],
      })
      if (balance || classic || token2022) return { balance, classic, token2022 }
      failure = new Error('The Solana RPC rate-limited this request.')
    } catch (error) {
      if (error instanceof RpcTooLarge) throw error
      failure = error instanceof Error ? error : failure
      console.error('Solana RPC endpoint failed:', endpoint, failure?.message)
    }
  }
  throw new Error(failure?.message ?? 'The Solana RPC did not answer.')
}

export async function walletPortfolio(address: string, rpcUrl?: string): Promise<WalletPortfolio> {
  if (!isSolanaAddress(address)) throw new Error('That is not a Solana wallet address.')

  return cached(`wallet:${address}`, 30_000, async () => {
    const { balance, classic, token2022 } = await readAccounts(rpcUrl, address)

    const amounts = new Map<string, number>()
    for (const entry of [...(classic?.value ?? []), ...(token2022?.value ?? [])]) {
      const info = entry.account?.data?.parsed?.info
      const mint = info?.mint
      const amount = info?.tokenAmount?.uiAmount ?? null
      if (!mint || amount == null || amount <= 0) continue
      amounts.set(mint, (amounts.get(mint) ?? 0) + amount)
    }

    // Priced in batched calls of 30, so 100 mints is four lookups — enough that
    // a real wallet is never silently truncated.
    const mints = [...amounts.keys()].slice(0, 100)
    const prices = await pricesFor([SOL_MINT, ...mints])
    const sol = (balance?.value ?? 0) / 1e9
    const solPrice = prices.get(SOL_MINT)?.price ?? null

    const holdings: WalletHolding[] = mints
      .map((mint) => {
        const amount = amounts.get(mint) ?? 0
        const price = prices.get(mint)
        return {
          mint,
          symbol: price?.symbol ?? `${mint.slice(0, 4)}…`,
          name: price?.symbol ?? 'Unlisted token',
          amount,
          price: price?.price ?? null,
          value: price?.price != null ? amount * price.price : null,
          change24h: price?.change24h ?? null,
          liquidity: price?.liquidity ?? null,
        }
      })
      .sort((a, b) => (b.value ?? -1) - (a.value ?? -1))

    const priced = holdings.reduce((sum, holding) => sum + (holding.value ?? 0), 0)
    const solValue = solPrice != null ? sol * solPrice : null
    return {
      address,
      sol,
      solValue,
      totalValue: solValue != null || priced > 0 ? (solValue ?? 0) + priced : null,
      holdings,
      unpriced: holdings.filter((holding) => holding.value == null).length,
      updatedAt: Date.now(),
    }
  })
}
