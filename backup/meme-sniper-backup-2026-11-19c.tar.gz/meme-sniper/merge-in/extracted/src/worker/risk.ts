// Rug-pull and developer-risk screen for a Solana token.
//
// Two layers: pool facts anyone can see (DexScreener), and on-chain holder facts
// that need an RPC endpoint. Every check that could not run is named in the
// output — a missing check is never silently scored as safe.

const UA = 'Mozilla/5.0 (compatible; Ulvarin/1.0)'
const DEX = 'https://api.dexscreener.com'

export type HolderRow = { address: string; pct: number }

export type RiskFlag = { level: 'high' | 'medium' | 'info'; note: string }

export type RugAssessment = {
  mint: string
  symbol: string
  name: string | null
  price: number | null
  change24h: number | null
  liquidityUsd: number | null
  /** Where the liquidity figure came from, so the number carries its own caveat. */
  liquiditySource: string
  /** How many pools the liquidity figure was summed across. */
  poolCount: number
  marketCapUsd: number | null
  ageHours: number | null
  liquidityToMarketCapPct: number | null
  volume24hUsd: number | null
  /** On-chain checks, null when no RPC is configured. */
  holders: { top1Pct: number | null; top10Pct: number; top: HolderRow[] } | null
  /** Whether an RPC was available at all, so the text can name the real reason. */
  rpcConfigured: boolean
  mintAuthority: string | null
  freezeAuthority: string | null
  supply: number | null
  flags: RiskFlag[]
  checked: string[]
  unavailable: string[]
}

type DsPair = {
  chainId?: string
  dexId?: string
  pairAddress?: string
  baseToken?: { address?: string; symbol?: string; name?: string }
  priceUsd?: string
  priceChange?: { h24?: number }
  liquidity?: { usd?: number }
  fdv?: number
  marketCap?: number
  pairCreatedAt?: number
  volume?: { h24?: number }
}

type TokenAccount = { address?: string; uiAmount?: number | null; uiAmountString?: string; amount?: string; decimals?: number }

type RpcResult<T> = { result?: T; error?: { message?: string } }

async function rpcCall<T>(url: string, body: unknown, timeout = 12_000): Promise<T | null> {
  const response = await fetch(url, {
    method: 'POST',
    headers: { 'content-type': 'application/json', accept: 'application/json', 'user-agent': 'ulvarin/1.0' },
    body: JSON.stringify(body),
    signal: AbortSignal.timeout(timeout),
  }).catch(() => null)
  if (!response?.ok) return null
  const payload = (await response.json().catch(() => null)) as RpcResult<T> | null
  if (!payload || payload.error) return null
  return payload.result ?? null
}

/** Total reserve across every indexed pool. DexScreener's token endpoint only
 *  returns a handful of pairs, so one pool's depth is not a token's liquidity. */
async function geckoReserve(mint: string): Promise<{ reserve: number | null; marketCap: number | null } | null> {
  const response = await fetch(`https://api.geckoterminal.com/api/v2/networks/solana/tokens/${mint}`, {
    headers: { accept: 'application/json', 'user-agent': UA },
    signal: AbortSignal.timeout(10_000),
  }).catch(() => null)
  if (!response?.ok) return null
  const body = (await response.json().catch(() => null)) as { data?: { attributes?: Record<string, unknown> } } | null
  const attributes = body?.data?.attributes
  if (!attributes) return null
  return { reserve: num(attributes.total_reserve_in_usd), marketCap: num(attributes.market_cap_usd) }
}

const num = (value: unknown): number | null => {
  const parsed = typeof value === 'number' ? value : typeof value === 'string' ? Number(value) : NaN
  return Number.isFinite(parsed) ? parsed : null
}

/**
 * What is knowable about a mint right now. `rpcUrl` is optional: without it the
 * holder and authority checks are listed as unavailable rather than guessed.
 */
export async function assessToken(mint: string, rpcUrl?: string): Promise<RugAssessment> {
  const response = await fetch(`${DEX}/tokens/v1/solana/${encodeURIComponent(mint)}`, {
    headers: { accept: 'application/json', 'user-agent': UA },
    signal: AbortSignal.timeout(12_000),
  }).catch(() => null)
  if (!response?.ok) throw new Error(`DexScreener did not answer for that mint (HTTP ${response?.status ?? 'no response'}).`)
  const pairs = ((await response.json().catch(() => [])) as DsPair[]) ?? []
  const own = pairs.filter((pair) => pair.baseToken?.address === mint).sort((a, b) => (b.liquidity?.usd ?? 0) - (a.liquidity?.usd ?? 0))
  const best = own[0]
  if (!best) throw new Error('No trading pair on DexScreener lists that mint as its base token.')

  // Liquidity is summed across every pool for this mint. Reading one pool would
  // call a liquid token thin just because its deepest book sits elsewhere.
  const poolLiquidity = own.reduce((sum, pair) => sum + (num(pair.liquidity?.usd) ?? 0), 0)
  const aggregate = await geckoReserve(mint).catch(() => null)
  const liquidity = aggregate?.reserve ?? (poolLiquidity > 0 ? poolLiquidity : null)
  const liquiditySource = aggregate?.reserve
    ? 'GeckoTerminal, all indexed pools'
    : 'DexScreener, the pools it returned'
  const marketCap = num(best.marketCap) ?? num(best.fdv) ?? aggregate?.marketCap ?? null
  const flags: RiskFlag[] = []
  const checked: string[] = ['market price and pool liquidity (DexScreener)', 'pair age (DexScreener)']
  const unavailable: string[] = []

  // Oldest pool, not the newest: this is how long the token has traded at all.
  const oldest = own.reduce((earliest, pair) => (pair.pairCreatedAt && pair.pairCreatedAt < earliest ? pair.pairCreatedAt : earliest), Number.MAX_SAFE_INTEGER)
  const ageMs = oldest === Number.MAX_SAFE_INTEGER ? null : Date.now() - oldest
  const ageHours = ageMs == null ? null : ageMs / 3_600_000

  const liquidityToMarketCapPct = liquidity != null && marketCap ? (liquidity / marketCap) * 100 : null
  if (liquidityToMarketCapPct != null) {
    checked.push('liquidity versus market cap')
    if (liquidityToMarketCapPct < 2) flags.push({ level: 'high', note: `thin exit: pool liquidity is ${liquidityToMarketCapPct.toFixed(2)}% of market cap` })
    else if (liquidityToMarketCapPct < 5) flags.push({ level: 'medium', note: `shallow pool: liquidity is ${liquidityToMarketCapPct.toFixed(2)}% of market cap` })
  }
  if (ageHours != null) {
    if (ageHours < 24) flags.push({ level: 'medium', note: `the primary pool is ${ageHours.toFixed(1)} hours old` })
  }
  const change = num(best.priceChange?.h24)
  if (change != null && change <= -70) flags.push({ level: 'high', note: `already down ${change.toFixed(0)}% in 24h — this is a post-dump, not an entry` })

  // On-chain layer.
  let holders: RugAssessment['holders'] = null
  let mintAuthority: string | null = null
  let freezeAuthority: string | null = null
  let supply: number | null = null
  if (!rpcUrl) {
    unavailable.push('holder concentration (needs SOLANA_RPC_URL)', 'mint and freeze authority (needs SOLANA_RPC_URL)', 'LP burn status (not checked)')
  } else {
    const account = await rpcCall<{ value?: { data?: { parsed?: { info?: Record<string, unknown> } } } | null }>(rpcUrl, {
      jsonrpc: '2.0',
      id: 1,
      method: 'getAccountInfo',
      params: [mint, { encoding: 'jsonParsed' }],
    })
    const info = account?.value?.data?.parsed?.info as
      | { mintAuthority?: string | null; freezeAuthority?: string | null; supply?: string; decimals?: number }
      | undefined
    if (!info) {
      unavailable.push('mint account read failed — the RPC did not return parsed token data')
    } else {
      checked.push('mint and freeze authority (on-chain)')
      mintAuthority = info.mintAuthority ?? null
      freezeAuthority = info.freezeAuthority ?? null
      const rawSupply = num(info.supply)
      const decimals = num(info.decimals) ?? 0
      supply = rawSupply == null ? null : rawSupply / 10 ** decimals
      if (mintAuthority) flags.push({ level: 'high', note: 'mint authority is still active: the creator can mint more supply' })
      if (freezeAuthority) flags.push({ level: 'high', note: 'freeze authority is still active: the creator can freeze holder wallets' })
    }

    const largest = await rpcCall<{ value?: TokenAccount[] }>(rpcUrl, {
      jsonrpc: '2.0',
      id: 2,
      method: 'getTokenLargestAccounts',
      params: [mint],
    })
    // uiAmount is deprecated on some endpoints and comes back null even when the
    // balance is there, so fall back to uiAmountString and then raw amount. A row
    // that parses to nothing is dropped rather than counted as 0%: scoring an
    // unread balance as zero would report a concentration that was never read.
    const rows = (largest?.value ?? [])
      .map((row) => {
        const decimals = num(row.decimals) ?? 0
        const raw = num(row.amount)
        const amount = num(row.uiAmount) ?? num(row.uiAmountString) ?? (raw == null ? null : raw / 10 ** decimals)
        return { address: String(row.address ?? ''), amount }
      })
      .filter((row): row is { address: string; amount: number } => row.amount != null && row.amount > 0)
    if (supply == null) {
      unavailable.push('holder concentration read failed (the token supply could not be read)')
    } else if (!rows.length) {
      unavailable.push('holder concentration read failed (the RPC returned no holder balances)')
    } else {
      checked.push('top-10 holder concentration (on-chain)')
      const total = supply
      const top = rows
        .sort((a, b) => b.amount - a.amount)
        .slice(0, 10)
        .map((row) => ({ address: row.address, pct: total ? (row.amount / total) * 100 : 0 }))
      holders = {
        top1Pct: top[0]?.pct ?? null,
        top10Pct: top.reduce((sum, row) => sum + row.pct, 0),
        top,
      }
      // Largest accounts include the pool's own token account, so a big number
      // here is a signal to inspect, not proof of a dev dump.
      if (holders.top1Pct != null && holders.top1Pct >= 25)
        flags.push({ level: 'medium', note: `one account holds ${holders.top1Pct.toFixed(1)}% of supply (pool accounts count here — verify it is liquidity)` })
      if (holders.top10Pct >= 70) flags.push({ level: 'medium', note: `the top 10 accounts hold ${holders.top10Pct.toFixed(1)}% of supply` })
    }
    unavailable.push('LP burn status (needs the pool LP mint, not checked)', 'developer wallet history (not checked)')
  }

  if (best.dexId === 'pump-fun') flags.push({ level: 'medium', note: 'bonding-curve pool: liquidity can be pulled and price impact is large' })

  return {
    mint,
    symbol: best.baseToken?.symbol ?? mint.slice(0, 4),
    name: best.baseToken?.name ?? null,
    price: num(best.priceUsd),
    change24h: change,
    liquidityUsd: liquidity,
    liquiditySource,
    poolCount: own.length,
    marketCapUsd: marketCap,
    ageHours,
    liquidityToMarketCapPct,
    volume24hUsd: num(best.volume?.h24),
    holders,
    rpcConfigured: Boolean(rpcUrl),
    mintAuthority,
    freezeAuthority,
    supply,
    flags,
    checked,
    unavailable,
  }
}

const money = (value: number | null): string => {
  if (value == null) return 'n/a'
  if (value >= 1_000_000) return `$${(value / 1_000_000).toFixed(2)}M`
  if (value >= 1_000) return `$${(value / 1_000).toFixed(1)}K`
  return value >= 1 ? `$${value.toFixed(2)}` : `$${value.toPrecision(4)}`
}

const authorityText = (risk: RugAssessment, address: string | null): string => {
  if (address) return `ACTIVE (${address.slice(0, 8)}…)`
  if (!risk.rpcConfigured) return 'unknown (no RPC)'
  if (risk.checked.some((item) => item.includes('authority'))) return 'revoked'
  return 'unknown (the RPC read failed)'
}

/** Text block for the model. Signals first, then what could not be checked. */
export function describeRisk(risk: RugAssessment): string {
  const high = risk.flags.filter((flag) => flag.level === 'high')
  const medium = risk.flags.filter((flag) => flag.level === 'medium')
  const lines = [
    `RUG SCREEN — ${risk.symbol}${risk.name ? ` (${risk.name})` : ''}`,
    `price ${money(risk.price)}${risk.change24h == null ? '' : ` · 24h ${risk.change24h >= 0 ? '+' : ''}${risk.change24h.toFixed(1)}%`} · liquidity ${money(risk.liquidityUsd)} (${risk.liquiditySource}) · market cap ${money(risk.marketCapUsd)}${
      risk.liquidityToMarketCapPct == null ? '' : ` · liquidity ${risk.liquidityToMarketCapPct.toFixed(2)}% of cap`
    }${risk.ageHours == null ? '' : ` · pool age ${risk.ageHours < 48 ? `${risk.ageHours.toFixed(1)}h` : `${(risk.ageHours / 24).toFixed(1)}d`}`}`,
    `mint authority ${authorityText(risk, risk.mintAuthority)}`,
    `freeze authority ${authorityText(risk, risk.freezeAuthority)}`,
  ]
  if (risk.holders) {
    lines.push(`top holder ${risk.holders.top1Pct?.toFixed(1) ?? 'n/a'}% · top 10 ${risk.holders.top10Pct.toFixed(1)}% of supply`)
  } else if (!risk.rpcConfigured) {
    lines.push('holder concentration: not measured — no Solana RPC is configured')
  } else {
    lines.push('holder concentration: not measured — the RPC blocked or failed the holder read')
  }
  lines.push('', `SIGNALS — ${high.length} high, ${medium.length} medium`)
  if (!risk.flags.length) lines.push('no mechanical warning fired. That is not a clean bill of health: it means none of the checks below returned a red flag.')
  for (const flag of risk.flags) lines.push(`- [${flag.level}] ${flag.note}`)
  lines.push('', `CHECKED: ${risk.checked.join('; ')}`)
  if (risk.unavailable.length) lines.push(`NOT CHECKED: ${risk.unavailable.join('; ')}`)
  lines.push('', 'These are signals from public data, not a verdict. Say what was and was not checked, and never call a token "safe".')
  return lines.join('\n').slice(0, 3_000)
}
