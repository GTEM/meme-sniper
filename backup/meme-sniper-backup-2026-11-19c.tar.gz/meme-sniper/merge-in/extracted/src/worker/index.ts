import { Hono } from 'hono'

import { requireUser } from './auth'
import { requireDb } from './db'
import type { AppContext, Env } from './env'
import { account } from './routes/account'
import { admin } from './routes/admin'
import { ai } from './routes/ai'
import { authRoutes } from './routes/auth'
import { chat } from './routes/chat'
import { conversations } from './routes/conversations'
import { markets } from './routes/markets'
import { meme, wallet } from './routes/meme'
import { memory } from './routes/memory'
import { settings } from './routes/settings'
import { sources } from './routes/sources'
import { studio } from './routes/studio'

const app = new Hono<AppContext>()

app.get('/api/health', (c) => c.json({ ok: true }))

// Public: claiming the instance, signing up, signing in, signing out.
app.route('/api/auth', authRoutes)

// Everything else requires an admitted account. requireDb runs first so the
// session lookup has a database; requireUser then resolves the cookie.
const api = new Hono<AppContext>()
api.use('*', requireDb, requireUser)
api.route('/', account)
api.route('/admin', admin)
api.route('/ai', ai)
api.route('/conversations', conversations)
api.route('/chat', chat)
api.route('/memory', memory)
api.route('/markets', markets)
api.route('/meme', meme)
api.route('/wallet', wallet)
api.route('/settings', settings)
api.route('/sources', sources)
api.route('/studio', studio)
app.route('/api', api)

app.onError((error, c) => {
  console.error(error)
  return c.json({ error: 'Something went wrong.' }, 500)
})
app.notFound((c) => (c.req.path.startsWith('/api/') ? c.json({ error: 'Not found.' }, 404) : c.env.ASSETS.fetch(c.req.raw)))

export default {
  fetch(request: Request, env: Env, ctx: ExecutionContext): Promise<Response> {
    return Promise.resolve(app.fetch(request, env, ctx))
  },
}
