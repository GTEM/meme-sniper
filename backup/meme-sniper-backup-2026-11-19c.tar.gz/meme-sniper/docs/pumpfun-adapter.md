# pump.fun adapter — implementation plan

**Status: plan only.** Nothing in this document is implemented except the venue
abstraction it plugs into ([src/venues.js](../src/venues.js)): positions now
carry a venue with its own round-trip cost and exit profile, and this adapter
adds `curve` as a real source and executor for that venue.

## 1. Goal

Detect pump.fun launches when they happen (same slot, not 30–60 seconds later),
price them on the bonding curve, and buy/sell on the curve using the risk
framework the bot already has (position caps, loss caps, cooldowns, profit
ladder, trailing stop, per-venue costs).

## 2. Why the current feeds cannot do this

`GeckoTerminal /new_pools` and `DexScreener token-profiles` only show tokens that
already have an *indexed pool with liquidity*. A pump.fun token spends its first
minutes on a bonding curve with no external pool at all, so:

- the feed sees it late (20–60s here, worse under rate limiting),
- `liqUsd`, `liqToMcap` and pool-depth slippage — three of the model's safety
  features — do not exist yet,
- the "liquidity pulled" rug rule cannot fire on a curve.

## 3. Non-goals

- Beating colocated bundle bots to the create block. That is a latency arms race
  you lose from a shared VM with a free RPC; the edge is in selection and exits
  over the following 30–90 seconds.
- Copy trading, wallet bundling, or creating tokens.
- Supporting every Solana launchpad. LaunchLab (letsbonk) can reuse the same
  interface later.

## 4. Module map

```
src/feeds/pumpfun/launch.js   LaunchFeed interface + adapters
                              (pumpdev | bitquery | rpc-logs)
src/feeds/pumpfun/curve.js    bonding-curve account decode + quote math
src/exec/solana-pump.js       buy/sell instruction builders + landing logic
src/venues.js                 already has the `curve` and `pumpswap` profiles
```

```
launch feed ──> normalise mint ──> prefilter (age, dev, bundle)
                                        │
                                        v
                            curve state read (single RPC call)
                                        │
                                        v
                    curve features ──> model.curve.json ──> entry
                                        │
                                        v
                    position(venue=curve) ──> exit engine (18% TP1)
                                        │
                             graduation? ──> venue pumpswap, re-price
```

## 5. Launch data provider — free, permanently

Constraint: **no subscriptions, no provider taking a cut of trades.** The only
money that leaves the wallet is Solana network gas, and the exit is the only
place the bot is ever allowed to pay more than the base fee.

Every option below is $0/month, and all of them are usable without a paid plan:

| Provider | Free stream | Cost | Cut of your trades | Notes |
| --- | --- | --- | --- | --- |
| **PumpPortal** | `subscribeNewToken`, `subscribeMigration` over `wss://pumpportal.fun/api/data` | $0 | none on the data stream; **0.5% Local / 1% Lightning** only if you call their trading endpoints — we never do | their own fee page: new-token and migration streams are free; trade streams are the metered ones (0.01 SOL / 10k messages) |
| **PumpDev** | `subscribeNewToken` | $0 on every tier | 0.25% only through their trading API | second decoder, different vendor |
| **PumpAPI.io** | full feed, filter client-side | $0 | none | third fallback |
| **Anaxer** | creations + graduations | $0 plan | none | fourth fallback |
| **Helius** | `logsSubscribe` + our own decoder | free tier, 1M credits/mo | none | RPC for reads and landing; detector only for emergencies |

**Decision:**

1. **Detection: two free sockets racing.** PumpPortal `subscribeNewToken` as the
   primary (filtered to `create`, no fee, no key needed for the free streams),
   PumpDev as the secondary, both behind the same `LaunchFeed` interface and
   deduplicated by mint. Two vendors instead of one also removes the old
   single-feed risk: if one changes terms, the other keeps running and the
   `rpc-logs` adapter is still a config change away.
2. **RPC (curve reads + transaction landing): Helius free tier**, or any free
   endpoint (`RPC_URL=https://api.mainnet-beta.solana.com`). Traffic is tiny —
   one `getAccountInfo` per candidate and one `sendTransaction` per fill — so
   the 1M-credit month is thousands of times more than this bot needs. Ping the
   websocket every 60s; idle sockets drop after 10 minutes.
3. **No paid tier is on the roadmap.** Helius Developer ($49/mo) and Bitquery
   CoreCast ($99/mo) buy latency this VM cannot use and historical curve data
   M1–M3 does not need. If the free feed ever becomes the measured bottleneck,
   the answer is a better decoder, not a bill.

**Why not raw `logsSubscribe` as the primary detector:** every pump.fun trade
emits logs, so the firehose is gigabytes per day — the free 1M credits are gone
in a day or two, and you would be paying to throw away 99% of it. A filtered
`create` stream costs nothing and removes a whole class of decode bugs.

**Why not their trading endpoints:** 0.5–1% per trade on PumpPortal, 0.25% on
PumpDev, on top of pump.fun's own 1.25% curve fee. A third party taking a slice
of every round trip is exactly the recurring cost this plan refuses. Detect with
their free feed, then build, sign and send the transaction yourself with
`@solana/web3.js` and the pump.fun IDL.

### What a "gas only" exit actually costs

| Item | Amount | Whose fee | Avoidable? |
| --- | --- | --- | --- |
| Solana base fee | 5,000 lamports per signature (~$0.0005 at $120 SOL) | network | no — this is the gas |
| Priority fee | **0 by default** (`PRIORITY_FEE_MICROLAMPORTS=0`); raised only on profit and rug exits | network | yes, off unless escalation fires |
| Jito tip | **0** — bundles are not used | — | yes, we do not buy them |
| ATA rent | 0.00203 SOL per token account | network, **refundable** | refunded by closing the account on exit (`CLOSE_ATA_ON_EXIT=1`) |
| pump.fun curve fee | 1.25% of each leg | pump.fun protocol | **no** — venue fee, not a provider |
| PumpSwap pool fee | 0.25% per leg after graduation | LPs | no |

So the exit transaction itself really does cost about a tenth of a cent. The
1.25% you feel on a curve trade is pump.fun's protocol fee, invisible to any
provider choice, and it is already inside the 250bps `curve` round-trip cost the
exit ladder uses. Nothing in this stack has a monthly bill or takes a percentage
of a trade.

Env additions:

```bash
PUMPFUN_FEED=portalpump         # portalpump | pumpdev | rpc-logs
PUMPFUN_FEED_KEY=               # optional; the free new-token streams need none
RPC_URL=                        # free tier: https://api.mainnet-beta.solana.com
HELIUS_API_KEY=                 # optional: wss/https://mainnet.helius-rpc.com/?api-key=...
PRIORITY_FEE_MICROLAMPORTS=0    # 0 = base fee only; bumped only on profit/rug exits
JITO_TIP_SOL=0                  # stays 0: no bundles, no tips
CLOSE_ATA_ON_EXIT=1             # reclaims the 0.00203 SOL token-account rent
```

## 6. Detection contract

- Program: `6EF8rrecthR5Dkzon8Nwu78hRvfCKubJ14M5uBEwF6P`
- Instructions: `create` `[24,30,200,40,5,28,7,119]` and `create_v2`
  `[214,144,76,236,95,139,49,180]`; new launches use `create_v2`, so match both.
- Mint is **account 0** in both. `create_v2` may carry extra trailing accounts
  (quote mint variants) — never assert on account count or data length.
- Take name/symbol/URI from the metadata, `Transaction.Signer` as creator.
- Deduplicate by mint; drop anything older than `maxAgeSec` to survive a replay
  storm on reconnect.

## 7. Curve pricing and cost model

- Price is `quote_reserve / token_reserve` on the virtual reserves; a buy moves
  both. Slippage is the **integral** over the curve, not a linear function of
  size — compute an exact quote for the intended size, and size down if the
  quote is worse than `maxSlippageBps`.
- Protocol fee on the curve is **1.25% total**, split creator/protocol. Round
  trip ≈ 2.5–3% including priority fee and graduation slippage, which is why the
  `curve` venue profile in [src/config.js](../src/config.js) uses 250bps and
  banks +18% instead of waiting for +60%.
- Completion is a token-balance constant (`complete == true`,
  `real_token_reserves == 0`), **not** a market-cap number. Do not hardcode
  "$69k".

## 8. Execution

- Build `buy(user, mint, amount, max_sol_cost)` / `sell(user, mint, amount,
  min_sol_output)` with the associated token account, `mint` and the curve.
- Landing is the hard part: send, rebroadcast every ~2s for 30s, abort on
  blockhash expiry, and record p50/p95 land time so the bot knows whether its
  edge is real. Priority fee starts at `PRIORITY_FEE_MICROLAMPORTS` (0) and is
  read from `getRecentPrioritizationFees` only after an exit escalates. No Jito
  tip, no bundle: that is a paid service, and the rule is gas only.
- Exit escalation reuses the existing policy verbatim: **entries never escalate;
  profit-taking and rug escapes may; ordinary stop losses never do.** It also
  has to pay for itself — the widened slippage plus extra priority fee
  (`escalationCostBps`) must be smaller than the profit being protected, or the
  exit is taken at the base fee and the profit is kept instead.

## 9. Features for the curve venue

The AMM feature set does not transfer. Replace:

| AMM feature | Curve replacement |
| --- | --- |
| liquidity USD | SOL raised on the curve |
| liq / market cap | curve progress % (of completion) |
| pool-depth slippage | integral quote slippage for our size |
| liquidity-pull rug rule | dev wallet sell + top-10 holder delta |
| volume turnover | buys/sells per minute and unique buyers, first 60s |
| — | creator wallet history (previous launches that died) |
| — | bundle cluster count (same funder, first N buyers) |
| socials, freshness, safety | unchanged (metadata URI + authority checks) |

Model weights are per venue (`data/model-curve.json`) — the priors differ enough
that sharing one vector would poison both.

## 10. Safety

- Verify `mint` and `freeze` authority are revoked before any buy (the program
  normally revokes them; trust nothing). The shared pre-entry rug analysis in
  [src/rug.js](../src/rug.js) already covers this, plus holder concentration,
  liquidity-vs-market-cap, liquidity that is already draining and single-minute
  dumps; the curve adapter only has to feed it the curve-shaped numbers below.
- Hard veto on bundle clusters above a threshold, oversized dev holding, or a
  creator with prior dead launches.
- One open position per creator wallet, so a serial launcher cannot fill the book.
- Skip curves already > ~85% complete on entry — you are buying the top.
- Immediate exit on dev sell, independent of PnL.

## 11. Graduation handling

When the curve completes it migrates to **PumpSwap**
(`pAMMBay6oceH9fJKBRHGP5D4bD4sWpmSwMn52FMfXEA`, pool index 0; Raydium is legacy).
An open position must:

1. flip `venue: curve → pumpswap` (cost 250 → 150bps, its own exit profile),
2. re-price from the PumpSwap pool, ignoring curve reads that now revert,
3. keep its ladder/peak state so the trailing stop is not reset.

## 12. Milestones

| # | Deliverable | Done when |
| --- | --- | --- |
| M1 | Detection only, no trading | launch count within a few % of an independent source over an hour |
| M2 | Curve pricing + paper fills | paper PnL matches hand-computed quotes on 20 trades |
| M3 | Curve features + separate model | score distribution spreads like the AMM calibration run |
| M4 | Live micro-size execution | 10 trades at minimum size, land-rate and slippage measured |
| M5 | Graduation + PumpSwap pricing | a position survives a migration without a stale price |

## 13. Risks

- **Latency arms race.** Create-block sniping is lost before you start; budget
  expectations accordingly and compete on selection and exits.
- **Feed dependency.** Both primary feeders are small third-party services with
  no contract. The `LaunchFeed` interface plus two competing free streams means a
  change in one is a config switch, not an outage.
- **Curve math errors** are silent money leaks — validate quotes against real
  transactions before M4.
- **Dev dumps** are the dominant loss mode on the curve and are not visible in
  price history until they happen.

## 14. Open questions

1. Solana only, or also Base launchpads through the same venue abstraction?
2. Do the free feeds sustain M1's launch-count check at peak hours, or is a
   third free fallback needed?
3. How small can the entry be while still clearing base fee + 1.25% curve fee?
