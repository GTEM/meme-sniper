# meme-sniper

An AI-assisted sniping bot for freshly launched meme coins: it watches new DEX
pools, scores them with an online-learning model, enters the ones that clear a
hard safety filter, and exits through a take-profit ladder with a trailing stop,
stop loss, rug detection and a time stop.

**It runs in paper mode by default.** Every fill is simulated against live
market prices, with fees and size-dependent slippage modelled, so nothing is
bought or sold for real until you explicitly switch to live mode.

## Quick start

```bash
npm install
cp .env.example .env      # optional: tune anything
npm start                 # bot + dashboard on http://localhost:3080
```

Other entry points:

```bash
npm run scan     # one scan, print a summary, exit (good for checking feeds)
npm run reset    # wipe portfolio + learned model, back to the starting bankroll
```

## How it decides

**1. Discover.** Every scan pulls the newest pools from GeckoTerminal for each
chain in `CHAINS`, then cheap-filters on age (`15s`–`20m`), liquidity
(`$15k`–`$600k`) and trade count. Only the top few survivors get enriched
(full token profile, second-opinion price/liquidity, 1-minute candles) to stay
inside the free API rate limits.

**2. Vet.** Hard vetoes run before any scoring: honeypot flag, unrevoked mint or
freeze authority, liquidity below floor / above band, liquidity under 1.5% of
market cap, too few trades, too fresh, too old.

**2b. Ownership (Solana).** The features above cannot see a bundler holding the
float, which is what the first 19 trades died to. Before scoring, the bot pulls
the token's holder table over plain Solana JSON-RPC — `getTokenLargestAccounts`
plus `getMultipleAccounts` for the owner wallets — excludes the pool's own
account, and computes top-1 / top-10 share, the dev's share and (with
`OWNERSHIP_DEEP=on`) bundle clusters: wallets whose first transaction was funded
by the same address collapse into one seller. That is free, needs no key, and
fails soft: if the RPC will not serve the call, the three ownership features go
neutral instead of guessing. The public `api.mainnet-beta.solana.com` endpoint
throttles these methods hard, so a free Helius key in `SOLANA_RPC_URL` is the
reliable zero-cost setup.

If you have a Solscan Pro key, put it in `SOLSCAN_API_KEY` (or the Settings
panel): the holder table then comes from `pro-api.solscan.io/v2.0/token/holders`
in a single request, which is fast enough to stay ahead of a throttled RPC. It is
strictly optional and fail-soft — with no key, or on any error, the on-chain walk
runs instead and behaviour is unchanged.

One thing to know before paying for a plan: Solscan's **free Level 1** key is
accepted by the API but cannot call any Pro `/v2.0` endpoint — verified against
token meta, price, holders, top, statistic, account detail and market list, all
of which answer `401 Unauthorized: Please upgrade your api key level`. The only
free route the docs list is Chain Information, and that path currently 404s. So
with a free key nothing changes: the bot detects the limit once, stops asking for
30 minutes, stays quiet in the log, and reads holder concentration from the RPC
walk. **Test Solscan key** in the Settings panel reports which of the two a key
can actually do.

The free MCP server (`public-mcp.solscan.io/mcp`) does accept a Level 1 key, but a
tools/list on it returns only network analytics — `chainInfoApi`,
`analyticsTransactionsApi`, `analyticsComputeUnitsApi`, `analyticsStakeApi`,
`analyticsFeesApi`, `analyticsSlotsApi`, `analyticsDexActivityApi`. There is no
`get_token_holders` there; that tool lives on the paid Pro server (54 tools).
None of the free seven describe a single token, so they cannot inform an entry
filter.

### Rug blacklist

The entry rug score cannot see a drain that has not happened yet: all 13 of the
book's first losses entered at risk 10 or 22, and one token (GTA) was bought,
rugged and re-bought three times. The exit knows what entry could not, so a
position closed by the rug watch — or down 50% or worse — pins its mint in
`data/rug-blacklist.json` and the entry gate refuses that mint for
`RUG_BLACKLIST_HOURS` (default 24). Pins survive restarts, expire on their own,
and count against the gate's `rug` tally. This cannot prevent a first rug; it
stops paying for the same one twice.

The one free source that does return per-wallet amounts is pump.fun's own
Developer API (`PUMPFUN_API_KEY`, approval required, key looks like
`pf_live_…`). `GET /v1/mint-positions/{mint}` lists the wallets holding a
position in a mint, and the bot measures top-1/top-10/dev against the mint
supply from one light `getTokenSupply` call. It lists pump.fun-visible positions
rather than every token account, so summaries are tagged `pumpfun` and the
on-chain walk stays as the cross-check — the order is pump.fun, then Solscan,
then the RPC walk, first success wins.

**3. Score.** A logistic model over 18 bounded features — buy pressure, momentum
and its acceleration, volume turnover and acceleration, trader breadth, candle
strength, drawdown from the launch high, liquidity-to-market-cap, social
presence, freshness, seller pressure, activity and safety. Entries need
`MIN_SCORE` (default 60%).

Two mechanical checks run alongside the score, because a high score can still be
built on a pool that is already somebody else's exit. A launch is vetoed when
five-minute volume exceeds a third of pool liquidity (`MAX_VOL_TO_LIQ_5M`) — the
pool is being churned — or when the safety score is under 0.7 (`MIN_SAFETY`),
which is roughly "top 10 wallets hold more than a third of supply" plus any
missing authority revocation. Both thresholds are deliberately loose: on a book
this small everything is in-sample, so the gate cuts the clearly bad end instead
of fitting a cutoff. Set either to 0 to switch it off.

Missing inputs are themselves a rejection: if the five-minute volume, the five-
minute trade count, the market cap or the holder table is absent, the launch is
vetoed as `not enough data: …` rather than scored on a neutral default
(`REQUIRE_DATA=on`). A neutral default is a guess, and an unseen pool is not a
safe pool. Set `REQUIRE_DATA=off` to trade on partial information again.

A chain that cannot supply a holder table at all is not scanned either.
GeckoTerminal publishes no holder distribution for EVM tokens (verified on fresh
Base pools and on a mature one), and there is no free on-chain alternative, so
while `REQUIRE_DATA=on` a `CHAINS=solana,base` config scans Solana only and logs
that Base was skipped. Drop Base from `CHAINS`, or set `REQUIRE_DATA=off` to
restore EVM scanning.

The model is **not** a static formula: each closed trade updates its weights by
gradient descent on "did this make money after costs", while an anchor term pulls
the weights back toward the domain priors so a few lucky wins cannot warp it.

The label is binary but the *sample is weighted*: a trade that lost 100% to a
liquidity pull carries 2.5x the gradient of a 2% scratch, and a rug exit gets
another 1.5x on top. Without that, a −100% rug counted the same as a +2% win and
the model learned the features of *pumps* — which is what a rug looks like one
minute before the pull. `npm run retrain` measures whether the score actually
separates wins from losses (AUC with a permutation p-value) instead of assuming
it does.

Feature **signs** are learnable too. Each feature keeps a running signed
evidence of which way its outcomes actually pushed it; once `SIGN_MIN_SAMPLES`
(default 20) closed trades agree that a domain prior points the wrong way, that
feature's anchor flips to the mirrored prior and the weight is walked there
trade by trade — nothing snaps. On the first 19 trades the default gate leaves
every prior alone; lowering it to 12 flips 8 of 15 priors without improving AUC
(0.38 vs 0.39), which is why the gate is conservative.
Weights, sample count and rolling accuracy are visible on the dashboard, and the
top positive/negative contributors are shown per candidate.

**4. Size.** `POSITION_SIZE_PCT` of current equity, capped at 1% of pool
liquidity so your own exit does not move the price.

**5. Exit.** In priority order:

| Rule | Trigger | Action |
| --- | --- | --- |
| Rug | pool liquidity down `RUG_LIQ_DROP_PCT` (65%) from entry | sell all |
| Stop loss | net PnL ≤ `STOP_LOSS_PCT` (-32%) | sell all |
| Peak stop | price `PEAK_STOP_PCT` (25%) below the peak, armed once the trade ran `PEAK_STOP_ARM_PCT` (10%) | sell all |
| Take profit 1 | net PnL ≥ +60% | sell 40% |
| Take profit 2 | net PnL ≥ +160% | sell 35% |
| Trailing | armed at +45% peak, exits `TRAIL_GAP_PCT` (30%) off the peak | sell rest |
| Momentum death | three lower readings while under -8% | sell all |
| Time stop | held `TIME_STOP_MIN` (22m) without +15% | sell all |

All PnL is net of a round-trip cost (`ROUND_TRIP_COST_BPS`, default 12%) split
across both legs, plus fills priced by a constant-product curve: a $50 order into
$20k of liquidity costs ~0.5%, into $100 costs ~50%, and into an emptied pool
returns exactly nothing. That last case matters — a linear slippage model lets
you "sell" a bag at 24x into a pool that no longer exists, which is how paper
results become fiction. A trade that "looks" +20% gross is barely break-even
after real meme-coin costs, which is why the AMM exit ladder starts where it does.

**Risk brakes.** Max concurrent positions, a daily loss cap, a halt after
`MAX_CONSECUTIVE_LOSSES`, and a 45-minute cooldown on any token that stops you
out.

## Venues: one cost model per market

A trade's economics depend on *where* it happens, so every position carries a
venue and each venue has its own round-trip cost and exit plan.

| Venue | Detected from | Round-trip cost | TP1 | TP2 | Trail | Stop | Time stop |
| --- | --- | --- | --- | --- | --- | --- | --- |
| DEX pool (`amm`) | any ordinary pool | 1200bps | +60% | +160% | 45% / 30% gap | −32% | 22m |
| pump.fun curve | `pump-fun` dex id | 250bps | +18% | +70% | 14% / 20% gap | −18% | 12m |
| PumpSwap | `pumpswap` dex id | 150bps | +22% | +80% | 16% / 22% gap | −20% | 15m |

A bonding curve charges 1.25% and has no LP to slip against, so a +18% move is
real money there while it is noise on a 12%-cost AMM pool. Waiting for +60% on a
curve would mean holding a coin that has already peaked.

## Rug analysis

Before anything is scored, every candidate gets a rug risk score (0–100) from
[src/rug.js](src/rug.js), computed only from data the scan already fetched — no
extra requests, so the analysis costs nothing and cannot slow discovery down.

| Signal | Effect |
| --- | --- |
| honeypot, unrevoked mint or freeze authority | **veto** |
| top-10 wallets above `RUG_MAX_TOP10_PCT` (70%) | **veto** |
| liquidity under 1% of market cap | **veto** |
| on-chain top-10 above `RUG_MAX_TOP10_PCT`, or 3+ top holders sharing one funder | **veto** |
| liquidity already down `RUG_MAX_LIQ_DECAY_PCT` (40%) since first seen | **veto** |
| a single minute that dumped 60%+ | **veto** |
| accumulated risk at or above `RUG_MAX_RISK` (70) | **veto** |
| 45–70% top-10 concentration, thin holder base | +10–30 risk |
| sell pressure dominating the 5m/1h tape | +12–20 risk |
| 35–50% off the high, −35% single-minute candle | +10–20 risk |
| wash trading (many trades per wallet), thin wallet breadth | +10–18 risk |
| +300% in 5m, no socials, feeds disagreeing on liquidity | +10–15 risk |

Above `RUG_SCORE_BONUS_FROM_RISK` (40) a coin does not get blocked but has to
clear a higher bar: `MIN_SCORE` plus `RUG_SCORE_BONUS` (0.10), so a 60% coin with
real distribution pressure needs 70%.

### The post-entry rug watch

Pre-entry filters cannot see a bundler draining the pool, so open positions get
a watch that fires on the first sign of a drain instead of waiting for the 65%
liquidity-pull rule (which fires when the pool is already empty). Every accepted
price snapshot stamps the per-tick deltas onto the position, and the watch exits
100% immediately on any of:

| Trigger | Default |
| --- | --- |
| depth down `RUG_WATCH_TICK_LIQ_DROP_PCT` in one tick | 18% |
| liquidity down `RUG_WATCH_LIQ_DROP_FROM_ENTRY_PCT` from entry | 35% |
| pool depth below `RUG_WATCH_MIN_DEPTH_MULTIPLE` × the position | 3x |
| price down `RUG_WATCH_TICK_PX_DROP_PCT` in one tick | 25% |

It is a rug escape (`kind: 'rug'`), so escalation is allowed under the same
policy as any other rug exit. `RUG_WATCH=off` disables it. The risk score, level and top signals are
stored on the position and the closed trade, and shown for every candidate on the
dashboard, so you can audit later which signals actually preceded the rugs.

## Paying up to land an exit

Fees are never escalated on entries, and never on ordinary stop losses — the
token is already underwater and paying more only deepens the loss. Escalation is
allowed only where it protects something:

- **profit** — a take-profit or trailing exit while the position is green,
- **rug** — escaping a pool whose liquidity was pulled.

When either fires, live mode raises the priority fee (`URGENT_PRIORITY_MULTIPLIER`)
and widens slippage to `URGENT_SLIPPAGE_PCT`, and paper mode charges the expected
cost of that rush so a paper run cannot look better than reality. Set
`EXIT_FEE_ESCALATION=profit,rug|profit|rug|off`.

Escalation also has to pay for itself: if the extra fee plus the wider slippage
(4.5% at the defaults) is larger than the profit being protected, the exit goes
out at the base fee and the profit is kept. In every case the extra spend is
gas — a higher priority fee — never a subscription or a data-provider commission.

## What the bot costs to run

Nothing except what the chain charges. Discovery uses free APIs, exits pay the
network base fee (a fraction of a cent), and there is no data subscription, no
RPC plan and no third-party cut of trades. The fees that do bite are the venue's
own: ~12% all-in on a thin DEX pool, and the pump.fun curve's 1.25% per leg —
which is already baked into the per-venue cost models below.

## Verify and tune

```bash
npm run selftest    # offline: fills, profit ladder, trailing stop, stop loss,
                    # rug exit, time stop, risk brakes, fee escalation
npm run calibrate   # score a batch of real launches and print the distribution
npm run rugbacktest # replay the rug veto over closed trades and report which
                    # losses it would have blocked and which winners it would
                    # have cost (proxy: only signals stored on the trade)
npm run rugwatch    # bound what the fast rug watch would have saved on the
                    # trades that ended in a liquidity pull (tick history is
                    # not stored, so it prints scenarios, not one number)
npm run entrytune   # sweep MIN_SCORE, the liquidity band and position size
                    # over the closed book, with a permutation p-value so a
                    # lucky threshold cannot pass for an edge
npm run retrain     # leave-one-out AUC for the score, plus the retrained
                    # weights; --write installs them (bot must be stopped)
```

`--write` now refuses a refit that cannot beat the untrained priors at
separating winners from losers, or that overturns more than three prior signs on
a small book (nine once the book passes 100 trades). A rejected refit leaves
`data/model.json` exactly as it was and exits non-zero; `--force` installs it
deliberately. One real refit scored LOO AUC 0.52 against priors at 0.63 while
flipping twelve of eighteen priors, including `safety` 1.25 → −1.25 — the guard
exists so that never needs a human to catch it.

`calibrate` exists because the score scale has to be checked against reality,
not vibes: it prints each candidate's features and score plus percentiles, so
you can see whether `MIN_SCORE` is admitting nothing or admitting junk.

## Dashboard

`http://localhost:3080` shows equity and the equity curve, open positions with
live net PnL and ladder progress, closed trades with exit reasons, the scan
funnel, the AI model's current weights, and a live activity log. `Pause scanning`
stops new entries while still managing open positions.

### Settings & dev tools

A panel on the dashboard edits the things you normally have to touch a file for:
the Solana RPC URL / API key, the test (paper) and live wallet addresses, ownership lookup, entry thresholds, position size,
scan interval, exit-escalation policy and the rug-watch thresholds. Saved values
persist in `data/settings.json` (gitignored) and apply to the running engine
immediately — no restart — and are re-applied on top of `.env` at startup.
API keys are masked on the way back to the browser and never echoed.

The two wallet fields are shown in the **Wallets** card above it. `PAPER_WALLET_ADDRESS`
is a watch-only label (a Solana base58 or EVM `0x…` address) — paper mode never signs
anything, so no key is needed. `LIVE_WALLET_ADDRESS` is a safety check: live mode
refuses to start unless that address is the one `WALLET_PRIVATE_KEY` controls, so a
typo cannot arm live trading against the wrong wallet.

Three buttons go with it:

- **Save settings** — validates every field (numbers clamp to their bounds, a
  bad select or a non-http URL is rejected and reported), then applies them.
- The test wallet is read over the RPC (`getBalance` + `getTokenAccountsByOwner` for SPL
and token-2022). `PAPER_WALLET_NETWORK=devnet` reads the same address on Solana devnet
(a Phantom account has one address per network, so the devnet faucet balance lives at
the same string); prices still come from mainnet, so devnet SOL is sized at the real
SOL price and devnet tokens are simply unpriced and valued with DexScreener prices, so the **Wallets** card shows what
it really holds. With a test address set, a paper book that is still empty opens at that
wallet's SOL value instead of `BANKROLL`, and **Reseed book from wallet** replaces the
paper book with the current balance. Token holdings are listed and valued but not
counted as cash: only SOL is tradable stake. The sync is two cheap read calls per press,
never per scan.

**Minimum trade size** and **minimum take-profit** both default to **$1**: the bot will not
commit less than a dollar, and will not bank a profit exit that makes less than a dollar.
On a small book that means the ladder waits for a larger move — a $2 position needs roughly
+120% before a TP1 partial clears $1 — so raise `POSITION_SIZE_PCT` if you want the floor
reached sooner. Protective exits (stop loss, collapse, rug watch, fast rug watch) ignore
the floor and always fire.

**Test RPC** — runs `getHealth` and a real `getTokenLargestAccounts` against a
  liquid token, so a key that works for a health check but not for the holder
  table is caught before the bot silently runs with neutral ownership features.
- **Reset paper book** — wipes the portfolio and the learned model without
  restarting; refused in live mode.

Open positions look ~-10% immediately after entry. That is correct: entry fee,
priority fee and slippage are all charged on the way in, and net PnL always
deducts the cost of the exit you have not made yet.

## Going live (EVM only)

Paper mode is the default and the only mode exercised in this workspace. Live
mode pays real money and is riskier than paper by a wide margin.

1. Set `RPC_URL` to an RPC for your chain — any free endpoint works; a private
   one just lands transactions more reliably.
2. Set `WALLET_PRIVATE_KEY` to a **fresh burner wallet** funded with only what
   you are willing to lose. Never use your main wallet.
3. Set `CONFIRM_LIVE=I_UNDERSTAND_THE_RISK`.
4. Set `NATIVE_USD_PRICE` to the chain's native coin price — sizing is in USD and
   the adapter refuses to trade without it rather than guess.
5. Remove `solana` from `CHAINS` — live execution is a Uniswap-V2-compatible
   router adapter for Base, Ethereum, Arbitrum and BSC.
6. `MODE=live npm start` and watch the first trades at tiny size.

Solana execution (pump.fun/PumpSwap) is not implemented; the plan, including
the free launch-data provider decision and the exact gas-only exit cost, is in
[docs/pumpfun-adapter.md](docs/pumpfun-adapter.md).

## Reality check

Meme-coin sniping is closer to picking up coins in front of a steamroller than
to investing. Most launches go to zero within hours, liquidity is often
one-sided, and a token can be unsellable even when the chart looks alive. This
bot is an engineering exercise in automated decision making: it is not financial
advice, and paper-mode results do not transfer to live trading — you are last in
line behind the bundlers, and the slippage model here is optimistic compared with
a real competitive block.
