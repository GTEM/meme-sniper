// Pushes the running bot's state to the published site.
//
// The bot listens on localhost only and cannot be reached from the internet, so
// the published dashboard is a mirror: this reads the bot's own /api/state on a
// short interval and POSTs it to the site's ingest route. Runs beside the bot.
//
//   PUBLISH_URL=https://<site> node tools/publish-state.mjs
//
// The token is read from INGEST_TOKEN, or from .secrets/ingest-token if unset.

import { readFileSync, existsSync } from 'node:fs';

const localStateUrl = process.env.LOCAL_STATE || `http://127.0.0.1:${process.env.PORT || 3080}/api/state`;
const publishBase = (process.env.PUBLISH_URL || '').replace(/\/+$/, '');
const everyMs = Number(process.env.PUBLISH_EVERY_MS || 5000);

if (!publishBase) {
  console.error('publish-state: PUBLISH_URL is required (for example https://meme-sniper-jkzxfz-preview.freebuff.site)');
  process.exit(1);
}

const token = process.env.INGEST_TOKEN || readFileSync(new URL('../.secrets/ingest-token', import.meta.url), 'utf8').trim();
if (!token) {
  console.error('publish-state: no ingest token found');
  process.exit(1);
}

let lastSent = '';
let failing = false;

// The snapshot served to the dashboard is trimmed for display (60 trades, no
// cooldowns), so it cannot rebuild a book. This pushes the book file itself, a
// few times a minute, to /api/book so a host with a throwaway disk can pull it
// back at boot.
const bookUrl = new URL('../data/portfolio.json', import.meta.url);
const bookEveryMs = Number(process.env.PUBLISH_BOOK_EVERY_MS || 60000);
let lastBook = '';
let lastBookAt = 0;

async function pushBook() {
  if (Date.now() - lastBookAt < bookEveryMs || !existsSync(bookUrl)) return;
  const body = readFileSync(bookUrl, 'utf8');
  if (body === lastBook) return;
  const up = await fetch(`${publishBase}/api/book`, {
    method: 'POST',
    headers: { 'content-type': 'application/json', authorization: `Bearer ${token}` },
    body,
  });
  if (up.ok) {
    lastBook = body;
    lastBookAt = Date.now();
    return;
  }
  console.error(`${stamp()} book backup refused ${up.status}`);
}

const stamp = () => new Date().toISOString().slice(11, 19);

async function tick() {
  void pushBook().catch(() => {});
  try {
    const local = await fetch(localStateUrl, { cache: 'no-store' });
    if (!local.ok) {
      if (!failing) console.error(`${stamp()} bot answered ${local.status}; waiting`);
      failing = true;
      return;
    }
    const body = await local.text();
    if (body === lastSent) return;

    const up = await fetch(`${publishBase}/api/ingest`, {
      method: 'POST',
      headers: { 'content-type': 'application/json', authorization: `Bearer ${token}` },
      body,
    });

    if (up.ok) {
      lastSent = body;
      if (failing) console.log(`${stamp()} publishing again`);
      failing = false;
      return;
    }

    const detail = (await up.text()).slice(0, 200);
    console.error(`${stamp()} ingest refused ${up.status}: ${detail}`);
    failing = true;
  } catch (err) {
    if (!failing) console.error(`${stamp()} push failed: ${err.message}`);
    failing = true;
  }
}

console.log(`publish-state: ${localStateUrl} -> ${publishBase}/api/ingest every ${everyMs}ms`);
tick();
setInterval(tick, everyMs);
