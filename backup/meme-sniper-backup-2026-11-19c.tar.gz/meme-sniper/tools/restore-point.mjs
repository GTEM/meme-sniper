/**
 * Restore points: a complete copy of the bot before a merge, and a way back.
 *
 *   node tools/restore-point.mjs                 create one
 *   node tools/restore-point.mjs --list          list them
 *   node tools/restore-point.mjs --restore <n>   put that one back
 *
 * A restore point holds the code (src, public, tools) and the book
 * (data/portfolio.json). Secrets are never copied: .env stays where it is.
 *
 * Restoring is blocked while the bot is listening on its dashboard port, because a running
 * engine saves the book it has in memory and would overwrite the restore.
 */
import { cpSync, existsSync, mkdirSync, readdirSync, readFileSync, rmSync, statSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';
import { createConnection } from 'node:net';

const ROOT = process.cwd();
const DIR = join(ROOT, 'restore-points');
const CODE = ['src', 'public', 'tools', 'package.json', 'package-lock.json'];
const BOOK = join('data', 'portfolio.json');

const port = (host, p) =>
  new Promise((resolve) => {
    const s = createConnection({ host, port: p }, () => {
      s.destroy();
      resolve(true);
    });
    s.on('error', () => resolve(false));
    s.setTimeout(1200, () => {
      s.destroy();
      resolve(false);
    });
  });

async function botRunning() {
  const p = Number(process.env.PORT) || 3080;
  return (await port('127.0.0.1', p)) || (await port('0.0.0.0', p));
}

function stamp() {
  return new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
}

function points() {
  if (!existsSync(DIR)) return [];
  return readdirSync(DIR)
    .filter((n) => statSync(join(DIR, n)).isDirectory())
    .sort();
}

function copyInto(target) {
  mkdirSync(target, { recursive: true });
  for (const item of CODE) {
    const from = join(ROOT, item);
    if (!existsSync(from)) continue;
    cpSync(from, join(target, item), { recursive: true });
  }
  if (existsSync(join(ROOT, BOOK))) {
    mkdirSync(join(target, 'data'), { recursive: true });
    cpSync(join(ROOT, BOOK), join(target, BOOK));
  }
  writeFileSync(
    join(target, 'RESTORE-POINT.json'),
    JSON.stringify(
      {
        createdAt: new Date().toISOString(),
        note: 'pre-merge state; .env is not included',
        files: CODE.filter((c) => existsSync(join(ROOT, c))),
        book: existsSync(join(ROOT, BOOK)),
      },
      null,
      2,
    ),
  );
}

const args = process.argv.slice(2);

if (args[0] === '--list') {
  const all = points();
  if (!all.length) console.log('no restore points yet');
  for (const p of all) {
    let meta = {};
    try {
      meta = JSON.parse(readFileSync(join(DIR, p, 'RESTORE-POINT.json'), 'utf8'));
    } catch {}
    console.log(p, meta.note ? `— ${meta.createdAt}` : '');
  }
  process.exit(0);
}

if (args[0] === '--restore') {
  const name = args[1];
  const all = points();
  if (!name || !all.includes(name)) {
    console.error(`usage: node tools/restore-point.mjs --restore <name>\n${all.map((n) => `  ${n}`).join('\n')}`);
    process.exit(1);
  }
  if (await botRunning()) {
    console.error('the bot is running on its dashboard port — stop it first, or its next save overwrites the restore');
    process.exit(1);
  }
  const safety = join(DIR, `pre-restore-${stamp()}`);
  copyInto(safety);
  for (const item of CODE) {
    const from = join(DIR, name, item);
    if (!existsSync(from)) continue;
    rmSync(join(ROOT, item), { recursive: true, force: true });
    cpSync(from, join(ROOT, item), { recursive: true });
  }
  const book = join(DIR, name, BOOK);
  if (existsSync(book)) cpSync(book, join(ROOT, BOOK));
  console.log(`restored ${name}`);
  console.log(`current state saved first in ${safety}`);
  process.exit(0);
}

const target = join(DIR, stamp());
copyInto(target);
console.log(`restore point: ${target}`);
console.log(`  code: ${CODE.filter((c) => existsSync(join(ROOT, c))).join(', ')}`);
console.log(`  book: ${existsSync(join(ROOT, BOOK)) ? 'data/portfolio.json' : 'none'}`);
console.log(`  undo: node tools/restore-point.mjs --restore ${target.split('/').pop()}`);
