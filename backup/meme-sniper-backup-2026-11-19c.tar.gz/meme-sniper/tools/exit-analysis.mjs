// Exit review: where does the book's money come from, and is an exit leaving
// value on the table?
//
// Reads the live state (or a saved copy) and prints, per entry-score bucket and
// per peak bucket, how trades ended. Read-only: run while the bot is up.
//
//   node tools/exit-analysis.mjs            # from http://127.0.0.1:3080
//   node tools/exit-analysis.mjs state.json # from a saved /api/state

import { readFileSync } from 'node:fs';

async function loadState(file) {
  if (file) return JSON.parse(readFileSync(file, 'utf8'));
  const res = await fetch(`http://127.0.0.1:${process.env.PORT || 3080}/api/state`, { signal: AbortSignal.timeout(10000) });
  if (!res.ok) throw new Error(`state: HTTP ${res.status}`);
  return res.json();
}

const s = await loadState(process.argv[2]);
const t = s.portfolio.trades;
const isRug = (x) => /fast rug watch|liquidity pulled/i.test(x.exitReason || '');
const sum = (a, f) => a.reduce((n, x) => n + f(x), 0);
const money = (x) => ('$' + x.toFixed(2)).padStart(9);

const actual = sum(t, (x) => x.pnlUsd);
console.log(`${t.length} trades, invested $${sum(t, (x) => x.investedUsd).toFixed(2)}, pnl ${money(actual)}`);

console.log('\nentry score bucket   n  rugs   rugPnL  otherPnL  totalPnL');
for (const [lo, hi] of [[0, 55], [55, 60], [60, 65], [65, 70], [70, 80], [80, 101]]) {
  const b = t.filter((x) => x.score * 100 >= lo && x.score * 100 < hi);
  if (!b.length) continue;
  const r = b.filter(isRug);
  const o = b.filter((x) => !isRug(x));
  console.log(
    `${lo}-${hi}%`.padEnd(20),
    String(b.length).padStart(3),
    String(r.length).padStart(5),
    money(sum(r, (x) => x.pnlUsd)),
    money(sum(o, (x) => x.pnlUsd)),
    money(sum(b, (x) => x.pnlUsd)),
  );
}

console.log('\npeak bucket    n  avgRealized  avgPeak   totalPnL  exit types');
for (const [lo, hi] of [[0, 15], [15, 30], [30, 60], [60, 120], [120, 1000]]) {
  const b = t.filter((x) => x.peakPnlPct * 100 >= lo && x.peakPnlPct * 100 < hi);
  if (!b.length) continue;
  const types = {};
  for (const x of b) {
    const k = (x.exitReason || '').split(':')[0].split('(')[0].trim().slice(0, 16);
    types[k] = (types[k] || 0) + 1;
  }
  console.log(
    `${lo}-${hi}%`.padEnd(12),
    String(b.length).padStart(3),
    (((sum(b, (x) => x.pnlPct) / b.length) * 100).toFixed(1) + '%').padStart(11),
    (((sum(b, (x) => x.peakPnlPct) / b.length) * 100).toFixed(1) + '%').padStart(8),
    money(sum(b, (x) => x.pnlUsd)),
    Object.entries(types).map(([k, v]) => `${k} x${v}`).join(', '),
  );
}

const byReason = (re) => t.filter((x) => re.test(x.exitReason || ''));
const avgHold = (a) => Math.round(sum(a, (x) => x.heldSec) / Math.max(1, a.length));
console.log(
  '\navg hold: trail ' + avgHold(byReason(/trailing/i)) + 's, peak stop ' + avgHold(byReason(/peak stop/i)) +
    's, time stop ' + avgHold(byReason(/time stop/i)) + 's, rug ' + avgHold(t.filter(isRug)) + 's',
);
