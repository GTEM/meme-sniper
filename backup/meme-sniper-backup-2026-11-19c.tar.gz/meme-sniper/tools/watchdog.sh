#!/usr/bin/env bash
# Keeps the paper loop, the preview forwarder and the site pusher alive while
# this VM is awake. It cannot survive the VM itself pausing when the session
# goes idle (the whole container is frozen, taking every process with it), but
# it does repair a dropped process or a crashed loop without a manual restart.
#
#   setsid nohup tools/watchdog.sh >> watchdog.log 2>&1 < /dev/null &
#
# Detection only: nothing here kills by pattern. A port that is open but not
# answering is left alone, because that is a slow scan, not a dead bot.
cd "$(dirname "$0")/.." || exit 1

PUBLISH_URL="${PUBLISH_URL:-https://meme-sniper-jkzxfz-preview.freebuff.site}"
export PUBLISH_URL

alive() { curl -sf -m 6 "$1" > /dev/null 2>&1; }
listening() { ss -ltn 2>/dev/null | grep -q ":$1 "; }

while true; do
  if ! listening 3080; then
    echo "$(date -u +%H:%M:%S) bot not listening on 3080 — starting"
    setsid nohup node src/index.js >> bot.log 2>&1 < /dev/null &
    sleep 25
  fi

  if ! listening 3001; then
    echo "$(date -u +%H:%M:%S) preview forwarder down — starting"
    setsid nohup node tools/preview-proxy.mjs >> proxy.log 2>&1 < /dev/null &
    sleep 2
  fi

  if ! pgrep -f 'tools/publish-state\.mjs' > /dev/null 2>&1; then
    echo "$(date -u +%H:%M:%S) site pusher down — starting"
    setsid nohup node tools/publish-state.mjs >> publish.log 2>&1 < /dev/null &
    sleep 2
  fi

  # A listening port that stopped answering for two checks in a row means the
  # event loop is stuck; say so in the log rather than silently rotting.
  if listening 3080 && ! alive http://127.0.0.1:3080/api/state; then
    sleep 20
    if listening 3080 && ! alive http://127.0.0.1:3080/api/state; then
      echo "$(date -u +%H:%M:%S) WARNING: 3080 is listening but not answering"
    fi
  fi

  sleep 20
done
