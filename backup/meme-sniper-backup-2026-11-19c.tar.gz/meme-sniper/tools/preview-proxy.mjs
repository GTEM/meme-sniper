// The hosted preview router can only reach one reserved port per chat. This
// forwards that port to wherever the bot actually runs:
//
//   TARGET_URL=https://meme-sniper-xjmn.onrender.com   (default below)
//   TARGET_PORT=3080                                   local bot instead
//
// With TARGET_URL set the panel shows the deployed bot, so it keeps working
// when this sandbox's own process tree gets reaped. Streams (/api/stream) pass
// through untouched either way.

import http from 'node:http';
import https from 'node:https';

const listenPort = Number(process.env.PREVIEW_PORT || 3001);
const targetUrl = (process.env.TARGET_URL ?? 'https://meme-sniper-xjmn.onrender.com').replace(/\/+$/, '');
const localPort = Number(process.env.TARGET_PORT || 3080);

const forward = (req, res) => {
  let upstream;
  if (targetUrl) {
    const target = new URL(targetUrl + (req.url || '/'));
    const lib = target.protocol === 'https:' ? https : http;
    upstream = lib.request(
      {
        protocol: target.protocol,
        hostname: target.hostname,
        port: target.port || (target.protocol === 'https:' ? 443 : 80),
        method: req.method,
        path: target.pathname + target.search,
        headers: { ...req.headers, host: target.host },
      },
      (up) => {
        res.writeHead(up.statusCode || 502, up.headers);
        up.pipe(res);
      },
    );
  } else {
    upstream = http.request(
      {
        host: '127.0.0.1',
        port: localPort,
        method: req.method,
        path: req.url,
        headers: { ...req.headers, host: `127.0.0.1:${localPort}` },
      },
      (up) => {
        res.writeHead(up.statusCode || 502, up.headers);
        up.pipe(res);
      },
    );
  }

  upstream.on('error', (err) => {
    if (!res.headersSent) res.writeHead(502, { 'content-type': 'text/plain; charset=utf-8' });
    res.end(`preview proxy: ${targetUrl || `127.0.0.1:${localPort}`} did not answer (${err.code || err.message})\n`);
  });

  req.pipe(upstream);
};

http.createServer(forward).listen(listenPort, '0.0.0.0', () => {
  console.log(`preview proxy: 0.0.0.0:${listenPort} -> ${targetUrl || `127.0.0.1:${localPort}`}`);
});
