// Does the score separate wins from losses?
//
// The online model learned from an unweighted binary label, so a -100% liquidity
// pull counted exactly as much as a +2% scratch, and the model ended up ranking
// rugs above winners. This tool measures separation four ways on the closed book:
//
//   priors med   the domain priors, no learning at all
//   live         the weights currently in data/model.json
//   recorded     the score each trade actually received at entry (out of sample)
//   loo weighted leave-one-out: train on the other trades with the new
//                cost-sensitive, rug-boosted label, score the held-out trade
//   loo plain    the same, with the old unweighted label, to isolate the fix
//
//   node tools/retrain.mjs
//   node tools/retrain.mjs --write     # install the refit weights (bot must be stopped)
//
// With a book this small every number is noisy, so each AUC comes with a
// permutation p-value: how often shuffled labels reach the same AUC.

import { readJson, writeJson } from '../src/lib/store.js';
import { SignalModel, PRIORS } from '../src/ai/model.js';
import { FEATURE_NAMES } from '../src/ai/features.js';
import { refitRefusals } from '../src/ai/retrain-guard.js';

const saved = readJson('portfolio.json', { trades: [] });
const rows = [...(saved.trades || [])].reverse().map((t) => ({
  symbol: t.symbol,
  features: t.features,
  outcome: t.pnlPct,
  // A repaired trade carries its own honest kind: its exit reason describes a
  // signal that turned out to be a feed glitch, not the rug it named.
  kind:
    t.exitKind ||
    (/liquidity pulled|fast rug watch/i.test(t.exitReason || '')
      ? 'rug'
      : /take profit|trailing|time stop|momentum/i.test(t.exitReason || '')
        ? 'profit'
        : 'stop'),
  win: t.pnlPct > 0,
  recorded: t.score,
}));

if (rows.length < 8) {
  console.error('Need at least 8 closed trades to say anything about separation.');
  process.exit(1);
}
if (rows.some((r) => !r.features)) {
  console.error('Some trades have no stored features - cannot retrain.');
  process.exit(1);
}

const pad = (s, n) => String(s).padEnd(n);
const padl = (s, n) => String(s).padStart(n);

/** AUC: probability a random winner outscores a random loser. */
function auc(pairs) {
  let good = 0;
  let total = 0;
  for (const a of pairs) {
    for (const b of pairs) {
      if (a.win === b.win) continue;
      total += 1;
      const hi = a.win ? a.s : b.s;
      const lo = a.win ? b.s : a.s;
      good += hi > lo ? 1 : hi === lo ? 0.5 : 0;
    }
  }
  return total ? good / total : 0.5;
}

function summary(label, scored) {
  const wins = scored.filter((r) => r.win);
  const losses = scored.filter((r) => !r.win);
  const mean = (xs) => (xs.length ? xs.reduce((s, r) => s + r.s, 0) / xs.length : 0);
  const a = auc(scored);
  return { label, auc: a, winMean: mean(wins), lossMean: mean(losses), n: scored.length, scored };
}

function permutationP(scored, trials = 4000) {
  const observed = auc(scored);
  const labels = scored.map((r) => r.win);
  let better = 0;
  for (let i = 0; i < trials; i++) {
    const shuffled = [...labels];
    for (let j = shuffled.length - 1; j > 0; j--) {
      const k = Math.floor(Math.random() * (j + 1));
      [shuffled[j], shuffled[k]] = [shuffled[k], shuffled[j]];
    }
    if (auc(scored.map((r, idx) => ({ ...r, win: shuffled[idx] }))) >= observed) better += 1;
  }
  return better / trials;
}

const scoreWith = (model) => rows.map((r) => ({ ...r, s: model.score(r.features).score }));

// --- the four candidates ---------------------------------------------------
const source = readJson('model.json', null);
const live = new SignalModel(source || {});
const priors = new SignalModel();

function train(useWeights) {
  const model = new SignalModel();
  for (const r of rows) {
    if (useWeights) model.learn(r.features, r.outcome, { kind: r.kind });
    else {
      // the old behaviour: unweighted binary label, no rug boost
      const { score: p, mass } = model.score(r.features);
      const label = r.outcome > 0 ? 1 : 0;
      const step = (0.08 * 3.2) / mass;
      for (const name of FEATURE_NAMES) {
        const x = Number(r.features[name]);
        if (!Number.isFinite(x)) continue;
        const centred = (x - 0.5) * 2;
        const prior = PRIORS[name] ?? 0;
        let w = model.weights[name] ?? prior;
        w += step * (label - p) * centred;
        w -= 0.012 * (w - prior);
        model.weights[name] = Math.max(-3.5, Math.min(3.5, w));
      }
      model.bias = Math.max(-2, Math.min(2, model.bias + step * 0.4 * (label - p)));
    }
  }
  return model;
}

function looScores(useWeights, signLearning = true) {
  return rows.map((held, i) => {
    const model = new SignalModel({}, { signLearning });
    rows.forEach((r, j) => {
      if (i === j) return;
      if (useWeights) model.learn(r.features, r.outcome, { kind: r.kind });
      else {
        const { score: p, mass } = model.score(r.features);
        const label = r.outcome > 0 ? 1 : 0;
        const step = (0.08 * 3.2) / mass;
        for (const name of FEATURE_NAMES) {
          const x = Number(r.features[name]);
          if (!Number.isFinite(x)) continue;
          const centred = (x - 0.5) * 2;
          const prior = PRIORS[name] ?? 0;
          let w = model.weights[name] ?? prior;
          w += step * (label - p) * centred;
          w -= 0.012 * (w - prior);
          model.weights[name] = Math.max(-3.5, Math.min(3.5, w));
        }
        model.bias = Math.max(-2, Math.min(2, model.bias + step * 0.4 * (label - p)));
      }
    });
    return { ...held, s: model.score(held.features).score };
  });
}

// Kept as named references: the write guard below compares these two directly.
const priorsResult = summary('priors (no learning)', scoreWith(priors));
const refitLoo = summary('refit + self-learning signs (LOO)', looScores(true, true));
const results = [
  priorsResult,
  summary('live weights', scoreWith(live)),
  summary('recorded at entry (out of sample)', rows.map((r) => ({ ...r, s: r.recorded }))),
  refitLoo,
  summary('refit, signs off (LOO)', looScores(true, false)),
  summary('refit, plain label (LOO)', looScores(false, false)),
];

const wins = rows.filter((r) => r.win).length;
console.log(`\nscore separation on ${rows.length} closed trades (${wins} wins, ${rows.length - wins} losses, ${rows.filter((r) => r.kind === 'rug').length} rugs)\n`);
console.log(`${pad('model', 36)}${padl('AUC', 7)}${padl('winners', 9)}${padl('losers', 8)}${padl('gap', 8)}${padl('p', 7)}`);
for (const r of results) {
  console.log(
    pad(r.label, 36) +
      padl(r.auc.toFixed(2), 7) +
      padl((r.winMean * 100).toFixed(0) + '%', 9) +
      padl((r.lossMean * 100).toFixed(0) + '%', 8) +
      padl(((r.winMean - r.lossMean) * 100).toFixed(0) + 'pt', 8) +
      padl(permutationP(r.scored).toFixed(2), 7),
  );
}
console.log('\nAUC 0.50 = no separation, 1.00 = every winner outranks every loser. p is the chance of');
console.log('seeing that AUC with the labels shuffled, so p above ~0.10 still means "unproven".\n');

// --- which single feature, if any, separates at all ------------------------
// If no feature on its own carries signal, no reweighting of the label can
// create it: the problem is the inputs, not the objective.
const univariate = FEATURE_NAMES.map((name) => {
  const scored = rows.map((r) => ({ win: r.win, s: Number(r.features[name]) || 0 }));
  return { name, auc: auc(scored), p: permutationP(scored, 1500) };
}).sort((a, b) => Math.abs(b.auc - 0.5) - Math.abs(a.auc - 0.5));

console.log('single-feature separation (0.5 = useless):');
console.log(`${pad('feature', 16)}${padl('AUC', 7)}${padl('p', 7)}`);
for (const u of univariate.slice(0, 6)) console.log(pad(u.name, 16) + padl(u.auc.toFixed(2), 7) + padl(u.p.toFixed(2), 7));
console.log('');

// --- what the refit changed -----------------------------------------------
const refit = train(true);
const drift = FEATURE_NAMES.map((name) => ({
  name,
  prior: PRIORS[name] ?? 0,
  live: live.weights[name] ?? 0,
  refit: refit.weights[name] ?? 0,
})).sort((a, b) => Math.abs(b.refit - b.prior) - Math.abs(a.refit - a.prior));

console.log(`${pad('feature', 16)}${padl('prior', 8)}${padl('live', 8)}${padl('refit', 8)}${padl('drift', 8)}`);
for (const d of drift.slice(0, 8)) {
  console.log(pad(d.name, 16) + padl(d.prior.toFixed(2), 8) + padl(d.live.toFixed(2), 8) + padl(d.refit.toFixed(2), 8) + padl((d.refit - d.prior).toFixed(2), 8));
}

const flipped = refit.flippedSigns();
console.log(
  flipped.length
    ? `prior signs overturned by the book: ${flipped.map((f) => `${f.name} ${f.prior} -> ${-f.prior} (evidence ${f.evidence})`).join(', ')}`
    : `no prior sign overturned yet (needs ${12}+ trades and consistent evidence; evidence: ${Object.entries(refit.evidence).map(([k, v]) => `${k} ${v.toFixed(3)}`).slice(0, 5).join(', ')} ...)`,
);

if (process.argv.includes('--write')) {
  // --- guard ---------------------------------------------------------------
  // Refuse to install a model that is worse than doing nothing, or one that
  // throws out most of the domain priors because a small book said so. Without
  // this, "rejected for making too many errors" depends on somebody reading the
  // table: a refit scoring 0.52 against priors at 0.63 was once written out and
  // had to be restored by hand.
  const refusals = refitRefusals({
    refitAuc: refitLoo.auc,
    priorAuc: priorsResult.auc,
    flips: refit.flippedSigns().length,
    features: FEATURE_NAMES.length,
    trades: rows.length,
  });
  if (refusals.length && !process.argv.includes('--force')) {
    console.error('\nREFUSED to install this refit:');
    for (const r of refusals) console.error('  - ' + r);
    console.error('\ndata/model.json is untouched. Re-run with --force to install it anyway.\n');
    process.exit(1);
  }
  if (refusals.length) console.warn('\nGuard bypassed with --force: ' + refusals.join('; ') + '\n');

  const net = await import('node:net');
  const busy = await new Promise((done) => {
    const sock = net.connect({ host: '127.0.0.1', port: Number(process.env.PORT) || 3080 });
    sock.on('connect', () => {
      sock.destroy();
      done(true);
    });
    sock.on('error', () => done(false));
    sock.setTimeout(600, () => {
      sock.destroy();
      done(false);
    });
  });
  if (busy) {
    console.error('A bot is running on the dashboard port. Stop it first: it saves its own weights on shutdown and would overwrite this.');
    process.exit(1);
  }
  writeJson('model.json', { ...refit.toJSON(), samples: rows.length, wins, recent: [] });
  console.log('Wrote refit weights to data/model.json (history recent[] cleared).');
} else {
  console.log('\nDry run. Re-run with --write (bot stopped) to install these weights.');
}
