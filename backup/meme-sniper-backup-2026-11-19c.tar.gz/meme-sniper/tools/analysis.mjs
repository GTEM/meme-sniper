// One coin, read the way the crypto desk build (3001) read it: order flow for a
// launch too young to chart, depth across every pool it trades in, and an
// indicator pass on the best candle series it has.
//
//   node tools/analysis.mjs <mint> [chain]
//
// Read-only: it fetches and prints, and never touches the book.

import { analyseToken } from '../src/analysis.js';

const [mint, chain = 'solana'] = process.argv.slice(2);
if (!mint) {
  console.error('usage: node tools/analysis.mjs <mint> [chain]');
  process.exit(1);
}

try {
  const read = await analyseToken(chain, mint);
  console.log(`\n${read.text}\n`);
  // A mint with no pair is a real answer, not a crash: say so and exit non-zero
  // so a script can tell "nothing to read" from "read fine".
  process.exit(read.pulse ? 0 : 2);
} catch (err) {
  console.error(`analysis failed: ${err.message}`);
  process.exit(1);
}
