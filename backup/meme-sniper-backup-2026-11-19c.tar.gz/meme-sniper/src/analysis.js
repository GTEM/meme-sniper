// One coin, read the way the crypto desk build (3001) read it: live order flow
// for coins too young to chart, depth summed across every pool the token trades
// in, and an indicator pass on the best candle series it actually has.
//
// Read-only and on demand. Nothing here feeds an entry or an exit threshold, so
// it cannot change what the bot does with the tuned model or the book; it is the
// second opinion you can ask for about any mint.

import { tokenPulse, flowRead, describePulse } from './feeds/pulse.js';
import { seriesFor } from './feeds/candles.js';
import { indicatorPass } from './ai/indicators.js';

const px = (v) => {
  if (v == null || !Number.isFinite(Number(v))) return 'n/a';
  const n = Number(v);
  if (Math.abs(n) >= 1) return `$${n.toLocaleString('en-US', { maximumFractionDigits: 2 })}`;
  return `$${n.toPrecision(4)}`;
};
const pc = (v) => (v == null || !Number.isFinite(Number(v)) ? 'n/a' : `${Number(v) >= 0 ? '+' : ''}${Number(v).toFixed(1)}%`);

/** The indicator half of the read, as text. */
export function describeIndicators(series, ind) {
  if (!series || !ind) {
    return 'INDICATORS — no candle series: no pool for this mint has enough history to read, so there are no levels to work from.';
  }
  const bars = series.interval === 'day' ? 'daily' : 'hourly';
  const levels = (list) => (list && list.length ? list.map(px).join(', ') : 'none');
  const reasons = ind.bias.reasons.length ? ` · ${ind.bias.reasons.join(' · ')}` : '';
  return [
    `INDICATORS — ${bars} candles, ${ind.samples} bars (${series.source})`,
    `price ${px(ind.price)} · SMA20 ${px(ind.sma20)} · SMA50 ${px(ind.sma50)} · EMA12 ${px(ind.ema12)} · EMA26 ${px(ind.ema26)}`,
    `RSI14 ${ind.rsi14 == null ? 'n/a' : ind.rsi14.toFixed(0)} · MACD ${ind.macd == null ? 'n/a' : `${ind.macd.hist >= 0 ? '+' : ''}${ind.macd.hist.toPrecision(3)}`} · ATR ${ind.atrPct == null ? 'n/a' : `${ind.atrPct.toFixed(1)}%`} · 20-bar move ${pc(ind.roc20)}`,
    `support ${levels(ind.support)} · resistance ${levels(ind.resistance)}`,
    `LEAN — ${ind.bias.direction} (${ind.bias.score > 0 ? '+' : ''}${ind.bias.score} of ${ind.bias.agree} signals, ${ind.bias.confidence} confidence)${reasons}`,
    series.note,
  ].join('\n');
}

/**
 * Everything knowable about one mint right now.
 *
 * @returns {Promise<{chain:string, mint:string, at:number, pulse:object|null, flow:object|null, series:object|null, indicators:object|null, text:string}>}
 */
export async function analyseToken(chain, mint, { withCandles = true } = {}) {
  const symbol = String(mint || '').trim();
  if (!symbol) throw new Error('a mint address is required');

  const pulse = await tokenPulse(chain, symbol).catch(() => null);
  const flow = pulse ? flowRead(pulse) : null;
  const series = withCandles ? await seriesFor(chain, symbol).catch(() => null) : null;
  const indicators = series ? indicatorPass(series.candles, series.price) : null;
  if (series && !series.symbol) series.symbol = pulse?.symbol || null;

  const text = [
    describePulse(pulse),
    describeIndicators(series, indicators),
  ].join('\n\n');

  return {
    chain,
    mint: symbol,
    at: Date.now(),
    pulse,
    flow,
    series: series
      ? {
          interval: series.interval,
          bars: series.candles.length,
          pool: series.pool,
          dex: series.dex,
          price: series.price,
          source: series.source,
          note: series.note,
        }
      : null,
    indicators,
    text,
  };
}
