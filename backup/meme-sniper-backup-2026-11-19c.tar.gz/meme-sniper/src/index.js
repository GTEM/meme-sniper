import { existsSync, writeFileSync } from 'node:fs';
import { config, liveConfigProblems } from './config.js';
import { Engine, scannableChains } from './engine.js';
import { startServer } from './server.js';
import { removeFile, ensureDataDir } from './lib/store.js';

const args = new Set(process.argv.slice(2));

async function runningBotOnPort(port) {
  const net = await import('node:net');
  return new Promise((done) => {
    const sock = net.connect({ host: '127.0.0.1', port }, () => {
      sock.destroy();
      done(true);
    });
    sock.on('error', () => done(false));
    sock.setTimeout(600, () => {
      sock.destroy();
      done(false);
    });
  });
}

if (args.has('--reset')) {
  if (await runningBotOnPort(config.port)) {
    console.error(`A bot is still running on port ${config.port}.`);
    console.error('Stop it first: it saves its in-memory book on shutdown and would overwrite the reset.');
    process.exit(1);
  }
  ensureDataDir();
  for (const f of ['portfolio.json', 'model.json']) removeFile(f);
  console.log('Cleared portfolio.json and model.json - starting from a clean bankroll.');
  process.exit(0);
}

// A host with a throwaway disk starts with no data/portfolio.json: Render's free
// tier wipes its filesystem on every restart, redeploy and spin-down. The mirror
// keeps a byte-for-byte copy of the book, so pull it back before the engine loads
// one, instead of silently opening a fresh bankroll and erasing the log.
//
//   PUBLISH_URL (or BOOK_SYNC_URL) = https://<site>
async function restoreBook() {
  const base = (process.env.BOOK_SYNC_URL || process.env.PUBLISH_URL || '').replace(/\/+$/, '');
  if (!base) return;
  if (existsSync('data/portfolio.json')) return;
  try {
    const res = await fetch(`${base}/api/book`, { cache: 'no-store' });
    if (!res.ok) {
      console.log(`book restore: ${base} answered ${res.status} - starting a fresh book`);
      return;
    }
    const body = await res.text();
    JSON.parse(body);
    ensureDataDir();
    writeFileSync('data/portfolio.json', body);
    console.log(`book restore: ${body.length} bytes from ${base}`);
  } catch (err) {
    console.log(`book restore failed (${err.message}) - starting a fresh book`);
  }
}

await restoreBook();

const problems = liveConfigProblems(config);
if (problems.length) {
  console.error('Live mode is not safely configured:');
  for (const p of problems) console.error(`  - ${p}`);
  console.error('\nFix the above in .env, or run with MODE=paper.');
  process.exit(1);
}

const engine = await new Engine(config).init();
const once = args.has('--once');

if (once) {
  // Single scan: useful for smoke-testing feeds and the decision path.
  process.env.QUIET = process.env.QUIET ?? '0';
  await engine.tick();
  const s = engine.state();
  console.log('\n— scan summary —');
  console.log(JSON.stringify({ scan: s.scan, equity: s.portfolio.equity, positions: s.portfolio.positions.length }, null, 2));
  process.exit(0);
}

await startServer(engine, config.port);
engine.start();

const scanChains = scannableChains(config);
console.log(`\n  meme-sniper | ${config.mode.toUpperCase()} | chains: ${(scanChains.length ? scanChains : config.chains).join(', ')}`);
console.log(`  dashboard: http://localhost:${config.port}\n`);

// Render's free web service stops after 15 minutes without an inbound request,
// and a stopped bot scans nothing. When the platform gives us its own origin,
// ask it for the state every 10 minutes: that request is inbound traffic, so the
// service stays awake without an external monitor and without another account.
const selfUrl = (
  process.env.SELF_URL ||
  process.env.RENDER_EXTERNAL_URL ||
  (process.env.RENDER_EXTERNAL_HOSTNAME ? `https://${process.env.RENDER_EXTERNAL_HOSTNAME}` : '') ||
  'https://meme-sniper-xjmn.onrender.com'
).replace(/\/+$/, '');
if (selfUrl) {
  const ping = setInterval(async () => {
    try {
      await fetch(`${selfUrl}/api/state`, { cache: 'no-store' });
    } catch (err) {
      engine.log('warn', `keep-alive ping failed: ${err.message}`);
    }
  }, 10 * 60 * 1000);
  ping.unref?.();
  // engine.log, not console: this is how the dashboard proves the keep-alive
  // exists without waiting out Render's 15-minute idle timer.
  engine.log('info', `keep-alive armed: ${selfUrl}/api/state every 10 minutes`);
}

let closing = false;
const shutdown = async (sig) => {
  if (closing) return;
  closing = true;
  console.log(`\n${sig} received - saving state and stopping.`);
  engine.stop();
  engine.save();
  setTimeout(() => process.exit(0), 200);
};
process.on('SIGINT', () => shutdown('SIGINT'));
process.on('SIGTERM', () => shutdown('SIGTERM'));
