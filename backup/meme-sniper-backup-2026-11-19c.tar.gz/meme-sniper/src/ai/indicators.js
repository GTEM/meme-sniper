// Indicators: the mechanical half of a read on a coin.
//
// Ported from the crypto desk build (the 3001 app) and kept free of I/O so it
// can be asserted in the selftest. Nothing here predicts anything: it turns
// candles into trend, momentum, volatility, the levels that matter, and a lean
// scored from fixed rules. Fixed rules stop conviction being invented; the
// trading decisions in this bot still belong to the strategy and the model.

const n = (v, def = 0) => {
  const x = Number(v);
  return Number.isFinite(x) ? x : def;
};

/** Simple moving average of the most recent `period` values. */
export function sma(values, period) {
  const clean = (values || []).map((v) => n(v, NaN)).filter((v) => Number.isFinite(v));
  if (!(period > 0) || clean.length < period) return null;
  let sum = 0;
  for (let i = clean.length - period; i < clean.length; i++) sum += clean[i];
  return sum / period;
}

/** Exponential moving average, seeded with the SMA of the first window. */
export function ema(values, period) {
  const clean = (values || []).map((v) => n(v, NaN)).filter((v) => Number.isFinite(v));
  if (!(period > 0) || clean.length < period) return null;
  const factor = 2 / (period + 1);
  let value = clean.slice(0, period).reduce((s, v) => s + v, 0) / period;
  for (let i = period; i < clean.length; i++) value = clean[i] * factor + value * (1 - factor);
  return value;
}

/** Wilder's RSI over closes, 0–100. */
export function rsi(values, period = 14) {
  const clean = (values || []).map((v) => n(v, NaN)).filter((v) => Number.isFinite(v));
  if (clean.length < period + 1) return null;
  let gain = 0;
  let loss = 0;
  for (let i = 1; i <= period; i++) {
    const delta = clean[i] - clean[i - 1];
    if (delta >= 0) gain += delta;
    else loss -= delta;
  }
  let avgGain = gain / period;
  let avgLoss = loss / period;
  for (let i = period + 1; i < clean.length; i++) {
    const delta = clean[i] - clean[i - 1];
    avgGain = (avgGain * (period - 1) + Math.max(delta, 0)) / period;
    avgLoss = (avgLoss * (period - 1) + Math.max(-delta, 0)) / period;
  }
  if (avgLoss === 0) return avgGain === 0 ? 50 : 100;
  return 100 - 100 / (1 + avgGain / avgLoss);
}

/** Average true range. A short candle series makes this close-to-close. */
export function atr(candles, period = 14) {
  const list = candles || [];
  if (list.length < period + 1) return null;
  const ranges = [];
  for (let i = 1; i < list.length; i++) {
    const c = list[i];
    const p = list[i - 1];
    ranges.push(Math.max(n(c.h) - n(c.l), Math.abs(n(c.h) - n(p.c)), Math.abs(n(c.l) - n(p.c))));
  }
  const window = ranges.slice(-period);
  return window.reduce((s, v) => s + v, 0) / window.length;
}

/** Sample standard deviation of the last `period` values. */
export function stdev(values, period) {
  const clean = (values || []).filter((v) => Number.isFinite(Number(v))).map(Number);
  if (!(period > 1) || clean.length < period) return null;
  const window = clean.slice(-period);
  const mean = window.reduce((s, v) => s + v, 0) / window.length;
  const variance = window.reduce((s, v) => s + (v - mean) ** 2, 0) / (window.length - 1);
  return Math.sqrt(variance);
}

/** Rate of change over `period` bars, in percent. */
export function roc(values, period) {
  const clean = (values || []).filter((v) => Number.isFinite(Number(v))).map(Number);
  if (clean.length < period + 1) return null;
  const then = clean[clean.length - 1 - period];
  const now = clean[clean.length - 1];
  return then === 0 ? null : ((now - then) / then) * 100;
}

/** MACD line, signal line and histogram. */
export function macd(values, fast = 12, slow = 26, signalPeriod = 9) {
  const clean = (values || []).filter((v) => Number.isFinite(Number(v))).map(Number);
  if (clean.length < slow + signalPeriod) return null;
  const line = [];
  for (let i = slow; i <= clean.length; i++) {
    const slice = clean.slice(0, i);
    const f = ema(slice, fast);
    const s = ema(slice, slow);
    if (f != null && s != null) line.push(f - s);
  }
  if (line.length < signalPeriod) return null;
  const signal = ema(line, signalPeriod);
  const value = line[line.length - 1];
  if (signal == null) return null;
  return { macd: value, signal, hist: value - signal };
}

/** Local swing highs above the price and swing lows below it, nearest first. */
export function swingLevels(candles, price) {
  const window = (candles || []).slice(-80);
  const px = n(price);
  const supports = [];
  const resistance = [];
  for (let i = 1; i < window.length - 1; i++) {
    const prev = window[i - 1];
    const cur = window[i];
    const next = window[i + 1];
    if (n(cur.l) <= n(prev.l) && n(cur.l) <= n(next.l) && n(cur.l) < px) supports.push(n(cur.l));
    if (n(cur.h) >= n(prev.h) && n(cur.h) >= n(next.h) && n(cur.h) > px) resistance.push(n(cur.h));
  }
  const nearest = (list) =>
    [...new Set(list.map((v) => Number(v.toPrecision(6))))]
      .sort((a, b) => Math.abs(a - px) - Math.abs(b - px))
      .slice(0, 3);
  return { support: nearest(supports), resistance: nearest(resistance) };
}

/**
 * A fixed scorecard over six classic signals: price vs SMA20, SMA20 vs SMA50,
 * EMA12 vs EMA26, MACD histogram, RSI regime and 20-bar momentum. One point
 * each, positive or negative. Deliberately modest: it exists to stop a lean
 * being dressed up as conviction, not to be a trading system.
 */
export function scoreBias(input = {}) {
  let score = 0;
  let agree = 0;
  const reasons = [];

  const vote = (bullish, label) => {
    if (bullish == null) return;
    agree += 1;
    if (bullish) {
      score += 1;
      return;
    }
    score -= 1;
    reasons.push(label);
  };

  const price = n(input.price);
  vote(input.sma20 == null || !(price > 0) ? null : price > input.sma20, 'price is below its 20-bar average');
  vote(input.sma20 == null || input.sma50 == null ? null : input.sma20 > input.sma50, 'the 20-bar average is below the 50-bar');
  vote(input.ema12 == null || input.ema26 == null ? null : input.ema12 > input.ema26, 'the 12-bar EMA is below the 26-bar');
  vote(input.macdHist == null ? null : input.macdHist > 0, 'the MACD histogram is negative');
  vote(input.rsi14 == null ? null : input.rsi14 >= 55 ? true : input.rsi14 <= 45 ? false : null, 'RSI is under 45');
  vote(input.roc20 == null ? null : input.roc20 > 0, '20-bar momentum is negative');

  if (input.rsi14 != null && input.rsi14 > 75) reasons.push(`RSI ${input.rsi14.toFixed(0)}: stretched, a pullback is likelier than a continuation`);
  if (input.samples != null && input.samples < 30) reasons.push(`only ${input.samples} candles: this lean is thin evidence`);

  const direction = score >= 2 ? 'up' : score <= -2 ? 'down' : 'neutral';
  const confidence = agree >= 6 && Math.abs(score) >= 5 ? 'high' : agree >= 4 && Math.abs(score) >= 3 ? 'medium' : 'low';
  return { direction, score, agree, confidence, reasons };
}

/**
 * One pass over a candle series: averages, momentum, volatility, the nearest
 * levels and the mechanical lean. Nulls mean "not enough candles", never zero.
 */
export function indicatorPass(candles, price = null) {
  const list = (candles || []).filter((c) => n(c.c) > 0);
  const closes = list.map((c) => n(c.c));
  const px = n(price) || (closes.length ? closes[closes.length - 1] : 0);
  const sma20 = sma(closes, 20);
  const sma50 = sma(closes, 50);
  const ema12 = ema(closes, 12);
  const ema26 = ema(closes, 26);
  const macdNow = macd(closes);
  const rsi14 = rsi(closes, 14);
  const roc20 = roc(closes, 20);
  const atr14 = atr(list, 14);
  const vol20 = stdev(closes, 20);
  const levels = swingLevels(list, px);
  const bias = scoreBias({
    price: px,
    sma20,
    sma50,
    ema12,
    ema26,
    macdHist: macdNow?.hist ?? null,
    rsi14,
    roc20,
    samples: list.length,
  });
  return {
    samples: list.length,
    price: px || null,
    sma20,
    sma50,
    ema12,
    ema26,
    macd: macdNow,
    rsi14,
    roc20,
    atr14,
    atrPct: atr14 != null && px > 0 ? (atr14 / px) * 100 : null,
    stdev20: vol20,
    stdevPct: vol20 != null && px > 0 ? (vol20 / px) * 100 : null,
    support: levels.support,
    resistance: levels.resistance,
    bias,
  };
}
