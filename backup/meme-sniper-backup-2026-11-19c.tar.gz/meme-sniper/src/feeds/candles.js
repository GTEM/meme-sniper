// Candle series for a coin that may be too young to chart.
//
// Ported from the crypto desk build (the 3001 app). The bot's scan reads
// 1-minute candles from the pool it found; that is the right window for a
// 15-minute-old launch and the wrong one for anything older, because 30 minutes
// of 1m bars says nothing about a trend. This module asks for daily candles,
// falls back to hourly when a pool is too young for them, and tries several
// pools when the deepest one is dead — then refuses with a reason instead of
// analysing noise.
//
// GeckoTerminal allows about 30 requests a minute per IP and answers 429 when
// the shared IP is busy; getJson already paces per host and backs off.

import { getJson } from '../lib/http.js';
import { allTokenPairs } from './dexscreener.js';

const BASE = 'https://api.geckoterminal.com/api/v2';

const num = (v, def = 0) => {
  const n = Number(v);
  return Number.isFinite(n) ? n : def;
};

/**
 * OHLCV for one pool, oldest first.
 * @param {'day'|'hour'|'minute'} interval
 */
export async function poolCandles(chain, poolAddress, interval = 'hour', { limit = 180, aggregate = 1 } = {}) {
  if (!poolAddress) return [];
  const url = `${BASE}/networks/${chain}/pools/${poolAddress}/ohlcv/${interval}?aggregate=${aggregate}&limit=${limit}&currency=usd`;
  try {
    const data = await getJson(url, { ttlMs: 45000, retries: 2, label: `${chain} ohlcv ${interval}` });
    return (data?.data?.attributes?.ohlcv_list || [])
      .map(([t, o, h, l, c, v]) => ({ t: num(t) * 1000, o: num(o), h: num(h), l: num(l), c: num(c), v: num(v) }))
      .filter((c2) => c2.c > 0)
      .sort((a, b) => a.t - b.t);
  } catch {
    return [];
  }
}

/**
 * The best candle series a mint has, with where it came from.
 *
 * A pump.fun launch is often hours old, so daily candles may not exist; hourly
 * is the honest fallback, and a pool with neither is refused rather than
 * forecast from noise. Several pools are tried because a dead pool can outrank
 * the one that actually trades, and an empty pool has no candles to read.
 *
 * @returns {Promise<{symbol:string, price:number, candles:object[], interval:'day'|'hour', pool:string, dex:string, source:string, note:string}|null>}
 */
export async function seriesFor(chain, mint, { minCandles = 30, pools = 3 } = {}) {
  if (!mint) return null;
  const pairs = (await allTokenPairs(chain, mint))
    .filter((p) => p.poolAddress && p.priceUsd > 0)
    .slice(0, Math.max(1, pools));
  if (!pairs.length) return null;

  for (const pair of pairs) {
    for (const interval of ['day', 'hour']) {
      const candles = await poolCandles(chain, pair.poolAddress, interval);
      if (candles.length < minCandles) continue;
      const price = num(pair.priceUsd) || candles[candles.length - 1].c;
      return {
        symbol: null,
        price,
        candles,
        interval,
        pool: pair.poolAddress,
        dex: pair.dex || 'unknown',
        source: `GeckoTerminal ${interval === 'day' ? 'daily' : 'hourly'} candles, ${candles.length} bars (${pair.dex || 'unknown venue'})`,
        note:
          interval === 'hour'
            ? 'Hourly candles because the pool is young, so the levels are intraday, not multi-week.'
            : pair.dex === 'pump-fun'
              ? 'Bonding-curve pool: liquidity is thin and can be pulled, so treat the levels as approximate.'
              : 'Pool-level candles: wicks reflect one venue, not the whole market.',
      };
    }
  }
  return null;
}
