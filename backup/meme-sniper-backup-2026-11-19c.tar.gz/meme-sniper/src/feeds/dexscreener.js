import { getJson } from '../lib/http.js';

// DexScreener is a second opinion: socials, pair age and independent liquidity.
// Divergence between the two feeds is itself a red flag (thin/faked pools).
//
// It is also the bot's independent discovery lane. GeckoTerminal's new-pools
// feed is the firehose, but it answers 429 whenever the shared IP is busy, and
// on those scans discovery used to collapse to the handful of DexScreener
// profiles read one address at a time. DexScreener's token endpoint prices 30
// mints per call, so the whole lane now costs two calls per scan instead of
// eleven and returns up to three times as many pools.

const num = (v, def = 0) => {
  const n = Number(v);
  return Number.isFinite(n) ? n : def;
};

/**
 * All pairs for a token, best (deepest liquidity) first.
 */
export async function tokenPairs(chain, address) {
  const url = `https://api.dexscreener.com/latest/dex/tokens/${address}`;
  try {
    const data = await getJson(url, { ttlMs: 45000, label: `${chain} dexscreener token` });
    const pairs = (data?.pairs || []).filter((p) => !chain || p.chainId === chain);
    if (!pairs.length) return null;
    pairs.sort((a, b) => num(b.liquidity?.usd) - num(a.liquidity?.usd));
    const p = pairs[0];
    return {
      chain,
      poolAddress: p.pairAddress,
      dex: p.dexId,
      baseToken: p.baseToken?.address || null,
      symbol: p.baseToken?.symbol,
      name: p.baseToken?.name,
      priceUsd: num(p.priceUsd),
      liqUsd: num(p.liquidity?.usd),
      fdvUsd: num(p.fdv),
      mcapUsd: num(p.marketCap),
      createdAtMs: p.pairCreatedAt || null,
      vol: { m5: num(p.volume?.m5), h1: num(p.volume?.h1), h24: num(p.volume?.h24) },
      txns: { m5: p.txns?.m5 || { buys: 0, sells: 0 }, h1: p.txns?.h1 || { buys: 0, sells: 0 } },
      pc: { m5: num(p.priceChange?.m5), h1: num(p.priceChange?.h1), h24: num(p.priceChange?.h24) },
      socials: (p.info?.socials || []).map((s) => s.type),
      websites: (p.info?.websites || []).map((w) => w.url),
      imageUrl: p.info?.imageUrl || null,
      boosts: p.boosts?.active || 0,
      pairCount: pairs.length,
    };
  } catch {
    return null;
  }
}

/**
 * Every pair for a token, deepest liquidity first.
 *
 * Needed to follow a graduation: when a token moves from its launch pool to a
 * new one, the old pair reports ~$0 and the bot used to sell there, booking a
 * total loss on a live position. The token is still trading — just elsewhere.
 */
export async function allTokenPairs(chain, address) {
  const url = `https://api.dexscreener.com/latest/dex/tokens/${address}`;
  try {
    const data = await getJson(url, { ttlMs: 20000, label: `${chain} dexscreener pairs` });
    const pairs = (data?.pairs || []).filter((p) => !chain || p.chainId === chain);
    return pairs
      .map((p) => ({
        poolAddress: p.pairAddress,
        dex: p.dexId,
        priceUsd: num(p.priceUsd),
        liqUsd: num(p.liquidity?.usd),
        createdAtMs: p.pairCreatedAt || null,
      }))
      .sort((a, b) => b.liqUsd - a.liqUsd);
  } catch {
    return [];
  }
}

/**
 * Raw DexScreener pairs -> the bot's pool shape: one row per mint, deepest pool
 * wins, deepest liquidity first. Pure, so the mapping is testable offline.
 *
 * m15 is mirrored from m5 and uniqueTrader counts stay 0 because DexScreener
 * does not report them; the feature extractor treats that as missing data, not
 * as a healthy reading.
 */
export function poolsFromPairs(chain, pairs = [], { limit = 30 } = {}) {
  const byMint = new Map();
  for (const p of pairs || []) {
    if (!p || (chain && p.chainId && p.chainId !== chain)) continue;
    const mint = p.baseToken?.address;
    const pool = p.pairAddress;
    const price = num(p.priceUsd);
    if (!mint || !pool || !(price > 0)) continue;
    const liq = num(p.liquidity?.usd);
    const prev = byMint.get(mint);
    if (prev && prev.liqUsd >= liq) continue;
    byMint.set(mint, {
      chain,
      poolAddress: pool,
      name: p.baseToken?.name || p.baseToken?.symbol || '',
      symbol: p.baseToken?.symbol || '',
      dex: p.dexId || 'unknown',
      baseToken: mint,
      createdAtMs: p.pairCreatedAt || null,
      priceUsd: price,
      liqUsd: liq,
      mcapUsd: num(p.marketCap) || num(p.fdv),
      vol: { m5: num(p.volume?.m5), m15: num(p.volume?.m5), h1: num(p.volume?.h1) },
      pc: {
        m5: num(p.priceChange?.m5),
        m15: num(p.priceChange?.m5),
        m30: num(p.priceChange?.m5),
        h1: num(p.priceChange?.h1),
      },
      txns: {
        m5: { buys: num(p.txns?.m5?.buys), sells: num(p.txns?.m5?.sells), buyers: 0, sellers: 0, uniqueTraders: 0 },
        h1: { buys: num(p.txns?.h1?.buys), sells: num(p.txns?.h1?.sells), buyers: 0, sellers: 0, uniqueTraders: 0 },
      },
      fetchedAt: Date.now(),
    });
  }
  return [...byMint.values()].sort((a, b) => b.liqUsd - a.liqUsd).slice(0, Math.max(1, limit));
}

/**
 * Independent discovery lane: the newest token profiles, priced in one batch.
 *
 * Two calls per scan, no GeckoTerminal budget. This is what keeps the scanner
 * fed while the new-pools feed is throttled instead of dropping to nine
 * addresses read one at a time.
 */
export async function latestPoolsBulk(chain, limit = 24) {
  let profiles;
  try {
    profiles = await getJson('https://api.dexscreener.com/token-profiles/latest/v1', {
      ttlMs: 60000,
      label: 'dexscreener profiles',
    });
  } catch {
    return [];
  }
  const addrs = [
    ...new Set(
      (profiles || [])
        .filter((p) => (!chain || p.chainId === chain) && p.tokenAddress)
        .map((p) => p.tokenAddress),
    ),
  ].slice(0, 30);
  if (!addrs.length) return [];

  try {
    const data = await getJson(`https://api.dexscreener.com/latest/dex/tokens/${addrs.join(',')}`, {
      ttlMs: 20000,
      label: `${chain} dexscreener batch`,
    });
    return poolsFromPairs(chain, data?.pairs || [], { limit });
  } catch {
    return [];
  }
}

/**
 * Former per-address reader. Kept as the thin wrapper callers already import;
 * it now goes through the batch endpoint, which is ten calls cheaper.
 */
export async function latestPools(chain, limit = 24) {
  return latestPoolsBulk(chain, limit);
}
