// Live order flow for a Solana token, including ones too young to chart.
//
// Ported from the crypto desk build (the 3001 app). A fresh launch has no candle
// series worth analysing, but it does have buy and sell counts, volume in short
// windows, pool depth and age. This reports those, and it keeps three states
// apart that look identical in a 24h summary: a launch still trading, a launch
// that already died, and a pool with no depth to exit into.
//
// The depth figure is the part the bot did not have. One pool's reserve is not
// a token's liquidity: a graduated token leaves its old pair reporting ~$0 while
// it trades in a new one, and DexScreener only returns the pairs it chooses to.
// GeckoTerminal's token endpoint carries the total reserve across every pool it
// indexes, so that is preferred, and which source answered is always reported.

import { getJson } from '../lib/http.js';

const num = (v, def = 0) => {
  const n = Number(v);
  return Number.isFinite(n) ? n : def;
};
const opt = (v) => {
  const n = Number(v);
  return Number.isFinite(n) ? n : null;
};

/** A window with no trades is null, not a zeroed window: no trade is data too. */
function windowOf(txn) {
  if (!txn) return null;
  const buys = num(txn.buys);
  const sells = num(txn.sells);
  return buys + sells > 0 ? { buys, sells } : null;
}

/** Total reserve across every indexed pool, or null when GeckoTerminal did not answer. */
export async function tokenDepth(chain, mint) {
  try {
    const data = await getJson(`https://api.geckoterminal.com/api/v2/networks/${chain}/tokens/${mint}`, {
      ttlMs: 30000,
      retries: 1,
      label: `${chain} token depth`,
    });
    const attributes = data?.data?.attributes;
    if (!attributes) return null;
    return { reserveUsd: opt(attributes.total_reserve_in_usd), marketCapUsd: opt(attributes.market_cap_usd) };
  } catch {
    return null;
  }
}

/**
 * Live flow for one mint, summed across every pool it trades in.
 *
 * `liquidityUsd` is 0 when the pools hold nothing, and that 0 is reported as 0:
 * calling it "unknown" would hide a pool that cannot be exited at all.
 */
export async function tokenPulse(chain, mint, { depth = true } = {}) {
  const data = await getJson(`https://api.dexscreener.com/latest/dex/tokens/${encodeURIComponent(mint)}`, {
    ttlMs: 20000,
    retries: 1,
    label: `${chain} pulse`,
  });
  const pairs = (data?.pairs || []).filter((p) => !chain || p.chainId === chain);
  const own = pairs
    .filter((p) => p.baseToken?.address === mint)
    .sort((a, b) => num(b.liquidity?.usd) - num(a.liquidity?.usd));
  const best = own[0];
  if (!best) return null;

  const reported = own.map((p) => opt(p.liquidity?.usd)).filter((v) => v != null);
  const pooled = reported.length ? reported.reduce((s, v) => s + v, 0) : null;
  const aggregate = depth ? await tokenDepth(chain, mint) : null;
  const liquidityUsd = aggregate?.reserveUsd ?? pooled;
  const marketCapUsd = opt(best.marketCap) ?? opt(best.fdv) ?? aggregate?.marketCapUsd ?? null;
  const created = opt(best.pairCreatedAt);
  const liqToMcapPct = liquidityUsd != null && marketCapUsd ? (liquidityUsd / marketCapUsd) * 100 : null;

  return {
    mint,
    symbol: best.baseToken?.symbol || mint.slice(0, 4),
    name: best.baseToken?.name || null,
    dex: best.dexId || null,
    pool: best.pairAddress || null,
    price: opt(best.priceUsd),
    ageHours: created == null ? null : (Date.now() - created) / 3600000,
    liquidityUsd,
    liquiditySource: aggregate?.reserveUsd != null ? 'GeckoTerminal, all indexed pools' : 'DexScreener, the pools it returned',
    poolCount: own.length,
    marketCapUsd,
    liqToMcapPct,
    change: {
      m5: opt(best.priceChange?.m5),
      h1: opt(best.priceChange?.h1),
      h6: opt(best.priceChange?.h6),
      h24: opt(best.priceChange?.h24),
    },
    volume: {
      m5: opt(best.volume?.m5),
      h1: opt(best.volume?.h1),
      h6: opt(best.volume?.h6),
      h24: opt(best.volume?.h24),
    },
    txns: { m5: windowOf(best.txns?.m5), h1: windowOf(best.txns?.h1), h24: windowOf(best.txns?.h24) },
  };
}

/**
 * Who is in control, and whether volume is behind them.
 *
 * Acceleration compares the last hour with the token's own 24-hour hourly
 * average, so a launch is measured against itself rather than an arbitrary
 * figure. When nothing traded recently, the 24h split is reported as history
 * rather than as current pressure.
 */
export function flowRead(pulse) {
  const h1 = pulse?.txns?.h1 || null;
  const h24 = pulse?.txns?.h24 || null;
  const h1Volume = pulse?.volume?.h1 ?? 0;
  const h6Volume = pulse?.volume?.h6 ?? 0;
  const h24Volume = pulse?.volume?.h24 ?? null;
  const acceleration = pulse?.volume?.h1 != null && h24Volume != null && h24Volume > 0 ? h1Volume / (h24Volume / 24) : null;
  const dormant = h1Volume === 0 && h6Volume === 0 && (h24Volume ?? 0) > 0;

  if (!h1 && !h24) {
    return { pressure: 'none', basis: null, acceleration, dormant, note: 'no trades are reported for this pair at all' };
  }

  const basis = h1 ? '1h' : '24h';
  const book = h1 || h24;
  const share = book.buys / Math.max(book.buys + book.sells, 1);
  const pressure = share >= 0.6 ? 'buyers' : share <= 0.4 ? 'sellers' : 'balanced';

  if (dormant) {
    return {
      pressure,
      basis,
      acceleration,
      dormant,
      note: `no volume in the last 6 hours — this pool has gone quiet, so the 24h move it shows is already over (24h split: ${h24.buys} buys / ${h24.sells} sells)`,
    };
  }
  if (!h1) {
    return {
      pressure,
      basis,
      acceleration,
      dormant,
      note: `no trades in the last hour, so there is no live pressure; the 24h split was ${h24.buys} buys / ${h24.sells} sells`,
    };
  }

  let note;
  if (pressure === 'buyers' && acceleration != null && acceleration >= 1.5) note = 'buyers are in control and volume is accelerating';
  else if (pressure === 'sellers' && acceleration != null && acceleration >= 1.5)
    note = 'sellers dominate while volume accelerates — that is distribution, not accumulation';
  else if (pressure === 'buyers') note = 'buyers dominate, but volume is not accelerating';
  else if (pressure === 'sellers') note = 'sellers dominate';
  else note = 'flow is balanced — neither side has control';
  if (acceleration != null && acceleration < 0.5) note += '; volume is fading against its own hourly average';

  return { pressure, basis, acceleration, dormant, note };
}

const money = (value) => {
  if (value == null) return 'n/a';
  if (value >= 1000000) return `$${(value / 1000000).toFixed(2)}M`;
  if (value >= 1000) return `$${(value / 1000).toFixed(1)}K`;
  if (value >= 1) return `$${value.toFixed(2)}`;
  return value > 0 ? `$${value.toPrecision(3)}` : '$0';
};
const pct = (value) => (value == null ? 'n/a' : `${value >= 0 ? '+' : ''}${value.toFixed(1)}%`);

/** The read as text, with the caveats attached to the numbers they belong to. */
export function describePulse(pulse) {
  if (!pulse) return 'No trading pair lists that mint as its base token, so there is no flow to read.';
  const read = flowRead(pulse);
  const age =
    pulse.ageHours == null
      ? 'age unknown'
      : pulse.ageHours < 48
        ? `${pulse.ageHours.toFixed(1)}h old`
        : `${(pulse.ageHours / 24).toFixed(1)}d old`;
  const trades = pulse.txns.h1
    ? `trades 1h: ${pulse.txns.h1.buys} buys / ${pulse.txns.h1.sells} sells`
    : pulse.txns.h24
      ? `trades 1h: none · 24h: ${pulse.txns.h24.buys} buys / ${pulse.txns.h24.sells} sells`
      : 'trade counts: not reported by the feed';

  const lines = [
    `ORDER FLOW — ${pulse.symbol}${pulse.name && pulse.name !== pulse.symbol ? ` (${pulse.name})` : ''} · ${age} · ${pulse.dex || 'unknown venue'} · ${pulse.poolCount} pool${pulse.poolCount === 1 ? '' : 's'}`,
    `price ${money(pulse.price)} USD · liquidity ${money(pulse.liquidityUsd)} (${pulse.liquiditySource})${pulse.liqToMcapPct == null ? '' : ` · ${pulse.liqToMcapPct.toFixed(2)}% of market cap`} · market cap ${money(pulse.marketCapUsd)}`,
    `moves: 5m ${pct(pulse.change.m5)} · 1h ${pct(pulse.change.h1)} · 6h ${pct(pulse.change.h6)} · 24h ${pct(pulse.change.h24)}`,
    `volume: 5m ${money(pulse.volume.m5)} · 1h ${money(pulse.volume.h1)} · 24h ${money(pulse.volume.h24)}`,
    trades,
    `READ — ${read.note}${read.acceleration == null || read.dormant ? '' : ` (1h volume is ${read.acceleration.toFixed(1)}x the token's own 24h hourly average)`}`,
  ];
  if (pulse.liquidityUsd === 0) lines.push('CAUTION — the pools report $0 of liquidity: there is no bid to exit into, whatever the price says.');
  else if (pulse.liqToMcapPct != null && pulse.liqToMcapPct < 2)
    lines.push('CAUTION — liquidity is under 2% of market cap: one exit can move the price hard.');
  if (read.dormant) lines.push('CAUTION — a quiet pool is not an entry on the strength of its 24h figure; the volume that produced it has stopped.');
  if (pulse.ageHours != null && pulse.ageHours < 24)
    lines.push('NOTE — this pool is under a day old, so there is no candle series to chart. This is a flow read, not a trend read.');
  return lines.join('\n');
}
