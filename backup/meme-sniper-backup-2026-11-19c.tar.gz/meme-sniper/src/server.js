import { createServer } from 'node:http';
import { readFile } from 'node:fs/promises';
import { resolve, extname } from 'node:path';
import { settingsView, saveSettings } from './settings.js';
import { analyseToken } from './analysis.js';
import { probeRpc } from './feeds/ownership.js';
import { probeSolscan } from './feeds/solscan.js';

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.ico': 'image/x-icon',
};

export function startServer(engine, port) {
  const publicDir = resolve(process.cwd(), 'public');
  const clients = new Set();
  let lastState = JSON.stringify(engine.state());

  const broadcast = () => {
    lastState = JSON.stringify(engine.state());
    for (const res of clients) {
      try {
        res.write(`data: ${lastState}\n\n`);
      } catch {
        clients.delete(res);
      }
    }
  };
  engine.bus.on('state', broadcast);
  engine.bus.on('log', broadcast);

  const jsonRes = (res, code, body) => {
    res.writeHead(code, { 'content-type': 'application/json', 'cache-control': 'no-store' });
    res.end(JSON.stringify(body));
  };

  const readJsonBody = (req) =>
    new Promise((done, fail) => {
      let size = 0;
      const chunks = [];
      req.on('data', (c) => {
        size += c.length;
        if (size > 64 * 1024) {
          fail(new Error('body too large'));
          req.destroy();
          return;
        }
        chunks.push(c);
      });
      req.on('end', () => {
        try {
          done(chunks.length ? JSON.parse(Buffer.concat(chunks).toString('utf8')) : {});
        } catch (err) {
          fail(new Error(`invalid JSON: ${err.message}`));
        }
      });
      req.on('error', fail);
    });

  const server = createServer(async (req, res) => {
    const url = new URL(req.url, `http://${req.headers.host}`);

    if (url.pathname === '/api/state') {
      res.writeHead(200, { 'content-type': 'application/json', 'cache-control': 'no-store' });
      res.end(lastState);
      return;
    }

    if (url.pathname === '/api/stream') {
      res.writeHead(200, {
        'content-type': 'text/event-stream',
        'cache-control': 'no-cache',
        connection: 'keep-alive',
      });
      res.write(`data: ${lastState}\n\n`);
      clients.add(res);
      const ping = setInterval(() => res.write(': ping\n\n'), 20000);
      req.on('close', () => {
        clearInterval(ping);
        clients.delete(res);
      });
      return;
    }

    if (url.pathname === '/api/settings') {
      if (req.method === 'POST') {
        try {
          const body = await readJsonBody(req);
          const result = saveSettings(body?.values || {}, engine.cfg);
          engine.log(
            result.rejected.length ? 'warn' : 'info',
            `settings: ${result.applied.length ? result.applied.join(', ') : 'no changes'}` +
              (result.rejected.length ? ` | rejected ${result.rejected.map((r) => `${r.key} (${r.reason})`).join(', ')}` : ''),
          );
          engine.bus.emit('state', engine.state());
          return jsonRes(res, 200, { ...result, settings: settingsView(engine.cfg) });
        } catch (err) {
          return jsonRes(res, 400, { ok: false, error: err.message });
        }
      }
      return jsonRes(res, 200, settingsView(engine.cfg));
    }

    if (url.pathname === '/api/settings/test-rpc' && req.method === 'POST') {
      try {
        const body = await readJsonBody(req);
        const out = await probeRpc(engine.cfg, body?.url);
        engine.log(
          out.ok ? 'info' : 'warn',
          `RPC check ${out.host}: ${out.checks.map((c) => `${c.name} ${c.ok ? 'ok' : `FAILED (${c.detail})`}`).join(' · ')}`,
        );
        return jsonRes(res, 200, out);
      } catch (err) {
        return jsonRes(res, 400, { ok: false, checks: [], error: err.message });
      }
    }

    if (url.pathname === '/api/settings/test-solscan' && req.method === 'POST') {
      try {
        const body = await readJsonBody(req);
        const out = await probeSolscan(engine.cfg, { apiKey: body?.key });
        engine.log(out.ok ? 'info' : 'warn', `Solscan check (${out.host}): ${out.verdict}`);
        return jsonRes(res, 200, out);
      } catch (err) {
        return jsonRes(res, 400, { ok: false, checks: [], error: err.message });
      }
    }

    if (url.pathname === '/api/wallet/sync' && req.method === 'POST') {
      try {
        const body = await readJsonBody(req);
        const address = engine.cfg.wallet?.paperAddress;
        if (!address) return jsonRes(res, 400, { ok: false, error: 'set a test wallet address in Settings first' });
        // RPC + pricing is I/O bound: answer now, let the state stream carry the
        // result (and any failure) back to the dashboard.
        engine.syncTestWallet({ reset: Boolean(body?.reset) }).catch(() => {});
        return jsonRes(res, 202, { ok: true, started: true, address });
      } catch (err) {
        return jsonRes(res, 400, { ok: false, error: err.message });
      }
    }

    // Bank every position that is in profit right now, through the normal exit
    // path (real depth, round-trip cost, graded trade, saved book).
    // Flat the book: sell everything that has a buyer, profit or loss.
    if (url.pathname === '/api/close-all' && req.method === 'POST') {
      try {
        const out = await engine.closeAll();
        return jsonRes(res, 200, { ok: true, ...out });
      } catch (err) {
        return jsonRes(res, 500, { ok: false, error: err.message });
      }
    }

    if (url.pathname === '/api/close-profitable' && req.method === 'POST') {
      try {
        const out = await engine.closeProfitable();
        return jsonRes(res, 200, { ok: true, ...out });
      } catch (err) {
        return jsonRes(res, 500, { ok: false, error: err.message });
      }
    }

    if (url.pathname === '/api/reset' && req.method === 'POST') {
      if (engine.cfg.mode === 'live') return jsonRes(res, 403, { ok: false, error: 'reset is paper-mode only' });
      try {
        engine.resetBook();
        return jsonRes(res, 200, { ok: true, equity: engine.portfolio.equity() });
      } catch (err) {
        return jsonRes(res, 400, { ok: false, error: err.message });
      }
    }

    // The 3001 crypto desk's read, on demand: flow, cross-pool depth and an
    // indicator pass for any mint. Read-only, so it cannot move the book.
    if (url.pathname === '/api/analysis') {
      const mint = (url.searchParams.get('mint') || '').trim();
      const chain = (url.searchParams.get('chain') || 'solana').trim() || 'solana';
      if (!mint) return jsonRes(res, 400, { ok: false, error: 'a mint address is required' });
      try {
        const read = await analyseToken(chain, mint);
        engine.log(
          read.pulse ? 'info' : 'warn',
          `analysis ${read.pulse?.symbol || `${mint.slice(0, 6)}…`}: ${read.flow?.note || 'no trading pair found'}`,
        );
        return jsonRes(res, 200, { ok: true, ...read });
      } catch (err) {
        return jsonRes(res, 502, { ok: false, error: err.message });
      }
    }

    if (url.pathname === '/api/pause' || url.pathname === '/api/resume') {
      engine.setPaused(url.pathname === '/api/pause');
      res.writeHead(200, { 'content-type': 'application/json' });
      res.end(JSON.stringify({ paused: engine.paused }));
      return;
    }

    // static
    const rel = url.pathname === '/' ? '/index.html' : url.pathname;
    const file = resolve(publicDir, `.${rel}`);
    if (!file.startsWith(publicDir)) {
      res.writeHead(403).end('forbidden');
      return;
    }
    try {
      const body = await readFile(file);
      res.writeHead(200, { 'content-type': MIME[extname(file)] || 'application/octet-stream' });
      res.end(body);
    } catch {
      res.writeHead(404, { 'content-type': 'text/plain' }).end('not found');
    }
  });

  return new Promise((done) => {
    server.listen(port, '0.0.0.0', () => done(server));
  });
}
