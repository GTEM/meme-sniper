# Running the bot on an Android phone with Termux

No account, no card, no VM: the phone is the server. It stays up while it is
charging on Wi-Fi, and the dashboard is `http://localhost:3080` in the phone's
browser.

Paper mode only makes sense here — a phone that Android can suspend should never
be holding a live position.

## 1. Install the apps (F-Droid, not the Play Store)

- **Termux** — <https://f-droid.org/packages/com.termux/> (the APK downloads
  straight from that page; you do not need the F-Droid app). Skip the Play Store
  build: it is an unsupported fork, and mixing the two breaks the install.
- **Termux:API** — <https://f-droid.org/packages/com.termux.api/> (gives you
  `termux-wake-lock`).
- **Termux:Boot** — <https://f-droid.org/packages/com.termux.boot/> (restarts the
  bot after a reboot). Open it once after installing so it registers.

All three must be the same signature (F-Droid), so install them from the same
place.

## 2. Packages and the code

```bash
pkg update -y && pkg upgrade -y
pkg install -y nodejs curl tar termux-api

mkdir -p ~/meme-sniper && cd ~/meme-sniper
curl -L -o app.tar.gz https://meme-sniper-jkzxfz-preview.freebuff.site/app.tar.gz
tar xzf app.tar.gz && rm app.tar.gz
node --version
```

The GitHub repository only holds the deploy shell, so the app itself comes from
that bundle (`src/`, `public/`, `tools/`, package files). `tar` overwrites those
on an update and never touches `data/`.

Paper mode needs no keys. To add one later, copy `.env.example` to `.env` and
edit it — never commit it anywhere.

## 3. Stop Android from freezing the phone

Three separate things kill a background process; do all three.

**a. Battery exemption** — Settings → Apps → Termux → Battery → **Unrestricted**
(and turn off "Pause app activity if unused" / "Remove permissions if unused").
Same for Termux:Boot if it has the setting.

**b. Wake lock** — without it, Doze suspends the CPU once the screen is off:

```bash
termux-wake-lock          # hold it; the screen can still turn off
termux-wake-unlock        # release it when you want to stop
```

**c. Phantom process killer** (Android 12+; this is the one that prints
`[Process completed (signal 9)]` and silently ends the bot):

- **Android 14 and newer** — no adb needed: Settings → System → Developer
  options → turn on **Disable child process restrictions**. (If you then turn
  Developer options back off, the killer comes back.)
- **Android 12L / 13** — Settings → Developer options → **Wireless debugging**
  on, then from Termux:

  ```bash
  pkg install -y android-tools
  adb pair 127.0.0.1:<pair-port>       # code from the Wireless debugging screen
  adb connect 127.0.0.1:<connect-port>
  adb shell "settings put global settings_enable_monitor_phantom_procs false"
  ```

- **Android 12** — the setting above does not exist; raise the ceiling instead:

  ```bash
  adb shell "/system/bin/device_config set_sync_disabled_for_tests persistent"
  adb shell "/system/bin/device_config put activity_manager max_phantom_processes 2147483647"
  ```

Some ROMs reset these on reboot — if the bot dies overnight, re-run the command.
Also **do not swipe Termux out of the recents list**: that ends the session.

## 4. Start the bot

```bash
termux-wake-lock
cd ~/meme-sniper
node src/index.js
```

Leave that running and open `http://localhost:3080` in Chrome. To run it
detached so you can close the keyboard and use the shell:

```bash
cd ~/meme-sniper
nohup node src/index.js >> bot.log 2>&1 &
tail -f bot.log
```

The scan loop is 25 seconds and the book is written to `data/portfolio.json`
after every trade, so stopping and starting loses nothing.

## 5. Come back up after a reboot

```bash
mkdir -p ~/.termux/boot
cat > ~/.termux/boot/start-bot.sh <<'EOF'
#!/data/data/com.termux/files/usr/bin/sh
termux-wake-lock
cd "$HOME/meme-sniper" || exit 1
nohup node src/index.js >> bot.log 2>&1 &
EOF
chmod +x ~/.termux/boot/start-bot.sh
```

Termux:Boot runs everything in `~/.termux/boot` at boot as long as the app has
been opened at least once since it was installed. Test it by rebooting with the
phone on the charger.

## 6. Optional: back the book up to the mirror

```bash
cd ~/meme-sniper
PUBLISH_URL=https://meme-sniper-jkzxfz-preview.freebuff.site \
INGEST_TOKEN=<the token from .secrets/ingest-token> \
nohup node tools/publish-state.mjs >> publish.log 2>&1 &
```

That publishes the dashboard to the mirror and copies the book to `/api/book`
every minute. The phone keeps using its own `data/portfolio.json`; the mirror
copy is only used when a machine starts with an empty disk.

## If something is wrong

| Symptom | Cause |
| --- | --- |
| `[Process completed (signal 9)]` | Phantom process killer — step 3c, or Termux was swiped from recents |
| `curl: connection refused` on `localhost:3080` | The bot is not running; check `tail bot.log` |
| Stops when the screen locks | Wake lock not held (step 3b) or battery not unrestricted (3a) |
| Dies after a day or two | Vendor battery management — exempt Termux, or disable the vendor's app "cleaner" |
| Restarts from a fresh $1000 book | `data/portfolio.json` missing; it lives in `$HOME/meme-sniper/data` |
