#!/usr/bin/env bash
# Rebuild the application bundle those Render builds download, and stage it in
# the mirror's static assets. Run this after changing anything under src/,
# public/ or tools/, then redeploy the site and press Deploy in Render (Render
# only rebuilds on a push or a manual deploy, and this bundle is not a commit).
set -euo pipefail
cd "$(dirname "$0")/../.."

tar -czf deploy/render/app.tar.gz --exclude='*.log' \
  src public tools package.json package-lock.json deploy/render/start.sh
cp deploy/render/app.tar.gz site/assets/app.tar.gz

echo "bundle: $(du -h deploy/render/app.tar.gz | cut -f1), $(tar -tzf deploy/render/app.tar.gz | wc -l) files"
