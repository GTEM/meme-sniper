# Free on Render — no card, no server to manage

**This is live:** <https://meme-sniper-xjmn.onrender.com> — free plan, Oregon,
service `srv-dbv16208v5cc739r8ud0`. It keeps itself awake: Render sets the
service's own origin in the environment, and the bot asks that origin for
`/api/state` every ten minutes, which is inbound traffic and resets Render's
15-minute idle timer. No external monitor account is needed.

Render's free web service needs **no payment method**. You sign in with GitHub,
it builds this repository and runs `node src/index.js`, and you get
`https://<name>.onrender.com` with the dashboard on it.

What it costs you: nothing, but it is 0.1 CPU / 512 MB, and Render puts a free
service to sleep after **15 minutes without an inbound request**. A free uptime
monitor pinging every 5 minutes keeps it awake. Render allows **750 instance
hours per month**; a 31-day month is 744 hours, so an always-awake service sits
just under the cap.

## 1. The GitHub repository already exists

<https://github.com/GTEM/meme-sniper> — public, three files: `render.yaml`,
`build.mjs` and a README. The deploy shell is thin on purpose: at build time
`build.mjs` downloads the application bundle (`src/`, `public/`, `tools/`,
package files) from the mirror at
`https://meme-sniper-jkzxfz-preview.freebuff.site/app.tar.gz` and unpacks it, so
nothing has to be uploaded by hand and no book data or secret ever enters the
repository.

To ship a code change later: `bash deploy/render/bundle.sh` rebuilds that
bundle from the working copy, then redeploy the site (the bundle is a static
asset) and press **Deploy** in Render — Render only rebuilds on a push or a
manual deploy, and the bundle itself is not a commit.

## 2. Create the service

Sign up at <https://dashboard.render.com/register> (GitHub login, no card),
then **New → Blueprint**, pick `GTEM/meme-sniper`, and apply. The `render.yaml`
committed there describes the service:

- plan `free`, runtime `node`
- build `node build.mjs`
- start `bash deploy/render/start.sh`

If you would rather not use a Blueprint: **New → Web Service**, same repository,
Language `Node`, Build Command and Start Command as above, Instance Type `Free`.

It asks for two environment variables:

| Variable        | Value                                                     |
| --------------- | --------------------------------------------------------- |
| `PUBLISH_URL`   | `https://meme-sniper-jkzxfz-preview.freebuff.site`        |
| `INGEST_TOKEN`  | the token in `.secrets/ingest-token` on the bot's own copy |

`PUBLISH_URL` + `INGEST_TOKEN` are what back the book up (see below). The bot
runs fine without them; it just will not survive a restart with its trade log
intact. Do not paste the token into chat — set it in Render's dashboard.

## 3. Stop it from idling out

Free monitoring accounts need no card either. UptimeRobot's free plan gives
5-minute HTTP checks: <https://uptimerobot.com/signUp>

**Add New Monitor → HTTP(s)**:

- URL: `https://<your-service>.onrender.com/api/state`
- Interval: **5 minutes**

5 minutes is inside Render's 15-minute idle window, so the service never spins
down. (Pulsetic and HetrixTools also have card-free plans with 1-5 minute checks
if you prefer another.)

## 4. Open it

`https://<your-service>.onrender.com` — the same dashboard as the local one:
book, open positions, candidates, Settings, pause.

## What is different from a VM

| Thing | On Render's free tier |
| --- | --- |
| Disk | **Throwaway.** Every restart, redeploy and spin-down wipes it. |
| The paper book | The pusher copies `data/portfolio.json` to the mirror every 60 s, and the bot pulls it back at boot when its disk is empty, so the log survives restarts. Up to a minute of the newest trades can be lost if the process is killed hard. |
| `data/model.json` | Not backed up. It starts from the repository's copy and relearns. |
| Instance hours | 750/month. Kept awake all month you are at ~744; crossing the cap suspends free services until the next month. Drop the monitor for a day if that happens. |
| Speed | 0.1 CPU. A 25-second scan interval can stretch under load; the log shows real timings. |
| Sleep | After 15 minutes with no inbound request, and ~1 minute to wake. |
| Restarts | Render may restart a free service at any time; the bot saves on `SIGTERM` and restores from the mirror on boot. |

## Links

Account and console — free, no card:

- Create the account: <https://dashboard.render.com/register>
- Dashboard: <https://dashboard.render.com/>
- New web service: <https://dashboard.render.com/c/new/web-service>
- New Blueprint: <https://dashboard.render.com/c/new/blueprint>
- Existing Blueprints: <https://dashboard.render.com/blueprints>
- Usage and the 750-hour counter: <https://dashboard.render.com/billing>
- Render status: <https://status.render.com/>

Docs:

- Free-tier limits: <https://render.com/docs/free>
- `render.yaml` reference: <https://render.com/docs/blueprint-spec>
- Environment variables: <https://render.com/docs/environment-variables>
- Web services and port binding: <https://render.com/docs/web-services>
- Deploys: <https://render.com/docs/deploys>
- Logs: <https://render.com/docs/logging>
- Failed build / deploy: <https://render.com/docs/troubleshooting-deploys>
- Pricing: <https://render.com/pricing>

The dashboard links answer with the sign-in page until you are logged in.

## If you would rather not use GitHub at all

Render needs a Git repository, so the free-account route always involves one.
The only zero-account option is running the bot on a device you already own —
an Android phone with Termux (`pkg install nodejs`, then `node src/index.js`)
stays up as long as the phone is charging and on Wi-Fi, and the dashboard is
`http://localhost:3080` in the phone's browser.
