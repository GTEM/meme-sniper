#!/usr/bin/env bash
# Render start command. Render gives one process group per service, so the bot
# runs in the foreground and the mirror pusher (state + book backup) beside it.
set -u

node src/index.js &
bot=$!

# Render sends SIGTERM on restart: pass it to the bot so it saves its book.
trap 'kill -TERM "$bot" 2>/dev/null' TERM INT

if [ -n "${PUBLISH_URL:-}" ] && [ -n "${INGEST_TOKEN:-}" ]; then
  node tools/publish-state.mjs &
else
  echo "start.sh: PUBLISH_URL or INGEST_TOKEN missing - no mirror, no book backup"
fi

wait "$bot"
