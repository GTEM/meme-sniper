#!/usr/bin/env bash
# One-shot installer for a fresh Ubuntu/Debian VM (Oracle Always Free, GCP
# e2-micro, etc). Puts the bot in /opt/meme-sniper and runs it under systemd, so
# it survives reboots, crashes and the SSH session ending.
#
#   sudo bash install.sh
#
# The bot has no npm dependencies; it only needs Node >= 20.6.
set -euo pipefail

HERE="$(cd "$(dirname "$0")" && pwd)"
APP_DIR=/opt/meme-sniper
SVC_USER=sniper
SVC_NAME=meme-sniper
MIN_NODE="20.6"

if [ "$(id -u)" -ne 0 ]; then
  echo "run this with sudo" >&2
  exit 1
fi

node_ok() {
  local v
  v="$(node -v 2>/dev/null | sed 's/^v//')" || return 1
  [ -n "$v" ] || return 1
  awk -v a="$v" -v b="$MIN_NODE" 'BEGIN{split(a,x,".");split(b,y,".");if(x[1]>y[1])exit 0;if(x[1]<y[1])exit 1;if(x[2]+0>=y[2]+0)exit 0;exit 1}'
}

if node_ok; then
  echo "· node $(node -v) already present"
else
  echo "· installing Node 22 (nodesource)"
  apt-get update -y
  apt-get install -y curl ca-certificates
  curl -fsSL https://deb.nodesource.com/setup_22.x | bash -
  apt-get install -y nodejs
fi
NODE_BIN="$(command -v node)"

echo "· creating service user $SVC_USER"
id -u "$SVC_USER" >/dev/null 2>&1 || useradd --system --home "$APP_DIR" --shell /usr/sbin/nologin "$SVC_USER"

echo "· unpacking app to $APP_DIR"
mkdir -p "$APP_DIR"
tar -xzf "$HERE/meme-sniper.tar.gz" -C "$APP_DIR"

if [ ! -f "$APP_DIR/.env" ]; then
  echo "· no .env found — copying .env.example (edit it before the bot sees live data)"
  cp "$APP_DIR/.env.example" "$APP_DIR/.env"
fi

chown -R "$SVC_USER":"$SVC_USER" "$APP_DIR"

echo "· writing systemd unit"
sed -e "s|__NODE__|$NODE_BIN|" -e "s|__APP__|$APP_DIR|" -e "s|__USER__|$SVC_USER|" \
  "$HERE/meme-sniper.service" > "/etc/systemd/system/$SVC_NAME.service"

systemctl daemon-reload
systemctl enable --now "$SVC_NAME"

sleep 6
systemctl --no-pager --lines=8 status "$SVC_NAME" || true

IP="$(curl -fsS -m 5 https://api.ipify.org 2>/dev/null || echo "<this-vms-ip>")"
cat <<EOF

installed. dashboard: http://$IP:3080
logs:      journalctl -u $SVC_NAME -f   (and $APP_DIR/bot.log)
restart:   systemctl restart $SVC_NAME
stop:      systemctl stop $SVC_NAME

if the page does not load, open TCP 3080 in the cloud firewall / security list,
restricted to your own IP — the dashboard has no login and can change settings.
EOF
