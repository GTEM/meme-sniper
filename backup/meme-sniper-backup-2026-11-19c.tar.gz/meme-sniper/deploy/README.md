# Running the bot 24/7 for free

The bot is a plain Node program with **no npm dependencies**. It needs Node 20.6
or newer and outbound internet. It binds `0.0.0.0:3080` and serves its own
dashboard from `public/index.html`.

Two routes, and only one of them is card-free:

- **No card at all → [`deploy/render/README.md`](render/README.md).** Render's
  free web service, a free GitHub account and a free 5-minute uptime monitor.
  Small (0.1 CPU, 512 MB) and the disk is throwaway, but it costs nothing and
  needs no payment method anywhere.
- **A real VM → below.** Oracle Cloud Always Free and GCP's free `e2-micro` both
  **require a card for identity verification at signup**, even though the tier
  itself is not charged. If there is no card to give, use the Render route.
- **No account at all → [`deploy/termux/README.md`](termux/README.md).** Run it on
  an Android phone under Termux: no signup, no card, but it only runs while the
  phone is on and awake.

## 1. Make the VM

## 2. Open the dashboard port

In the VM's firewall (Oracle: *Security List → Ingress Rules*; GCP: *VPC network
→ Firewall*), allow **TCP 3080**.

Restrict the source to **your own IP** if you can. The dashboard has no login,
and anything on that port can change the bot's settings.

On the VM itself, if `ufw` is active: `sudo ufw allow 3080/tcp`.

## 3. Copy the bot up

From the folder holding `meme-sniper.tar.gz` and `install.sh`:

```bash
scp meme-sniper.tar.gz install.sh ubuntu@<vm-ip>:~
```

Then on the VM:

```bash
sudo bash install.sh
```

That unpacks to `/opt/meme-sniper`, installs Node 22 if it is missing, creates a
`sniper` service user, installs and starts `meme-sniper.service`, and prints the
dashboard URL.

## 4. Your keys

The tarball deliberately carries **no `.env`** and no `.secrets/`. The installer
copies `.env.example` to `/opt/meme-sniper/.env` as a starting point.

Either:

```bash
scp .env ubuntu@<vm-ip>:/tmp/mine.env
sudo install -o sniper -g sniper -m 600 /tmp/mine.env /opt/meme-sniper/.env
sudo rm /tmp/mine.env
sudo systemctl restart meme-sniper
```

or leave the file alone and use the dashboard's **Settings** panel, which writes
the values it accepts into the same file.

Paper mode is the default (`PAPER=on`). Nothing here can move funds while it is
on.

## 5. Checking on it

```bash
systemctl status meme-sniper          # is it up
journalctl -u meme-sniper -f          # engine events
tail -f /opt/meme-sniper/bot.log      # scan log
systemctl restart meme-sniper         # restart
```

`Restart=always` means a crash, an OOM kill or a reboot brings the loop back
within five seconds. The paper book lives in `/opt/meme-sniper/data/portfolio.json`
and is written after every trade, so a restart resumes where it left off.

## Optional: keep the freebuff.site mirror updated

The published page at `https://meme-sniper-jkzxfz-preview.freebuff.site` is a
read-only mirror fed by `tools/publish-state.mjs`. On a VM with a public IP you
do not need it — `http://<vm-ip>:3080` is the live dashboard. If you still want
the mirror, run the pusher as a second service with the token in
`/opt/meme-sniper/.secrets/ingest-token` (that file is not in the tarball; copy
it the same way as `.env`).
