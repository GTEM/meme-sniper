// Published mirror of the bot's dashboard.
//
// The bot keeps running on its own host (a Node process with a 25-second scan
// loop, which Workers cannot run). It pushes its state here every few seconds;
// this Worker keeps the last snapshot in D1 and serves it, so the site shows the
// same book the bot is trading without the bot being reachable from the internet.
//
// Everything that would change the book is refused: this is a view, not a control
// panel. Controls stay on the bot host.

const JSON_HEADERS = {
  'content-type': 'application/json; charset=utf-8',
  'cache-control': 'no-store',
};

const STREAM_TICK_MS = 5000;
const STREAM_MAX_MS = 10 * 60 * 1000;

const json = (code, body) =>
  new Response(JSON.stringify(body), { status: code, headers: JSON_HEADERS });

async function ensureTable(env) {
  await env.DB.prepare(
    'CREATE TABLE IF NOT EXISTS snapshot (id INTEGER PRIMARY KEY, payload TEXT NOT NULL, updated_at INTEGER NOT NULL)',
  ).run();
}

async function latest(env) {
  try {
    return await env.DB.prepare('SELECT payload, updated_at FROM snapshot WHERE id = 1').first();
  } catch {
    return null;
  }
}

async function ensureBookTable(env) {
  await env.DB.prepare(
    'CREATE TABLE IF NOT EXISTS book (id INTEGER PRIMARY KEY, payload TEXT NOT NULL, updated_at INTEGER NOT NULL)',
  ).run();
}

// A byte-for-byte copy of data/portfolio.json. The published dashboard only
// needs the rendered snapshot, but a host with a throwaway disk (Render's free
// tier wipes the filesystem on every restart) needs the real book back: the
// snapshot drops cooldowns, the seen table and every trade past the sixtieth,
// so it cannot be used to rebuild one.
async function savedBook(env) {
  try {
    return await env.DB.prepare('SELECT payload, updated_at FROM book WHERE id = 1').first();
  } catch {
    return null;
  }
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);

    if (url.pathname === '/api/ingest') {
      if (request.method !== 'POST') return json(405, { ok: false, error: 'POST only' });
      if (!env.INGEST_TOKEN) {
        return json(503, { ok: false, error: 'ingest is not configured: set the INGEST_TOKEN secret' });
      }
      if (request.headers.get('authorization') !== `Bearer ${env.INGEST_TOKEN}`) {
        return json(401, { ok: false, error: 'bad token' });
      }
      const body = await request.text();
      if (!body) return json(400, { ok: false, error: 'empty state' });
      if (body.length > 1_000_000) return json(413, { ok: false, error: 'state too large' });
      try {
        JSON.parse(body);
      } catch {
        return json(400, { ok: false, error: 'state is not JSON' });
      }
      await ensureTable(env);
      await env.DB.prepare(
        'INSERT INTO snapshot (id, payload, updated_at) VALUES (1, ?1, ?2) ON CONFLICT(id) DO UPDATE SET payload = ?1, updated_at = ?2',
      )
        .bind(body, Date.now())
        .run();
      return json(200, { ok: true, bytes: body.length });
    }

    if (url.pathname === '/api/book') {
      if (request.method === 'POST' || request.method === 'PUT') {
        if (!env.INGEST_TOKEN) {
          return json(503, { ok: false, error: 'ingest is not configured: set the INGEST_TOKEN secret' });
        }
        if (request.headers.get('authorization') !== `Bearer ${env.INGEST_TOKEN}`) {
          return json(401, { ok: false, error: 'bad token' });
        }
        const body = await request.text();
        if (!body) return json(400, { ok: false, error: 'empty book' });
        if (body.length > 1_000_000) return json(413, { ok: false, error: 'book too large' });
        try {
          JSON.parse(body);
        } catch {
          return json(400, { ok: false, error: 'book is not JSON' });
        }
        await ensureBookTable(env);
        await env.DB.prepare(
          'INSERT INTO book (id, payload, updated_at) VALUES (1, ?1, ?2) ON CONFLICT(id) DO UPDATE SET payload = ?1, updated_at = ?2',
        )
          .bind(body, Date.now())
          .run();
        return json(200, { ok: true, bytes: body.length });
      }
      const row = await savedBook(env);
      if (!row) return json(503, { ok: false, error: 'no book has been backed up yet' });
      return new Response(row.payload, {
        status: 200,
        headers: { ...JSON_HEADERS, 'x-book-at': String(row.updated_at) },
      });
    }

    if (url.pathname === '/api/state') {
      const row = await latest(env);
      if (!row) return json(503, { ok: false, error: 'the bot has not published a snapshot yet' });
      return new Response(row.payload, {
        status: 200,
        headers: { ...JSON_HEADERS, 'x-snapshot-at': String(row.updated_at) },
      });
    }

    // The dashboard opens an EventSource first and only falls back to polling
    // after 90s of silence, so this stream has to exist and keep talking.
    if (url.pathname === '/api/stream') {
      const { readable, writable } = new TransformStream();
      const writer = writable.getWriter();
      const encoder = new TextEncoder();
      let closed = false;

      const push = async () => {
        if (closed) return;
        const row = await latest(env);
        if (!row) return;
        try {
          await writer.write(encoder.encode(`data: ${row.payload}\n\n`));
        } catch {
          closed = true;
        }
      };

      const startedAt = Date.now();
      const timer = setInterval(() => {
        if (Date.now() - startedAt > STREAM_MAX_MS) {
          clearInterval(timer);
          closed = true;
          writer.close().catch(() => {});
          return;
        }
        push();
      }, STREAM_TICK_MS);

      request.signal?.addEventListener?.('abort', () => {
        clearInterval(timer);
        closed = true;
        writer.close().catch(() => {});
      });

      push();
      return new Response(readable, {
        headers: {
          'content-type': 'text/event-stream',
          'cache-control': 'no-store',
          connection: 'keep-alive',
        },
      });
    }

    if (url.pathname.startsWith('/api/')) {
      return json(501, {
        ok: false,
        error: 'this site is a read-only mirror of the bot; settings and pause live on the bot host',
      });
    }

    return env.ASSETS.fetch(request);
  },
};
