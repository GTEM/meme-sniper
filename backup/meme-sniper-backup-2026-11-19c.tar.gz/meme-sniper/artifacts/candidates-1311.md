# Every candidate, 04:30 → 13:10 (today)

Source: bot.log (all candidate lines) + /api/state scan.recent (last 25 with factor breakdown).

## Summary

| Blocked by | Count |
|---|---|
| churn (volume / liquidity) | 160 |
| safety (holders / authority) | 159 |
| rug blacklist / copycat pin | 42 |
| not enough data | 32 |
| liquidity vs market cap | 13 |
| too old | 1 |
| reached the AI, scored under the 60% bar | 57 |
| cleared the bar | 0 |
| **entered** | 63 |

## Cleared the 60% bar

None.

## Reached the AI, refused on score

| Time | Symbol | Score | Needed | Liquidity | Age | Rug risk |
|---|---|---|---|---|---|---|
| 13:10:40 | Jason | 41% | 60% | $3687 | 57s | 10/100 |
| 13:10:00 | FLC | 37% | 60% | $3862 | 106s | 22/100 |
| 13:09:16 | wind | 30% | 60% | $3485 | 117s | 32/100 |
| 13:04:27 | Boobie | 39% | 60% | $11704 | 30s | 10/100 |
| 13:04:22 | CRIMECAT | 42% | 60% | $3791 | 36s | 22/100 |
| 13:03:52 | GT | 54% | 60% | $4638 | 49s | 10/100 |
| 13:02:17 | VI | 39% | 60% | $78292 | 685s | 10/100 |
| 13:02:08 | BUCKZ | 51% | 60% | $20201 | 1122s | 10/100 |
| 13:01:21 | AC | 56% | 60% | $6518 | 63s | 10/100 |
| 12:30:25 | Tashima | 36% | 60% | $89061 | 52s | 22/100 |
| 12:29:05 | ADC | 41% | 60% | $3775 | 127s | 10/100 |
| 12:27:57 | DacityCoin | 60% | 60% | $3715 | 152s | 10/100 |
| 12:09:25 | AFTER | 34% | 60% | $12696 | 70s | 10/100 |
| 12:08:51 | mihao | 37% | 60% | $12091 | 79s | 10/100 |
| 12:08:45 | GTAVII | 23% | 60% | $3132 | 75s | 22/100 |
| 12:08:15 | DACT | 31% | 60% | $12091 | 38s | 10/100 |
| 12:06:32 | DacityCoin | 33% | 60% | $3711 | 55s | 10/100 |
| 12:06:27 | 花 | 31% | 60% | $9997 | 58s | 22/100 |
| 12:04:52 | AU | 31% | 60% | $3104 | 122s | 10/100 |
| 12:03:28 | DacityCoin | 58% | 60% | $3713 | 93s | 10/100 |
| 12:00:24 | DacityCoin | 23% | 60% | $3075 | 124s | 36/100 |
| 11:59:40 | Speed | 57% | 60% | $3731 | 65s | 10/100 |
| 11:59:04 | Audacity | 31% | 60% | $3506 | 84s | 10/100 |
| 11:56:26 | YUKON | 37% | 60% | $3862 | 71s | 10/100 |
| 11:54:39 | mihao | 35% | 60% | $6032 | 73s | 10/100 |
| 11:48:37 | BEAST | 38% | 60% | $3771 | 215s | 10/100 |
| 11:46:03 | TATTOO | 45% | 60% | $3548 | 88s | 10/100 |
| 11:41:40 | COSPNG | 41% | 60% | $91735 | 62s | 22/100 |
| 11:30:36 | Democat | 41% | 60% | $30563 | 266s | 22/100 |
| 11:26:10 | Christmas | 36% | 60% | $30387 | 54s | 22/100 |
| 11:14:37 | CORK | 42% | 60% | $85566 | 72s | 22/100 |
| 10:56:04 | APEC | 47% | 60% | $31750 | 101s | 10/100 |
| 10:55:23 | Breast | 50% | 60% | $30250 | 247s | 10/100 |
| 10:40:05 | GTA6 | 56% | 60% | $61761 | 93s | 10/100 |
| 10:38:03 | GTA6 | 48% | 60% | $87773 | 166s | 10/100 |
| 10:07:47 | Tradercat | 51% | 60% | $30500 | 54s | 10/100 |
| 10:01:17 | TRADER | 42% | 60% | $30866 | 76s | 22/100 |
| 09:59:40 | GrokChan | 33% | 60% | $30966 | 67s | 22/100 |
| 09:55:29 | IFRUIT | 50% | 60% | $32421 | 77s | 10/100 |
| 09:54:23 | FOX | 40% | 60% | $31537 | 69s | 22/100 |
| 09:52:41 | IFRUIT | 51% | 60% | $32211 | 47s | 10/100 |
| 09:41:30 | UODF | 53% | 60% | $30576 | 84s | 10/100 |
| 09:40:36 | Tradercat | 47% | 60% | $30001 | 67s | 10/100 |
| 09:25:07 | Breast | 53% | 60% | $30766 | 177s | 10/100 |
| 09:12:10 | GTA6 | 40% | 60% | $75866 | 105s | 22/100 |
| 09:09:37 | Intel | 50% | 60% | $31537 | 65s | 10/100 |
| 09:07:47 | TESLA | 40% | 60% | $30484 | 153s | 22/100 |
| 09:01:33 | TRADER | 42% | 60% | $30457 | 44s | 22/100 |
| 08:58:04 | $GOAT | 47% | 60% | $31993 | 101s | 22/100 |
| 08:57:59 | Intel | 55% | 60% | $31587 | 97s | 10/100 |
| 08:44:03 | Democat | 42% | 60% | $30367 | 129s | 22/100 |
| 08:43:51 | SKYLION | 44% | 60% | $90319 | 102s | 22/100 |
| 08:37:16 | Tradercat | 58% | 60% | $30234 | 48s | 10/100 |
| 08:20:35 | GTA6 | 51% | 60% | $86834 | 73s | 22/100 |
| 08:05:38 | Musk | 52% | 60% | $30352 | 51s | 22/100 |
| 05:27:10 | REBOOT | 58% | 60% | $150285 | 414s | 12/100 |
| 05:17:13 | LIQUIDBGT | 46% | 60% | $15010 | 454s | 12/100 |
| 04:38:14 | clawd | 57% | 60% | $15339 | 219s | 10/100 |

## Refused before scoring

### churn (volume / liquidity) — 160

| Time | Symbol | Reason |
|---|---|---|
| 05:46:59 | Strawberry | churn: 5m volume is 55% of pool liquidity (max 33%) |
| 05:52:13 | Strawberry | churn: 5m volume is 139% of pool liquidity (max 33%) |
| 05:55:46 | slopaganda | churn: 5m volume is 200% of pool liquidity (max 33%) |
| 06:03:10 | FI | churn: 5m volume is 55% of pool liquidity (max 33%) |
| 06:03:16 | tiecat | churn: 5m volume is 49% of pool liquidity (max 33%) |
| 06:09:14 | FI | churn: 5m volume is 191% of pool liquidity (max 33%) |
| 06:18:50 | SLOPAGANDA | churn: 5m volume is 90% of pool liquidity (max 33%) |
| 06:20:12 | FI | churn: 5m volume is 202% of pool liquidity (max 33%) |
| 06:22:25 | HODL | churn: 5m volume is 85% of pool liquidity (max 33%) |
| 06:24:54 | WAKO | churn: 5m volume is 130% of pool liquidity (max 33%) |
| 06:26:24 | FI | churn: 5m volume is 71% of pool liquidity (max 33%) |
| 06:29:32 | FI | churn: 5m volume is 133% of pool liquidity (max 33%) |
| 06:31:25 | NI | churn: 5m volume is 99% of pool liquidity (max 33%) |
| 06:41:35 | 7777 | churn: 5m volume is 153% of pool liquidity (max 33%) |
| 06:42:53 | Human | churn: 5m volume is 110% of pool liquidity (max 33%) |
| 06:43:04 | HUMAN | churn: 5m volume is 50% of pool liquidity (max 33%) |
| 06:44:55 | Human | churn: 5m volume is 203% of pool liquidity (max 33%) |
| 06:47:08 | Leonida | churn: 5m volume is 80% of pool liquidity (max 33%) |
| 06:51:05 | Pablо | churn: 5m volume is 35% of pool liquidity (max 33%) |
| 06:56:39 | mihao | churn: 5m volume is 81% of pool liquidity (max 33%) |
| 06:57:55 | CLIP | churn: 5m volume is 71% of pool liquidity (max 33%) |
| 06:59:39 | DCI | churn: 5m volume is 49% of pool liquidity (max 33%) |
| 07:11:12 | GTAVI | churn: 5m volume is 67% of pool liquidity (max 33%) |
| 07:14:00 | Star | churn: 5m volume is 70% of pool liquidity (max 33%) |
| 07:20:24 | 나비가 | churn: 5m volume is 66% of pool liquidity (max 33%) |
| 07:20:29 | 나비가 | churn: 5m volume is 54% of pool liquidity (max 33%) |
| 07:22:38 | Aliyа | churn: 5m volume is 124% of pool liquidity (max 33%) |
| 07:22:39 | 나비가 | churn: 5m volume is 135% of pool liquidity (max 33%) |
| 07:23:10 | Aliyа | churn: 5m volume is 91% of pool liquidity (max 33%) |
| 07:23:15 | 나비 | churn: 5m volume is 68% of pool liquidity (max 33%) |
| 07:24:28 | 나비 | churn: 5m volume is 90% of pool liquidity (max 33%) |
| 07:35:02 | GTA | churn: 5m volume is 71% of pool liquidity (max 33%) |
| 07:40:13 | BANDANA | churn: 5m volume is 46% of pool liquidity (max 33%) |
| 07:46:10 | Gamooor | churn: 5m volume is 47% of pool liquidity (max 33%) |
| 07:48:38 | EI | churn: 5m volume is 142% of pool liquidity (max 33%) |
| 07:50:30 | eepy | churn: 5m volume is 57% of pool liquidity (max 33%) |
| 07:56:30 | controller | churn: 5m volume is 42% of pool liquidity (max 33%) |
| 07:56:53 | controller | churn: 5m volume is 77% of pool liquidity (max 33%) |
| 08:02:40 | controller | churn: 5m volume is 231% of pool liquidity (max 33%) |
| 08:06:25 | FAILE | churn: 5m volume is 51% of pool liquidity (max 33%) |
| 08:07:51 | DIH | churn: 5m volume is 100% of pool liquidity (max 33%) |
| 08:20:23 | SHK | churn: 5m volume is 194% of pool liquidity (max 33%) |
| 08:22:05 | Sharkcards | churn: 5m volume is 116% of pool liquidity (max 33%) |
| 08:26:47 | SHARKCARDS | churn: 5m volume is 179% of pool liquidity (max 33%) |
| 08:26:51 | Sharkcards | churn: 5m volume is 202% of pool liquidity (max 33%) |
| 08:28:36 | JS8 | churn: 5m volume is 137% of pool liquidity (max 33%) |
| 08:30:39 | Sharkcards | churn: 5m volume is 94% of pool liquidity (max 33%) |
| 08:30:41 | GTAVI | churn: 5m volume is 39% of pool liquidity (max 33%) |
| 08:36:40 | Sharkcards | churn: 5m volume is 194% of pool liquidity (max 33%) |
| 08:36:50 | DaPussy | churn: 5m volume is 153% of pool liquidity (max 33%) |
| 08:39:47 | Makenzi | churn: 5m volume is 54% of pool liquidity (max 33%) |
| 08:41:13 | DCI | churn: 5m volume is 133% of pool liquidity (max 33%) |
| 08:41:15 | DCI | churn: 5m volume is 72% of pool liquidity (max 33%) |
| 08:44:35 | SHARK | churn: 5m volume is 50% of pool liquidity (max 33%) |
| 08:46:22 | CB | churn: 5m volume is 105% of pool liquidity (max 33%) |
| 08:51:14 | IDRENT | churn: 5m volume is 60% of pool liquidity (max 33%) |
| 08:56:54 | FAILE | churn: 5m volume is 250% of pool liquidity (max 33%) |
| 08:57:02 | Elon | churn: 5m volume is 88% of pool liquidity (max 33%) |
| 08:59:39 | SHARK | churn: 5m volume is 73% of pool liquidity (max 33%) |
| 09:01:27 | RP | churn: 5m volume is 35% of pool liquidity (max 33%) |
| 09:04:25 | BI | churn: 5m volume is 222% of pool liquidity (max 33%) |
| 09:06:19 | KATIA | churn: 5m volume is 75% of pool liquidity (max 33%) |
| 09:09:10 | TTWO | churn: 5m volume is 114% of pool liquidity (max 33%) |
| 09:11:29 | FAILE | churn: 5m volume is 54% of pool liquidity (max 33%) |
| 09:15:21 | FAILE | churn: 5m volume is 56% of pool liquidity (max 33%) |
| 09:25:34 | IDRENT | churn: 5m volume is 88% of pool liquidity (max 33%) |
| 09:28:25 | CHUD | churn: 5m volume is 107% of pool liquidity (max 33%) |
| 09:30:07 | Jason | churn: 5m volume is 34% of pool liquidity (max 33%) |
| 09:30:36 | CHUD | churn: 5m volume is 81% of pool liquidity (max 33%) |
| 09:30:44 | CHUD | churn: 5m volume is 55% of pool liquidity (max 33%) |
| 09:32:24 | 兰兰 | churn: 5m volume is 247% of pool liquidity (max 33%) |
| 09:32:29 | plobu | churn: 5m volume is 291% of pool liquidity (max 33%) |
| 09:34:29 | MOD | churn: 5m volume is 52% of pool liquidity (max 33%) |
| 09:35:35 | BI | churn: 5m volume is 78% of pool liquidity (max 33%) |
| 09:37:26 | POOPCOIN | churn: 5m volume is 129% of pool liquidity (max 33%) |
| 09:43:33 | BI | churn: 5m volume is 78% of pool liquidity (max 33%) |
| 09:49:48 | LIFTD | churn: 5m volume is 261% of pool liquidity (max 33%) |
| 09:51:50 | SHOCKCAT | churn: 5m volume is 176% of pool liquidity (max 33%) |
| 09:52:03 | Shockcat | churn: 5m volume is 178% of pool liquidity (max 33%) |
| 09:52:36 | GTA6 | churn: 5m volume is 238% of pool liquidity (max 33%) |
| 09:57:44 | COCKSTAR | churn: 5m volume is 78% of pool liquidity (max 33%) |
| 09:59:28 | GTA6 | churn: 5m volume is 225% of pool liquidity (max 33%) |
| 10:01:16 | Shockcat | churn: 5m volume is 156% of pool liquidity (max 33%) |
| 10:04:18 | Shockcat | churn: 5m volume is 120% of pool liquidity (max 33%) |
| 10:04:30 | 1B | churn: 5m volume is 73% of pool liquidity (max 33%) |
| 10:05:59 | AegisAI | churn: 5m volume is 103% of pool liquidity (max 33%) |
| 10:08:36 | RAPECOIN | churn: 5m volume is 42% of pool liquidity (max 33%) |
| 10:11:30 | ACI | churn: 5m volume is 35% of pool liquidity (max 33%) |
| 10:13:53 | AegisAI | churn: 5m volume is 336% of pool liquidity (max 33%) |
| 10:14:03 | CHUD | churn: 5m volume is 176% of pool liquidity (max 33%) |
| 10:17:02 | FlapCare | churn: 5m volume is 85% of pool liquidity (max 33%) |
| 10:22:00 | 给他爱6 | churn: 5m volume is 100% of pool liquidity (max 33%) |
| 10:22:10 | IDRENT | churn: 5m volume is 76% of pool liquidity (max 33%) |
| 10:23:02 | Camino | churn: 5m volume is 168% of pool liquidity (max 33%) |
| 10:23:50 | ACI | churn: 5m volume is 96% of pool liquidity (max 33%) |
| 10:25:12 | ACI | churn: 5m volume is 188% of pool liquidity (max 33%) |
| 10:25:48 | ACI | churn: 5m volume is 43% of pool liquidity (max 33%) |
| 10:37:55 | WHITEPILL | churn: 5m volume is 256% of pool liquidity (max 33%) |
| 10:39:24 | Whitepill | churn: 5m volume is 224% of pool liquidity (max 33%) |
| 10:40:00 | WP | churn: 5m volume is 90% of pool liquidity (max 33%) |
| 10:47:38 | MIA | churn: 5m volume is 66% of pool liquidity (max 33%) |
| 10:47:50 | GTA6 | churn: 5m volume is 55% of pool liquidity (max 33%) |
| 10:49:39 | clipping | churn: 5m volume is 72% of pool liquidity (max 33%) |
| 10:50:56 | Mansion | churn: 5m volume is 43% of pool liquidity (max 33%) |
| 10:53:57 | Mansion | churn: 5m volume is 45% of pool liquidity (max 33%) |
| 10:55:59 | Bunk | churn: 5m volume is 148% of pool liquidity (max 33%) |
| 11:00:00 | WGMI | churn: 5m volume is 152% of pool liquidity (max 33%) |
| 11:00:05 | WANTED | churn: 5m volume is 102% of pool liquidity (max 33%) |
| 11:03:58 | DACT | churn: 5m volume is 1212% of pool liquidity (max 33%) |
| 11:04:50 | GTAVl | churn: 5m volume is 126% of pool liquidity (max 33%) |
| 11:09:19 | DACT | churn: 5m volume is 58% of pool liquidity (max 33%) |
| 11:22:12 | AudaCity | churn: 5m volume is 56% of pool liquidity (max 33%) |
| 11:23:34 | AudaCity | churn: 5m volume is 349% of pool liquidity (max 33%) |
| 11:38:24 | b | churn: 5m volume is 132% of pool liquidity (max 33%) |
| 11:39:37 | CRYPTO | churn: 5m volume is 107% of pool liquidity (max 33%) |
| 11:39:39 | SHITBEAST | churn: 5m volume is 157% of pool liquidity (max 33%) |
| 11:40:10 | CSC | churn: 5m volume is 113% of pool liquidity (max 33%) |
| 11:40:14 | DacityCoin | churn: 5m volume is 244% of pool liquidity (max 33%) |
| 11:40:49 | CSC | churn: 5m volume is 59% of pool liquidity (max 33%) |
| 11:42:11 | DacityPad | churn: 5m volume is 278% of pool liquidity (max 33%) |
| 11:42:16 | AodaCety | churn: 5m volume is 184% of pool liquidity (max 33%) |
| 11:42:47 | buck | churn: 5m volume is 59% of pool liquidity (max 33%) |
| 11:43:38 | VM | churn: 5m volume is 162% of pool liquidity (max 33%) |
| 11:43:40 | CSC | churn: 5m volume is 59% of pool liquidity (max 33%) |
| 11:44:35 | GTASZN | churn: 5m volume is 112% of pool liquidity (max 33%) |
| 11:45:55 | WASTED | churn: 5m volume is 106% of pool liquidity (max 100%) |
| 11:46:34 | Pussy | churn: 5m volume is 130% of pool liquidity (max 100%) |
| 11:47:54 | PRAY | churn: 5m volume is 237% of pool liquidity (max 100%) |
| 11:50:33 | AUDY | churn: 5m volume is 110% of pool liquidity (max 100%) |
| 11:51:07 | IMG | churn: 5m volume is 182% of pool liquidity (max 100%) |
| 11:53:10 | DACT | churn: 5m volume is 106% of pool liquidity (max 100%) |
| 11:53:15 | COWBOYS | churn: 5m volume is 167% of pool liquidity (max 100%) |
| 11:53:51 | CHIEN | churn: 5m volume is 812% of pool liquidity (max 100%) |
| 11:54:38 | busted | churn: 5m volume is 331% of pool liquidity (max 100%) |
| 11:55:35 | busted | churn: 5m volume is 108% of pool liquidity (max 100%) |
| 11:55:41 | CHUCKS | churn: 5m volume is 126% of pool liquidity (max 100%) |
| 11:56:25 | YUKON | churn: 5m volume is 216% of pool liquidity (max 100%) |
| 11:57:47 | b | churn: 5m volume is 195% of pool liquidity (max 100%) |
| 11:57:53 | IFMGLITCH | churn: 5m volume is 169% of pool liquidity (max 100%) |
| 11:58:23 | DacityCoin | churn: 5m volume is 317% of pool liquidity (max 100%) |
| 11:58:28 | GARY | churn: 5m volume is 290% of pool liquidity (max 100%) |
| 12:01:35 | BUTT | churn: 5m volume is 114% of pool liquidity (max 100%) |
| 12:01:41 | 𝒃 | churn: 5m volume is 250% of pool liquidity (max 100%) |
| 12:02:42 | DacityCoin | churn: 5m volume is 551% of pool liquidity (max 100%) |
| 12:03:22 | AUDC | churn: 5m volume is 123% of pool liquidity (max 100%) |
| 12:04:02 | VI | churn: 5m volume is 247% of pool liquidity (max 100%) |
| 12:09:26 | RIGHTWING | churn: 5m volume is 167% of pool liquidity (max 100%) |
| 12:10:37 | Billy | churn: 5m volume is 143% of pool liquidity (max 100%) |
| 12:18:08 | EDDIE | churn: 5m volume is 169% of pool liquidity (max 100%) |
| 12:18:11 | DATN | churn: 5m volume is 204% of pool liquidity (max 100%) |
| 12:20:27 | IMG | churn: 5m volume is 281% of pool liquidity (max 100%) |
| 12:20:33 | IMG | churn: 5m volume is 269% of pool liquidity (max 100%) |
| 12:21:10 | Mandy | churn: 5m volume is 178% of pool liquidity (max 100%) |
| 12:28:12 | RYU | churn: 5m volume is 180% of pool liquidity (max 100%) |
| 12:28:15 | RAC7 | churn: 5m volume is 214% of pool liquidity (max 100%) |
| 12:29:51 | wasted | churn: 5m volume is 218% of pool liquidity (max 100%) |
| 13:01:31 | cooked | churn: 5m volume is 101% of pool liquidity (max 100%) |
| 13:03:46 | CRIME | churn: 5m volume is 154% of pool liquidity (max 100%) |
| 13:06:33 | AC | churn: 5m volume is 161% of pool liquidity (max 100%) |
| 13:08:35 | PUSSY | churn: 5m volume is 104% of pool liquidity (max 100%) |

### safety (holders / authority) — 159

| Time | Symbol | Reason |
|---|---|---|
| 05:46:22 | CHUBBY | safety 0.60 < 0.7 (holder concentration / authorities) |
| 05:47:04 | TNA | safety 0.15 < 0.7 (holder concentration / authorities) |
| 05:47:40 | slopaganda | safety 0.00 < 0.7 (holder concentration / authorities) |
| 05:49:25 | Organicat | safety 0.03 < 0.7 (holder concentration / authorities) |
| 05:49:27 | mihao | safety 0.26 < 0.7 (holder concentration / authorities) |
| 05:54:24 | FI | safety 0.00 < 0.7 (holder concentration / authorities) |
| 05:55:01 | Bosko | safety 0.15 < 0.7 (holder concentration / authorities) |
| 05:55:51 | LUCIA | safety 0.15 < 0.7 (holder concentration / authorities) |
| 06:01:39 | slopaganda | safety 0.00 < 0.7 (holder concentration / authorities) |
| 06:02:13 | BLIMBO | safety 0.00 < 0.7 (holder concentration / authorities) |
| 06:02:15 | SI | safety 0.00 < 0.7 (holder concentration / authorities) |
| 06:12:02 | FI | safety 0.00 < 0.7 (holder concentration / authorities) |
| 06:14:23 | Human | safety 0.00 < 0.7 (holder concentration / authorities) |
| 06:15:11 | HODL | safety 0.00 < 0.7 (holder concentration / authorities) |
| 06:18:52 | HODL | safety 0.15 < 0.7 (holder concentration / authorities) |
| 06:25:04 | GTAVI | safety 0.26 < 0.7 (holder concentration / authorities) |
| 06:29:43 | GTAVI | safety 0.11 < 0.7 (holder concentration / authorities) |
| 06:30:27 | FOX | safety 0.15 < 0.7 (holder concentration / authorities) |
| 06:30:29 | FI | safety 0.00 < 0.7 (holder concentration / authorities) |
| 06:32:54 | FI | safety 0.09 < 0.7 (holder concentration / authorities) |
| 06:40:13 | SLOPAGANDA | safety 0.15 < 0.7 (holder concentration / authorities) |
| 06:40:27 | 7777 | safety 0.22 < 0.7 (holder concentration / authorities) |
| 06:40:39 | inu | safety 0.00 < 0.7 (holder concentration / authorities) |
| 06:42:19 | Calypso | safety 0.15 < 0.7 (holder concentration / authorities) |
| 06:47:17 | Leonida | safety 0.00 < 0.7 (holder concentration / authorities) |
| 06:48:12 | LIFE | safety 0.00 < 0.7 (holder concentration / authorities) |
| 06:49:02 | mihao | safety 0.00 < 0.7 (holder concentration / authorities) |
| 06:49:53 | DCI | safety 0.00 < 0.7 (holder concentration / authorities) |
| 06:50:24 | 紫うさぎ | safety 0.00 < 0.7 (holder concentration / authorities) |
| 06:50:59 | DCI | safety 0.15 < 0.7 (holder concentration / authorities) |
| 06:54:39 | mihao | safety 0.26 < 0.7 (holder concentration / authorities) |
| 06:55:09 | Calypso | safety 0.15 < 0.7 (holder concentration / authorities) |
| 06:56:00 | KATIA | safety 0.15 < 0.7 (holder concentration / authorities) |
| 06:58:05 | IFRUIT | safety 0.15 < 0.7 (holder concentration / authorities) |
| 07:00:12 | SpaceChip | safety 0.00 < 0.7 (holder concentration / authorities) |
| 07:01:02 | SpaceChip | safety 0.00 < 0.7 (holder concentration / authorities) |
| 07:02:52 | SpaceChip | safety 0.15 < 0.7 (holder concentration / authorities) |
| 07:04:25 | Calypso | safety 0.15 < 0.7 (holder concentration / authorities) |
| 07:05:14 | DacityCoin | safety 0.15 < 0.7 (holder concentration / authorities) |
| 07:07:18 | PurpleRabb | safety 0.00 < 0.7 (holder concentration / authorities) |
| 07:09:49 | PurpleRabbit | safety 0.00 < 0.7 (holder concentration / authorities) |
| 07:13:24 | KATIA | safety 0.00 < 0.7 (holder concentration / authorities) |
| 07:14:05 | Aliyа | safety 0.00 < 0.7 (holder concentration / authorities) |
| 07:14:36 | GETAJOB | safety 0.15 < 0.7 (holder concentration / authorities) |
| 07:20:59 | ANT | safety 0.15 < 0.7 (holder concentration / authorities) |
| 07:26:12 | Gamooor | safety 0.15 < 0.7 (holder concentration / authorities) |
| 07:27:12 | BAWSAQ | safety 0.15 < 0.7 (holder concentration / authorities) |
| 07:30:03 | GTAVI | safety 0.26 < 0.7 (holder concentration / authorities) |
| 07:35:04 | MrMeow | safety 0.00 < 0.7 (holder concentration / authorities) |
| 07:35:34 | 猫老板 | safety 0.00 < 0.7 (holder concentration / authorities) |
| 07:37:03 | GTA | safety 0.00 < 0.7 (holder concentration / authorities) |
| 07:37:34 | GTA | safety 0.00 < 0.7 (holder concentration / authorities) |
| 07:40:14 | STELLAR | safety 0.15 < 0.7 (holder concentration / authorities) |
| 07:40:54 | pepzilla | safety 0.59 < 0.7 (holder concentration / authorities) |
| 07:44:17 | BANDANADCI | safety 0.00 < 0.7 (holder concentration / authorities) |
| 07:46:13 | WORKER | safety 0.15 < 0.7 (holder concentration / authorities) |
| 07:51:52 | ATEABEE | safety 0.58 < 0.7 (holder concentration / authorities) |
| 07:53:38 | ADCY | safety 0.15 < 0.7 (holder concentration / authorities) |
| 07:54:41 | controller | safety 0.00 < 0.7 (holder concentration / authorities) |
| 07:55:25 | USPR | safety 0.00 < 0.7 (holder concentration / authorities) |
| 08:11:38 | GATO | safety 0.15 < 0.7 (holder concentration / authorities) |
| 08:12:14 | 1 | safety 0.00 < 0.7 (holder concentration / authorities) |
| 08:12:17 | IFRUIT | safety 0.15 < 0.7 (holder concentration / authorities) |
| 08:16:20 | Sharkcards | safety 0.15 < 0.7 (holder concentration / authorities) |
| 08:22:15 | SIEGE | safety 0.15 < 0.7 (holder concentration / authorities) |
| 08:23:16 | CONTROLLER | safety 0.00 < 0.7 (holder concentration / authorities) |
| 08:27:05 | PURR | safety 0.15 < 0.7 (holder concentration / authorities) |
| 08:27:53 | mihao | safety 0.11 < 0.7 (holder concentration / authorities) |
| 08:32:17 | チーズ | safety 0.00 < 0.7 (holder concentration / authorities) |
| 08:37:14 | KATIA | safety 0.15 < 0.7 (holder concentration / authorities) |
| 08:38:58 | Tipped | safety 0.00 < 0.7 (holder concentration / authorities) |
| 08:43:05 | Makenzi | safety 0.15 < 0.7 (holder concentration / authorities) |
| 08:43:15 | TULIP | safety 0.00 < 0.7 (holder concentration / authorities) |
| 08:45:18 | GTAVI | safety 0.26 < 0.7 (holder concentration / authorities) |
| 08:45:30 | CHEEKY | safety 0.00 < 0.7 (holder concentration / authorities) |
| 08:50:25 | KAME | safety 0.42 < 0.7 (holder concentration / authorities) |
| 08:58:40 | LIFE | safety 0.15 < 0.7 (holder concentration / authorities) |
| 09:03:12 | ANTCAP | safety 0.00 < 0.7 (holder concentration / authorities) |
| 09:06:22 | RETIRE | safety 0.00 < 0.7 (holder concentration / authorities) |
| 09:09:38 | controller | safety 0.15 < 0.7 (holder concentration / authorities) |
| 09:10:53 | P1 | safety 0.15 < 0.7 (holder concentration / authorities) |
| 09:11:40 | FAILE | safety 0.00 < 0.7 (holder concentration / authorities) |
| 09:12:15 | mihao | safety 0.15 < 0.7 (holder concentration / authorities) |
| 09:12:51 | CARDED | safety 0.00 < 0.7 (holder concentration / authorities) |
| 09:13:26 | Carded | safety 0.00 < 0.7 (holder concentration / authorities) |
| 09:17:29 | CARDED | safety 0.15 < 0.7 (holder concentration / authorities) |
| 09:19:18 | CHUD | safety 0.15 < 0.7 (holder concentration / authorities) |
| 09:19:20 | GTAVI | safety 0.26 < 0.7 (holder concentration / authorities) |
| 09:22:35 | P1 | safety 0.00 < 0.7 (holder concentration / authorities) |
| 09:25:39 | Nikki | safety 0.15 < 0.7 (holder concentration / authorities) |
| 09:26:19 | Jason | safety 0.00 < 0.7 (holder concentration / authorities) |
| 09:26:31 | GTA6 | safety 0.00 < 0.7 (holder concentration / authorities) |
| 09:33:06 | plobu | safety 0.15 < 0.7 (holder concentration / authorities) |
| 09:34:02 | DCI | safety 0.26 < 0.7 (holder concentration / authorities) |
| 09:34:15 | CLIP | safety 0.00 < 0.7 (holder concentration / authorities) |
| 09:34:40 | ORBIT | safety 0.15 < 0.7 (holder concentration / authorities) |
| 09:35:58 | CLIP | safety 0.00 < 0.7 (holder concentration / authorities) |
| 09:40:43 | TBC | safety 0.15 < 0.7 (holder concentration / authorities) |
| 09:42:32 | controller | safety 0.00 < 0.7 (holder concentration / authorities) |
| 09:50:00 | MOON | safety 0.00 < 0.7 (holder concentration / authorities) |
| 09:51:04 | GTAVI | safety 0.26 < 0.7 (holder concentration / authorities) |
| 09:51:15 | Shockcat | safety 0.00 < 0.7 (holder concentration / authorities) |
| 09:54:28 | Shockcat | safety 0.15 < 0.7 (holder concentration / authorities) |
| 09:56:29 | eepy | safety 0.00 < 0.7 (holder concentration / authorities) |
| 10:15:49 | PRUFROCK | safety 0.00 < 0.7 (holder concentration / authorities) |
| 10:15:51 | 10M | safety 0.00 < 0.7 (holder concentration / authorities) |
| 10:17:14 | MCAT | safety 0.42 < 0.7 (holder concentration / authorities) |
| 10:26:38 | ACI | safety 0.15 < 0.7 (holder concentration / authorities) |
| 10:32:46 | clipping | safety 0.00 < 0.7 (holder concentration / authorities) |
| 10:33:38 | rockstar | safety 0.15 < 0.7 (holder concentration / authorities) |
| 10:35:48 | ASS | safety 0.00 < 0.7 (holder concentration / authorities) |
| 10:36:36 | Whitepill | safety 0.00 < 0.7 (holder concentration / authorities) |
| 10:39:29 | GTAVI | safety 0.26 < 0.7 (holder concentration / authorities) |
| 10:40:35 | OIL | safety 0.15 < 0.7 (holder concentration / authorities) |
| 10:49:03 | THUG | safety 0.15 < 0.7 (holder concentration / authorities) |
| 10:54:16 | Mansion | safety 0.08 < 0.7 (holder concentration / authorities) |
| 10:54:28 | OIL | safety 0.00 < 0.7 (holder concentration / authorities) |
| 10:57:15 | FEET | safety 0.15 < 0.7 (holder concentration / authorities) |
| 10:58:11 | Bunk | safety 0.00 < 0.7 (holder concentration / authorities) |
| 10:58:53 | MARATHON | safety 0.00 < 0.7 (holder concentration / authorities) |
| 11:00:36 | GOONLON | safety 0.15 < 0.7 (holder concentration / authorities) |
| 11:07:28 | DACT | safety 0.26 < 0.7 (holder concentration / authorities) |
| 11:09:32 | DACT | safety 0.00 < 0.7 (holder concentration / authorities) |
| 11:11:35 | DACT | safety 0.09 < 0.7 (holder concentration / authorities) |
| 11:12:55 | DacityCoin | safety 0.26 < 0.7 (holder concentration / authorities) |
| 11:16:22 | MS | safety 0.03 < 0.7 (holder concentration / authorities) |
| 11:17:14 | DacityCoin | safety 0.24 < 0.7 (holder concentration / authorities) |
| 11:23:02 | TOMÁS | safety 0.09 < 0.7 (holder concentration / authorities) |
| 11:34:23 | VEPE | safety 0.00 < 0.7 (holder concentration / authorities) |
| 11:35:48 | Crypto | safety 0.15 < 0.7 (holder concentration / authorities) |
| 11:35:53 | EDDIE | safety 0.00 < 0.7 (holder concentration / authorities) |
| 11:40:50 | DOLORES | safety 0.28 < 0.7 (holder concentration / authorities) |
| 11:48:39 | DACT | safety 0.24 < 0.7 (holder concentration / authorities) |
| 11:49:13 | DICE | safety 0.02 < 0.7 (holder concentration / authorities) |
| 11:49:14 | DaCityCoin | safety 0.15 < 0.7 (holder concentration / authorities) |
| 11:51:16 | Billy | safety 0.15 < 0.7 (holder concentration / authorities) |
| 11:51:46 | CLHQ | safety 0.41 < 0.7 (holder concentration / authorities) |
| 11:52:38 | DACT | safety 0.26 < 0.7 (holder concentration / authorities) |
| 11:52:39 | CLHQ | safety 0.58 < 0.7 (holder concentration / authorities) |
| 11:53:53 | DACT | safety 0.24 < 0.7 (holder concentration / authorities) |
| 12:00:26 | BUCKZ | safety 0.06 < 0.7 (holder concentration / authorities) |
| 12:01:00 | LOCKIN | safety 0.65 < 0.7 (holder concentration / authorities) |
| 12:05:35 | BUCKZ | safety 0.23 < 0.7 (holder concentration / authorities) |
| 12:10:03 | HUGH | safety 0.69 < 0.7 (holder concentration / authorities) |
| 12:10:38 | BUCKZ | safety 0.03 < 0.7 (holder concentration / authorities) |
| 12:11:13 | BUCKZ | safety 0.00 < 0.7 (holder concentration / authorities) |
| 12:30:26 | LOCKIN | safety 0.58 < 0.7 (holder concentration / authorities) |
| 13:04:50 | $GOTH | safety 0.44 < 0.7 (holder concentration / authorities) |
| 13:06:02 | TPRP | safety 0.00 < 0.7 (holder concentration / authorities) |
| 13:06:39 | ちいかわ | safety 0.23 < 0.7 (holder concentration / authorities) |
| 13:07:13 | CRIME | safety 0.00 < 0.7 (holder concentration / authorities) |
| 13:07:15 | VICEPEPE | safety 0.15 < 0.7 (holder concentration / authorities) |
| 13:07:58 | FHC | safety 0.43 < 0.7 (holder concentration / authorities) |
| 13:08:04 | $GOTH | safety 0.58 < 0.7 (holder concentration / authorities) |
| 13:08:40 | DACT | safety 0.68 < 0.7 (holder concentration / authorities) |
| 13:09:11 | SUNBUCKS | safety 0.01 < 0.7 (holder concentration / authorities) |
| 13:10:02 | BOGE | safety 0.04 < 0.7 (holder concentration / authorities) |
| 13:11:11 | $greg | safety 0.51 < 0.7 (holder concentration / authorities) |
| 13:11:16 | n | safety 0.59 < 0.7 (holder concentration / authorities) |

### rug blacklist / copycat pin — 42

| Time | Symbol | Reason |
|---|---|---|
| 04:32:50 | Houser | rug 100/100 — top 10 wallets hold ~96% |
| 04:32:51 | ANT | rug 100/100 — top 10 wallets hold ~98% |
| 04:33:36 | Houser | rug 100/100 — top 10 wallets hold ~82% |
| 04:34:58 | MrBeast | rug 100/100 — top 10 wallets hold ~98% |
| 04:40:22 | clawd | rug 100/100 — top 10 wallets hold ~81% |
| 04:40:27 | MrBeast | rug 100/100 — top 10 wallets hold ~96% |
| 04:48:04 | NZC | rug 100/100 — top 10 wallets hold ~95% |
| 04:48:06 | DCI | rug 100/100 — top 10 wallets hold ~80% |
| 04:49:12 | SPCX | rug 100/100 — top 10 wallets hold ~96% |
| 05:06:17 | Copycat | rug 100/100 — top 10 wallets hold ~100% |
| 05:08:03 | NEKX | rug 100/100 — top 10 wallets hold ~97% |
| 05:08:05 | MAGENTA | rug 100/100 — top 10 wallets hold ~95% |
| 05:09:33 | Calypso | rug 100/100 — top 10 wallets hold ~90% |
| 05:11:48 | DD | rug 100/100 — top 10 wallets hold ~95% |
| 05:20:13 | mihao | rug 100/100 — top 10 wallets hold ~80% |
| 05:23:13 | SPACEXJAK | rug 100/100 — top 10 wallets hold ~94% |
| 05:24:03 | UDTF | rug 100/100 — top 10 wallets hold ~98% |
| 05:24:37 | SpaceChip | rug 100/100 — top 10 wallets hold ~93% |
| 05:24:39 | SPACECHIP | rug 100/100 — top 10 wallets hold ~85% |
| 05:27:48 | GTAVI | rug 100/100 — top 10 wallets hold ~96% |
| 05:30:32 | COW | rug 100/100 — top 10 wallets hold ~93% |
| 05:31:51 | OI | rug 100/100 — top 10 wallets hold ~90% |
| 05:35:27 | Calypso | rug 100/100 — top 10 wallets hold ~99%; -70% dump in one minute |
| 05:40:01 | Calypso | rug 100/100 — top 10 wallets hold ~97% |
| 05:40:02 | SPACE | rug 100/100 — top 10 wallets hold ~95% |
| 05:40:36 | Organicat | rug 100/100 — top 10 wallets hold ~93% |
| 05:43:49 | Clarus | rug 100/100 — top 10 wallets hold ~100% |
| 05:45:00 | Pablо | rug 100/100 — top 10 wallets hold ~95% |
| 07:50:30 | GTA | rug blacklist: GTA is a copycat name - a token called that drained out of a position, 24h left |
| 07:53:38 | GTA | rug blacklist: GTA is a copycat name - a token called that drained out of a position, 24h left |
| 08:11:36 | GTA | rug blacklist: GTA is a copycat name - a token called that drained out of a position, 24h left |
| 08:16:15 | GTA | rug blacklist: GTA is a copycat name - a token called that drained out of a position, 23h left |
| 08:29:07 | GTA | rug blacklist: GTA is a copycat name - a token called that drained out of a position, 23h left |
| 08:32:52 | Musk | rug blacklist: Musk is a copycat name - a token called that drained out of a position, 24h left |
| 08:39:04 | GTA | rug blacklist: GTA is a copycat name - a token called that drained out of a position, 23h left |
| 09:35:35 | Musk | rug blacklist: Musk is a copycat name - a token called that drained out of a position, 23h left |
| 09:57:39 | GTA | rug blacklist: GTA is a copycat name - a token called that drained out of a position, 22h left |
| 10:58:41 | GTA | rug blacklist: GTA is a copycat name - a token called that drained out of a position, 21h left |
| 11:05:46 | GTA | rug blacklist: GTA is a copycat name - a token called that drained out of a position, 21h left |
| 11:44:35 | ANT | rug blacklist: ANT is a copycat name - a token called that drained out of a position, 20h left |
| 12:11:13 | GTA | rug blacklist: GTA is a copycat name - a token called that drained out of a position, 20h left |
| 13:04:37 | GTA | rug blacklist: GTA is a copycat name - a token called that drained out of a position, 19h left |

### not enough data — 32

| Time | Symbol | Reason |
|---|---|---|
| 06:00:57 | Basecat | not enough data: holder table |
| 06:13:01 | FI | not enough data: market cap |
| 07:56:18 | USPR | not enough data: market cap |
| 08:19:04 | UODF | not enough data: market cap |
| 08:33:04 | UODF | not enough data: market cap |
| 08:34:24 | SOL | not enough data: market cap |
| 08:34:26 | DaPussy | not enough data: market cap |
| 08:39:19 | TULIP | not enough data: market cap |
| 08:46:26 | TULIP | not enough data: market cap |
| 09:10:48 | Tradercat | not enough data: market cap |
| 09:13:24 | GTA6 | not enough data: market cap |
| 09:22:23 | Breast | not enough data: market cap |
| 09:24:23 | GTA6 | not enough data: market cap |
| 09:38:20 | BI | not enough data: market cap |
| 09:42:20 | TBC | not enough data: market cap |
| 09:43:40 | SHK | not enough data: market cap |
| 09:44:35 | TBC | not enough data: market cap |
| 09:45:38 | VPN | not enough data: market cap |
| 10:26:37 | ANTTHERM | not enough data: market cap |
| 11:41:35 | DANKCRAB | not enough data: market cap |
| 11:50:28 | DACT | not enough data: market cap |
| 11:58:58 | DacityCoin | not enough data: holder table |
| 11:59:34 | AudaCity | not enough data: market cap |
| 12:01:05 | b | not enough data: holder table |
| 12:04:49 | b | not enough data: holder table |
| 12:05:23 | BUCKZ | not enough data: market cap |
| 12:08:13 | Christmas | not enough data: market cap |
| 12:28:55 | RAC7 | not enough data: holder table |
| 12:29:49 | Bcat | not enough data: market cap |
| 13:02:48 | BLOX | not enough data: market cap |
| 13:05:11 | Goon | not enough data: holder table |
| 13:10:36 | Jason | not enough data: market cap |

### liquidity vs market cap — 13

| Time | Symbol | Reason |
|---|---|---|
| 05:39:16 | JALU | liquidity is <1.5% of market cap |
| 06:41:40 | GODF | liquidity is <1.5% of market cap |
| 06:50:29 | Human | liquidity is <1.5% of market cap |
| 06:58:41 | GTAVI | liquidity is <1.5% of market cap |
| 07:32:31 | Human | liquidity is <1.5% of market cap |
| 08:05:40 | GTAVI | liquidity is <1.5% of market cap |
| 08:15:09 | Carbcrab | liquidity is <1.5% of market cap |
| 08:32:07 | Human | liquidity is <1.5% of market cap |
| 09:14:18 | SHARK | liquidity is <1.5% of market cap |
| 09:49:33 | Balvote | liquidity is <1.5% of market cap |
| 09:53:21 | SHARK | liquidity is <1.5% of market cap |
| 10:55:28 | Solphx | liquidity is <1.5% of market cap |
| 11:23:04 | VGTC | liquidity is <1.5% of market cap |

### too old — 1

| Time | Symbol | Reason |
|---|---|---|
| 04:56:19 | LAPTOP | too old (22m) |

## Entered

| Time | Symbol |
|---|---|
| 04:33:38 | Christmas |
| 04:49:14 | Intel |
| 04:56:57 | 67coin |
| 04:57:03 | Intel |
| 05:06:14 | Cool |
| 05:09:35 | Green |
| 05:20:16 | Intel |
| 05:29:12 | Democat |
| 05:33:37 | Calypso |
| 05:33:38 | Tradercat |
| 05:35:39 | vensa |
| 05:36:13 | Musk |
| 05:36:15 | Tradercat |
| 05:42:00 | GTA |
| 05:43:50 | JAPE |
| 05:45:05 | Intel |
| 05:47:38 | AR |
| 05:52:14 | Tradercat |
| 05:59:12 | FOX |
| 06:01:38 | USPR |
| 06:03:50 | Intel |
| 06:05:00 | AR |
| 06:13:03 | UBSFORT |
| 06:16:10 | FI |
| 06:16:16 | FI |
| 06:25:48 | vensa |
| 06:25:50 | Green |
| 06:26:26 | ANT |
| 06:33:05 | FOX |
| 06:43:34 | OILCAM |
| 06:49:03 | FLOYD |
| 06:49:48 | ANT |
| 06:51:49 | ANT |
| 06:52:25 | Meash |
| 07:00:52 | DCI |
| 07:05:13 | ANSEM |
| 07:09:01 | ANSEM |
| 07:11:17 | Musk |
| 07:11:47 | BEROWL |
| 07:24:33 | 나비 |
| 07:26:17 | Tradercat |
| 07:33:52 | Musk |
| 07:34:02 | Tradercat |
| 07:36:55 | ANT |
| 07:42:05 | TRADER |
| 07:47:50 | Aqaxo |
| 07:50:16 | 💲CASHCAT |
| 07:52:47 | Musk |
| 07:58:08 | FOX |
| 07:59:58 | USPR |
| 08:00:04 | TRADER |
| 08:02:01 | 哈吉咪 |
| 08:04:25 | Democat |
| 08:07:52 | Breast |
| 08:28:02 | Tradercat |
| 08:29:19 | Musk |
| 08:39:53 | UODF |
| 08:41:49 | GTA6 |
| 08:55:16 | FOX |
| 08:58:51 | FOX |
| 09:00:36 | IDRENT |
| 10:23:52 | TESLA |
| 11:48:02 | Raspberry |
