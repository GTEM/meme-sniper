// Rebuild every closed trade from the prices it actually filled at.
//
// The exit reasons quote *net* PnL ("now -2%"), and net PnL includes an exit
// estimate that depends on the liquidity reading. When that reading collapsed,
// a token that was up 35% printed "now -2%" -- and those reason strings were then
// used to re-book trades at a loss they never took. The fills are the truth: the
// SOLD line prints the price the executor used, and the proceeds that came back.
//
// Two kinds of fill are not usable and are left alone:
//   * a fill priced at ~$0 because the depth cap paid nothing (UBSFORT, Tradercat,
//     Musk) -- those were already re-priced at the pool's own quote;
//   * a trade with no SOLD line in this session's log.
//
//   node tools/restore-fills.mjs            # report only
//   node tools/restore-fills.mjs --write    # apply (stop the bot first)

import { copyFileSync, mkdirSync, readFileSync } from 'node:fs';
import { readJson, writeJson } from '../src/lib/store.js';

const write = process.argv.includes('--write');
const book = readJson('portfolio.json', null);
if (!book) {
  console.error('No data/portfolio.json.');
  process.exit(1);
}
const round = (x, d = 2) => Math.round(x * 10 ** d) / 10 ** d;

const SOLD = /^(\d\d):(\d\d):(\d\d)\s+(\S+)\s+SOLD\s+(\d+(?:\.\d+)?)%\s+(.+?)\s+@\s+\$(\S+)\s+→\s+\$(\d+(?:\.\d+)?)\s+\((.+?)\)(?:\s+\[[^\]]*\])?$/;
const dayStart = new Date();
dayStart.setHours(0, 0, 0, 0);
const at = (h, m, s) => dayStart.getTime() + ((+h * 60 + +m) * 60 + +s) * 1000;

const sells = [];
for (const line of readFileSync('bot.log', 'utf8').split('\n')) {
  const m = SOLD.exec(line.trim());
  if (m) sells.push({ t: at(m[1], m[2], m[3]), symbol: m[6].trim(), fraction: +m[5] / 100, price: +m[7], proceeds: +m[8] });
}

const fixes = [];
const skipped = [];
for (const tr of book.trades || []) {
  const legs = sells.filter((s) => s.symbol === tr.symbol && s.t >= tr.openedAt - 60000 && s.t <= tr.closedAt + 60000);
  if (!legs.length) {
    skipped.push({ tr, why: 'no fill line' });
    continue;
  }
  const proceeds = round(legs.reduce((s, l) => s + l.proceeds, 0));
  const sold = legs.reduce((s, l) => s + l.fraction, 0);
  const fillPrice = legs.reduce((s, l) => s + l.price * l.fraction, 0) / sold;
  // A $0 payout on a live price is the depth cap, not the market.
  if (!(fillPrice > 0) || (tr.exitPrice > 0 && fillPrice / tr.exitPrice < 0.5)) {
    skipped.push({ tr, why: 'fill priced at ~$0 by the depth cap' });
    continue;
  }
  const pnlUsd = round(proceeds - tr.investedUsd);
  const pnlPct = +((pnlUsd / tr.investedUsd) || 0).toFixed(4);
  const delta = round(pnlUsd - (tr.pnlUsd || 0));
  if (Math.abs(delta) < 0.02) continue;
  fixes.push({ tr, proceeds, fillPrice, pnlUsd, pnlPct, delta });
}

for (const f of fixes) {
  console.log(
    `${String(f.tr.symbol).slice(0, 11).padEnd(12)} ${((f.tr.pnlPct || 0) * 100).toFixed(1).padStart(6)}% -> ${(f.pnlPct * 100).toFixed(1).padStart(6)}%` +
      `  (${f.delta.toFixed(2).padStart(5)})  fill ${f.fillPrice.toExponential(3)}  ${f.tr.exitReason.slice(0, 42)}`,
  );
}
for (const s of skipped.slice(0, 4)) console.log(`kept ${String(s.tr.symbol).padEnd(11)} ${((s.tr.pnlPct || 0) * 100).toFixed(0).padStart(5)}%  (${s.why})`);

const delta = fixes.reduce((s, f) => s + f.delta, 0);
console.log(`\n${fixes.length} trades rebuilt from their fills, cash ${round(delta)} (${skipped.length} kept as they are)`);

if (!write) {
  console.log('\nDry run. Stop the bot, then re-run with --write.');
  process.exit(0);
}
if (!fixes.length) process.exit(0);

for (const f of fixes) {
  const t = f.tr;
  f.before = { pnlPct: t.pnlPct, pnlUsd: t.pnlUsd, exitPrice: t.exitPrice };
  t.pnlPct = f.pnlPct;
  t.pnlUsd = f.pnlUsd;
  t.returnedUsd = f.proceeds;
  t.grossPnlUsd = round(t.pnlUsd + (t.feesUsd || 0));
  t.exitPrice = f.fillPrice;
  t.repaired = 'rebuilt from the fills: the reason string quotes net PnL, which collapses with the liquidity reading';
}

book.cash = round(book.cash + delta);
book.totals = book.totals || {};
book.totals.realizedUsd = round((book.trades || []).reduce((s, t) => s + (Number(t.pnlUsd) || 0), 0), 2);
book.totals.wins = (book.trades || []).filter((t) => t.pnlUsd >= 0).length;
book.totals.losses = (book.trades || []).filter((t) => t.pnlUsd < 0).length;
for (const p of book.equityCurve || []) {
  let adjust = 0;
  for (const f of fixes) if (p.t >= (f.tr.closedAt || 0)) adjust += f.delta;
  if (adjust) p.e = round(p.e + adjust);
}

const stamp = 'fills-' + new Date().toISOString().slice(11, 19).replace(/:/g, '');
mkdirSync(`data/backup-${stamp}`, { recursive: true });
copyFileSync('data/portfolio.json', `data/backup-${stamp}/portfolio.json`);
writeJson('portfolio.json', book);
writeJson('restored-fills.json', {
  at: Date.now(),
  reason: 'exit reasons quote net PnL, not price; trades were re-booked from the fills they actually got',
  cashDelta: round(delta),
  fixes: fixes.map((f) => ({ symbol: f.tr.symbol, closedAt: f.tr.closedAt, before: f.before, after: { pnlPct: f.pnlPct, pnlUsd: f.pnlUsd, exitPrice: f.fillPrice }, delta: f.delta })),
});
console.log(`Wrote the rebuilt book, backup in data/backup-${stamp}/.`);
