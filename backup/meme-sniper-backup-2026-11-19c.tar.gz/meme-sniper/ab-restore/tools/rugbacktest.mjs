// Backtest the pre-entry rug veto against trades the bot already closed.
//
// Honest scope: a closed trade stores the 15 model features, the score, the
// entry price and the exit reason - but not the raw pool snapshot, token info or
// candles. So only the rug signals that survive in those features can be
// replayed:
//
//   liquidity / market cap     from features.liqToMcap
//   sell pressure 5m and 1h    from features.buyPressure / sellPressure
//   price collapse              from features.drawdown
//   no identity                 (all of these trades had no socials and no
//                                verified profile, so it is a cohort-wide +12)
//
// Holder concentration, authority flags, liquidity decay and wash trading were
// never stored - and the tokens are dead now, so re-fetching tells us nothing
// about entry time. That makes this a LOWER BOUND on what the veto would have
// done, not an exact replay.
//
//   node tools/rugbacktest.mjs
//   node tools/rugbacktest.mjs 30 40 50 60 70

import { readJson } from '../src/lib/store.js';
import { config } from '../src/config.js';
import { analyzeRug } from '../src/rug.js';

const saved = readJson('portfolio.json', { trades: [] });
const trades = [...(saved.trades || [])].reverse(); // oldest first

if (!trades.length) {
  console.error('No closed trades in data/portfolio.json - nothing to backtest.');
  process.exit(1);
}

/** Inverse of the log-scaled feature transform used by extractFeatures. */
const expNorm = (f, lo, hi) => Math.exp(Math.log(Math.max(lo, 1e-9)) + f * (Math.log(hi) - Math.log(Math.max(lo, 1e-9))));

function candidateFromFeatures(f) {
  if (!f || typeof f.liquidity !== 'number') return null;
  const liq = expNorm(f.liquidity, config.minLiqUsd * 0.5, config.maxLiqUsd);
  // features.liqToMcap = clamp01((liqToMcap - 0.03) / 0.45)
  const ratio = f.liqToMcap * 0.45 + 0.03;
  const mcap = liq / Math.max(ratio, 1e-9);
  const sell5 = Math.max(0, Math.min(1, 1 - f.buyPressure));
  const sell1h = Math.max(0, Math.min(1, 1 - f.sellPressure));
  // features.drawdown = clamp01(1 - drawdownFrac / 0.55)
  const drawdownFrac = Math.max(0, Math.min(1, (1 - f.drawdown) * 0.55));
  const n = 100;
  return {
    pool: {
      liqUsd: liq,
      mcapUsd: mcap,
      priceUsd: 1,
      pc: { m5: -(drawdownFrac * 100) },
      txns: {
        m5: { buys: n * (1 - sell5), sells: n * sell5 },
        h1: { buys: n * (1 - sell1h), sells: n * sell1h },
      },
    },
    // Every trade in this book scored social = 0 and had no verified profile.
    info: { socials: {}, gtVerified: false },
    ds: {},
    candles: [],
  };
}

const rows = trades.map((t) => {
  const cand = candidateFromFeatures(t.features);
  const rug = cand ? analyzeRug(cand, config, {}) : null;
  return {
    symbol: t.symbol,
    pnlPct: t.pnlPct,
    pnlUsd: t.pnlUsd,
    exitReason: t.exitReason,
    score: t.score,
    storedRisk: typeof t.rugRisk === 'number' ? t.rugRisk : null,
    risk: rug ? rug.risk : null,
    signals: rug ? rug.signals.map((s) => s.detail) : ['no stored features'],
    pulled: /liquidity pulled/i.test(t.exitReason || ''),
  };
});

const losses = rows.filter((r) => r.pnlPct <= 0);
const wins = rows.filter((r) => r.pnlPct > 0);
const pulled = losses.filter((r) => r.pulled);

console.log(`\nrug veto backtest - ${rows.length} closed trades (${losses.length} losses, ${wins.length} wins)`);
console.log(`losses whose liquidity was pulled: ${pulled.length}/${losses.length}`);
console.log(`proxy coverage: liquidity-vs-mcap, sell pressure, price collapse, identity baseline`);
console.log(`not replayable: holder concentration, authority flags, liquidity decay, wash trading\n`);

const pad = (s, n) => String(s).padEnd(n);
const padl = (s, n) => String(s).padStart(n);
console.log(`${pad('symbol', 10)}${padl('pnl', 8)}${padl('risk', 6)}${padl('stored', 8)}  signals`);
for (const r of [...rows].sort((a, b) => (b.risk ?? -1) - (a.risk ?? -1))) {
  console.log(
    `${pad(r.symbol, 10)}${padl(`${(r.pnlPct * 100).toFixed(0)}%`, 8)}${padl(r.risk === null ? '-' : r.risk, 6)}${padl(r.storedRisk === null ? '-' : r.storedRisk, 8)}  ${r.signals.join(' / ')}`,
  );
}

// The two trades that carry a real score: does the proxy agree?
const checkable = rows.filter((r) => r.storedRisk !== null && r.risk !== null);
if (checkable.length) {
  console.log('\nproxy vs stored risk:');
  for (const r of checkable) console.log(`  ${r.symbol}: stored ${r.storedRisk}, proxy ${r.risk}`);
}

const thresholds = process.argv.slice(2).map(Number).filter((x) => Number.isFinite(x));
const sweep = thresholds.length ? thresholds : [20, 25, 30, 35, 40, 50, 60, 70];

console.log('\nthreshold sweep (a trade is blocked when proxy risk >= threshold)');
console.log(`${padl('risk>=', 7)}${padl('losers blocked', 16)}${padl('winners blocked', 16)}${padl('$ loss avoided', 16)}${padl('$ gain forgone', 16)}`);
for (const t of sweep) {
  const blocked = rows.filter((r) => r.risk !== null && r.risk >= t);
  const bl = blocked.filter((r) => r.pnlPct <= 0);
  const bw = blocked.filter((r) => r.pnlPct > 0);
  const avoided = bl.reduce((s, r) => s + r.pnlUsd, 0);
  const forgone = bw.reduce((s, r) => s + r.pnlUsd, 0);
  console.log(
    `${padl(t, 7)}${padl(`${bl.length}/${losses.length}`, 16)}${padl(`${bw.length}/${wins.length}`, 16)}${padl(`$${avoided.toFixed(2)}`, 16)}${padl(`$${forgone.toFixed(2)}`, 16)}`,
  );
}

const current = config.rug.maxRisk;
const atCurrent = rows.filter((r) => r.risk !== null && r.risk >= current);
console.log(`\nat the configured RUG_MAX_RISK=${current}: ${atCurrent.length} of ${rows.length} trades would have been blocked` +
  (atCurrent.length ? ` (${atCurrent.map((r) => r.symbol).join(', ')})` : ' - the veto could not see these pulls coming from the stored data'));

const avg = (xs) => (xs.length ? xs.reduce((a, b) => a + b, 0) / xs.length : 0);
console.log(`mean proxy risk: losers ${avg(losses.map((r) => r.risk ?? 0)).toFixed(1)}, winners ${avg(wins.map((r) => r.risk ?? 0)).toFixed(1)}`);
console.log('');
