// Check every big exit against the pool's own price history at the minute we sold.
//
// The book's fills are what the bot *thought* the price was. The pool's 1-minute
// candles are what the market actually did, and GeckoTerminal serves them free.
// For each loss, this finds the candle in force at closedAt and compares it with
// the entry price, which settles whether the exit was real:
//
//   UBSFORT was booked -44%, but the pool closed that minute at 6.48e-2 against a
//   4.79e-2 entry: the token was up 35% and the bot sold into a $0 depth print.
//
//   node tools/verify-exits.mjs            # report + data/exit-verification.json
//   node tools/verify-exits.mjs --write    # re-book the ones the candles refute

import { copyFileSync, mkdirSync } from 'node:fs';
import { readJson, writeJson } from '../src/lib/store.js';
import { costBpsFor } from '../src/venues.js';
import { config } from '../src/config.js';

const write = process.argv.includes('--write');
const book = readJson('portfolio.json', null);
if (!book) {
  console.error('No data/portfolio.json.');
  process.exit(1);
}
const round = (x, d = 2) => Math.round(x * 10 ** d) / 10 ** d;
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

const rugs = (book.trades || []).filter(
  (t) => t.poolAddress && t.entryPrice > 0 && (/rug/i.test(t.exitReason || '') || (t.pnlPct ?? 0) <= -0.3),
);

async function candles(pool) {
  for (let attempt = 0; attempt < 2; attempt += 1) {
    const url = `https://api.geckoterminal.com/api/v2/networks/solana/pools/${pool}/ohlcv/minute?aggregate=1&limit=1000`;
    const res = await fetch(url, { headers: { accept: 'application/json' }, signal: AbortSignal.timeout(15000) }).catch(() => null);
    if (res?.status === 429) {
      await sleep(8000);
      continue;
    }
    if (!res?.ok) return { error: `HTTP ${res?.status}` };
    const j = await res.json().catch(() => null);
    return { list: j?.data?.attributes?.ohlcv_list || [] };
  }
  return { error: 'rate limited' };
}

const rows = [];
for (const t of rugs) {
  const { list, error } = await candles(t.poolAddress);
  await sleep(2600); // the free tier is 30 calls a minute
  if (error || !list.length) {
    rows.push({ t, error: error || 'no candles', verdict: 'unverified' });
    continue;
  }
  const exitSec = Math.floor(t.closedAt / 1000);
  const inForce = list.filter((c) => c[0] <= exitSec).sort((a, b) => b[0] - a[0])[0] || null;
  if (!inForce || exitSec - inForce[0] > 900) {
    rows.push({ t, error: 'no candle near the exit', verdict: 'unverified' });
    continue;
  }
  const close = Number(inForce[4]);
  const costBps = Number(t.venueCostBps) || costBpsFor(config, t.venue || 'amm');
  const honestPct = close / t.entryPrice - 1 - costBps / 10000;
  const diff = honestPct - (t.pnlPct ?? 0);
  rows.push({ t, close, at: inForce[0], honestPct, diff, verdict: Math.abs(diff) > 0.05 ? 'refuted' : 'confirmed' });
}

for (const r of rows) {
  const { t } = r;
  const label = String(t.symbol).slice(0, 11).padEnd(12);
  if (r.verdict === 'unverified') {
    console.log(`${label} booked ${((t.pnlPct || 0) * 100).toFixed(0).padStart(5)}%  unverified (${r.error})`);
    continue;
  }
  console.log(
    `${label} booked ${((t.pnlPct || 0) * 100).toFixed(0).padStart(5)}%  candle ${new Date(r.at * 1000).toISOString().slice(11, 16)} close ${r.close.toExponential(2)}` +
      ` => ${(r.honestPct * 100).toFixed(0).padStart(5)}%  ${r.verdict.toUpperCase()}  (${round(r.diff * t.investedUsd)} )`,
  );
}

const refuted = rows.filter((r) => r.verdict === 'refuted');
const confirmed = rows.filter((r) => r.verdict === 'confirmed');
const unverified = rows.filter((r) => r.verdict === 'unverified');
const delta = refuted.reduce((s, r) => s + (r.honestPct * r.t.investedUsd - (r.t.pnlUsd || 0)), 0);
console.log(`\n${rows.length} exits checked: ${confirmed.length} confirmed by the candles, ${refuted.length} refuted, ${unverified.length} unverified`);
console.log(`re-booking the refuted ones changes cash by ${round(delta)}`);

writeJson('exit-verification.json', {
  at: Date.now(),
  rows: rows.map((r) => ({
    symbol: r.t.symbol,
    pool: r.t.poolAddress,
    closedAt: r.t.closedAt,
    bookedPct: r.t.pnlPct,
    candleAt: r.at ? new Date(r.at * 1000).toISOString() : null,
    candleClose: r.close ?? null,
    honestPct: r.honestPct ?? null,
    verdict: r.verdict,
    error: r.error ?? null,
  })),
});

if (!refuted.length) process.exit(0);
if (!write) {
  console.log('\nDry run. Stop the bot, then re-run with --write.');
  process.exit(0);
}

let cashDelta = 0;
for (const r of refuted) {
  const t = r.t;
  const before = { pnlPct: t.pnlPct, pnlUsd: t.pnlUsd };
  const pnlUsd = round(r.honestPct * t.investedUsd);
  cashDelta += pnlUsd - (t.pnlUsd || 0);
  t.pnlPct = +r.honestPct.toFixed(4);
  t.pnlUsd = pnlUsd;
  t.returnedUsd = round(t.investedUsd + pnlUsd);
  t.grossPnlUsd = round(t.pnlUsd + (t.feesUsd || 0));
  t.exitPrice = r.close;
  t.exitKind = r.honestPct >= 0 ? 'profit' : 'stop';
  t.repaired = `re-priced from the pool's candle at ${new Date(r.at * 1000).toISOString().slice(11, 16)} (was ${before.pnlUsd})`;
}

book.cash = round(book.cash + cashDelta);
book.totals = book.totals || {};
book.totals.realizedUsd = round((book.trades || []).reduce((s, t) => s + (Number(t.pnlUsd) || 0), 0), 2);
book.totals.wins = (book.trades || []).filter((t) => t.pnlUsd >= 0).length;
book.totals.losses = (book.trades || []).filter((t) => t.pnlUsd < 0).length;
for (const p of book.equityCurve || []) {
  let adjust = 0;
  for (const r of refuted) if (p.t >= (r.t.closedAt || 0)) adjust += r.honestPct * r.t.investedUsd - (r.t.pnlUsd || 0);
  if (adjust) p.e = round(p.e + adjust);
}

const stamp = 'candles-' + new Date().toISOString().slice(11, 19).replace(/:/g, '');
mkdirSync(`data/backup-${stamp}`, { recursive: true });
copyFileSync('data/portfolio.json', `data/backup-${stamp}/portfolio.json`);
writeJson('portfolio.json', book);
console.log(`\nRe-booked ${refuted.length} exits, cash ${round(cashDelta)}, backup in data/backup-${stamp}/.`);
