// Offline calibration harness: pull real new pools, enrich them exactly like
// the engine does, and print the feature vectors + scores so the model's scale
// and MIN_SCORE can be tuned against actual market data instead of guesses.
//
//   node tools/calibrate.mjs [sampleSize]

import { config } from '../src/config.js';
import * as gt from '../src/feeds/geckoterminal.js';
import { tokenPairs } from '../src/feeds/dexscreener.js';
import { extractFeatures, FEATURE_NAMES } from '../src/ai/features.js';
import { SignalModel } from '../src/ai/model.js';

const N = Number(process.argv[2] || 10);
const RELAXED = process.env.RELAXED === '1';
const NO_CANDLES = process.env.NO_CANDLES === '1';
const model = new SignalModel();

const filters = RELAXED
  ? { ...config, minLiqUsd: 2000, maxLiqUsd: 2000000, minAgeSec: 10, maxAgeSec: 21600, minTxns5M: 3 }
  : config;

process.env.QUIET = '1';

const pools = [];
for (const chain of config.chains) {
  for (const page of [1, 2]) {
    try {
      for (const p of await gt.newPools(chain, page)) pools.push(p);
    } catch (e) {
      console.error(`feed ${chain} p${page}: ${e.message}`);
    }
  }
}

const now = Date.now();
const pre = [];
for (const pool of pools) {
  const ageSec = pool.createdAtMs ? (now - pool.createdAtMs) / 1000 : null;
  if (!pool.baseToken || !pool.priceUsd || ageSec === null) continue;
  if (ageSec < filters.minAgeSec || ageSec > filters.maxAgeSec) continue;
  if (pool.liqUsd < filters.minLiqUsd || pool.liqUsd > filters.maxLiqUsd) continue;
  const t = pool.txns.m5.buys + pool.txns.m5.sells;
  if (t < filters.minTxns5M) continue;
  pre.push({ pool, ageSec });
}
console.log(`${pools.length} pools fetched, ${pre.length} passed the cheap prefilter\n`);

const rows = [];
for (const { pool, ageSec } of pre.slice(0, N)) {
  const [info, ds, candles] = await Promise.all([
    gt.tokenInfo(pool.chain, pool.baseToken),
    tokenPairs(pool.chain, pool.baseToken),
    NO_CANDLES ? [] : gt.candles(pool.chain, pool.poolAddress, { limit: 30 }).catch(() => []),
  ]);
  const f = extractFeatures({ chain: pool.chain, pool, info, ds, candles, ageSec }, filters);
  const s = model.score(f.features);
  rows.push({ pool, ageSec, f, s });
  const pctStr = f.veto ? 'VETO ' + f.veto : `${(s.score * 100).toFixed(0)}%`;
  console.log(
    `${(pool.symbol || '?').padEnd(12).slice(0, 12)} ${pool.chain.padEnd(7)} liq=${String(Math.round(pool.liqUsd)).padStart(7)} ` +
      `age=${String(Math.round(ageSec)).padStart(4)}s m5=${String(Math.round(pool.pc.m5)).padStart(5)}% ` +
      `buy=${(pool.txns.m5.buys / Math.max(1, pool.txns.m5.buys + pool.txns.m5.sells) * 100).toFixed(0).padStart(3)}% ` +
      `mcap=${String(Math.round(f.mcapUsd)).padStart(8)} score=${pctStr}`,
  );
  if (process.env.VERBOSE === '1') {
    console.log('   ', Object.fromEntries(FEATURE_NAMES.map((n) => [n, +f.features[n].toFixed(2)])).valueOf());
    console.log('   top:', s.contributions.slice(0, 4).map((c) => `${c.name}:${c.effect.toFixed(2)}`).join(' '));
  }
}

const scored = rows.filter((r) => !r.f.veto).map((r) => r.s.score).sort((a, b) => a - b);
const q = (p) => (scored.length ? scored[Math.min(scored.length - 1, Math.floor(p * scored.length))] : null);
console.log('\nscore distribution (non-vetoed, n=' + scored.length + ')');
console.log('  min/25/50/75/90/max:', [0, 0.25, 0.5, 0.75, 0.9, 1].map((p) => (q(p) === null ? '—' : (q(p) * 100).toFixed(0))).join(' / '));
console.log('  vetoed:', rows.filter((r) => r.f.veto).length, 'of', rows.length);

const means = {};
for (const n of FEATURE_NAMES) {
  const vals = rows.filter((r) => !r.f.veto).map((r) => r.f.features[n]);
  means[n] = vals.length ? vals.reduce((a, b) => a + b, 0) / vals.length : 0;
}
console.log('\nmean feature values (non-vetoed)');
console.log('  ', Object.entries(means).map(([k, v]) => `${k}=${v.toFixed(2)}`).join('  '));
