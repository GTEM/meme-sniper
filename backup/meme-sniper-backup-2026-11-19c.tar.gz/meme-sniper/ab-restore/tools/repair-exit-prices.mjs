// Make every closed trade's recorded exit price the price it actually exited at.
//
// The `exitPrice` on a closed trade is whatever the feed last said at close. When
// a peak stop fires the token is often still holding the peak price in the record,
// so the table showed "entry 1.71e-5 → exit 2.33e-5" (+36%) on a trade booked at
// -2%. The price is not decoration: it is the evidence for whether the trade made
// money, so it has to agree with the result.
//
// Every exit states the price it fired at in its own reason:
//   "trailing stop at +2% (peak +18%)", "peak stop: ... (peak +34%, now -2%)"
//
// Single-fill trades are rewritten to that price. Multi-leg trades keep the
// record they have: their booked total is the sum of several fills and no single
// price can stand for it.
//
//   node tools/repair-exit-prices.mjs            # report only
//   node tools/repair-exit-prices.mjs --write    # apply (stop the bot first)

import { copyFileSync, mkdirSync, readFileSync } from 'node:fs';
import { readJson, writeJson } from '../src/lib/store.js';

const write = process.argv.includes('--write');
const book = readJson('portfolio.json', null);
if (!book) {
  console.error('No data/portfolio.json to repair.');
  process.exit(1);
}
const round = (x, d = 2) => Math.round(x * 10 ** d) / 10 ** d;

const SOLD = /^(\d\d):(\d\d):(\d\d)\s+(\S+)\s+SOLD\s+(\d+(?:\.\d+)?)%\s+(.+?)\s+@\s+\$(\S+)\s+→\s+\$(\d+(?:\.\d+)?)\s+\((.+?)\)(?:\s+\[[^\]]*\])?$/;
const dayStart = new Date();
dayStart.setHours(0, 0, 0, 0);
const at = (h, m, s) => dayStart.getTime() + ((+h * 60 + +m) * 60 + +s) * 1000;

const stated = (reason = '') => {
  const now = /\bnow\s+(-?\d+(?:\.\d+)?)%/.exec(reason);
  if (now) return Number(now[1]) / 100;
  const p = /\bat\s+\$?\+?(-?\d+(?:\.\d+)?)%/.exec(reason);
  if (p) return Number(p[1]) / 100;
  return null;
};

const legs = [];
for (const line of readFileSync('bot.log', 'utf8').split('\n')) {
  const m = SOLD.exec(line.trim());
  if (m) legs.push({ t: at(m[1], m[2], m[3]), symbol: m[6].trim(), reason: m[9] });
}

const fixes = [];
for (const t of book.trades || []) {
  if (!(t.entryPrice > 0 && t.exitPrice > 0)) continue;
  const mine = legs.filter((l) => l.symbol === t.symbol && l.t >= t.openedAt - 60000 && l.t <= t.closedAt + 60000);
  if (mine.length !== 1) continue; // several fills: no single exit price
  const pctAtExit = stated(mine[0].reason);
  if (pctAtExit == null) continue;
  const exitPrice = t.entryPrice * (1 + pctAtExit);
  const change = exitPrice / t.exitPrice - 1;
  if (Math.abs(change) < 0.03) continue; // already agrees
  fixes.push({ t, exitPrice, pctAtExit, change, leg: mine[0].reason });
}

if (!fixes.length) {
  console.log('Nothing to repair: every single-fill trade already records the price it exited at.');
  process.exit(0);
}

for (const f of fixes) {
  console.log(
    `${String(f.t.symbol).padEnd(11)} exit ${f.t.exitPrice.toExponential(3)} -> ${f.exitPrice.toExponential(3)}` +
      ` (${(f.change * 100).toFixed(0)}%)  booked ${((f.t.pnlPct || 0) * 100).toFixed(1)}%  | ${f.leg}`,
  );
  if (!write) continue;
  f.before = f.t.exitPrice;
  f.t.exitPrice = f.exitPrice;
  f.t.exitPriceRepaired = 'recorded the last price seen at close; rewritten to the price the exit fired at';
}

console.log(`\n${fixes.length} exit prices to correct`);
if (!write) {
  console.log('\nDry run. Stop the bot, then re-run with --write.');
  process.exit(0);
}

const stamp = 'exitpx-' + new Date().toISOString().slice(11, 19).replace(/:/g, '');
mkdirSync(`data/backup-${stamp}`, { recursive: true });
copyFileSync('data/portfolio.json', `data/backup-${stamp}/portfolio.json`);
writeJson('portfolio.json', book);
writeJson('repaired-exit-prices.json', {
  at: Date.now(),
  reason: 'exitPrice held the last price seen at close rather than the price the exit fired at',
  fixes: fixes.map((f) => ({
    symbol: f.t.symbol,
    closedAt: f.t.closedAt,
    leg: f.leg,
    before: f.before,
    after: round(f.exitPrice, 12),
    change: +f.change.toFixed(4),
  })),
});
console.log(`\nWrote ${fixes.length} corrected exit prices, backup in data/backup-${stamp}/.`);
