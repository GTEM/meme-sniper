// Repair peak-stop trades that were filled at a stale price.
//
// Background: engine.sell used pos.lastPrice, the last *confirmed* snapshot. A
// crash steep enough to trip the peak stop is exactly the kind of print the 4x
// feed guard holds pending confirmation, so the sell booked the old high. Six
// trades are affected: each one's own exit reason records the price the rule
// actually saw ("peak +49%, now -2%"), and that is the honest outcome.
//
// This rewrites those trades to that price, carries the difference out of cash
// and the equity curve, writes an audit file and a backup, and leaves the model
// refit to tools/retrain.mjs --write (which reads the corrected pnlPct).
//
//   node tools/repair-peak-fills.mjs            # report only
//   node tools/repair-peak-fills.mjs --write    # apply (stop the bot first)

import { copyFileSync, mkdirSync } from 'node:fs';
import { readJson, writeJson } from '../src/lib/store.js';

const write = process.argv.includes('--write');
const book = readJson('portfolio.json', null);
if (!book) {
  console.error('No data/portfolio.json to repair.');
  process.exit(1);
}

const stamp = new Date().toISOString().slice(11, 19).replace(/:/g, '');
const round = (x, d = 2) => Math.round(x * 10 ** d) / 10 ** d;

const repairs = [];
for (const t of book.trades || []) {
  if (!/peak stop/i.test(t.exitReason || '')) continue;
  const m = String(t.exitReason).match(/now (-?\d+)%/);
  if (!m) continue;
  const honestPct = Number(m[1]) / 100;
  if (!(t.investedUsd > 0)) continue;
  const honestUsd = round(honestPct * t.investedUsd);
  const delta = round(honestUsd - t.pnlUsd);
  if (Math.abs(delta) < 0.005) continue;
  repairs.push({ trade: t, honestPct, honestUsd, delta });
}

if (!repairs.length) {
  console.log('Nothing to repair: no peak-stop trade disagrees with its own exit reason.');
  process.exit(0);
}

let cashDelta = 0;
let realizedDelta = 0;
for (const r of repairs) {
  const t = r.trade;
  r.before = { pnlPct: t.pnlPct, pnlUsd: t.pnlUsd, exitPrice: t.exitPrice, returnedUsd: t.returnedUsd };
  if (write) {
    t.pnlPct = r.honestPct;
    t.pnlUsd = r.honestUsd;
    t.returnedUsd = round(t.investedUsd + r.honestUsd);
    t.exitPrice = t.entryPrice * (1 + r.honestPct);
    t.grossPnlUsd = round(t.pnlUsd + (t.feesUsd || 0));
    // The exit was a stop, not a signal failure: say so for the retrain label.
    t.exitKind = 'stop';
    t.repaired = 'filled at the price the peak stop saw, not the stale snapshot';
    cashDelta += r.delta;
    realizedDelta += r.delta;
  }
  console.log(
    `${String(t.symbol).padEnd(10)} ${(r.before.pnlPct * 100).toFixed(0)}% -> ${(r.honestPct * 100).toFixed(0)}%  (${r.delta.toFixed(2)})`,
  );
}

console.log(`\n${repairs.length} trades, cash ${cashDelta.toFixed(2)}, realised ${realizedDelta.toFixed(2)}`);

if (!write) {
  console.log('\nDry run. Stop the bot, then re-run with --write.');
  process.exit(0);
}

// Keep every repaired trade in the same order (newest first) for the model.
book.cash = round(book.cash + cashDelta);
book.totals = book.totals || {};
book.totals.realizedUsd = round((book.totals.realizedUsd || 0) + realizedDelta);
// A trade that booked +34% and was really -2% is a loss, so the counters move too.
book.totals.wins = (book.trades || []).filter((t) => t.pnlUsd >= 0).length;
book.totals.losses = (book.trades || []).filter((t) => t.pnlUsd < 0).length;
// The paper proceeds were credited on close, so the curve carries the same excess.
for (const p of book.equityCurve || []) {
  let adjust = 0;
  for (const r of repairs) if (p.t >= (r.trade.closedAt || 0)) adjust += r.delta;
  if (adjust) p.e = round(p.e + adjust);
}
if (book.day && typeof book.day.realized === 'number') {
  let adjust = 0;
  const dayStart = new Date(book.day.key + 'T00:00:00Z').getTime();
  for (const r of repairs) if ((r.trade.closedAt || 0) >= dayStart) adjust += r.delta;
  book.day.realized = round(book.day.realized + adjust);
}

mkdirSync('data/backup-' + stamp, { recursive: true });
copyFileSync('data/portfolio.json', `data/backup-${stamp}/portfolio.json`);
try {
  copyFileSync('data/model.json', `data/backup-${stamp}/model.json`);
} catch {
  /* no model yet */
}

writeJson('portfolio.json', book);
writeJson('repaired-peak-fills.json', {
  at: Date.now(),
  reason: 'peak-stop exits filled at pos.lastPrice (stale, held by the 4x feed guard) instead of the price the rule acted on',
  cashDelta: round(cashDelta),
  repairs: repairs.map((r) => ({
    symbol: r.trade.symbol,
    tokenAddress: r.trade.tokenAddress,
    closedAt: r.trade.closedAt,
    exitReason: r.trade.exitReason,
    before: r.before,
    after: { pnlPct: r.honestPct, pnlUsd: r.honestUsd },
    delta: r.delta,
  })),
});
console.log(`\nWrote the corrected book and data/repaired-peak-fills.json. Backup in data/backup-${stamp}/.`);
console.log('Next: node tools/retrain.mjs --write  (bot must stay stopped)');
