// Check every closed trade against its own entry and exit prices.
//
// The booked PnL should equal (exitPrice / entryPrice - 1) minus the venue's
// round-trip cost, for every trade, whatever the exit reason. Anything else is a
// bookkeeping claim the prices do not support.
//
//   node tools/price-audit.mjs

import { readJson } from '../src/lib/store.js';
import { costBpsFor } from '../src/venues.js';
import { config } from '../src/config.js';

const book = readJson('portfolio.json', { trades: [] });
const round = (x, d = 2) => Math.round(x * 10 ** d) / 10 ** d;
const pct = (x) => `${(x * 100).toFixed(1)}%`.padStart(7);
const usd = (x) => `$${x.toFixed(2)}`.padStart(7);

const rows = [];
for (const t of book.trades || []) {
  if (!(t.exitPrice > 0 && t.entryPrice > 0)) continue;
  const ratio = t.exitPrice / t.entryPrice;
  const costBps = Number(t.venueCostBps) || costBpsFor(config, t.venue || 'amm');
  const fairPct = ratio - 1 - costBps / 10000;
  const fairUsd = fairPct * t.investedUsd;
  const delta = (t.pnlUsd ?? 0) - fairUsd;
  // How far the prices are from a believable fill. Outside this, the entry price
  // was probably taken from another pool or another token's decimals.
  const scaled = ratio > 20 || ratio < 0.05;
  let kind = 'agrees';
  if (scaled) kind = 'scale-broken';
  else if (Math.abs(delta) <= Math.max(0.05, t.investedUsd * 0.03)) kind = 'agrees';
  else if ((t.pnlUsd ?? 0) < fairUsd) kind = 'understated'; // booked worse than the prices
  else kind = 'overstated'; // booked better than the prices
  rows.push({ t, ratio, fairPct, fairUsd, delta, costBps, kind });
}

const order = { 'scale-broken': 0, understated: 1, overstated: 2, agrees: 3 };
rows.sort((a, b) => order[a.kind] - order[b.kind] || a.t.closedAt - b.t.closedAt);

let booked = 0;
let fair = 0;
for (const r of rows) {
  booked += r.t.pnlUsd ?? 0;
  fair += r.fairUsd;
  const { t } = r;
  console.log(
    `${String(t.symbol || '?').slice(0, 11).padEnd(11)} ${String(t.exitKind || t.exitReason?.split(':')[0] || '').slice(0, 9).padEnd(9)}` +
      ` in ${t.entryPrice.toExponential(3)} out ${t.exitPrice.toExponential(3)} ${pct(r.ratio - 1)}` +
      ` booked ${pct(t.pnlPct)} ${usd(t.pnlUsd)} | prices say ${pct(r.fairPct)} ${usd(r.fairUsd)}` +
      ` | ${r.kind}${r.kind === 'agrees' ? '' : ` (${usd(r.delta)})`}`,
  );
}

const by = (k) => rows.filter((r) => r.kind === k);
console.log(`\n${rows.length} closed trades`);
console.log(`booked total  ${usd(booked)}`);
console.log(`prices total  ${usd(fair)}   difference ${usd(booked - fair)}`);
for (const k of ['agrees', 'understated', 'overstated', 'scale-broken']) {
  const g = by(k);
  if (!g.length) continue;
  const gap = g.reduce((s, r) => s + r.delta, 0);
  console.log(`  ${k.padEnd(13)} ${String(g.length).padStart(3)} trades  booked-vs-prices ${usd(gap)}`);
}
