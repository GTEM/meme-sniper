// Entry tuning on the trades actually taken.
//
// Three candidate changes, measured on the closed book:
//   1. raise MIN_SCORE          - whose trades survive each threshold
//   2. narrow the liquidity band - entry liquidity is recoverable exactly from
//                                  the stored 'liquidity' feature
//   3. cut position size        - model-based: same price path, smaller notional,
//                                  fills recomputed with the constant-product
//                                  model
//
// The sample is tiny (one book of trades), so every rule is also checked against
// a permutation baseline: if random subsets of the same size do as well, the
// rule is noise. Numbers first, confidence second.
//
//   node tools/entry-tune.mjs

import { readJson } from '../src/lib/store.js';
import { config } from '../src/config.js';
import { depthFillRate, costBpsFor } from '../src/venues.js';

const saved = readJson('portfolio.json', { trades: [] });
const trades = [...(saved.trades || [])].reverse();
if (trades.length < 5) {
  console.error('Not enough closed trades to tune on.');
  process.exit(1);
}

const expNorm = (f, lo, hi) => Math.exp(Math.log(Math.max(lo, 1e-9)) + f * (Math.log(hi) - Math.log(Math.max(lo, 1e-9))));

const rows = trades.map((t) => {
  const f = t.features || {};
  const liq = typeof f.liquidity === 'number' ? expNorm(f.liquidity, config.minLiqUsd * 0.5, config.maxLiqUsd) : null;
  return {
    ...t,
    liqUsd: liq,
    win: t.pnlPct > 0,
    pulled: /liquidity pulled/i.test(t.exitReason || ''),
  };
});

const pad = (s, n) => String(s).padEnd(n);
const padl = (s, n) => String(s).padStart(n);
const money = (x) => `${x < 0 ? '-' : '+'}$${Math.abs(x).toFixed(2)}`;

function stats(subset) {
  const n = subset.length;
  const wins = subset.filter((t) => t.win).length;
  const pnl = subset.reduce((s, t) => s + t.pnlUsd, 0);
  return {
    n,
    wins,
    losses: n - wins,
    winRate: n ? wins / n : 0,
    pnl,
    avg: n ? pnl / n : 0,
    pulled: subset.filter((t) => t.pulled).length,
  };
}

console.log(`\nentry tuning - ${rows.length} closed trades | win rate ${(stats(rows).winRate * 100).toFixed(0)}% | total ${money(stats(rows).pnl)}`);
console.log(`score range ${(Math.min(...rows.map((t) => t.score)) * 100).toFixed(0)}-${(Math.max(...rows.map((t) => t.score)) * 100).toFixed(0)}%, ` +
  `entry liquidity $${Math.round(Math.min(...rows.map((t) => t.liqUsd || Infinity)))}-$${Math.round(Math.max(...rows.map((t) => t.liqUsd || 0)))}\n`);

const header = `${pad('rule', 26)}${padl('n', 4)}${padl('W-L', 7)}${padl('win%', 7)}${padl('pulled', 8)}${padl('total', 10)}${padl('avg/trade', 11)}`;

// --- 1. MIN_SCORE -----------------------------------------------------------
console.log(header);
console.log(pad('all trades (baseline)', 26) + padl(stats(rows).n, 4) + padl(`${stats(rows).wins}-${stats(rows).losses}`, 7) +
  padl(`${(stats(rows).winRate * 100).toFixed(0)}%`, 7) + padl(stats(rows).pulled, 8) + padl(money(stats(rows).pnl), 10) + padl(money(stats(rows).avg), 11));
for (let pct = 50; pct <= 85; pct += 5) {
  const s = stats(rows.filter((t) => t.score >= pct / 100));
  if (!s.n) continue;
  console.log(pad(`MIN_SCORE >= ${pct}%`, 26) + padl(s.n, 4) + padl(`${s.wins}-${s.losses}`, 7) +
    padl(`${(s.winRate * 100).toFixed(0)}%`, 7) + padl(s.pulled, 8) + padl(money(s.pnl), 10) + padl(money(s.avg), 11));
}

// --- 2. liquidity band ------------------------------------------------------
console.log(`\n${header}`);
for (const floor of [6000, 8000, 10000, 15000, 20000, 30000, 40000]) {
  const s = stats(rows.filter((t) => t.liqUsd !== null && t.liqUsd >= floor));
  if (!s.n) continue;
  console.log(pad(`liq >= $${floor / 1000}k`, 26) + padl(s.n, 4) + padl(`${s.wins}-${s.losses}`, 7) +
    padl(`${(s.winRate * 100).toFixed(0)}%`, 7) + padl(s.pulled, 8) + padl(money(s.pnl), 10) + padl(money(s.avg), 11));
}
for (const cap of [15000, 25000, 40000, 60000]) {
  const s = stats(rows.filter((t) => t.liqUsd !== null && t.liqUsd <= cap));
  if (!s.n) continue;
  console.log(pad(`liq <= $${cap / 1000}k`, 26) + padl(s.n, 4) + padl(`${s.wins}-${s.losses}`, 7) +
    padl(`${(s.winRate * 100).toFixed(0)}%`, 7) + padl(s.pulled, 8) + padl(money(s.pnl), 10) + padl(money(s.avg), 11));
}

// --- 3. position size (model-based) ----------------------------------------
// Size cannot change which trades happen, only how much each costs. Re-price
// each trade at a smaller notional with the same quoted prices and the depth
// model: entry slippage shrinks on deep pools, but a drained pool still returns
// nothing at any size.
console.log('\nposition size (same trades, re-priced with the constant-product fill model)');
console.log(`${pad('size % of bankroll', 26)}${padl('avg entry slip', 16)}${padl('total PnL', 12)}${padl('win%', 8)}`);
for (const pct of [1, 2.5, 5, 10]) {
  const size = (config.bankroll * pct) / 100;
  let total = 0;
  let slipSum = 0;
  for (const t of rows) {
    const liq0 = t.liqUsd || 0;
    if (!(liq0 > 0) || !(t.entryPrice > 0)) {
      total += (t.pnlPct * size);
      continue;
    }
    const keep0 = depthFillRate(t.investedUsd, liq0);
    const raw = keep0 > 0 ? t.entryPrice * keep0 : t.entryPrice; // undo the recorded slippage
    const keep = depthFillRate(size, liq0);
    const qty = (size * (1 - costBpsFor(config, t.venue || 'amm') / 20000)) / (raw / Math.max(keep, 1e-9));
    // Exit at the recorded quoted price, with whatever depth was left. A pulled
    // pool has none, which is why size cannot rescue those trades.
    const exitLiq = t.pulled ? 0 : liq0;
    const gross = qty * t.exitPrice;
    const proceeds = exitLiq > 0 ? gross * depthFillRate(gross, exitLiq) * (1 - costBpsFor(config, t.venue || 'amm') / 20000) : 0;
    total += proceeds - size;
    slipSum += 1 - keep;
  }
  console.log(pad(`${pct}%`, 26) + padl(`${((slipSum / rows.length) * 100).toFixed(2)}%`, 16) + padl(money(total), 12) + padl('same', 8));
}

// --- 4. is any of this real? -----------------------------------------------
// The best-looking rule is only interesting if random subsets of the same size
// do worse. Enumerate exactly when possible, otherwise sample.
function randomSubsetPValue(rule, trials = 20000) {
  const kept = rows.filter(rule);
  if (!kept.length || kept.length === rows.length) return { p: 1, kept };
  const keptPnl = kept.reduce((s, t) => s + t.pnlUsd, 0);
  const k = kept.length;
  let better = 0;
  for (let i = 0; i < trials; i++) {
    const pool = [...rows];
    let sum = 0;
    for (let j = 0; j < k; j++) {
      const idx = Math.floor(Math.random() * pool.length);
      sum += pool.splice(idx, 1)[0].pnlUsd;
    }
    if (sum >= keptPnl) better += 1;
  }
  return { p: better / trials, kept };
}

const candidates = [];
for (let pct = 55; pct <= 85; pct += 5) candidates.push({ label: `MIN_SCORE >= ${pct}%`, rule: (t) => t.score >= pct / 100 });
for (const floor of [8000, 10000, 15000, 20000, 30000]) candidates.push({ label: `liq >= $${floor / 1000}k`, rule: (t) => t.liqUsd !== null && t.liqUsd >= floor });
for (const cap of [15000, 25000, 40000]) candidates.push({ label: `liq <= $${cap / 1000}k`, rule: (t) => t.liqUsd !== null && t.liqUsd <= cap });
for (let pct = 65; pct <= 80; pct += 5) {
  for (const floor of [10000, 15000, 20000]) {
    candidates.push({ label: `score>=${pct}% & liq>=$ ${floor / 1000}k`.replace('$ ', ''), rule: (t) => t.score >= pct / 100 && t.liqUsd !== null && t.liqUsd >= floor });
  }
}

const scored = candidates
  .map((c) => ({ ...c, ...stats(rows.filter(c.rule)), ...randomSubsetPValue(c.rule) }))
  .filter((c) => c.n >= 3)
  .sort((a, b) => b.pnl - a.pnl);

console.log('\nbest rules by total PnL (with permutation p-value: chance of doing this well with random trades of the same count)');
console.log(`${pad('rule', 34)}${padl('n', 4)}${padl('W-L', 7)}${padl('total', 10)}${padl('p', 7)}`);
for (const c of scored.slice(0, 8)) {
  console.log(pad(c.label, 34) + padl(c.n, 4) + padl(`${c.wins}-${c.losses}`, 7) + padl(money(c.pnl), 10) + padl(c.p.toFixed(2), 7));
}

const best = scored[0];
console.log(`\nbest rule: ${best.label} | n=${best.n} | win rate ${(best.winRate * 100).toFixed(0)}% | ${money(best.pnl)} vs ${money(stats(rows).pnl)} baseline | p=${best.p.toFixed(2)}`);
console.log(`with ${rows.length} trades, a p-value above 0.10 means the rule is indistinguishable from luck.\n`);
