// What would the fast post-entry rug watch have saved on the trades already
// closed?
//
// Limits of the data, stated up front: a closed trade stores entry/exit price,
// invested USD, peak PnL and the exit reason - but not the tick-by-tick pool
// depth, and the pools are dead now (GeckoTerminal rate limits this host and
// keeps no candles for delisted pools). So the exact tick on which the watch
// would have fired cannot be replayed. This tool brackets it with three
// scenarios instead of pretending to one number:
//
//   same-tick  the pull completes between two 25s polls; the watch sees the pool
//              already empty and realises the same ~$0 as the 65% rule
//   gradual    the watch fires as soon as depth is 65% of entry (the 35%
//              threshold), at the price the trade actually exited on - i.e. it
//              gets the better depth but no better price
//   price-held the same 65% depth, and the quoted price had not moved yet
//              (a proportional liquidity removal does not move an AMM price)
//   peak       the ceiling: exit at the position's recorded peak
//
//   node tools/rugwatch-backtest.mjs

import { readJson } from '../src/lib/store.js';
import { config } from '../src/config.js';
import { depthFillRate, costBpsFor } from '../src/venues.js';

const saved = readJson('portfolio.json', { trades: [] });
const trades = [...(saved.trades || [])].reverse();
if (!trades.length) {
  console.error('No closed trades in data/portfolio.json - nothing to backtest.');
  process.exit(1);
}

const expNorm = (f, lo, hi) => Math.exp(Math.log(Math.max(lo, 1e-9)) + f * (Math.log(hi) - Math.log(Math.max(lo, 1e-9))));

const pulled = trades.filter((t) => /liquidity pulled/i.test(t.exitReason || ''));
const rows = pulled.map((t) => {
  const f = t.features || {};
  const liq0 = typeof f.liquidity === 'number' ? expNorm(f.liquidity, config.minLiqUsd * 0.5, config.maxLiqUsd) : 0;
  const qty = t.entryPrice > 0 ? t.investedUsd / t.entryPrice : 0;
  const costBps = costBpsFor(config, t.venue || 'amm');
  const proceeds = (px, liq) => {
    if (!(px > 0) || !(liq > 0)) return 0;
    const gross = qty * px;
    return gross * depthFillRate(gross, liq) * (1 - costBps / 2 / 10000);
  };
  const watchDepth = liq0 * (1 - config.rugWatch.liqDropFromEntryPct / 100);
  return {
    symbol: t.symbol,
    actual: t.pnlUsd,
    gradual: proceeds(t.exitPrice, watchDepth) - t.investedUsd,
    priceHeld: proceeds(t.entryPrice, watchDepth) - t.investedUsd,
    peak: (t.peakPnlPct || 0) * t.investedUsd,
    liq0,
    priceRatio: t.entryPrice > 0 ? t.exitPrice / t.entryPrice : 0,
  };
});

const pad = (s, n) => String(s).padEnd(n);
const padl = (s, n) => String(s).padStart(n);
const money = (x) => `${x < 0 ? '-' : '+'}$${Math.abs(x).toFixed(2)}`;

console.log(`\nfast rug watch backtest - ${pulled.length} of ${trades.length} closed trades ended in a liquidity pull`);
console.log(`watch: exit on first tick with depth -${config.rugWatch.liqDropFromEntryPct}% from entry, ` +
  `-${config.rugWatch.tickLiqDropPct}% in one tick, -${config.rugWatch.tickPxDropPct}% price in one tick\n`);

console.log(`${pad('symbol', 10)}${padl('actual', 9)}${padl('gradual', 10)}${padl('price-held', 12)}${padl('peak', 9)}${padl('px ratio', 10)}`);
for (const r of rows) {
  console.log(
    `${pad(r.symbol, 10)}${padl(money(r.actual), 9)}${padl(money(r.gradual), 10)}${padl(money(r.priceHeld), 12)}${padl(money(r.peak), 9)}${padl(r.priceRatio.toFixed(3), 10)}`,
  );
}

const total = (k) => rows.reduce((s, r) => s + r[k], 0);
console.log(
  `\n${pad('total', 10)}${padl(money(total('actual')), 9)}${padl(money(total('gradual')), 10)}${padl(money(total('priceHeld')), 12)}${padl(money(total('peak')), 9)}`,
);

console.log('\nreading it:');
console.log('  same-tick  = the actual column. A pull that lands in one transaction between polls gives the');
console.log('               watch nothing to see - it exits into the same empty pool.');
console.log('  gradual    is the realistic upside when the drain is spread over several ticks: same exit');
console.log('               price, much better depth. Price-collapsed trades (px ratio << 1) gain almost');
console.log('               nothing; trades whose depth died while the price held gain most of the loss back.');
console.log('  price-held is the optimistic end and peak is the ceiling, not a forecast.');
console.log('\nthe watch also exits some winners early; that cost is not measurable without tick history.\n');
