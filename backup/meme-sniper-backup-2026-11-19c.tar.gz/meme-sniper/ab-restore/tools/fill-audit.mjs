// Did each closed trade actually make money, judged by the price it left at?
//
// Three numbers disagree for the same trade, so this states all of them:
//   entryPrice  what we bought at
//   fill        the price the executor used (SOLD line in bot.log)
//   at exit     the price the exit rule saw, which every reason states itself:
//               "trailing stop at +64% (peak +104%)", "peak stop: -27% from the
//               peak (peak +34%, now -2%)", "take profit 1 at +23%"
//
// The "at exit" figure is the honest one. Two bugs are visible only here:
// peak-stop fills were taken at the peak price while the token was already back
// at -2%, and depth-clamp fills paid out about 1e-9 on a price that had not
// fallen. Both are repaired in the book now; this tool keeps them visible.
//
//   node tools/fill-audit.mjs

import { readFileSync } from 'node:fs';
import { readJson } from '../src/lib/store.js';
import { costBpsFor } from '../src/venues.js';
import { config } from '../src/config.js';

const book = readJson('portfolio.json', { trades: [] });
const log = readFileSync('bot.log', 'utf8').split('\n');
const round = (x, d = 2) => Math.round(x * 10 ** d) / 10 ** d;
const pct = (x) => `${(x * 100).toFixed(1)}%`.padStart(8);
const usd = (x) => `$${x.toFixed(2)}`.padStart(7);

// The reason can be followed by "[fees escalated to land the exit]".
const SOLD = /^(\d\d):(\d\d):(\d\d)\s+(\S+)\s+SOLD\s+(\d+(?:\.\d+)?)%\s+(.+?)\s+@\s+\$(\S+)\s+→\s+\$(\d+(?:\.\d+)?)\s+\((.+?)\)(?:\s+\[[^\]]*\])?$/;

const dayStart = new Date();
dayStart.setHours(0, 0, 0, 0);
const at = (h, m, s) => dayStart.getTime() + ((+h * 60 + +m) * 60 + +s) * 1000;

/** The price the exit rule saw, as a fraction of entry (0.05 = +5%). */
export function statedExitPct(reason = '') {
  const now = /\bnow\s+(-?\d+(?:\.\d+)?)%/.exec(reason);
  if (now) return Number(now[1]) / 100;
  const atPct = /\bat\s+\$?\+?(-?\d+(?:\.\d+)?)%/.exec(reason);
  if (atPct) return Number(atPct[1]) / 100;
  return null;
}

const sells = [];
for (const line of log) {
  const m = SOLD.exec(line.trim());
  if (!m) continue;
  sells.push({
    t: at(m[1], m[2], m[3]),
    time: `${m[1]}:${m[2]}:${m[3]}`,
    loss: m[4] === '🩸',
    fraction: +m[5] / 100,
    symbol: m[6].trim(),
    price: Number(m[7]),
    proceeds: +m[8],
    reason: m[9],
    escalated: /fees escalated/.test(line),
  });
}

const rows = [];
for (const tr of book.trades || []) {
  const legs = sells
    .filter((s) => s.symbol === tr.symbol && s.t >= tr.openedAt - 60000 && s.t <= tr.closedAt + 60000)
    .sort((a, b) => a.t - b.t);
  const proceeds = legs.reduce((s, x) => s + x.proceeds, 0);
  const costBps = Number(tr.venueCostBps) || costBpsFor(config, tr.venue || 'amm');
  const lastPct = statedExitPct(legs.at(-1)?.reason || tr.exitReason || '');
  // The price the exit rule saw, as a return on the whole position.
  const exitPct = lastPct ?? (tr.exitPrice > 0 ? tr.exitPrice / tr.entryPrice - 1 : null);
  // A ratio outside this band is not a return, it is a broken entry price (ANT's
  // exit is 140,000x its entry), so it cannot enter the totals either way.
  const usable = exitPct != null && exitPct > -0.99 && exitPct < 20;
  const honestPct = usable ? exitPct - costBps / 10000 : null;
  const honestUsd = honestPct == null ? null : honestPct * tr.investedUsd;
  rows.push({ tr, legs, proceeds, costBps, exitPct, honestPct, honestUsd, single: legs.length === 1 });
}

console.log('trade        entry        fill         at exit    booked     honest     diff   note');
for (const r of rows) {
  const { tr } = r;
  const fill = r.legs.length ? r.legs.reduce((s, x) => s + x.price * x.fraction, 0) : tr.exitPrice;
  const note = !r.legs.length
    ? 'no fill line'
    : r.legs.length > 1
      ? `${r.legs.length} legs, booked = sum of fills`
      : Math.abs((r.honestUsd ?? 0) - (tr.pnlUsd ?? 0)) > Math.max(0.05, tr.investedUsd * 0.04)
        ? 'BOOKED DIFFERS FROM THE PRICE AT EXIT'
        : '';
  console.log(
    `${String(tr.symbol).slice(0, 10).padEnd(12)} ${tr.entryPrice.toExponential(3)} ${fill.toExponential(3)}` +
      ` ${pct(r.exitPct ?? NaN)} ${pct(tr.pnlPct)} ${usd(r.honestUsd ?? NaN)} ${usd((tr.pnlUsd ?? 0) - (r.honestUsd ?? tr.pnlUsd ?? 0))}   ${note}`,
  );
}

const single = rows.filter((r) => r.single && r.honestUsd != null);
const drift = single.filter((r) => Math.abs(r.honestUsd - r.tr.pnlUsd) > Math.max(0.05, r.tr.investedUsd * 0.04));
const booked = rows.reduce((s, r) => s + (r.tr.pnlUsd || 0), 0);
const honest = rows.reduce((s, r) => s + (r.honestUsd ?? r.tr.pnlUsd ?? 0), 0);
const unresolved = rows.filter((r) => r.honestUsd == null).length;

console.log(`\n${rows.length} closed trades (${single.length} exited in one fill)`);
console.log(`booked ${usd(booked)}   at exit prices ${usd(honest)}   drift ${usd(booked - honest)}   (${unresolved} unpriceable, counted at book)`);
console.log(`${drift.length} single-fill trades where the book disagrees with the price at exit`);
for (const r of drift) {
  console.log(
    `  ${String(r.tr.symbol).padEnd(11)} booked ${pct(r.tr.pnlPct)} but the price at exit was ${pct(r.exitPct)} (${r.tr.exitReason})`,
  );
}

const byReason = {};
for (const r of rows) {
  const kind = /peak stop/.test(r.tr.exitReason || '') ? 'peak stop'
    : /trailing/.test(r.tr.exitReason || '') ? 'trailing'
      : /time stop/.test(r.tr.exitReason || '') ? 'time stop'
        : /rug/.test(r.tr.exitReason || '') ? 'rug watch'
          : /take profit|profit/.test(r.tr.exitReason || '') ? 'take profit'
            : 'other';
  byReason[kind] = byReason[kind] || { n: 0, usd: 0 };
  byReason[kind].n += 1;
  byReason[kind].usd += r.tr.pnlUsd || 0;
}
console.log('\nby exit type (booked):');
for (const [k, v] of Object.entries(byReason).sort((a, b) => a[1].usd - b[1].usd)) {
  console.log(`  ${k.padEnd(12)} ${String(v.n).padStart(2)} trades ${usd(v.usd)}`);
}
