/**
 * Undo a closed trade that never actually sold.
 *
 * A trade closed with $0 returned was not a sale: the exit fired into a pool
 * that had no tradeable depth (LP staked or frozen, or the pool already empty).
 * Booking that as -100% claims a loss the market never charged, so the position
 * goes back on the book at its entry price and waits for a pool it can price.
 *
 * Only touches trades that received nothing. Anything that returned money was a
 * real sale and is left alone.
 *
 *   node tools/reopen-unsold.mjs <tradeId>
 */
import { copyFileSync, mkdirSync } from 'node:fs';
import { Portfolio } from '../src/portfolio.js';
import { config } from '../src/config.js';
import { costBpsFor } from '../src/venues.js';

const id = process.argv[2];
if (!id) {
  console.error('usage: node tools/reopen-unsold.mjs <tradeId>');
  process.exit(1);
}

const book = Portfolio.load(config);
const trade = book.trades.find((t) => t.id === id);
if (!trade) {
  console.error(`no closed trade ${id}`);
  process.exit(1);
}
if (Number(trade.returnedUsd) > 0) {
  console.error(`${trade.symbol} ${id} returned $${trade.returnedUsd} — that was a real sale, leaving it alone`);
  process.exit(1);
}

const stamp = new Date().toISOString().slice(11, 19).replace(/:/g, '');
const backup = `data/backup-reopen-${stamp}`;
mkdirSync(backup, { recursive: true });
copyFileSync('data/portfolio.json', `${backup}/portfolio.json`);

const qty = trade.investedUsd / trade.entryPrice;
book.trades = book.trades.filter((t) => t.id !== id);
book.positions.push({
  id: trade.id,
  chain: trade.chain,
  venue: trade.venue,
  venueCostBps: costBpsFor(config, trade.venue),
  poolAddress: trade.poolAddress,
  tokenAddress: trade.tokenAddress,
  symbol: trade.symbol,
  name: trade.name,
  imageUrl: null,
  dex: null,
  mode: trade.mode || 'paper',
  entryAt: trade.openedAt,
  entryPrice: trade.entryPrice,
  qty,
  investedUsd: trade.investedUsd,
  realizedUsd: 0,
  peakPx: trade.entryPrice,
  peakPnlPct: 0,
  lastPrice: trade.entryPrice,
  lastLiqUsd: 0,
  entryLiqUsd: 0,
  entryMcapUsd: null,
  ageAtEntrySec: null,
  score: trade.score,
  rugRisk: trade.rugRisk ?? null,
  rugSignals: null,
  features: trade.features,
  reasons: trade.reasons,
  ladder: { tp1: false, tp2: false },
  trailArmed: false,
  pnlHistory: [],
  walletTx: null,
  fills: [{ side: 'buy', at: trade.openedAt, price: trade.entryPrice, qty, feeUsd: 0 }],
  feesUsd: 0,
  migrationHoldAt: Date.now(),
  unpriced: 'the exit booked $0 into a pool with no tradeable depth; position restored at cost, waiting for a tradeable pool',
});
book.recount();
book.save();

console.log(`reopened ${trade.symbol} ${id} at $${trade.entryPrice} — ${qty.toFixed(0)} tokens, $${trade.investedUsd} at cost`);
console.log(`backup: ${backup}/portfolio.json`);
console.log(
  `book: ${book.trades.length} closed, realised $${book.totals.realizedUsd} (${book.totals.wins}W/${book.totals.losses}L), ${book.positions.length} open, equity $${book.equity().toFixed(2)}`,
);
