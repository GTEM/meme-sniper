// Re-book trailing exits that were filled at the price the token peaked at,
// instead of the price the stop actually triggered at.
//
// The reason string carries both numbers: "trailing stop at +2% (peak +18%)".
// Booked +18% on that trade means the executor was handed the last price seen
// before the fall — the peak — rather than the +2% the rule fired on. That is
// the same stale-fill fault fixed in engine.sell() with exitFillPrice(); these
// trades predate the fix and their profits are inflated.
//
// Only single-fill trades are touched: with several legs the booked total is the
// sum of what was actually received per leg.
//
//   node tools/repair-stale-trails.mjs            # report only
//   node tools/repair-stale-trails.mjs --write    # apply (stop the bot first)

import { copyFileSync, mkdirSync, readFileSync } from 'node:fs';
import { readJson, writeJson } from '../src/lib/store.js';
import { costBpsFor } from '../src/venues.js';
import { config } from '../src/config.js';

const write = process.argv.includes('--write');
const book = readJson('portfolio.json', null);
if (!book) {
  console.error('No data/portfolio.json to repair.');
  process.exit(1);
}
const round = (x, d = 2) => Math.round(x * 10 ** d) / 10 ** d;
// The reason can be followed by "[fees escalated to land the exit]": the old
// pattern dropped every escalated exit, which is most trailing stops, so the
// first pass of this repair missed 21 of them.
const SOLD = /^(\d\d):(\d\d):(\d\d)\s+(\S+)\s+SOLD\s+(\d+(?:\.\d+)?)%\s+(.+?)\s+@\s+\$(\S+)\s+→\s+\$(\d+(?:\.\d+)?)\s+\((.+?)\)(?:\s+\[[^\]]*\])?$/;
const dayStart = new Date();
dayStart.setHours(0, 0, 0, 0);
const at = (h, m, s) => dayStart.getTime() + ((+h * 60 + +m) * 60 + +s) * 1000;

// Every exit prints the price it fired at: "at +2%", or "now -2%" for peak stops.
const stated = (reason = '') => {
  const now = /\bnow\s+(-?\d+(?:\.\d+)?)%/.exec(reason);
  if (now) return Number(now[1]) / 100;
  const p = /\bat\s+\$?\+?(-?\d+(?:\.\d+)?)%/.exec(reason);
  if (p) return Number(p[1]) / 100;
  return null;
};

const legs = [];
for (const line of readFileSync('bot.log', 'utf8').split('\n')) {
  const m = SOLD.exec(line.trim());
  if (m) legs.push({ t: at(m[1], m[2], m[3]), symbol: m[6].trim(), reason: m[9] });
}

const repairs = [];
for (const t of book.trades || []) {
  const mine = legs.filter((l) => l.symbol === t.symbol && l.t >= t.openedAt - 60000 && l.t <= t.closedAt + 60000);
  if (mine.length !== 1) continue;
  const exitPct = stated(mine[0].reason);
  if (exitPct == null) continue;
  const costBps = Number(t.venueCostBps) || costBpsFor(config, t.venue || 'amm');
  const honestPct = exitPct - costBps / 10000;
  const over = (t.pnlPct ?? 0) - honestPct;
  if (over <= 0.04) continue; // book is at or below the trigger price: nothing to claw back
  const honestUsd = round(honestPct * t.investedUsd);
  repairs.push({ t, exitPct, honestPct, honestUsd, delta: round(honestUsd - t.pnlUsd), reason: mine[0].reason });
}

if (!repairs.length) {
  console.log('Nothing to repair: no single-fill exit is booked above the price it triggered at.');
  process.exit(0);
}

let delta = 0;
for (const r of repairs) {
  console.log(
    `${String(r.t.symbol).padEnd(11)} booked ${((r.t.pnlPct || 0) * 100).toFixed(1)}% -> ${(r.honestPct * 100).toFixed(1)}%` +
      `  (${r.delta.toFixed(2)})  | ${r.reason}`,
  );
  delta += r.delta;
  if (!write) continue;
  r.before = { pnlPct: r.t.pnlPct, pnlUsd: r.t.pnlUsd, returnedUsd: r.t.returnedUsd };
  r.t.pnlPct = +r.honestPct.toFixed(4);
  r.t.pnlUsd = r.honestUsd;
  r.t.returnedUsd = round(r.t.investedUsd + r.honestUsd);
  r.t.grossPnlUsd = round(r.t.pnlUsd + (r.t.feesUsd || 0));
  r.t.repaired = 'filled at the peak price; re-booked at the price the stop fired at';
}
console.log(`\n${repairs.length} trades, cash ${delta.toFixed(2)}`);
if (!write) {
  console.log('\nDry run. Stop the bot, then re-run with --write.');
  process.exit(0);
}

book.cash = round(book.cash + delta);
book.totals = book.totals || {};
book.totals.realizedUsd = round((book.totals.realizedUsd || 0) + delta);
book.totals.wins = (book.trades || []).filter((t) => t.pnlUsd >= 0).length;
book.totals.losses = (book.trades || []).filter((t) => t.pnlUsd < 0).length;
for (const p of book.equityCurve || []) {
  let adjust = 0;
  for (const r of repairs) if (p.t >= (r.t.closedAt || 0)) adjust += r.delta;
  if (adjust) p.e = round(p.e + adjust);
}

const stamp = 'stale-' + new Date().toISOString().slice(11, 19).replace(/:/g, '');
mkdirSync(`data/backup-${stamp}`, { recursive: true });
copyFileSync('data/portfolio.json', `data/backup-${stamp}/portfolio.json`);
writeJson('portfolio.json', book);
writeJson('repaired-stale-trails.json', {
  at: Date.now(),
  reason: 'trailing exits filled at the peak price rather than the price the stop fired at',
  cashDelta: round(delta),
  repairs: repairs.map((r) => ({ symbol: r.t.symbol, closedAt: r.t.closedAt, leg: r.reason, before: r.before, after: { pnlPct: +r.honestPct.toFixed(4), pnlUsd: r.honestUsd }, delta: r.delta })),
});
console.log(`\nWrote the corrected book, backup in data/backup-${stamp}/.`);
