// Repair exits booked as -100% because the liquidity reading collapsed while the
// price did not.
//
// How it happened: the rug watch's depth rule fired on a liquidity print alone,
// and the paper executor caps proceeds at half the *reported* depth. A pair that
// momentarily reports "$0 liquidity" therefore paid out nothing on a position
// whose quote was +5%. Four trades are affected; each one's own exitPrice is the
// quoted price at close and never fell, which is the proof that the drain was a
// feed artifact rather than a rug.
//
// Re-price at that quoted price, minus the venue's round-trip cost, and drop the
// blacklist pins those exits created (they were not earned).
//
//   node tools/repair-depth-fills.mjs            # report only
//   node tools/repair-depth-fills.mjs --write    # apply (stop the bot first)

import { copyFileSync, mkdirSync } from 'node:fs';
import { readJson, writeJson } from '../src/lib/store.js';
import { costBpsFor } from '../src/venues.js';
import { config } from '../src/config.js';

const write = process.argv.includes('--write');
const book = readJson('portfolio.json', null);
if (!book) {
  console.error('No data/portfolio.json to repair.');
  process.exit(1);
}
const stamp = new Date().toISOString().slice(11, 19).replace(/:/g, '');
const round = (x, d = 2) => Math.round(x * 10 ** d) / 10 ** d;

// A quote ratio outside this band is not believable either way (a 14,000,000x
// price says the entry price was for a different pool, not that we made 14m%).
// Only where the quote essentially held (>= 0.9). A token whose price really
// halved may have been drained for real, and its thin-pool payout was honest.
const SANE = [0.9, 3];

const repairs = [];
const skipped = [];
for (const t of book.trades || []) {
  if (!(t.pnlPct <= -0.9)) continue;
  if (!(t.exitPrice > 0 && t.entryPrice > 0 && t.investedUsd > 0)) continue;
  const ratio = t.exitPrice / t.entryPrice;
  if (ratio < SANE[0] || ratio > SANE[1]) {
    skipped.push({ symbol: t.symbol, ratio });
    continue;
  }
  const costBps = Number(t.venueCostBps) || costBpsFor(config, t.venue || 'amm');
  const netPct = ratio - 1 - costBps / 10000;
  const netUsd = round(netPct * t.investedUsd);
  repairs.push({ trade: t, ratio, netPct, netUsd, delta: round(netUsd - t.pnlUsd) });
}

if (!repairs.length) {
  console.log('Nothing to repair: no total loss has a quoted price that held up.');
  process.exit(0);
}

let cashDelta = 0;
for (const r of repairs) {
  const t = r.trade;
  r.before = { pnlPct: t.pnlPct, pnlUsd: t.pnlUsd, returnedUsd: t.returnedUsd };
  console.log(
    `${String(t.symbol).padEnd(11)} quote ${((r.ratio - 1) * 100).toFixed(0)}%  booked ${(t.pnlPct * 100).toFixed(0)}% -> ${(r.netPct * 100).toFixed(1)}%  (${r.delta.toFixed(2)})`,
  );
  cashDelta += r.delta;
  if (!write) continue;
  t.pnlPct = +r.netPct.toFixed(4);
  t.pnlUsd = r.netUsd;
  t.returnedUsd = round(t.investedUsd + r.netUsd);
  t.grossPnlUsd = round(t.pnlUsd + (t.feesUsd || 0));
  t.exitKind = 'stop';
  t.repaired = 'proceeds were capped at a bogus near-zero depth reading; re-priced at the quoted exit price less round-trip cost';
}
for (const s of skipped) console.log(`${String(s.symbol).padEnd(11)} skipped: quoted ratio ${s.ratio.toExponential(2)} is not believable, outcome unknown`);

console.log(`\n${repairs.length} trades, cash ${cashDelta.toFixed(2)}`);

if (!write) {
  console.log('\nDry run. Stop the bot, then re-run with --write.');
  process.exit(0);
}

book.cash = round(book.cash + cashDelta);
book.totals = book.totals || {};
book.totals.realizedUsd = round((book.totals.realizedUsd || 0) + cashDelta);
book.totals.wins = (book.trades || []).filter((t) => t.pnlUsd >= 0).length;
book.totals.losses = (book.trades || []).filter((t) => t.pnlUsd < 0).length;
for (const p of book.equityCurve || []) {
  let adjust = 0;
  for (const r of repairs) if (p.t >= (r.trade.closedAt || 0)) adjust += r.delta;
  if (adjust) p.e = round(p.e + adjust);
}

// Those exits also pinned their mint and name. The pins were not earned, so drop
// them: a $0 depth print is not a rug.
const blacklist = readJson('rug-blacklist.json', null);
let unpinned = 0;
if (blacklist) {
  for (const r of repairs) {
    const t = r.trade;
    if (/pool depth/i.test(t.exitReason || '')) {
      if (blacklist.entries?.[t.tokenAddress]) {
        delete blacklist.entries[t.tokenAddress];
        unpinned += 1;
      }
      const key = String(t.symbol || '').toUpperCase();
      if (blacklist.symbols?.[key] && /pool depth/i.test(blacklist.symbols[key].reason || '')) {
        delete blacklist.symbols[key];
        unpinned += 1;
      }
    }
  }
  if (unpinned) writeJson('rug-blacklist.json', blacklist);
}

mkdirSync('data/backup-' + stamp, { recursive: true });
copyFileSync('data/portfolio.json', `data/backup-${stamp}/portfolio.json`);
writeJson('portfolio.json', book);
writeJson('repaired-depth-fills.json', {
  at: Date.now(),
  reason: 'exit proceeds capped at a bogus near-zero depth reading while the quoted price held',
  cashDelta: round(cashDelta),
  unpinned,
  repairs: repairs.map((r) => ({
    symbol: r.trade.symbol,
    tokenAddress: r.trade.tokenAddress,
    closedAt: r.trade.closedAt,
    exitReason: r.trade.exitReason,
    quoteRatio: +r.ratio.toFixed(4),
    before: r.before,
    after: { pnlPct: +r.netPct.toFixed(4), pnlUsd: r.netUsd },
    delta: r.delta,
  })),
});
console.log(`\nWrote the corrected book, dropped ${unpinned} unearned pins, backup in data/backup-${stamp}/.`);
