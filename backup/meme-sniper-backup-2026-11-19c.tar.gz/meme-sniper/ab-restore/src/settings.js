// Editable runtime settings, surfaced in the dashboard so RPC keys and tuning
// can be changed without editing files on a phone.
//
// Values live in data/settings.json (gitignored) and are applied on top of the
// env/defaults at startup and immediately when saved from the UI. Secrets are
// masked on the way out and are never echoed back to the browser.

import { readJson, writeJson } from './lib/store.js';

export const FIELDS = [
  {
    key: 'solanaRpcUrl',
    label: 'Solana RPC URL',
    help: 'Free Helius tier: https://mainnet.helius-rpc.com/?api-key=YOUR_KEY',
    type: 'text',
    secret: true,
    env: 'SOLANA_RPC_URL',
    path: ['ownership', 'rpcUrl'],
  },
  {
    key: 'solscanApiKey',
    label: 'Solscan API key (optional)',
    help: 'From pro-api.solscan.io. One request returns the holder table instead of two RPC calls that throttle. Note: a free Level 1 key is accepted but cannot call any /v2.0 Pro endpoint, holders included, so the bot keeps using the on-chain walk. Use “Test Solscan key” to check.',
    type: 'text',
    secret: true,
    env: 'SOLSCAN_API_KEY',
    path: ['solscan', 'apiKey'],
  },
  {
    key: 'pumpfunApiKey',
    label: 'pump.fun API key (optional)',
    help: 'From developers.pump.fun, after approval. Key looks like pf_live_… and is server-side only. Enables the /mint-positions holder table, which replaces the throttled RPC holder walk. Blank = on-chain walk.',
    type: 'text',
    secret: true,
    env: 'PUMPFUN_API_KEY',
    path: ['pumpfun', 'apiKey'],
  },
  {
    key: 'paperWalletAddress',
    label: 'Test (paper) wallet address',
    help: 'Watch-only label for the simulated book — Solana base58 or EVM 0x. Paper mode never uses a key.',
    type: 'text',
    address: 'any',
    env: 'PAPER_WALLET_ADDRESS',
    path: ['wallet', 'paperAddress'],
  },
  {
    key: 'paperWalletNetwork',
    label: 'Test wallet network',
    help: 'devnet reads the same address on Solana devnet (faucet SOL). Prices still come from mainnet, so a devnet balance is sized at the real SOL price.',
    type: 'select',
    options: ['mainnet', 'devnet'],
    env: 'PAPER_WALLET_NETWORK',
    path: ['wallet', 'network'],
  },
  {
    key: 'liveWalletAddress',
    label: 'Live wallet address (EVM)',
    help: 'Safety check: live mode refuses to start unless WALLET_PRIVATE_KEY belongs to this address.',
    type: 'text',
    address: 'evm',
    env: 'LIVE_WALLET_ADDRESS',
    path: ['wallet', 'liveAddress'],
  },
  { key: 'ownershipEnabled', label: 'Ownership lookup', type: 'bool', env: 'OWNERSHIP', path: ['ownership', 'enabled'] },
  { key: 'ownershipDeep', label: 'Bundle clusters (deep, 2 extra RPC calls per holder)', type: 'bool', env: 'OWNERSHIP_DEEP', path: ['ownership', 'deep'] },
  { key: 'minScore', label: 'Minimum score to enter', type: 'number', min: 0, max: 1, step: 0.01, env: 'MIN_SCORE', path: ['minScore'] },
  { key: 'minLiqUsd', label: 'Min pool liquidity (USD)', type: 'number', min: 0, step: 500, env: 'MIN_LIQ_USD', path: ['minLiqUsd'] },
  { key: 'maxLiqUsd', label: 'Max pool liquidity (USD)', type: 'number', min: 0, step: 10000, env: 'MAX_LIQ_USD', path: ['maxLiqUsd'] },
  { key: 'positionSizePct', label: 'Position size (% of equity)', type: 'number', min: 0.5, max: 50, step: 0.5, env: 'POSITION_SIZE_PCT', path: ['positionSizePct'] },
  { key: 'maxPositions', label: 'Max open positions', type: 'number', min: 1, max: 20, step: 1, env: 'MAX_POSITIONS', path: ['maxPositions'] },
  { key: 'minTradeUsd', label: 'Minimum trade size (USD)', type: 'number', min: 0.5, max: 1000, step: 0.5, env: 'MIN_TRADE_USD', path: ['minTradeUsd'] },
  { key: 'minTakeUsd', label: 'Minimum take-profit (USD)', type: 'number', min: 0, max: 1000, step: 0.5, env: 'MIN_TAKE_USD', path: ['minTakeUsd'] },
  { key: 'scanIntervalMs', label: 'Scan interval (ms)', type: 'number', min: 5000, max: 600000, step: 1000, env: 'SCAN_INTERVAL_MS', path: ['scanIntervalMs'] },
  {
    key: 'exitFeeEscalation',
    label: 'Exit fee escalation',
    type: 'select',
    options: ['profit,rug', 'profit', 'rug', 'off'],
    env: 'EXIT_FEE_ESCALATION',
    path: ['exitEscalation', 'policy'],
  },
  { key: 'rugMaxRisk', label: 'Rug veto at risk', type: 'number', min: 10, max: 100, step: 5, env: 'RUG_MAX_RISK', path: ['rug', 'maxRisk'] },
  { key: 'rugWatchTickLiqPct', label: 'Watch: depth drop per tick (%)', type: 'number', min: 5, max: 100, step: 1, env: 'RUG_WATCH_TICK_LIQ_DROP_PCT', path: ['rugWatch', 'tickLiqDropPct'] },
  { key: 'rugWatchFromEntryPct', label: 'Watch: liquidity drop from entry (%)', type: 'number', min: 5, max: 100, step: 1, env: 'RUG_WATCH_LIQ_DROP_FROM_ENTRY_PCT', path: ['rugWatch', 'liqDropFromEntryPct'] },
  { key: 'rugWatchTickPxPct', label: 'Watch: price drop per tick (%)', type: 'number', min: 5, max: 100, step: 1, env: 'RUG_WATCH_TICK_PX_DROP_PCT', path: ['rugWatch', 'tickPxDropPct'] },
];

const byKey = new Map(FIELDS.map((f) => [f.key, f]));

const getPath = (obj, path) => path.reduce((o, k) => (o == null ? undefined : o[k]), obj);
const setPath = (obj, path, value) => {
  let o = obj;
  for (const k of path.slice(0, -1)) o = o[k] = o[k] || {};
  o[path[path.length - 1]] = value;
};

/** Show enough of a secret to recognise it, never enough to use it. */
export function maskSecret(value) {
  const s = String(value || '');
  if (!s) return '';
  if (s.length <= 12) return '••••';
  return `${s.slice(0, Math.min(26, s.length - 6))}…${s.slice(-6)}`;
}

export function loadSettings() {
  const saved = readJson('settings.json', {});
  return saved && typeof saved === 'object' && !Array.isArray(saved) ? saved : {};
}

function coerce(field, raw) {
  if (field.type === 'bool') return [Boolean(raw), null];
  if (field.type === 'select') {
    const v = String(raw);
    if (!field.options.includes(v)) return [undefined, `must be one of ${field.options.join(', ')}`];
    return [v, null];
  }
  if (field.type === 'number') {
    const n = Number(raw);
    if (!Number.isFinite(n)) return [undefined, 'not a number'];
    if (field.min !== undefined && n < field.min) return [field.min, null];
    if (field.max !== undefined && n > field.max) return [field.max, null];
    return [n, null];
  }
  const v = String(raw ?? '').trim();
  if (!v) return ['', null];
  if (field.key === 'solanaRpcUrl' && !/^https?:\/\//i.test(v)) return [undefined, 'must start with http:// or https://'];
  if (field.address) {
    const evm = /^0x[0-9a-fA-F]{40}$/.test(v);
    const solana = /^[1-9A-HJ-NP-Za-km-z]{32,44}$/.test(v);
    if (field.address === 'evm' && !evm) return [undefined, 'must be a 0x… 40-hex EVM address'];
    if (field.address === 'any' && !evm && !solana) return [undefined, 'must be a base58 Solana or 0x… EVM address'];
  }
  return [v, null];
}

/**
 * Validate + persist a patch of {key: value} and apply it to the live config.
 * @returns {{ok:boolean, applied:string[], rejected:{key:string,reason:string}[]}}
 */
export function saveSettings(patch = {}, cfg, { persist = true } = {}) {
  const applied = [];
  const rejected = [];
  const saved = loadSettings();

  for (const [key, raw] of Object.entries(patch)) {
    const field = byKey.get(key);
    if (!field) {
      rejected.push({ key, reason: 'unknown setting' });
      continue;
    }
    const [value, err] = coerce(field, raw);
    if (err) {
      rejected.push({ key, reason: err });
      continue;
    }
    const current = getPath(cfg, field.path);
    if (value === current) continue;
    setPath(cfg, field.path, value);
    saved[key] = value;
    applied.push(key);
  }

  // Merge into what is already on disk: a save must never drop fields the user
  // set in an earlier session (that is how an RPC key gets wiped by a typo fix).
  if (applied.length && persist) writeJson('settings.json', { ...loadSettings(), ...saved });
  return { ok: rejected.length === 0, applied, rejected };
}

/** Apply saved overrides on top of env/defaults. */
export function applySettings(cfg, saved = loadSettings()) {
  for (const field of FIELDS) {
    if (!(field.key in saved)) continue;
    const [value] = coerce(field, saved[field.key]);
    if (value !== undefined) setPath(cfg, field.path, value);
  }
  return cfg;
}

/** What the dashboard shows: values + metadata, secrets masked. */
export function settingsView(cfg) {
  return {
    fields: FIELDS.map((f) => {
      const raw = getPath(cfg, f.path);
      return {
        key: f.key,
        label: f.label,
        help: f.help || '',
        type: f.type,
        options: f.options || null,
        min: f.min ?? null,
        max: f.max ?? null,
        step: f.step ?? null,
        env: f.env,
        masked: Boolean(f.secret),
        value: f.secret ? maskSecret(raw) : raw,
        configured: f.secret ? Boolean(raw) && !/PASTE_KEY_HERE/.test(String(raw)) : undefined,
      };
    }),
  };
}
