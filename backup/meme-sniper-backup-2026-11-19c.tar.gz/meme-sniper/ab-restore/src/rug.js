// Rug analysis.
//
// The bot's job is to buy launches that survive long enough to sell. Most of
// them do not: a token can look alive (price, volume, buy pressure) and still be
// a rug that is already in progress. This module scores the failure modes that
// are visible *before* entry and turns the worst of them into hard vetoes.
//
// It is deliberately pure: it reads the candidate the engine already fetched
// (pool snapshot, GeckoTerminal token info, DexScreener second opinion, candles,
// plus the engine's own liquidity observations) and returns a risk score with
// the exact reasons. No extra HTTP requests, so a scan cannot get more expensive
// or more rate-limited because of it.
//
// Hard vetoes (risk is forced to 100):
//   honeypot / unrevoked mint or freeze authority
//   top-10 wallets above RUG_MAX_TOP10_PCT
//   liquidity under 1% of market cap
//   liquidity already down RUG_MAX_LIQ_DECAY_PCT since first seen
//   a single minute that dumped 60%+
//   total risk at or above RUG_MAX_RISK

export const WATCH_DEFAULTS = {
  enabled: true,
  // Liquidity gone since entry (percent of the entry pool).
  liqDropFromEntryPct: 35,
  // Liquidity gone between two ticks - the drain happening right now.
  tickLiqDropPct: 18,
  // Price collapse between two ticks: a dump signature, not a drawdown.
  tickPxDropPct: 25,
  // Pool depth (both sides) below this multiple of our position: the exit is
  // about to become expensive even if the price still looks fine.
  minDepthMultiple: 3,
};

export const QUALITY_DEFAULTS = {
  // Five-minute volume above a third of pool liquidity: the pool is being
  // churned, so a buy is somebody else's exit. Every rug in the closed book sat
  // at or above this line.
  maxVolumeToLiquidity5m: 1 / 3,
  // Safety is 1 - top10/90 plus bonuses for revoked authorities and a verified
  // profile, so 0.7 means roughly "top 10 hold under a third of supply".
  minSafety: 0.7,
  // Reject a launch whose inputs are missing rather than letting a neutral
  // default carry it through the score.
  requireData: true,
};

/**
 * Entry quality gate: the reasons to skip a launch that the rug score and the
 * model score both happily accept.
 *
 * Pure, so the scan can explain the veto and the selftest can pin it down.
 *
 * @param {{features?: object, volToLiq5m?: number}} cand
 * @param {object} cfg bot config (uses cfg.entryQuality)
 * @returns {string|null} veto reason, or null to let the candidate through
 */
export function entryQualityVeto(cand = {}, cfg = {}) {
  const q = { ...QUALITY_DEFAULTS, ...(cfg?.entryQuality || {}) };
  // Missing inputs first: without them the other checks are guessing.
  const missing = Array.isArray(cand.missing) ? cand.missing.filter(Boolean) : [];
  if (q.requireData !== false && missing.length) {
    return `not enough data: ${missing.join(', ')}`;
  }
  const ratio = Number(cand.volToLiq5m);
  const maxRatio = Number(q.maxVolumeToLiquidity5m);
  if (Number.isFinite(ratio) && ratio > 0 && Number.isFinite(maxRatio) && maxRatio > 0 && ratio > maxRatio) {
    return `churn: 5m volume is ${Math.round(ratio * 100)}% of pool liquidity (max ${Math.round(maxRatio * 100)}%)`;
  }
  const safety = Number(cand.features?.safety);
  const minSafety = Number(q.minSafety);
  if (Number.isFinite(safety) && Number.isFinite(minSafety) && minSafety > 0 && safety < minSafety) {
    return `safety ${safety.toFixed(2)} < ${minSafety} (holder concentration / authorities)`;
  }
  return null;
}

export const RUG_DEFAULTS = {
  enabled: true,
  maxRisk: 70,
  maxTop10Pct: 70,
  maxLiqDecayPct: 40,
  // Above this risk the entry bar rises instead of blocking outright: a risky
  // coin has to be a much better opportunity to be worth taking.
  bonusFromRisk: 40,
  scoreBonus: 0.1,
};

const clamp = (x, lo, hi) => Math.max(lo, Math.min(hi, x));
const num = (v, d = 0) => {
  const x = Number(v);
  return Number.isFinite(x) ? x : d;
};

function settings(cfg) {
  return { ...RUG_DEFAULTS, ...(cfg?.rug || {}) };
}

function levelOf(risk, maxRisk) {
  if (risk >= maxRisk) return 'critical';
  if (risk >= 45) return 'high';
  if (risk >= 25) return 'medium';
  return 'low';
}

/**
 * @param {object} cand {pool, info, ds, candles, ageSec}
 * @param {object} cfg bot config (uses cfg.rug)
 * @param {{history?: {firstLiqUsd:number, samples:number, firstSeenAt:number}}} ctx
 * @returns {{enabled:boolean, risk:number, level:string, veto:string|null, signals:object[], summary:string}}
 */
export function analyzeRug(cand = {}, cfg = {}, ctx = {}) {
  const rc = settings(cfg);
  const pool = cand.pool || {};
  const info = cand.info || {};
  const ds = cand.ds || {};
  const candles = Array.isArray(cand.candles) ? cand.candles : [];

  const signals = [];
  const vetoes = [];
  const add = (id, weight, detail) => {
    if (weight > 0) signals.push({ id, weight: Math.round(weight), detail });
  };
  const hard = (id, detail) => {
    vetoes.push(detail);
    signals.push({ id, weight: 100, detail, hard: true });
  };

  if (!rc.enabled) {
    return { enabled: false, risk: 0, level: 'low', veto: null, signals: [], summary: 'rug analysis off' };
  }

  const liq = num(pool.liqUsd || ds.liqUsd);
  const mcap = num(pool.mcapUsd || pool.fdvUsd || ds.mcapUsd || ds.fdvUsd);
  const liqToMcap = mcap > 0 ? liq / mcap : 0;
  const price = num(pool.priceUsd);
  const m5 = pool.txns?.m5 || {};
  const h1 = pool.txns?.h1 || {};
  const buys5 = num(m5.buys);
  const sells5 = num(m5.sells);
  const txns5 = buys5 + sells5;
  const sellShare5 = txns5 > 0 ? sells5 / txns5 : null;
  const buys1 = num(h1.buys);
  const sells1 = num(h1.sells);
  const unique5 = num(m5.uniqueTraders ?? m5.buyers);

  // --- 1. contract safety --------------------------------------------------
  if (info.honeypot === 'yes' || info.honeypot === true) hard('honeypot', 'honeypot flagged');
  if (info.mintAuthority === 'yes') hard('mint-authority', 'mint authority not revoked');
  if (info.freezeAuthority === 'yes') hard('freeze-authority', 'freeze authority not revoked');

  // --- 2. who holds the supply ---------------------------------------------
  // Prefer the on-chain holder table when the RPC answered: GeckoTerminal's
  // distribution is missing on most fresh launches, which is exactly when a
  // concentration read matters.
  const own = cand.ownership && cand.ownership.ok ? cand.ownership : null;
  const top10 = own && own.top10Pct !== null && own.top10Pct !== undefined
    ? num(own.top10Pct)
    : info.holderConcentration === null || info.holderConcentration === undefined
      ? null
      : num(info.holderConcentration);
  if (top10 !== null) {
    if (top10 > rc.maxTop10Pct) hard('holder-concentration', `top 10 wallets hold ~${top10.toFixed(0)}%`);
    else if (top10 > 45) {
      add('holder-concentration', ((top10 - 45) / Math.max(1, rc.maxTop10Pct - 45)) * 30, `top 10 wallets hold ~${top10.toFixed(0)}%`);
    }
  }
  const holders = own?.holders || (info.holders === null || info.holders === undefined ? null : num(info.holders));
  if (holders !== null && holders > 0 && holders < 25) add('thin-holder-base', 10, `only ${holders} holders`);

  // Bundle wallets: several top holders funded by the same wallet are one seller.
  if (own?.clusters && own.clusters.checked >= 2 && own.clusters.clusterPct >= 70 && own.clusters.wallets >= 3) {
    hard('bundle-cluster', `${own.clusters.wallets} top holders share one funder and hold ${own.clusters.clusterPct}%`);
  } else if (own?.clusters && own.clusters.checked >= 2 && own.clusters.clusterPct >= 40) {
    add('bundle-cluster', 25, `${own.clusters.wallets} top holders share one funder (${own.clusters.clusterPct}%)`);
  }
  if (own?.devPct !== null && own?.devPct !== undefined && own.devPct >= 15) {
    add('dev-holding', 25, `dev still holds ${own.devPct}%`);
  } else if (own?.devPct !== null && own?.devPct !== undefined && own.devPct >= 5) {
    add('dev-holding', 12, `dev holds ${own.devPct}%`);
  }

  // --- 3. liquidity structure ----------------------------------------------
  // A pool whose liquidity is a sliver of its market cap has a price that only
  // exists on paper: the exit will not be there.
  if (mcap > 0 && liq > 0) {
    if (liqToMcap < 0.01) hard('liq-vs-mcap', `liquidity is ${(liqToMcap * 100).toFixed(1)}% of market cap`);
    else if (liqToMcap < 0.04) add('liq-vs-mcap', (1 - liqToMcap / 0.04) * 20, `liquidity is ${(liqToMcap * 100).toFixed(1)}% of market cap`);
  }

  // Already shrinking before we bought: the pull has started.
  const hist = ctx.history;
  if (hist && num(hist.firstLiqUsd) > 0 && liq > 0) {
    const decay = 1 - liq / num(hist.firstLiqUsd);
    const limit = rc.maxLiqDecayPct / 100;
    if (decay >= limit) hard('liquidity-decay', `liquidity already down ${(decay * 100).toFixed(0)}% since first seen`);
    else if (decay > 0.15) add('liquidity-decay', ((decay - 0.15) / Math.max(0.01, limit - 0.15)) * 25, `liquidity down ${(decay * 100).toFixed(0)}% since first seen`);
  }

  // Two feeds disagreeing by >3x usually means one pool is a fake mirror.
  const dsLiq = num(ds.liqUsd);
  if (dsLiq > 0 && liq > 0) {
    const ratio = Math.max(liq, dsLiq) / Math.min(liq, dsLiq);
    if (ratio > 3) add('fake-pool', 12, `feeds disagree on liquidity ${ratio.toFixed(1)}x`);
  }

  // --- 4. distribution pressure --------------------------------------------
  // A young coin can print green price and still be distributing: sellers
  // dominating the tape is the dev or a bundle exiting into the buyers.
  if (sellShare5 !== null && sellShare5 > 0.5) {
    add('sell-pressure', Math.min(20, (sellShare5 - 0.5) * 100), `${(sellShare5 * 100).toFixed(0)}% of 5m trades are sells`);
  }
  if (buys1 > 0 && sells1 > buys1 * 2) add('sell-pressure-1h', 12, `${sells1} sells vs ${buys1} buys in 1h`);

  // --- 5. price action ------------------------------------------------------
  if (candles.length >= 3) {
    const peak = Math.max(...candles.map((c) => num(c.h)));
    const dd = peak > 0 && price > 0 ? 1 - price / peak : 0;
    if (dd > 0.5) add('drawdown', 20, `${(dd * 100).toFixed(0)}% off the high`);
    else if (dd > 0.35) add('drawdown', 10, `${(dd * 100).toFixed(0)}% off the high`);

    // Worst single-minute move, open-to-close and high-to-close. One candle
    // dumping 60% is not volatility, it is the exit.
    let worst = 0;
    let worstAt = 0;
    for (const c of candles) {
      const o = num(c.o);
      const h = num(c.h);
      const cl = num(c.c);
      if (!(o > 0) || !(h > 0)) continue;
      const drop = Math.min((cl - o) / o, (cl - h) / h);
      if (drop < worst) {
        worst = drop;
        worstAt = num(c.t);
      }
    }
    if (worst <= -0.6) hard('single-candle-dump', `${(worst * 100).toFixed(0)}% dump in one minute`);
    else if (worst <= -0.35) add('single-candle-dump', 18, `${(worst * 100).toFixed(0)}% dump in one minute at ${new Date(worstAt || Date.now()).toISOString().slice(11, 16)}`);
  }

  // Candles only exist for one candidate per scan, so the pool's own price
  // windows are the fallback evidence. A young pool already down 40%+ in a
  // five-minute window is usually the dev or a bundle selling into buyers, not
  // a dip: nothing has had time to dip yet.
  if (candles.length < 3) {
    const m5pc = num(pool.pc?.m5);
    const m15pc = num(pool.pc?.m15);
    const worstPc = Math.min(m5pc, m15pc || m5pc);
    if (worstPc <= -55) add('dump-5m', 30, `${worstPc.toFixed(0)}% in 5-15m`);
    else if (worstPc <= -35) add('dump-5m', 20, `${worstPc.toFixed(0)}% in 5-15m`);
    else if (worstPc <= -25) add('dump-5m', 10, `${worstPc.toFixed(0)}% in 5-15m`);
  }

  // --- 6. wash trading / thin tape -----------------------------------------
  if (unique5 > 0 && txns5 / unique5 > 10) {
    add('wash-trading', Math.min(18, (txns5 / unique5 - 10) * 1.5), `${(txns5 / unique5).toFixed(0)} trades per wallet in 5m`);
  }
  if (unique5 > 0 && unique5 < 10 && txns5 > 25) add('thin-tape', 10, `only ${unique5} wallets traded in 5m`);

  // --- 7. blow-off top ------------------------------------------------------
  const m5pc = num(pool.pc?.m5);
  if (m5pc > 300 && candles.length >= 3) add('blowoff', 15, `+${m5pc.toFixed(0)}% in 5m — likely already topped`);

  // --- 8. no corroborating identity ----------------------------------------
  const hasSocial = Boolean(
    info.socials?.twitter ||
      info.socials?.telegram ||
      info.socials?.website ||
      (ds.socials || []).length ||
      (ds.websites || []).length,
  );
  if (!hasSocial && !info.gtVerified) add('no-identity', 12, 'no socials or verified profile');

  signals.sort((a, b) => b.weight - a.weight);
  const risk = Math.round(clamp(signals.reduce((s, x) => s + x.weight, 0), 0, 100));
  const level = levelOf(risk, rc.maxRisk);
  let veto = vetoes.length ? vetoes.join('; ') : null;
  if (!veto && risk >= rc.maxRisk) {
    const top = signals.slice(0, 2).map((s) => s.detail).join(' + ');
    veto = `rug risk ${risk}/100${top ? ` (${top})` : ''}`;
  }

  const summary = signals.length
    ? signals.slice(0, 3).map((s) => s.detail).join(' · ')
    : 'no rug signals';
  return { enabled: true, risk, level, veto, signals, summary };
}

/**
 * Post-entry rug watch: decide whether to leave *now*, on the first sign of a
 * drain, instead of waiting for the strategy's 65% liquidity-pull rule - by
 * which point the pool is empty and the exit is worthless.
 *
 * The engine stamps `tickLiqDropPct` / `tickPxDropPct` on the position each time
 * a snapshot is accepted, so this is pure and testable.
 *
 * @param {object} pos open position
 * @param {object} cfg bot config (uses cfg.rugWatch)
 * @returns {{reason:string, kind:'rug'}|null}
 */
export function fastRugExit(pos, cfg) {
  const w = { ...WATCH_DEFAULTS, ...(cfg?.rugWatch || {}) };
  if (!w.enabled) return null;

  const liq = Number(pos.lastLiqUsd) || 0;
  const entryLiq = Number(pos.entryLiqUsd) || 0;

  // Liquidity only tells the truth when the price agrees. A pool that is really
  // being drained cannot also print a new high, so when the last price is still
  // at its peak a collapsed depth reading is a feed gap (some PumpSwap pairs
  // report $0 liquidity while trading normally). Without this, a position up 40%
  // got force-sold into "no depth" and booked as a total loss.
  const px = Number(pos.lastPrice) || 0;
  const peak = Math.max(Number(pos.peakPx) || 0, px);
  const priceConfirmsDrain = !(px > 0 && peak > 0) || px <= peak * 0.92;

  // Just after following a graduation, the old pool's drain says nothing about
  // the pool we are actually in now.
  const justMoved = Date.now() - (Number(pos.reboundAt) || 0) < 120000;

  // 1. The drain is happening right now.
  if (!justMoved && priceConfirmsDrain && Number.isFinite(pos.tickLiqDropPct) && pos.tickLiqDropPct >= w.tickLiqDropPct / 100) {
    return { reason: `fast rug watch: liquidity -${(pos.tickLiqDropPct * 100).toFixed(0)}% in one tick`, kind: 'rug' };
  }

  // 2. Liquidity gone since entry.
  if (!justMoved && priceConfirmsDrain && entryLiq > 0 && liq > 0) {
    const fromEntry = 1 - liq / entryLiq;
    if (fromEntry >= w.liqDropFromEntryPct / 100) {
      return { reason: `fast rug watch: liquidity -${(fromEntry * 100).toFixed(0)}% from entry`, kind: 'rug' };
    }
  }

  // 3. Depth is about to make the exit itself the loss.
  //    This one needs the price to agree, like every other rule here. A depth
  //    print on its own is not evidence: four positions were sold at "$0 depth"
  //    while their quotes were +5%, +9% and +3%, and because the executor caps
  //    proceeds at half the reported depth, each was booked as a -100% loss at a
  //    price that had not fallen at all. Liquidity alone cannot drain a pool; the
  //    price has to move with it, and rules 1, 2 and 4 catch that.
  const notional = (Number(pos.qty) || 0) * (Number(pos.lastPrice) || 0);
  const depth = liq / 2;
  if (!justMoved && priceConfirmsDrain && notional > 0 && depth > 0 && depth < notional * w.minDepthMultiple) {
    return { reason: `fast rug watch: pool depth $${Math.round(depth)} under ${w.minDepthMultiple}x the position`, kind: 'rug' };
  }

  // 4. A single-tick price collapse: the dev sold, not a healthy pullback.
  if (Number.isFinite(pos.tickPxDropPct) && pos.tickPxDropPct >= w.tickPxDropPct / 100) {
    return { reason: `fast rug watch: price -${(pos.tickPxDropPct * 100).toFixed(0)}% in one tick`, kind: 'rug' };
  }

  return null;
}
