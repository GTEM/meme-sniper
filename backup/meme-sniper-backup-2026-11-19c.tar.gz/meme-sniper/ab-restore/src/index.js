import { config, liveConfigProblems } from './config.js';
import { Engine, scannableChains } from './engine.js';
import { startServer } from './server.js';
import { removeFile, ensureDataDir } from './lib/store.js';

const args = new Set(process.argv.slice(2));

async function runningBotOnPort(port) {
  const net = await import('node:net');
  return new Promise((done) => {
    const sock = net.connect({ host: '127.0.0.1', port }, () => {
      sock.destroy();
      done(true);
    });
    sock.on('error', () => done(false));
    sock.setTimeout(600, () => {
      sock.destroy();
      done(false);
    });
  });
}

if (args.has('--reset')) {
  if (await runningBotOnPort(config.port)) {
    console.error(`A bot is still running on port ${config.port}.`);
    console.error('Stop it first: it saves its in-memory book on shutdown and would overwrite the reset.');
    process.exit(1);
  }
  ensureDataDir();
  for (const f of ['portfolio.json', 'model.json']) removeFile(f);
  console.log('Cleared portfolio.json and model.json - starting from a clean bankroll.');
  process.exit(0);
}

const problems = liveConfigProblems(config);
if (problems.length) {
  console.error('Live mode is not safely configured:');
  for (const p of problems) console.error(`  - ${p}`);
  console.error('\nFix the above in .env, or run with MODE=paper.');
  process.exit(1);
}

const engine = await new Engine(config).init();
const once = args.has('--once');

if (once) {
  // Single scan: useful for smoke-testing feeds and the decision path.
  process.env.QUIET = process.env.QUIET ?? '0';
  await engine.tick();
  const s = engine.state();
  console.log('\n— scan summary —');
  console.log(JSON.stringify({ scan: s.scan, equity: s.portfolio.equity, positions: s.portfolio.positions.length }, null, 2));
  process.exit(0);
}

await startServer(engine, config.port);
engine.start();

const scanChains = scannableChains(config);
console.log(`\n  meme-sniper | ${config.mode.toUpperCase()} | chains: ${(scanChains.length ? scanChains : config.chains).join(', ')}`);
console.log(`  dashboard: http://localhost:${config.port}\n`);

let closing = false;
const shutdown = async (sig) => {
  if (closing) return;
  closing = true;
  console.log(`\n${sig} received - saving state and stopping.`);
  engine.stop();
  engine.save();
  setTimeout(() => process.exit(0), 200);
};
process.on('SIGINT', () => shutdown('SIGINT'));
process.on('SIGTERM', () => shutdown('SIGTERM'));
