import { readJson, writeJson } from './lib/store.js';

// Live accounting for the entry quality gate.
//
// Two questions, both of which need state across restarts:
//   1. How often does each rule fire? Churn, safety, and the rug score are
//      separate mechanisms and are worth counting separately.
//   2. Is the book better since the gate went live? The book as it stood when
//      the gate was first enabled is frozen as a baseline, so the win rate of
//      trades closed afterwards can be compared against it honestly.

const FILE = 'gate-stats.json';
const KINDS = ['churn', 'safety', 'rug', 'other'];

/** Which rule produced this veto string. */
export function classifyVeto(reason) {
  const text = String(reason || '');
  if (!text) return null;
  if (/^churn:/i.test(text)) return 'churn';
  if (/^safety /i.test(text)) return 'safety';
  if (/^rug \d+\/100|^rug /i.test(text)) return 'rug';
  return 'other';
}

const zero = () => ({ churn: 0, safety: 0, rug: 0, other: 0 });

export class GateStats {
  constructor(state = {}) {
    this.counts = { ...zero(), ...(state.counts || {}) };
    this.since = state.since || null;
    this.scans = Number(state.scans) || 0;
    this.baseline = state.baseline || null;
    this.scanCounts = zero();
  }

  /** Freeze the book the first time the gate runs; never overwrite it later. */
  ensureBaseline(totals) {
    if (this.baseline || !totals) return this.baseline;
    this.baseline = {
      at: Date.now(),
      trades: Number(totals.trades) || 0,
      wins: Number(totals.wins) || 0,
      losses: Number(totals.losses) || 0,
      realizedUsd: Number(totals.realizedUsd) || 0,
    };
    this.since = this.baseline.at;
    return this.baseline;
  }

  record(reason) {
    const kind = classifyVeto(reason);
    if (!kind) return null;
    this.counts[kind] += 1;
    this.scanCounts[kind] += 1;
    return kind;
  }

  /** Called once per scan; returns that scan's tally and resets it. */
  endScan() {
    this.scans += 1;
    const tally = { ...this.scanCounts };
    this.scanCounts = zero();
    return tally;
  }

  /** What the dashboard shows: totals, plus the book since the gate. */
  view(totals = {}) {
    const base = this.baseline || { trades: 0, wins: 0, losses: 0, realizedUsd: 0, at: this.since };
    const trades = Math.max(0, (Number(totals.trades) || 0) - base.trades);
    const wins = Math.max(0, (Number(totals.wins) || 0) - base.wins);
    const losses = Math.max(0, (Number(totals.losses) || 0) - base.losses);
    const realizedUsd = Number(((Number(totals.realizedUsd) || 0) - base.realizedUsd).toFixed(2));
    const rate = (w, n) => (n > 0 ? Number((w / n).toFixed(4)) : null);
    return {
      counts: { ...this.counts },
      scans: this.scans,
      since: this.since,
      baseline: { trades: base.trades, wins: base.wins, losses: base.losses, winRate: rate(base.wins, base.trades) },
      book: { trades, wins, losses, realizedUsd, winRate: rate(wins, trades) },
    };
  }

  save() {
    writeJson(FILE, { counts: this.counts, scans: this.scans, since: this.since, baseline: this.baseline });
  }

  static load() {
    return new GateStats(readJson(FILE, {}));
  }
}

export const GATE_KINDS = KINDS;
