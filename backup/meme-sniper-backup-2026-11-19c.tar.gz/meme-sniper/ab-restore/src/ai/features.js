// Feature engineering: turns a raw candidate (pool + token info + second
// opinion + candles) into a fixed vector in [0,1] that the signal model can
// score. Every transform is monotone and bounded so weights stay comparable
// and online learning cannot blow up.

export const FEATURE_NAMES = [
  'liquidity',
  'turnover',
  'buyPressure',
  'traderBreadth',
  'momentum',
  'acceleration',
  'candleStrength',
  'drawdown',
  'liqToMcap',
  'social',
  'freshness',
  'volumeAccel',
  'sellPressure',
  'activity',
  'safety',
  // Ownership: the only signals that describe a bundler sitting on the float.
  'holderTop10',
  'bundleShare',
  'devShare',
];

const clamp01 = (x) => (x < 0 ? 0 : x > 1 ? 1 : x);
const n = (v, def = 0) => {
  const x = Number(v);
  return Number.isFinite(x) ? x : def;
};
/** log-scaled position of x between lo and hi, clamped to 0..1 */
const logNorm = (x, lo, hi) => {
  if (!(x > 0)) return 0;
  const a = Math.log(Math.max(lo, 1e-9));
  const b = Math.log(Math.max(hi, lo * 1.0001));
  return clamp01((Math.log(x) - a) / (b - a));
};

/**
 * @param {object} cand candidate with .pool, .info (token info), .ds (dexscreener), .candles
 * @param {object} cfg bot config
 * @returns {{features: Record<string,number>, reasons: string[], veto: string|null}}
 */
export function extractFeatures(cand, cfg, now = Date.now()) {
  const pool = cand.pool || {};
  const info = cand.info || {};
  const ds = cand.ds || {};
  const candles = cand.candles || [];
  const reasons = [];
  let veto = null;

  const liq = n(pool.liqUsd || ds.liqUsd);
  const mcap = n(pool.mcapUsd || pool.fdvUsd || ds.mcapUsd || ds.fdvUsd);
  const m5 = pool.txns?.m5 || {};
  const h1 = pool.txns?.h1 || {};
  const buys5 = n(m5.buys);
  const sells5 = n(m5.sells);
  const txn5 = buys5 + sells5;

  const own = cand.ownership && cand.ownership.ok ? cand.ownership : null;
  // Ownership is authoritative when the RPC answered: GeckoTerminal's holder
  // distribution is missing on most fresh launches.
  const concentration = own && own.top10Pct !== null && own.top10Pct !== undefined ? own.top10Pct : info.holderConcentration;

  const ageSec = pool.createdAtMs ? Math.max(0, (now - pool.createdAtMs) / 1000) : n(cand.ageSec, 600);
  const vol5 = n(pool.vol?.m5 || ds.vol?.m5);
  const vol1h = n(pool.vol?.h1 || ds.vol?.h1);
  const liqToMcap = mcap > 0 ? liq / mcap : 0;

  // --- hard safety vetoes ---------------------------------------------------
  if (info.honeypot === 'yes' || info.honeypot === true) {
    veto = 'honeypot flagged by GeckoTerminal';
  }
  if (info.mintAuthority === 'yes') {
    veto = 'mint authority not revoked';
  }
  if (info.freezeAuthority === 'yes') {
    veto = 'freeze authority not revoked';
  }
  if (ageSec < cfg.minAgeSec) veto = veto || `too fresh (${Math.round(ageSec)}s)`;
  if (liq < cfg.minLiqUsd) veto = veto || `liquidity below floor ($${Math.round(liq)})`;
  if (liq > cfg.maxLiqUsd) veto = veto || `liquidity above band ($${Math.round(liq)})`;
  if (ageSec > cfg.maxAgeSec) veto = veto || `too old (${Math.round(ageSec / 60)}m)`;
  if (txn5 < cfg.minTxns5M) veto = veto || `too few trades (${txn5} in 5m)`;
  if (pool.priceUsd <= 0) veto = veto || 'no price';

  // Liquidity collapse vs. market cap: classic fake-pool / wash setup.
  if (liqToMcap > 0 && liqToMcap < 0.015 && mcap > 50000) {
    veto = veto || 'liquidity is <1.5% of market cap';
  }
  // Two feeds disagreeing by >3x usually means one pool is a fake mirror.
  if (n(ds.liqUsd) > 0 && liq > 0) {
    const ratio = Math.max(liq, ds.liqUsd) / Math.min(liq, ds.liqUsd);
    if (ratio > 3) reasons.push(`feeds disagree on liquidity (${ratio.toFixed(1)}x)`);
  }

  // --- candle-derived ------------------------------------------------------
  const closes = candles.map((c) => c.c).filter((c) => c > 0);
  const last = n(pool.priceUsd, closes.at(-1) || 0);
  let candleStrength;
  let drawdown;
  if (candles.length >= 3) {
    const peak = Math.max(...candles.map((c) => c.h));
    const recent = candles.slice(-3);
    const startRecent = recent[0].o;
    const upRatio = candles.filter((c) => c.c >= c.o).length / candles.length;
    const raw = startRecent > 0 ? clamp01((last / startRecent - 1) / 2 + 0.5) : 0.5;
    candleStrength = clamp01(raw * 0.6 + upRatio * 0.4);
    const drawdownFrac = peak > 0 ? Math.max(0, (peak - last) / peak) : 0;
    // A young coin 0-20% off its high is healthy; >55% off is a dump.
    drawdown = clamp01(1 - drawdownFrac / 0.55);
  } else {
    // No candle budget left this scan: fall back to the pool's own
    // price-change windows, which are just as directionally useful.
    const m5 = n(pool.pc?.m5);
    const m15 = n(pool.pc?.m15);
    candleStrength = clamp01(0.5 + m5 / 200);
    drawdown = clamp01(1 + Math.min(m5, m15 || m5) / 60);
  }

  const buyRatio5 = txn5 > 0 ? buys5 / txn5 : 0.5;
  const sellRatio1 = h1.buys + h1.sells > 0 ? n(h1.sells) / (n(h1.buys) + n(h1.sells)) : 0.5;

  // Breadth = how many distinct wallets are trading, damped when the same few
  // wallets churn the pool (wash trading looks identical to organic volume
  // except in this ratio).
  const unique5 = n(m5.uniqueTraders ?? m5.buyers);
  const tradesPerWallet = unique5 > 0 ? txn5 / unique5 : txn5;
  const washPenalty = clamp01(1 - Math.max(0, tradesPerWallet - 4) / 12);
  // Some feeds do not report distinct traders. That is missing data, not a
  // reason to punish the candidate, so stay neutral rather than scoring 0.
  const breadth = unique5 > 0
    ? clamp01(logNorm(unique5, 3, 90) * (0.4 + 0.6 * washPenalty))
    : txn5 > 0 ? 0.5 : 0.35;

  // Momentum saturates and then *decays*: a coin already up several hundred
  // percent in five minutes is a top, not an entry. This is the single most
  // expensive mistake in meme sniping, so it is modelled explicitly.
  const m5pc = n(pool.pc?.m5);
  const momentum = m5pc <= 100
    ? clamp01((m5pc + 30) / 150)
    : clamp01(0.87 - ((Math.min(m5pc, 700) - 100) / 600) * 0.5); // -30%..+120%
  const acceleration = clamp01((n(pool.pc?.m5) - n(pool.pc?.m15) + 40) / 80); // -40%..+40%
  const turnover = logNorm(liq > 0 ? vol5 / liq : 0, 0.004, 0.6);

  // Volume acceleration is only measurable once a pool has some history; on a
  // 10-minute-old launch every trade is in the first bucket, so stay neutral
  // rather than handing out a free high score.
  const vol15 = n(pool.vol?.m15);
  const volumeAccel = ageSec >= 900 && vol15 > 0
    ? logNorm(vol5 / Math.max(vol15 / 3, 1e-9), 0.2, 3)
    : ageSec >= 900 && vol1h > 0
      ? logNorm(vol5 / Math.max(vol1h / 12, 1e-9), 0.2, 3)
      : 0.5;

  const liquidity = logNorm(liq, cfg.minLiqUsd * 0.5, cfg.maxLiqUsd);
  const activity = logNorm(txn5, 4, 120);
  const freshness = clamp01(1 - ageSec / Math.max(cfg.maxAgeSec, 1));

  const socialParts = [
    info.socials?.twitter || ds.socials?.includes('twitter') ? 1 : 0,
    info.socials?.telegram || ds.socials?.includes('telegram') ? 1 : 0,
    info.socials?.website || (ds.websites || []).length ? 1 : 0,
  ];
  const social = clamp01(socialParts.reduce((a, b) => a + b, 0) / 3 + (info.gtVerified ? 0.1 : 0));

  // Safety score is a graded penalty: neutral when data is missing, harsh when
  // holders are concentrated or the token is unverified with no info at all.
  let safety = 0.6;
  if (concentration !== null && concentration !== undefined) {
    const top10 = n(concentration);
    safety = clamp01(1 - top10 / 90);
    if (top10 > 60) reasons.push(`top holders own ~${top10.toFixed(0)}%`);
  }

  // Ownership features. A pool's own token account is excluded upstream, so
  // these describe real wallets, not the float.
  const holderTop10 = own && own.top10Pct !== null ? clamp01(1 - own.top10Pct / 100) : 0.5;
  const bundleShare =
    own && own.clusters && own.clusters.checked >= 2 ? clamp01(1 - own.clusters.clusterPct / 100) : 0.5;
  const devShare = own && own.devPct !== null ? clamp01(1 - own.devPct / 15) : 0.5;
  if (own) {
    if (own.top10Pct !== null) reasons.push(`top 10 wallets hold ${own.top10Pct.toFixed(0)}% (pool excluded)`);
    if (own.devPct !== null && own.devPct > 3) reasons.push(`dev holds ${own.devPct.toFixed(1)}%`);
    if (own.clusters && own.clusters.checked >= 2 && own.clusters.clusterPct > 25) {
      reasons.push(`${own.clusters.wallets} top holders share one funder (${own.clusters.clusterPct.toFixed(0)}%)`);
    }
  }
  if (info.mintAuthority === 'no' && info.freezeAuthority === 'no') safety = clamp01(safety + 0.15);
  if (info.gtVerified) safety = clamp01(safety + 0.1);
  if (info.honeypot === 'no') safety = clamp01(safety + 0.1);

  const features = {
    liquidity,
    turnover,
    buyPressure: buyRatio5,
    traderBreadth: breadth,
    momentum,
    acceleration,
    candleStrength,
    drawdown,
    // New launches almost always sit near liq ~= market cap, so this is only
    // informative in its bad tail: liquidity that is a sliver of the cap means
    // the price is fake and the exit will not be there.
    liqToMcap: clamp01((liqToMcap - 0.03) / 0.45),
    social,
    freshness,
    volumeAccel,
    sellPressure: clamp01(1 - sellRatio1),
    activity: clamp01(activity * 0.7 + breadth * 0.3),
    safety,
    holderTop10,
    bundleShare,
    devShare,
  };

  // Explainability: the three strongest raw facts about this coin.
  if (buyRatio5 > 0.62) reasons.push(`${Math.round(buyRatio5 * 100)}% buy pressure in 5m`);
  if (n(pool.pc?.m5) > 15) reasons.push(`+${n(pool.pc.m5).toFixed(0)}% in 5m`);
  if (n(pool.pc?.m5) < -25) reasons.push(`${n(pool.pc.m5).toFixed(0)}% in 5m`);
  if (turnover > 0.6) reasons.push('volume turning over liquidity fast');
  if (social >= 0.99) reasons.push('twitter + telegram + site present');
  if (info.gtVerified) reasons.push('verified token profile');

  // Raw (un-normalised) churn: dollars traded in five minutes against the pool's
  // own depth. The entry gate needs the real ratio, not the log-scaled feature.
  const volToLiq5m = liq > 0 ? vol5 / liq : 0;

  // What we could not see. Neutral defaults keep the *score* sane, but every
  // one of them is a guess, and the entry gate must be able to tell "healthy"
  // apart from "unknown" - an unseen pool is not a safe pool.
  const missing = [];
  if (!(liq > 0)) missing.push('liquidity');
  if (!(vol5 > 0)) missing.push('5m volume');
  if (!(txn5 > 0)) missing.push('5m trades');
  if (!(mcap > 0)) missing.push('market cap');
  if (!own && (concentration === null || concentration === undefined)) missing.push('holder table');

  return { features, reasons, veto, ageSec, liquidityUsd: liq, mcapUsd: mcap, volToLiq5m, missing };
}
