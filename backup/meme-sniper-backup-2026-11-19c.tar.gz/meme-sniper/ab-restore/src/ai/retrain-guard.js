// Should a refit be installed at all?
//
// A batch refit on a small book can look fine in-sample and still be worse than
// doing nothing. That is not hypothetical: a refit scored LOO AUC 0.52 against
// priors at 0.63 and overturned twelve of eighteen domain priors, including
// safety 1.25 -> -1.25, and it was written out because a human had to notice.
//
// Two rules, both from numbers the retrain already computes:
//   1. It has to beat the untrained priors at separating winners from losers.
//   2. It may not overturn most of the domain priors unless the book is big
//      enough to justify it.
//
// Pure function so the policy is testable without running a refit.

/** Sign flips allowed before the book has to be bigger. */
export function flipLimit(features, trades) {
  return trades >= 100 ? Math.ceil(features * 0.5) : 3;
}

/**
 * @param {{refitAuc:number, priorAuc:number, flips:number, features:number, trades:number, minAuc?:number}} v
 * @returns {string[]} reasons to refuse; empty means install it
 */
export function refitRefusals({ refitAuc, priorAuc, flips, features, trades, minAuc = 0.55 }) {
  if (!Number.isFinite(refitAuc) || refitAuc <= 0) return ['the refit could not be scored at all'];

  const refusals = [];
  if (!(refitAuc > priorAuc)) {
    refusals.push(
      `LOO AUC ${refitAuc.toFixed(2)} does not beat the priors' ${priorAuc.toFixed(2)}: the refit separates winners from losers worse than no learning`,
    );
  }
  if (refitAuc < minAuc) refusals.push(`LOO AUC ${refitAuc.toFixed(2)} is at chance (0.50)`);

  const limit = flipLimit(features, trades);
  if (flips > limit) {
    refusals.push(`${flips} of ${features} prior signs overturned, ${limit} allowed at ${trades} trades`);
  }
  return refusals;
}
