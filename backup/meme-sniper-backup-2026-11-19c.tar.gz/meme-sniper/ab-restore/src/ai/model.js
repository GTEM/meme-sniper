import { existsSync } from 'node:fs';
import { resolve } from 'node:path';
import { DATA_DIR, readJson, writeJson } from '../lib/store.js';
import { FEATURE_NAMES } from './features.js';

// An online-learning logistic model.
//
// Why this and not an LLM call per coin: entry decisions have to run in
// seconds against 20+ numeric signals, they must be identical on replay, and
// they must improve from the bot's own trade outcomes. A logistic model with
// domain priors does exactly that, needs no API key, and cannot hallucinate a
// buy signal. It is genuinely adaptive: every closed trade updates the weights
// (SGD with a pull back toward the priors so a lucky streak cannot warp it).

const PRIORS = {
  liquidity: 0.55,
  turnover: 0.5,
  buyPressure: 1.15,
  traderBreadth: 0.75,
  momentum: 0.9,
  acceleration: 0.7,
  candleStrength: 0.65,
  drawdown: 0.85,
  liqToMcap: 0.6,
  social: 0.55,
  freshness: 0.35,
  volumeAccel: 0.8,
  sellPressure: 0.7,
  activity: 0.6,
  safety: 1.25,
  // Ownership priors: dispersed holders, no single funder behind the top wallets,
  // and a dev who is not sitting on the float.
  holderTop10: 1.0,
  bundleShare: 0.9,
  devShare: 0.8,
};

const DEFAULT_BIAS = -0.15;
const GAIN = 3.2;         // score sharpness after weight-mass normalisation
const LR = 0.08;          // learning rate (normalised gradient)
const ANCHOR = 0.012;     // pull toward priors, per closed trade
const W_CLAMP = 3.5;

// Self-learning feature signs. A domain prior says "more socials is better"; the
// bot's own trades may say the opposite (scam tokens add socials to look
// legitimate). Each feature keeps an EWMA of the signed gradient - which way its
// outcomes actually pushed it - and once there are enough trades, a prior whose
// sign the evidence contradicts becomes an anchor at -prior instead. Nothing
// snaps: the anchor is slow, so the weight has to be walked there trade by trade.
// Defaults are deliberately conservative: a 19-trade book flips 8 of 15 priors
// if the gate is lower, which says the gradients are noise at that sample size,
// not that the domain priors are wrong. Tune with SIGN_MIN_SAMPLES /
// SIGN_EVIDENCE when there are more trades.
const SIGN_MIN_SAMPLES = Number(process.env.SIGN_MIN_SAMPLES) || 20;
const SIGN_EVIDENCE = Number(process.env.SIGN_EVIDENCE) || 0.05;
const SIGN_DECAY = 0.85;

const sigmoid = (z) => 1 / (1 + Math.exp(-z));

export class SignalModel {
  constructor(state = {}, { signLearning = true } = {}) {
    this.weights = { ...PRIORS, ...(state.weights || {}) };
    this.bias = Number.isFinite(state.bias) ? state.bias : DEFAULT_BIAS;
    this.samples = state.samples || 0;
    this.wins = state.wins || 0;
    this.signLearning = signLearning;
    this.evidence = { ...(state.evidence || {}) };
    this.recent = Array.isArray(state.recent) ? state.recent.slice(-200) : [];
    for (const k of FEATURE_NAMES) {
      if (!Number.isFinite(this.weights[k])) this.weights[k] = PRIORS[k] ?? 0;
      if (!Number.isFinite(this.evidence[k])) this.evidence[k] = 0;
    }
    this.dirty = false;
  }

  /**
   * Where the anchor pulls this feature now: its domain prior, or the mirrored
   * prior once the bot's own outcomes have consistently contradicted it.
   */
  anchorTarget(name) {
    const prior = PRIORS[name] ?? 0;
    if (!this.signLearning) return prior;
    if (this.samples < SIGN_MIN_SAMPLES) return prior;
    if (Math.abs(prior) < 0.3) return prior; // too weak to be worth flipping
    const ev = this.evidence[name] ?? 0;
    if (ev === 0) return prior;
    if (Math.sign(ev) === Math.sign(prior)) return prior;
    if (Math.abs(ev) < SIGN_EVIDENCE) return prior;
    return -prior;
  }

  /** Features whose prior sign the bot's own trades have overturned. */
  flippedSigns() {
    return FEATURE_NAMES.filter((name) => this.anchorTarget(name) !== (PRIORS[name] ?? 0)).map((name) => ({
      name,
      prior: PRIORS[name],
      evidence: +(this.evidence[name] ?? 0).toFixed(3),
    }));
  }

  /**
   * Weighted evidence, normalised by total weight mass so the score stays on a
   * comparable scale no matter how large the learned weights grow. Raw sums
   * saturate to >95% within a week of learning; this does not.
   * @returns {{score:number, mass:number, contributions:{name:string,value:number,weight:number,effect:number}[]}}
   */
  score(features) {
    const contributions = [];
    let raw = 0;
    let mass = 0;
    for (const name of FEATURE_NAMES) {
      const x = Number(features?.[name]);
      if (!Number.isFinite(x)) continue;
      const centred = (x - 0.5) * 2; // -1..1
      const w = this.weights[name] ?? 0;
      const effect = w * centred;
      raw += effect;
      mass += Math.abs(w);
      contributions.push({ name, value: +x.toFixed(3), weight: +w.toFixed(3), effect: +effect.toFixed(3) });
    }
    mass = Math.max(mass, 1);
    const z = this.bias + (GAIN * raw) / mass;
    contributions.sort((a, b) => Math.abs(b.effect) - Math.abs(a.effect));
    return { score: sigmoid(z), mass, contributions };
  }

  /**
   * Learn from a closed trade.
   *
   * The label is binary (did it make money after costs), but the *sample* is
   * weighted by how much money the outcome represented and, harder, by whether
   * the trade ended in a liquidity pull. A plain unweighted label let a −100%
   * rug count the same as a +2% scratch and the same as a +80% win, so the
   * model learned the features of *pumps* - which is what a rug looks like just
   * before the pull - and ended up scoring rugs above winners.
   *
   * @param {Record<string,number>} features the entry-time feature vector
   * @param {number} outcome net PnL fraction, e.g. -0.32 or +1.45
   * @param {{kind?:'rug'|'profit'|'stop'|'time'|string}} [opts] why the trade closed
   */
  learn(features, outcome, opts = {}) {
    if (!features) return null;
    const { score: p, mass } = this.score(features);
    const label = outcome > 0 ? 1 : 0;
    // Cost-sensitive: |outcome| drives the weight, so the rugs that actually
    // emptied the account dominate the gradient. A rug escape is a failure mode
    // of its own and is weighted again on top.
    const severity = Math.min(1, Math.abs(Number(outcome) || 0) / 0.5);
    const weight = 0.5 + 2 * severity;
    const rugBoost = opts.kind === 'rug' ? 1.5 : 1;
    const step = (LR * GAIN * weight * rugBoost) / mass;
    for (const name of FEATURE_NAMES) {
      const x = Number(features[name]);
      if (!Number.isFinite(x)) continue;
      const centred = (x - 0.5) * 2;
      const target = this.anchorTarget(name);
      let w = this.weights[name] ?? target;
      w += step * (label - p) * centred;
      w -= ANCHOR * (w - target);
      this.weights[name] = Math.max(-W_CLAMP, Math.min(W_CLAMP, w));
      // Which way did this trade actually push the feature? Unweighted, so a
      // single rug cannot decide a feature's sign on its own.
      const push = (label - p) * centred;
      this.evidence[name] = (this.evidence[name] ?? 0) * SIGN_DECAY + (1 - SIGN_DECAY) * push;
    }
    this.bias += step * 0.4 * (label - p);
    this.bias = Math.max(-2, Math.min(2, this.bias));
    this.samples += 1;
    if (label) this.wins += 1;
    this.recent.push({ p: +p.toFixed(4), label, w: +weight.toFixed(2), kind: opts.kind || null, at: Date.now() });
    if (this.recent.length > 200) this.recent = this.recent.slice(-200);
    this.dirty = true;
    return { p, label, weight };
  }

  /** Rolling accuracy over the last N graded entries. */
  stats() {
    const recent = this.recent.slice(-50);
    const correct = recent.filter((r) => (r.p >= 0.5 ? 1 : 0) === r.label).length;
    return {
      samples: this.samples,
      wins: this.wins,
      winRate: this.samples ? this.wins / this.samples : null,
      rollingAccuracy: recent.length ? correct / recent.length : null,
      bias: +this.bias.toFixed(3),
      flippedSigns: this.flippedSigns(),
      topWeights: Object.entries(this.weights)
        .sort((a, b) => Math.abs(b[1]) - Math.abs(a[1]))
        .slice(0, 6)
        .map(([name, w]) => ({ name, weight: +w.toFixed(3) })),
    };
  }

  toJSON() {
    return {
      weights: this.weights,
      evidence: this.evidence,
      bias: this.bias,
      samples: this.samples,
      wins: this.wins,
      recent: this.recent.slice(-200),
      savedAt: Date.now(),
    };
  }

  save() {
    writeJson('model.json', this.toJSON());
    this.dirty = false;
  }

  static load() {
    const p = resolve(DATA_DIR, 'model.json');
    if (!existsSync(p)) return new SignalModel();
    return new SignalModel(readJson('model.json', {}));
  }
}

export { PRIORS, DEFAULT_BIAS };
