import { readJson, writeJson } from './lib/store.js';

// Tokens this book has actually been rugged by, and a cooldown on re-buying them.
//
// Why this exists: the entry-time rug score cannot see a drain that has not
// happened yet. Of the first 48 closed trades every one of the 13 losses entered
// at risk 10 or 22 - "safe" by score - and then exited through the rug watch. GTA
// was bought, drained and re-bought three times, losing all three.
//
// The exit already knows what the entry could not. So a position closed by the rug
// watch, or down 50% or worse, pins its mint for a cooldown and the entry gate
// refuses that mint until the cooldown expires. Nothing else about entry changes.

const FILE = 'rug-blacklist.json';
const DEFAULT_HOURS = 24;
const HOUR_MS = 60 * 60 * 1000;

export class RugBlacklist {
  /**
   * @param {object} cfg bot config (uses cfg.rug.blacklistHours)
   * @param {{file?:string, now?:number}} opts test hooks
   */
  constructor(cfg = {}, { file = FILE, now = Date.now() } = {}) {
    const configured = Number(cfg?.rug?.blacklistHours);
    this.hours = Number.isFinite(configured) && configured > 0 ? configured : DEFAULT_HOURS;
    const symbolHours = Number(cfg?.rug?.symbolBlacklistHours);
    this.symbolHours = Number.isFinite(symbolHours) && symbolHours > 0 ? symbolHours : this.hours;
    this.file = file;
    const state = readJson(file, { entries: {} }) || { entries: {} };
    this.entries = state.entries && typeof state.entries === 'object' ? state.entries : {};
    // Symbol pins are separate from mint pins: six different mints called
    // "Tradercat" were bought and rugged, because a symbol that ran is copied
    // immediately. Same expiry rules, keyed by the uppercased symbol.
    this.symbols = state.symbols && typeof state.symbols === 'object' ? state.symbols : {};
    this.prune(now);
  }

  /** Drop expired pins; called on load and on every save. */
  prune(now = Date.now()) {
    let removed = 0;
    for (const [mint, e] of Object.entries(this.entries)) {
      if (!(Number(e?.until) > now)) {
        delete this.entries[mint];
        removed += 1;
      }
    }
    for (const [sym, e] of Object.entries(this.symbols)) {
      if (!(Number(e?.until) > now)) {
        delete this.symbols[sym];
        removed += 1;
      }
    }
    return removed;
  }

  /** The pin for this mint, or null when it may be traded. */
  check(mint, now = Date.now()) {
    if (!mint) return null;
    const e = this.entries[mint];
    return e && Number(e.until) > now ? e : null;
  }

  /** The pin for this symbol, or null. */
  checkSymbol(symbol, now = Date.now()) {
    const key = String(symbol || '').trim().toUpperCase();
    if (!key) return null;
    const e = this.symbols[key];
    return e && Number(e.until) > now ? e : null;
  }

  /** Pin a symbol too: copycats reuse the name of whatever just ran or rugged. */
  blockSymbol(symbol, { reason = null, mint = null } = {}, now = Date.now()) {
    const key = String(symbol || '').trim().toUpperCase();
    if (!key) return null;
    const entry = {
      symbol: key,
      reason,
      mint,
      at: now,
      until: now + this.symbolHours * HOUR_MS,
      hours: this.symbolHours,
    };
    this.symbols[key] = entry;
    this.save(now);
    return entry;
  }

  /** Pin a mint after a rug exit. */
  block(mint, { symbol = null, reason = null, pnlPct = null } = {}, now = Date.now()) {
    if (!mint) return null;
    const entry = {
      mint,
      symbol,
      reason,
      pnlPct: Number.isFinite(pnlPct) ? +pnlPct.toFixed(4) : null,
      at: now,
      until: now + this.hours * HOUR_MS,
      hours: this.hours,
    };
    this.entries[mint] = entry;
    this.save(now);
    return entry;
  }

  save(now = Date.now()) {
    this.prune(now);
    writeJson(this.file, {
      updatedAt: now,
      hours: this.hours,
      symbolHours: this.symbolHours,
      entries: this.entries,
      symbols: this.symbols,
    });
  }

  view(now = Date.now()) {
    const active = Object.values(this.entries).filter((e) => Number(e?.until) > now);
    const symbols = Object.values(this.symbols).filter((e) => Number(e?.until) > now);
    return {
      hours: this.hours,
      symbolHours: this.symbolHours,
      count: active.length,
      symbolCount: symbols.length,
      mints: active.slice(0, 20),
      names: symbols.slice(0, 20),
    };
  }
}

/**
 * Should a closed trade pin its mint?
 *
 * The rug watch firing is the direct signal. A loss of half the position is the
 * same information arriving late, and catches exits that escalated by a different
 * rule while the pool was already gone.
 */
export function shouldBlacklist({ kind = null, pnlPct = 0 } = {}) {
  if (kind === 'rug') return true;
  return Number.isFinite(pnlPct) && pnlPct <= -0.5;
}
