import { costBpsFor, depthFillRate, exitDepth } from '../venues.js';

// Paper fills against live prices. Slippage scales with order size relative to
// pool depth, and fees are taken on both legs, so paper PnL is deliberately
// pessimistic compared with a naive "buy at price X" backtest.
//
// Urgent exits pay an escalation premium: in live mode that is priority fee and
// a wider slippage tolerance, and here it is modelled as its expected cost so a
// paper run cannot look better than the real thing.

export function slippageOf(notionalUsd, liqUsd) {
  return 1 - depthFillRate(notionalUsd, liqUsd);
}

export function createPaperExecutor(cfg) {
  const esc = cfg.exitEscalation || {};

  return {
    name: 'paper',
    async buy({ priceUsd, sizeUsd, liqUsd, venue = 'amm' }) {
      const feeRate = costBpsFor(cfg, venue) / 2 / 10000;
      const keep = depthFillRate(sizeUsd, liqUsd);
      if (keep < 0.05) throw new Error('pool too thin for this size');
      const impact = 1 - keep;
      const fillPrice = priceUsd / keep; // you pay up for crossing the curve
      const feeUsd = sizeUsd * feeRate;
      const spendable = sizeUsd - feeUsd;
      const qty = spendable / fillPrice;
      return { fillPrice, qty, feeUsd, spentUsd: sizeUsd, slippage: impact, txHash: null };
    },
    async sell({ position, priceUsd, fraction, liqUsd, urgent = false }) {
      const qty = position.qty * Math.min(1, Math.max(0, fraction));
      if (!(qty > 0) || !(priceUsd > 0)) throw new Error('nothing to sell');
      const notional = qty * priceUsd;
      const costBps = position.venueCostBps ?? costBpsFor(cfg, position.venue);
      const feeRate = costBps / 2 / 10000 + (urgent ? (esc.extraBps || 0) / 10000 : 0);
      // One rule, the same shape as the buy side: slippage grows with the order
      // relative to the pool's depth. There used to be a second rule here that
      // capped proceeds at half the reported depth; it caught a drained pool
      // paying out a stale 23,000x price, but it also paid $0 for a pool that
      // momentarily reported no liquidity, booking -100% on positions that were
      // up. exitDepth() decides which readings can be priced against at all, and
      // then the slippage curve does the rest.
      const depth = exitDepth(position, liqUsd, notional, priceUsd);
      const keep = depthFillRate(notional, depth);
      const baseImpact = 1 - keep;
      // You rarely pay the full widened tolerance, but you do pay for the rush.
      const urgentImpact = ((esc.slippagePct || 0) / 100) * 0.5;
      const impact = urgent ? Math.min(0.99, Math.max(baseImpact, urgentImpact)) : baseImpact;
      const fillPrice = priceUsd * (1 - impact);
      const gross = qty * fillPrice;
      const feeUsd = gross * feeRate;
      return {
        fillPrice,
        qty,
        grossUsd: gross,
        feeUsd,
        proceedsUsd: Math.max(0, gross - feeUsd),
        slippage: impact,
        escalated: urgent,
        txHash: null,
      };
    },
  };
}
