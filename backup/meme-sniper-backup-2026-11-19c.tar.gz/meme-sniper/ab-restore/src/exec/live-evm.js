// Live execution on EVM chains through a Uniswap-V2-compatible router.
//
// READ THIS BEFORE USING IT:
//  * Requires MODE=live, RPC_URL, WALLET_PRIVATE_KEY, NATIVE_USD_PRICE and
//    CONFIRM_LIVE=I_UNDERSTAND_THE_RISK. Live mode pays real money and can lose
//    all of it; meme coins are frequently honeypots that you cannot sell.
//  * Sizing is in USD. NATIVE_USD_PRICE converts it to the chain's native coin;
//    without it the bot refuses to trade rather than guess (guessing 50 "USD"
//    as 50 ETH is how accounts die).
//  * Exits marked urgent (profit protection / rug escape) pay a higher priority
//    fee and accept wider slippage so the sell actually lands. Entries never do.
//  * This adapter has NOT been executed against a funded wallet in this
//    workspace. Treat your first runs as tiny-size smoke tests.
//  * Solana is not supported here: pump.fun/Raydium routing needs a separate
//    adapter (see docs/pumpfun-adapter.md).

const CHAINS = {
  base: {
    chainId: 8453,
    router: '0x4752ba5DBc23f44D87826276BF6Fd6b1C372aD24',
    wrapped: '0x4200000000000000000000000000000000000006',
  },
  eth: {
    chainId: 1,
    router: '0x7a250d5630B4cF539739dF2C5dAcb4c659F2488D',
    wrapped: '0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2',
  },
  arbitrum: {
    chainId: 42161,
    router: '0x4752ba5DBc23f44D87826276BF6Fd6b1C372aD24',
    wrapped: '0x82aF49447D8a07e3bd95BD0d56f35241523fBab1',
  },
  bsc: {
    chainId: 56,
    router: '0x10ED43C718714eb63d5aA57B78B54704E256024E',
    wrapped: '0xbb4CdB9CBd36B01bD1cBaEBF2De08d9173bc095c',
  },
};

const ROUTER_ABI = [
  'function swapExactETHForTokensSupportingFeeOnTransferTokens(uint256 amountOutMin, address[] path, address to, uint256 deadline) payable',
  'function swapExactTokensForETHSupportingFeeOnTransferTokens(uint256 amountIn, uint256 amountOutMin, address[] path, address to, uint256 deadline)',
];

const ERC20_ABI = [
  'function approve(address spender, uint256 amount) returns (bool)',
  'function allowance(address owner, address spender) view returns (uint256)',
  'function balanceOf(address owner) view returns (uint256)',
  'function decimals() view returns (uint8)',
];

export async function createLiveExecutor(cfg) {
  if (cfg.mode !== 'live') throw new Error('live executor requires MODE=live');
  const nativeUsd = Number(cfg.live.nativeUsdPrice);
  if (!(nativeUsd > 0)) {
    throw new Error('NATIVE_USD_PRICE is required in live mode (e.g. 3000 for an ETH at $3000)');
  }

  let ethers;
  try {
    ethers = await import('ethers');
  } catch {
    throw new Error('ethers is not installed - run `npm install ethers` to enable live mode');
  }

  const { JsonRpcProvider, Wallet, Contract, parseUnits, formatUnits, MaxUint256 } = ethers;
  const provider = new JsonRpcProvider(cfg.live.rpcUrl, undefined, { staticNetwork: true });
  const wallet = new Wallet(cfg.live.privateKey, provider);
  const esc = cfg.exitEscalation || {};
  const baseSlip = cfg.maxSlippageBps / 10000;

  const routerFor = (chain) => {
    const meta = CHAINS[chain];
    if (!meta) throw new Error(`live trading not configured for chain "${chain}"`);
    return { router: new Contract(cfg.live.routerAddress || meta.router, ROUTER_ABI, wallet), meta };
  };

  /** Priority-fee bump so an urgent exit is not left sitting in the queue. */
  const gasOverrides = async (urgent) => {
    if (!urgent) return {};
    const mult = BigInt(Math.max(1, Math.round(esc.priorityMultiplier || 2)));
    const fd = await provider.getFeeData();
    const out = {};
    if (fd.maxPriorityFeePerGas) out.maxPriorityFeePerGas = fd.maxPriorityFeePerGas * mult;
    if (fd.maxFeePerGas) out.maxFeePerGas = fd.maxFeePerGas * mult;
    return out;
  };

  return {
    name: 'live',

    async buy({ priceUsd, sizeUsd, liqUsd, candidate, venue = 'amm' }) {
      const chain = candidate.chain;
      const { router, meta } = routerFor(chain);
      const token = candidate.pool.baseToken;
      const erc20 = new Contract(token, ERC20_ABI, wallet);
      const decimals = Number(await erc20.decimals().catch(() => 18));

      // USD -> native. This is the guard against spending 50 ETH for a "$50" trade.
      const nativeAmount = sizeUsd / nativeUsd;
      const value = parseUnits(nativeAmount.toFixed(18), 18);
      const expectedTokens = nativeAmount / priceUsd;
      const minOut = parseUnits(Math.max(0, expectedTokens * (1 - baseSlip)).toFixed(0), decimals);

      const tx = await router.swapExactETHForTokensSupportingFeeOnTransferTokens(
        minOut,
        [meta.wrapped, token],
        wallet.address,
        Math.floor(Date.now() / 1000) + 90,
        { value },
      );
      const receipt = await tx.wait();
      const bal = await erc20.balanceOf(wallet.address);
      const qty = Number(formatUnits(bal, decimals));

      return {
        fillPrice: qty > 0 ? sizeUsd / qty : priceUsd,
        qty,
        feeUsd: sizeUsd * (venueCostBps(cfg, venue) / 2 / 10000),
        spentUsd: sizeUsd,
        slippage: baseSlip,
        txHash: receipt?.hash || tx.hash,
      };
    },

    async sell({ position, priceUsd, fraction, urgent = false }) {
      const { router, meta } = routerFor(position.chain);
      const erc20 = new Contract(position.tokenAddress, ERC20_ABI, wallet);
      const decimals = Number(await erc20.decimals().catch(() => 18));
      const balance = await erc20.balanceOf(wallet.address);
      const frac = Math.min(1, Math.max(0, fraction));
      const amountIn = frac >= 1 ? balance : (balance * BigInt(Math.round(frac * 10000))) / 10000n;
      if (amountIn <= 0n) throw new Error('no token balance to sell');

      const allowance = await erc20.allowance(wallet.address, await router.getAddress());
      if (allowance < amountIn) {
        const ap = await erc20.approve(await router.getAddress(), MaxUint256);
        await ap.wait();
      }

      // Urgent exits widen tolerance so the swap is not rejected by a fast drop.
      const slip = urgent ? Math.max(baseSlip, (esc.slippagePct || 0) / 100) : baseSlip;
      const expectedOut = Number(formatUnits(amountIn, decimals)) * priceUsd;
      const minOut = parseUnits(Math.max(0, expectedOut * (1 - slip)).toFixed(12), 18);

      const tx = await router.swapExactTokensForETHSupportingFeeOnTransferTokens(
        amountIn,
        minOut,
        [position.tokenAddress, meta.wrapped],
        wallet.address,
        Math.floor(Date.now() / 1000) + 90,
        await gasOverrides(urgent),
      );
      const receipt = await tx.wait();

      const feeCostBps = (position.venueCostBps ?? venueCostBps(cfg, position.venue)) + (urgent ? (esc.extraBps || 0) : 0);
      const gross = expectedOut;
      const feeRate = feeCostBps / 2 / 10000;
      return {
        fillPrice: priceUsd * (1 - slip),
        qty: Number(formatUnits(amountIn, decimals)),
        grossUsd: gross,
        feeUsd: gross * feeRate,
        proceedsUsd: gross * (1 - feeRate),
        slippage: slip,
        escalated: urgent,
        txHash: receipt?.hash || tx.hash,
      };
    },
  };
}

function venueCostBps(cfg, venue) {
  return cfg.venues?.[venue]?.costBps ?? cfg.venues?.amm?.costBps ?? 1200;
}

export function liveChains() {
  return Object.keys(CHAINS);
}

export { CHAINS };
