import { EventEmitter } from 'node:events';
import { config as defaultConfig, derivedLiveAddress } from './config.js';
import * as gt from './feeds/geckoterminal.js';
import { tokenPairs, latestPools, allTokenPairs } from './feeds/dexscreener.js';
import { extractFeatures } from './ai/features.js';
import { SignalModel } from './ai/model.js';
import { Portfolio } from './portfolio.js';
import { evaluateExit, maxSizeForPool, exitFillPrice } from './strategy.js';
import { venueOf, exitsFor, worthEscalating, pickMigratedPool } from './venues.js';
import { analyzeRug, fastRugExit, entryQualityVeto } from './rug.js';
import { GateStats } from './gate-stats.js';
import { RugBlacklist, shouldBlacklist } from './rug-blacklist.js';
import { tokenOwnership, rpc as solanaRpc } from './feeds/ownership.js';
import { solscanHolders, solscanConfigured } from './feeds/solscan.js';
import { pumpfunHolders, pumpfunConfigured } from './feeds/pumpfun.js';
import { readTestWallet } from './feeds/wallet.js';
import { createPaperExecutor } from './exec/paper.js';

const MAX_LOGS = 400;

// Holder data is the one entry input that cannot be synthesised: it comes from
// Solana's getTokenLargestAccounts. GeckoTerminal returns no holder distribution
// for EVM tokens at all (checked on fresh Base pools and on a mature one), and
// there is no free on-chain alternative, so with REQUIRE_DATA on an EVM chain can
// never satisfy the gate. Scanning it would only spend rate limit on candidates
// that are certain to be vetoed.
const HOLDER_DATA_CHAINS = new Set(['solana']);

/** Chains worth scanning: those that can supply the data the entry gate needs. */
export function scannableChains(cfg) {
  const chains = Array.isArray(cfg?.chains) ? cfg.chains : [];
  if (cfg?.entryQuality?.requireData === false) return [...chains];
  return chains.filter((c) => HOLDER_DATA_CHAINS.has(c));
}

export class Engine {
  constructor(cfg = defaultConfig, { executor } = {}) {
    this.cfg = cfg;
    this.executor = executor;
    this.bus = new EventEmitter();
    this.bus.setMaxListeners(50);
    this.logs = [];
    this.paused = false;
    this.ticking = false;
    this.scanCount = 0;
    this.startedAt = Date.now();
    this.lastScanAt = null;
    this.scanStats = { found: 0, prefiltered: 0, evaluated: 0, vetoed: 0, belowThreshold: 0, entriesBlocked: 0, entered: 0 };
    // Which entry rule fired, and how the book has done since the gate went live.
    this.gate = GateStats.load();
    // Mints this book has already been rugged by, with a re-buy cooldown.
    this.rugBlacklist = new RugBlacklist(cfg);
    // Chains that can actually supply holder data; never fall back to idling.
    this.chains = scannableChains(cfg);
    this.chainsEmpty = this.chains.length === 0;
    if (this.chainsEmpty) this.chains = [...cfg.chains];
    this.lastEvaluated = [];
    this.lastPools = new Map();
    // Liquidity observations per token, so a pool that is already draining when
    // we first look at it can be vetoed instead of bought.
    this.rugWatch = new Map();
    this.errors = 0;
    // Last read of the test wallet's on-chain balances (paper mode only).
    this.walletView = null;
    this.walletSyncing = false;
  }

  async init() {
    this.portfolio = Portfolio.load(this.cfg);
    this.gate.ensureBaseline(this.portfolio.totals);
    this.model = SignalModel.load();
    if (!this.executor) {
      if (this.cfg.mode === 'live') {
        const { createLiveExecutor } = await import('./exec/live-evm.js');
        this.executor = await createLiveExecutor(this.cfg);
      } else {
        this.executor = createPaperExecutor(this.cfg);
      }
    }
    this.log('info', `engine ready in ${this.cfg.mode.toUpperCase()} mode on ${this.chains.join(', ')} | equity $${this.portfolio.equity().toFixed(2)}`);
    const skipped = this.cfg.chains.filter((c) => !this.chains.includes(c));
    if (skipped.length) {
      this.log('warn', `${skipped.join(', ')} not scanned: no holder data source, so every entry there would be vetoed (REQUIRE_DATA=on)`);
    }
    if (this.chainsEmpty) {
      this.log('error', `no configured chain can supply holder data; set CHAINS=solana or REQUIRE_DATA=off - scanning ${this.cfg.chains.join(', ')} anyway and the gate will veto there`);
    }
    if (this.cfg.mode === 'paper' && this.cfg.wallet?.paperAddress) {
      // Fire and forget: a slow or unauthorised RPC must not delay startup.
      this.syncTestWallet().catch(() => {});
    }
    return this;
  }

  log(level, message, data) {
    const entry = { at: Date.now(), level, message, ...(data ? { data } : {}) };
    this.logs.push(entry);
    if (this.logs.length > MAX_LOGS) this.logs.shift();
    this.bus.emit('log', entry);
    if (process.env.QUIET !== '1') {
      // A closed trade is not automatically a win: a -100% rug used to print 💰.
      const tag = { info: '  ', trade: '💰', loss: '🩸', skip: '·', warn: '!', error: '✖', score: '★' }[level] ?? '·';
      console.log(`${new Date(entry.at).toISOString().slice(11, 19)} ${tag} ${message}`);
    }
  }

  // ---------------------------------------------------------------------------
  // main loop
  // ---------------------------------------------------------------------------

  start() {
    if (this.timer) return this;
    const loop = async () => {
      const started = Date.now();
      await this.tick();
      if (!this.timer) return;
      const wait = Math.max(2000, this.cfg.scanIntervalMs - (Date.now() - started));
      this.timer = setTimeout(loop, wait);
    };
    this.timer = setTimeout(loop, 0);
    return this;
  }

  stop() {
    if (this.timer) clearTimeout(this.timer);
    this.timer = null;
  }

  async tick() {
    if (this.ticking) return;
    this.ticking = true;
    try {
      await this.refreshPositions();
      await this.managePositions();
      if (!this.paused) await this.discover();
      this.portfolio.recordEquity();
      this.portfolio.rollDay();
      this.lastScanAt = Date.now();
      this.save();
      this.bus.emit('state', this.state());
    } catch (err) {
      this.errors += 1;
      this.log('error', `tick failed: ${err.message}`);
    } finally {
      this.ticking = false;
    }
  }

  // ---------------------------------------------------------------------------
  // position management
  // ---------------------------------------------------------------------------

  async refreshPositions() {
    const byChain = new Map();
    for (const pos of this.portfolio.positions) {
      if (!byChain.has(pos.chain)) byChain.set(pos.chain, []);
      byChain.get(pos.chain).push(pos.poolAddress);
    }

    for (const [chain, pools] of byChain) {
      const snaps = await gt.poolSnapshots(chain, pools);
      const missing = [];
      for (const pos of this.portfolio.positions.filter((p) => p.chain === chain)) {
        const snap = snaps.get(pos.poolAddress);
        if (snap) this.applyPrice(pos, snap);
        else missing.push(pos);
      }
      // GeckoTerminal is the primary price feed but it is aggressively rate
      // limited; an exit rule is only as good as the last price, so fall back
      // to DexScreener per position rather than sitting on a stale one.
      for (const pos of missing) {
        const pair = await tokenPairs(chain, pos.tokenAddress);
        if (pair?.priceUsd > 0) {
          this.applyPrice(pos, { priceUsd: pair.priceUsd, liqUsd: pair.liqUsd });
          if (pair.liqUsd > 0 && pos.entryLiqUsd <= 0) pos.entryLiqUsd = pair.liqUsd;
        }
      }
    }
  }

  applyPrice(pos, snap) {
    // A held position has no tradeable pool: an empty pool's leftover quote
    // is not a valuation, and acting on it re-books the loss we just undid.
    if (pos.migrationHoldAt) return;
    const prevLiq = pos.lastLiqUsd;
    if (snap.priceUsd > 0) {
      const prev = pos.lastPrice;
      if (prev > 0) {
        const ratio = snap.priceUsd / prev;
        // A single print that quadruples or quarters the price is far more
        // likely a bad feed row than a real move, and acting on it manufactures
        // fills that never existed. Require a second read to agree first.
        if (ratio > 4 || ratio < 0.25) {
          const pending = pos.pendingPrice;
          const confirms = pending && Math.abs(Math.log(snap.priceUsd / pending)) < Math.log(1.15);
          if (!confirms) {
            pos.pendingPrice = snap.priceUsd;
            this.log('warn', `${pos.symbol}: ignoring ${ratio > 1 ? '+' : ''}${((ratio - 1) * 100).toFixed(0)}% single-tick jump, awaiting confirmation`);
            return;
          }
        }
      }
      pos.pendingPrice = null;
      // Per-tick deltas for the fast rug watch: what changed since the last
      // accepted snapshot, not since entry.
      pos.tickPxDropPct = prev > 0 ? 1 - snap.priceUsd / prev : null;
      pos.tickLiqDropPct = prevLiq > 0 && snap.liqUsd > 0 ? 1 - snap.liqUsd / prevLiq : null;
      pos.lastPrice = snap.priceUsd;
      pos.peakPx = Math.max(pos.peakPx || 0, snap.priceUsd);
      pos.lastPriceAt = Date.now();
    }
    // Only a real reading updates depth. A missing or zero liquidity figure is
    // a feed gap, not an emptied pool: DexScreener reports 0 liquidity for some
    // PumpSwap pairs that are demonstrably still trading at the same price, and
    // treating "unknown" as "zero" made exits fill at $0 on positions that were
    // up (a phantom loss). A pool that is genuinely drained also collapses the
    // price, which the price rules below still catch.
    const liqNow = Number(snap.liqUsd);
    if (Number.isFinite(liqNow) && liqNow > 0) {
      pos.lastObservedLiqUsd = liqNow;
      pos.lastLiqUsd = liqNow;
    }
    // Keep this current. It used to be written only once, at entry, so every exit
    // was evaluated against the price from when the position was opened: Musk was
    // sold at 2.443e-6 while its pool traded at 2.979e-5 (+75%), and FLOYD at -2%
    // while its pool was at +38%.
    if (snap.poolAddress) {
      this.lastPools.set(pos.poolAddress, { ...snap, priceUsd: pos.lastPrice, liqUsd: pos.lastLiqUsd || snap.liqUsd });
    }
  }

  async managePositions() {
    for (const pos of [...this.portfolio.positions]) {
      // A graduated token trades in a new pool; the old pair reports nothing.
      // Follow it before any exit rule can sell into the dead one. If no pool
      // can be found, the position stays rather than selling blind.
      if (await this.followMigration(pos)) continue;

      // Rug watch first: a drain in progress outranks every other exit rule.
      const fast = fastRugExit(pos, this.cfg);
      if (fast) {
        try {
          const urgent = worthEscalating(this.portfolio.netPnlPct(pos), fast.kind, this.cfg);
          await this.sell(pos, 1, fast.reason, urgent);
        } catch (err) {
          this.log('error', `fast rug exit failed for ${pos.symbol}: ${err.message}`);
        }
        continue;
      }

      const pool = this.lastPools.get(pos.poolAddress) || null;
      const ladderBefore = { ...pos.ladder };
      let decision;
      try {
        decision = evaluateExit(pos, pool, this.cfg);
      } catch (err) {
        this.log('error', `exit check failed for ${pos.symbol}: ${err.message}`);
        continue;
      }
      if (decision.action !== 'sell') continue;
      try {
        await this.sell(pos, decision.fraction, decision.reason, decision.urgent, decision.price);
      } catch (err) {
        pos.ladder = ladderBefore;
        this.log('error', `sell failed for ${pos.symbol}: ${err.message}`);
      }
    }
  }

  /**
   * Follow a token whose liquidity moved to a new pool.
   *
   * When a token graduates, the pair we bought in reports ~$0 while the token
   * keeps trading in the new one. Selling into the old pair is what booked total
   * losses on positions that were alive: the price printed there no longer means
   * anything. This rebinds the position to the deepest live pool instead.
   */
  async followMigration(pos) {
    // A position we already know is unpriced (its exit never had a tradeable
    // pool) is carried at cost until a pool appears: no repricing, no exit.
    if (pos.unpriced && pos.migrationHoldAt) {
      pos.lastPrice = pos.entryPrice;
      if (!(pos.peakPx > 0)) pos.peakPx = pos.entryPrice;
      return 'hold';
    }

    const entry = Number(pos.entryLiqUsd) || 0;
    const liq = Number(pos.lastLiqUsd) || 0;
    // Depth came back on the pool we hold: whatever was missing was a feed gap.
    if (pos.migrationHoldAt && entry > 0 && liq >= entry * 0.2) {
      pos.migrationHoldAt = null;
      pos.lastPoolCheckAt = 0;
      this.log('info', `${pos.symbol}: depth back to $${Math.round(liq)} on the same pool — exits resume`);
    }
    // A restored position has no entry depth to compare against and no pool to
    // price it: it waits on its hold instead of being sold at whatever prints.
    if (!(entry > 0)) return pos.migrationHoldAt ? 'hold' : false;
    if (liq >= entry * 0.2) return false;
    // Depth also reads $0 when the LP is staked or locked (frozen for months in
    // some graduations). The pool is alive and the price is still real, so this
    // is not a migration and must not freeze the position: only look for a new
    // pool when the price confirms the drain too.
    const px = Number(pos.lastPrice) || 0;
    const peak = Number(pos.peakPx) || 0;
    const priceFalling = !(px > 0) || (peak > 0 && px <= peak * 0.92);
    if (!priceFalling) return false;
    if (Date.now() - (pos.lastPoolCheckAt || 0) < 45000) return pos.migrationHoldAt ? 'hold' : false;
    pos.lastPoolCheckAt = Date.now();

    const floor = Math.max(500, entry * 0.1);
    // Two independent indexes: DexScreener lists pairs, GeckoTerminal lists the
    // token's pools even when DexScreener hasn't indexed the new one yet.
    let next = pickMigratedPool(await allTokenPairs(pos.chain, pos.tokenAddress), pos.poolAddress, floor);
    if (!next) next = pickMigratedPool(await gt.tokenPools(pos.chain, pos.tokenAddress), pos.poolAddress, floor);
    if (!next || !(next.priceUsd > 0)) {
      // Nothing to sell into and nowhere better to go: the position stays put.
      // Selling into a pool we cannot price is how a live token books -100%.
      if (!pos.migrationHoldAt) {
        pos.migrationHoldAt = Date.now();
        this.log(
          'warn',
          `${pos.symbol}: depth gone ($${Math.round(liq)} of $${Math.round(entry)} at entry) and no replacement pool indexed — holding instead of selling blind`,
        );
      }
      // No pool means no market price: carry it at cost rather than at the empty
      // pool's leftover quote, which books a loss nobody could trade.
      pos.lastPrice = pos.entryPrice;
      if (!(pos.peakPx > 0)) pos.peakPx = pos.entryPrice;
      return 'hold';
    }

    this.log(
      'info',
      `${pos.symbol}: liquidity moved to ${next.dex} ${String(next.poolAddress).slice(0, 8)}… ($${Math.round(next.liqUsd)}) — following the token there`,
    );
    const oldPool = pos.poolAddress;
    pos.poolAddress = next.poolAddress;
    pos.dex = next.dex;
    pos.entryLiqUsd = next.liqUsd;
    pos.lastLiqUsd = next.liqUsd;
    pos.lastObservedLiqUsd = next.liqUsd;
    pos.lastPrice = next.priceUsd;
    pos.peakPx = Math.max(pos.peakPx || 0, next.priceUsd);
    pos.tickLiqDropPct = null;
    pos.tickPxDropPct = null;
    pos.pendingPrice = null;
    pos.reboundAt = Date.now();
    pos.migrationHoldAt = null;
    this.lastPools.delete(oldPool);
    return 'rebound';
  }

  /** Depth an exit can realistically draw on right now. */
  exitDepth(pos) {
    const known = (v) => Number.isFinite(Number(v)) && Number(v) > 0;
    const observed = pos.lastObservedLiqUsd;
    const healthy = pos.lastLiqUsd;
    // Nothing observed this tick: fall back to the last real depth instead of
    // capping the fill at zero. A thin-but-real reading still wins, so a drained
    // pool can never pay out more than it holds.
    if (!known(observed)) return healthy;
    if (!known(healthy)) return observed;
    return Math.min(healthy, observed);
  }

  async sell(pos, fraction, reason, urgent = false, decisionPrice = null) {
    // Fill at the price the rule acted on. pos.lastPrice is the last confirmed
    // snapshot and can sit at the old high while a big drop waits for the feed's
    // confirmation guard, which is how peak-stop exits were booked at the peak.
    const fillPrice = exitFillPrice(pos.lastPrice, decisionPrice);
    const fill = await this.executor.sell({
      position: pos,
      priceUsd: fillPrice,
      fraction,
      liqUsd: this.exitDepth(pos),
      urgent,
      candidate: { chain: pos.chain, pool: { baseToken: pos.tokenAddress, poolAddress: pos.poolAddress } },
    });
    const applied = this.portfolio.applySell(pos, fraction, fill, reason);
    if (!applied) return;
    // Tag the sale by what it did, not by the fact that it happened.
    const soldBasis = pos.investedUsd * Math.min(1, fraction);
    const saleLevel = fill.proceedsUsd < soldBasis ? 'loss' : 'trade';
    this.log(
      saleLevel,
      `SOLD ${(Math.min(1, fraction) * 100).toFixed(0)}% ${pos.symbol} @ $${fill.fillPrice.toPrecision(4)} → $${fill.proceedsUsd.toFixed(2)} (${reason})` +
        (fill.escalated ? ' [fees escalated to land the exit]' : ''),
    );

    const dust = pos.qty * pos.lastPrice < 0.5;
    if (pos.qty <= 1e-12 || dust || fraction >= 1) {
      const trade = this.portfolio.closePosition(pos, reason);
      const kind = /liquidity pulled|fast rug watch/i.test(trade.exitReason || '') ? 'rug' : /take profit|trailing|time stop|momentum/i.test(trade.exitReason || '') ? 'profit' : 'stop';
      // Pin the mint. The exit knows what entry scoring could not: this token drains.
      if (shouldBlacklist({ kind, pnlPct: trade.pnlPct })) {
        const pin = this.rugBlacklist.block(pos.tokenAddress, {
          symbol: pos.symbol,
          reason: trade.exitReason,
          pnlPct: trade.pnlPct,
        });
        // Pin the name as well: copycats of whatever just drained show up within
        // minutes, and they are the expensive part.
        const symPin = this.rugBlacklist.blockSymbol(pos.symbol, { reason: trade.exitReason, mint: pos.tokenAddress });
        if (pin) {
          this.log(
            'info',
            `blacklisted ${pos.symbol} for ${pin.hours}h${symPin ? ` (name pinned too)` : ''}: ${trade.exitReason}`,
          );
        }
      }
      const learned = this.model.learn(trade.features, trade.pnlPct, { kind });
      if (learned) {
        this.model.save();
        this.log(
          learned.p < 0.5 !== trade.pnlPct > 0 ? 'warn' : 'info',
          `AI update: model confidence at entry ${(learned.p * 100).toFixed(0)}%, outcome ${(trade.pnlPct * 100).toFixed(1)}% (n=${this.model.samples})`,
        );
      }
      this.log(
        trade.pnlPct >= 0 ? 'trade' : 'loss',
        `CLOSED ${trade.symbol}: ${trade.pnlPct >= 0 ? '+' : ''}${(trade.pnlPct * 100).toFixed(1)}% ($${trade.pnlUsd.toFixed(2)}) in ${trade.heldSec}s | peak +${(trade.peakPnlPct * 100).toFixed(0)}%`,
      );
    }
    this.save();
  }

  // ---------------------------------------------------------------------------
  // discovery
  // ---------------------------------------------------------------------------

  async discover() {
    const cfg = this.cfg;
    const now = Date.now();
    const found = new Map();
    const pages = this.scanCount % 4 === 0 ? [1, 2] : [1];

    // Both discovery sources run concurrently: GeckoTerminal is the firehose of
    // brand-new pools, DexScreener's token profiles are independent and cheap.
    // Never let one throttled feed serialise the whole scan.
    const perChain = await Promise.allSettled(
      this.chains.map(async (chain) => {
        const [gtRes, dsRes] = await Promise.allSettled([
          (async () => {
            const out = [];
            for (const page of pages) out.push(...(await gt.newPools(chain, page)));
            return out;
          })(),
          latestPools(chain, 10),
        ]);
        return { chain, gt: gtRes, ds: dsRes };
      }),
    );

    for (const settled of perChain) {
      if (settled.status !== 'fulfilled') {
        this.log('warn', `discovery failed: ${settled.reason?.message || settled.reason}`);
        continue;
      }
      const { chain, gt: gtRes, ds: dsRes } = settled.value;
      const gtPools = gtRes.status === 'fulfilled' ? gtRes.value : [];
      const dsPools = dsRes.status === 'fulfilled' ? dsRes.value : [];
      if (gtRes.status === 'rejected') this.log('warn', `${chain} new_pools failed: ${gtRes.reason?.message || gtRes.reason}`);
      for (const pool of [...gtPools, ...dsPools]) {
        if (!found.has(pool.poolAddress)) found.set(pool.poolAddress, pool);
      }
      for (const pool of gtPools) this.lastPools.set(pool.poolAddress, pool);
      if (dsPools.length) this.log('info', `${chain}: ${gtPools.length} new pools from GeckoTerminal, ${dsPools.length} from DexScreener`);
    }
    this.scanCount += 1;

    // Record every pool we see, even the ones we will not evaluate: liquidity
    // decay between observations is the cheapest pre-rug signal there is.
    for (const pool of found.values()) this.observeLiquidity(pool);

    const held = new Set(this.portfolio.positions.map((p) => p.tokenAddress));
    const tokensThisScan = new Set();
    const candidates = [];
    for (const pool of [...found.values()].sort((a, b) => b.liqUsd - a.liqUsd)) {
      const ageSec = pool.createdAtMs ? (now - pool.createdAtMs) / 1000 : null;
      if (!pool.baseToken || !pool.priceUsd) continue;
      if (held.has(pool.baseToken)) continue;
      // Several pools can exist for the same token (v2 + v3 + a copycat
      // router); evaluate each token once, on its deepest pool.
      if (tokensThisScan.has(pool.baseToken)) continue;
      tokensThisScan.add(pool.baseToken);
      if (this.portfolio.seen[pool.poolAddress]) continue;
      if (ageSec === null || ageSec < cfg.minAgeSec || ageSec > cfg.maxAgeSec) continue;
      if (pool.liqUsd < cfg.minLiqUsd || pool.liqUsd > cfg.maxLiqUsd) continue;
      const t5 = pool.txns.m5.buys + pool.txns.m5.sells;
      if (t5 < cfg.minTxns5M) continue;
      const turnover = pool.vol.m5 / Math.max(pool.liqUsd, 1);
      const buyRatio = pool.txns.m5.buys / Math.max(t5, 1);
      candidates.push({ pool, ageSec, preRank: buyRatio * 0.55 + Math.min(1, turnover) * 0.45 });
    }

    candidates.sort((a, b) => b.preRank - a.preRank);
    this.scanStats = {
      found: found.size,
      prefiltered: candidates.length,
      evaluated: 0,
      vetoed: 0,
      belowThreshold: 0,
      entriesBlocked: 0,
      entered: 0,
    };

    const shortlist = candidates.slice(0, cfg.maxCandidatesPerScan);
    for (let i = 0; i < shortlist.length; i++) {
      const { pool, ageSec } = shortlist[i];
      this.portfolio.seen[pool.poolAddress] = now;
      try {
        // Candles are the most expensive enrichment: only spend them on the
        // strongest pre-ranked candidate of the scan.
        const keepOpen = await this.evaluateCandidate(pool, ageSec, i === 0);
        if (keepOpen) delete this.portfolio.seen[pool.poolAddress];
      } catch (err) {
        this.errors += 1;
        this.log('error', `evaluation failed for ${pool.symbol || pool.poolAddress}: ${err.message}`);
      }
    }

    // One line per scan, so the gate's effect stays visible in the log and not
    // only in the cumulative totals.
    const tally = this.gate.endScan();
    const fired = ['churn', 'safety', 'rug', 'other'].filter((k) => tally[k] > 0).map((k) => `${k} ${tally[k]}`);
    if (fired.length) {
      const c = this.gate.counts;
      this.log('info', `entry gate: vetoed ${fired.join(', ')} this scan | total churn ${c.churn}, safety ${c.safety}, rug ${c.rug}`);
    }
    this.gate.save();

    if (this.scanStats.evaluated === 0 && this.scanStats.prefiltered === 0) {
      this.log('skip', `scan: ${found.size} new pools, none passed the snipe filter`);
    }
  }

  /**
   * Enrich + score one candidate.
   * @returns {Promise<boolean>} true if entry was blocked by capacity, so the
   *   candidate should be re-considered on a later scan.
   */
  async evaluateCandidate(pool, ageSec, allowCandles) {
    const { chain, baseToken } = pool;

    // A mint that already drained out of this book is not worth re-buying however
    // healthy its new pool looks: GTA was bought and rugged three times in a row.
    const mintPin = this.rugBlacklist.check(baseToken);
    const symbolPin = pool.symbol ? this.rugBlacklist.checkSymbol(pool.symbol) : null;
    const pinned = mintPin || symbolPin;
    if (pinned) {
      const hoursLeft = Math.max(1, Math.round((Number(pinned.until) - Date.now()) / 3600000));
      // Six different mints called "Tradercat" were bought; the name is the
      // repeat in that case, not the token.
      const reason = mintPin
        ? `rug blacklist: ${pinned.symbol || 'this mint'} already drained out of a position, ${hoursLeft}h left`
        : `rug blacklist: ${pool.symbol} is a copycat name - a token called that drained out of a position, ${hoursLeft}h left`;
      this.scanStats.vetoed += 1;
      this.gate.record(reason);
      this.pushEvaluated({
        at: Date.now(),
        chain,
        symbol: pool.symbol,
        name: pool.name,
        poolAddress: pool.poolAddress,
        imageUrl: null,
        liqUsd: Math.round(pool.liqUsd || 0),
        ageSec: Math.round(ageSec),
        priceUsd: pool.priceUsd,
        venue: venueOf(pool),
        score: null,
        requiredScore: null,
        rug: { risk: null, level: 'blacklisted', signals: [pinned.reason].filter(Boolean) },
        veto: reason,
        reasons: [],
        decision: 'vetoed',
      });
      this.log('skip', `vetoed ${pool.symbol}: ${reason}`);
      return false;
    }

    const [info, ds, candles] = await Promise.all([
      gt.tokenInfo(chain, baseToken),
      tokenPairs(chain, baseToken),
      allowCandles ? gt.candles(chain, pool.poolAddress, { limit: 30 }).catch(() => []) : Promise.resolve([]),
    ]);

    // Ownership is on-chain only and Solana-specific; it is the one enrichment
    // that can see a bundler holding the float, so it goes in before scoring.
    let ownership = null;
    if (chain === 'solana') {
      // Holder tables, cheapest first. pump.fun's own /mint-positions lists the
      // wallets holding a position in the mint in one request; it needs the mint
      // supply, which is one light getTokenSupply call (unlike the throttled
      // getTokenLargestAccounts). Any failure falls through to the next source.
      if (pumpfunConfigured(this.cfg)) {
        let supply = 0;
        try {
          const sup = await solanaRpc(this.cfg, 'getTokenSupply', [baseToken]);
          supply = Number(sup?.value?.uiAmount) || 0;
        } catch {
          supply = 0;
        }
        const viaPump = await pumpfunHolders(this.cfg, baseToken, {
          poolAddresses: [pool.poolAddress],
          devAddress: info?.devAddress || null,
          supply,
        });
        if (viaPump.ok) ownership = viaPump;
        else if (viaPump.quiet) {
          // Key not approved yet, wrong scope, or throttled: say it once.
          if (!this.pumpfunQuiet) {
            this.pumpfunQuiet = true;
            this.log('info', `pump.fun holders off: ${viaPump.reason} - using the next holder source`);
          }
        } else {
          this.log('warn', `pump.fun holders unavailable for ${pool.symbol}: ${viaPump.reason} - falling back`);
        }
      }

      // Solscan next when a key is configured: one request instead of two RPC
      // calls, and it survives the throttling that otherwise vetoes a launch for
      // a missing holder table. Any failure falls back to the on-chain walk.
      if (!ownership?.ok && solscanConfigured(this.cfg)) {
        const viaSolscan = await solscanHolders(this.cfg, baseToken, {
          poolAddresses: [pool.poolAddress],
          devAddress: info?.devAddress || null,
        });
        if (viaSolscan.ok) ownership = viaSolscan;
        else if (viaSolscan.quiet) {
          // Expected with the free plan: say it once, then stay quiet and fall back.
          if (!this.solscanQuiet) {
            this.solscanQuiet = true;
            this.log('info', `solscan holders off: ${viaSolscan.reason} - holders come from the RPC walk`);
          }
        } else {
          this.log('warn', `solscan holders unavailable for ${pool.symbol}: ${viaSolscan.reason} - using the RPC walk`);
        }
      }
      if (!ownership?.ok) {
        try {
          ownership = await tokenOwnership(this.cfg, baseToken, {
            poolAddress: pool.poolAddress,
            devAddress: info?.devAddress || null,
            deep: Boolean(this.cfg.ownership?.deep),
          });
        } catch (err) {
          this.log('warn', `ownership lookup failed for ${pool.symbol}: ${err.message}`);
        }
      }
    }

    const cand = { chain, pool, info, ds, candles, ageSec, ownership, venue: venueOf(pool) };
    const { features, reasons, veto, volToLiq5m, missing } = extractFeatures(cand, this.cfg);
    const rug = analyzeRug(cand, this.cfg, { history: this.rugWatch.get(baseToken) });
    // Mechanical reasons to skip a launch the rug score and the model would both
    // accept: missing inputs, churned liquidity, a weak safety profile.
    const quality = entryQualityVeto({ features, volToLiq5m, missing }, this.cfg);
    cand.rug = rug;
    this.scanStats.evaluated += 1;

    const base = {
      at: Date.now(),
      chain,
      symbol: pool.symbol || info?.symbol || '???',
      name: info?.name || pool.name,
      poolAddress: pool.poolAddress,
      imageUrl: info?.imageUrl || ds?.imageUrl || null,
      liqUsd: Math.round(pool.liqUsd),
      ageSec: Math.round(ageSec),
      priceUsd: pool.priceUsd,
      venue: cand.venue,
      score: null,
      requiredScore: null,
      rug: { risk: rug.risk, level: rug.level, signals: rug.signals.slice(0, 4).map((s) => s.detail) },
      veto: veto || quality || rug.veto || null,
      reasons,
    };

    const gate = veto || quality;
    if (gate || rug.veto) {
      const reason = gate || `rug ${rug.risk}/100 — ${rug.veto}`;
      this.scanStats.vetoed += 1;
      this.gate.record(reason);
      this.pushEvaluated({ ...base, decision: 'vetoed' });
      this.log('skip', `vetoed ${base.symbol}: ${reason}`);
      return false;
    }

    const { score, contributions } = this.model.score(features);
    // A coin with real rug indicators has to be a materially better bet, not
    // merely a passing one: risk raises the bar before it blocks outright.
    const required = this.cfg.minScore + (rug.risk >= this.cfg.rug.bonusFromRisk ? this.cfg.rug.scoreBonus : 0);
    base.score = score;
    base.requiredScore = required;
    base.contributions = contributions.slice(0, 6);

    if (score < required) {
      this.scanStats.belowThreshold += 1;
      this.pushEvaluated({ ...base, decision: 'below-threshold' });
      this.log(
        'score',
        `${base.symbol} scored ${(score * 100).toFixed(0)}% < ${(required * 100).toFixed(0)}% (rug ${rug.risk}/100, liq $${base.liqUsd}, age ${base.ageSec}s)`,
      );
      return false;
    }

    const block = this.portfolio.entryBlock(baseToken);
    if (block) {
      this.scanStats.entriesBlocked += 1;
      this.pushEvaluated({ ...base, decision: 'blocked', veto: block });
      this.log('skip', `${base.symbol} passed (${(score * 100).toFixed(0)}%) but entry blocked: ${block}`);
      return block === 'max positions reached' || block === 'insufficient cash';
    }

    await this.enter({ ...cand, features, reasons, score });
    return false;
  }

  observeLiquidity(pool) {
    const token = pool?.baseToken;
    if (!token || !(pool.liqUsd > 0)) return;
    const prev = this.rugWatch.get(token);
    if (!prev) {
      this.rugWatch.set(token, {
        firstLiqUsd: pool.liqUsd,
        minLiqUsd: pool.liqUsd,
        firstSeenAt: Date.now(),
        samples: 1,
      });
      if (this.rugWatch.size > 600) this.rugWatch.delete(this.rugWatch.keys().next().value);
      return;
    }
    prev.minLiqUsd = Math.min(prev.minLiqUsd, pool.liqUsd);
    prev.lastLiqUsd = pool.liqUsd;
    prev.samples += 1;
  }

  pushEvaluated(entry) {
    this.lastEvaluated.unshift(entry);
    if (this.lastEvaluated.length > 40) this.lastEvaluated.length = 40;
  }

  async enter(cand) {
    const { pool } = cand;
    let sizeUsd = this.portfolio.sizeForEntry();
    sizeUsd = Math.min(sizeUsd, maxSizeForPool(pool.liqUsd, this.cfg));
    sizeUsd = Math.floor(sizeUsd * 100) / 100;
    const minTrade = this.cfg.minTradeUsd ?? 1;
    if (sizeUsd < minTrade) {
      this.log('skip', `size too small for ${pool.symbol} ($${sizeUsd.toFixed(2)} < $${minTrade})`);
      return;
    }

    const fill = await this.executor.buy({
      priceUsd: pool.priceUsd,
      sizeUsd,
      liqUsd: pool.liqUsd,
      venue: cand.venue,
      candidate: cand,
    });

    const pos = this.portfolio.openPosition({
      candidate: cand,
      sizeUsd,
      fill,
      score: cand.score,
      features: cand.features,
      reasons: cand.reasons,
      mode: this.executor.name,
    });

    this.scanStats.entered += 1;
    this.pushEvaluated({
      at: Date.now(),
      chain: cand.chain,
      symbol: pos.symbol,
      name: pos.name,
      poolAddress: pos.poolAddress,
      imageUrl: pos.imageUrl,
      liqUsd: Math.round(pool.liqUsd),
      ageSec: Math.round(cand.ageSec),
      priceUsd: pool.priceUsd,
      score: cand.score,
      requiredScore: this.cfg.minScore + (cand.rug.risk >= this.cfg.rug.bonusFromRisk ? this.cfg.rug.scoreBonus : 0),
      rug: { risk: cand.rug.risk, level: cand.rug.level, signals: cand.rug.signals.slice(0, 4).map((s) => s.detail) },
      veto: null,
      reasons: cand.reasons,
      decision: 'entered',
    });
        this.log(
      'trade',
      `SNIPED ${pos.symbol} on ${pos.chain} [${pos.venue}] @ $${fill.fillPrice.toPrecision(4)} | $${sizeUsd.toFixed(2)} | score ${(cand.score * 100).toFixed(0)}% | liq $${Math.round(pool.liqUsd)} | ${pos.reasons.slice(0, 2).join(', ')}`,
    );
    this.save();
  }

  // ---------------------------------------------------------------------------
  // introspection
  // ---------------------------------------------------------------------------

  save() {
    try {
      this.portfolio.save();
    } catch (err) {
      this.log('error', `state save failed: ${err.message}`);
    }
  }

  /**
   * Wipe the book and the learned model without restarting the process. Paper
   * mode only: in live mode this would hide real history.
   */
  resetBook({ cash, reason = 'paper book reset from the dashboard' } = {}) {
    if (this.cfg.mode === 'live') throw new Error('reset is paper-mode only');
    this.portfolio = new Portfolio(this.cfg, cash > 0 ? { cash, startingBankroll: cash } : {});
    this.model = new SignalModel();
    this.portfolio.save();
    this.model.save();
    this.lastEvaluated = [];
    this.lastPools.clear();
    this.rugWatch.clear();
    this.scanCount = 0;
    this.log('info', `${reason} | equity $${this.portfolio.equity().toFixed(2)}`);
    this.bus.emit('state', this.state());
  }

  /**
   * Read the test wallet's real SOL + token balances. Seeds the paper book from
   * the SOL side when it is empty (or when reset is asked for explicitly): the
   * tokens are holdings outside the book, not cash the bot can trade with.
   */
  async syncTestWallet({ reset = false } = {}) {
    if (this.cfg.mode === 'live') throw new Error('test wallet sync is paper-mode only');
    const address = this.cfg.wallet?.paperAddress;
    if (!address) throw new Error('set a test wallet address in Settings first');
    if (this.walletSyncing) return this.walletView;
    this.walletSyncing = true;
    try {
      const network = this.cfg.wallet?.network || 'mainnet';
      const view = await readTestWallet(this.cfg, address, { network });
      delete view.seeded;
      const empty = this.portfolio.positions.length === 0 && this.portfolio.totals.trades === 0;
      // Automatic seeding trusts a wallet roughly the size of a test stake; a
      // seven-figure balance means the wrong address was pasted, so the book is
      // left alone (an explicit reseed still honours it).
      const sane = view.solUsd <= Math.max(100, this.cfg.bankroll * 100);
      const seed = (reset || empty) && view.solUsd > 0 && (reset || sane);
      if (seed) {
        this.resetBook({
          cash: view.solUsd,
          reason: reset ? 'paper book reseeded from the test wallet' : 'paper book opened at the test wallet balance',
        });
        view.seeded = true;
      }
      this.walletView = view;
      this.log(
        'info',
        `test wallet [${network}] ${address.slice(0, 4)}…${address.slice(-4)}: ${view.sol.toFixed(4)} SOL ($${view.solUsd.toFixed(2)})` +
          (view.tokenCount ? ` + ${view.tokenCount} token${view.tokenCount === 1 ? '' : 's'} ~$${view.tokenUsd.toFixed(2)}` : '') +
          (view.seeded ? ` | book seeded at $${view.solUsd.toFixed(2)}` : empty && view.solUsd > 0 && !seed ? ' | not seeding from this balance' : ''),
      );
      this.bus.emit('state', this.state());
      return this.walletView;
    } catch (err) {
      this.walletView = { ...(this.walletView || {}), address, error: err.message, at: Date.now() };
      this.log('warn', `test wallet read failed: ${err.message}`);
      this.bus.emit('state', this.state());
      throw err;
    } finally {
      this.walletSyncing = false;
    }
  }

  setPaused(paused) {
    this.paused = Boolean(paused);
    this.log('info', this.paused ? 'scanning paused - managing open positions only' : 'scanning resumed');
    this.bus.emit('state', this.state());
  }

  state() {
    return {
      status: {
        mode: this.cfg.mode,
        executor: this.executor?.name,
        paused: this.paused,
        ticking: this.ticking,
        chains: this.chains,
        startedAt: this.startedAt,
        lastScanAt: this.lastScanAt,
        scanIntervalMs: this.cfg.scanIntervalMs,
        errors: this.errors,
        scans: this.scanCount,
        wallet: {
          paper: this.cfg.wallet?.paperAddress || '',
          network: this.cfg.wallet?.network || 'mainnet',
          live: this.cfg.wallet?.liveAddress || '',
          liveKeyAddress: derivedLiveAddress(this.cfg),
          balances: this.walletView,
        },
        settings: {
          bankroll: this.cfg.bankroll,
          positionSizePct: this.cfg.positionSizePct,
          maxPositions: this.cfg.maxPositions,
          minScore: this.cfg.minScore,
          minLiqUsd: this.cfg.minLiqUsd,
          maxLiqUsd: this.cfg.maxLiqUsd,
          minAgeSec: this.cfg.minAgeSec,
          maxAgeSec: this.cfg.maxAgeSec,
          roundTripCostBps: this.cfg.roundTripCostBps,
          exits: this.cfg.exits,
          venues: Object.fromEntries(
            Object.entries(this.cfg.venues).map(([k, v]) => [k, { label: v.label, costBps: v.costBps, exits: v.exits }]),
          ),
          exitEscalation: this.cfg.exitEscalation,
          rug: this.cfg.rug,
          rugWatch: this.cfg.rugWatch,
          ownership: { enabled: this.cfg.ownership.enabled, deep: this.cfg.ownership.deep },
        },
      },
      portfolio: this.portfolio.snapshot(),
      model: this.model.stats(),
      scan: { ...this.scanStats, recent: this.lastEvaluated.slice(0, 25) },
      gate: this.gate.view(this.portfolio.totals),
      logs: this.logs.slice(-120).reverse(),
    };
  }
}
