// Venue profiles.
//
// A trade's economics depend on where it happens. A generic DEX pool costs
// roughly 12% all-in to round trip (LP fee + priority fee + slippage on thin
// meme liquidity). A pump.fun bonding curve charges a flat 1.25% and has no LP
// to slip against, so a +18% move is real profit there while it is noise on an
// AMM. One global cost/threshold set cannot serve both, so every position
// carries a venue and each venue has its own cost model and exit plan.

const CURVE_DEXES = new Set(['pump-fun', 'pumpfun', 'pump_fun', 'pumpfun-curve']);
const PUMPSWAP_DEXES = new Set(['pumpswap', 'pump-amm', 'pumpamm', 'pump_swap']);

export const VENUE_LABELS = {
  amm: 'DEX pool',
  curve: 'pump.fun curve',
  pumpswap: 'PumpSwap',
};

/**
 * Which venue profile a pool belongs to.
 * @param {{dex?: string}} pool
 * @returns {'amm'|'curve'|'pumpswap'}
 */
export function venueOf(pool) {
  const dex = String(pool?.dex || '').toLowerCase();
  if (CURVE_DEXES.has(dex)) return 'curve';
  if (PUMPSWAP_DEXES.has(dex)) return 'pumpswap';
  return 'amm';
}

/**
 * Fraction of a notional you actually realise when crossing a pool.
 *
 * Modelled as a constant-product curve (x*y=k) rather than a linear haircut: a
 * $50 order into $20k of liquidity costs ~0.5%, the same order into $100 of
 * liquidity returns almost nothing, and into an emptied pool returns exactly
 * nothing. The linear version this replaced capped the loss at 35%, which let
 * paper mode "sell" a bag at a 24x price into a pool that no longer existed.
 *
 * @param {number} notionalUsd size being traded
 * @param {number} liqUsd total pool liquidity (both sides)
 * @returns {number} 0..1 multiplier on the quoted price
 */
export function depthFillRate(notionalUsd, liqUsd) {
  const n = Number(notionalUsd);
  if (!(n > 0)) return 1;
  const depth = Math.max(Number(liqUsd) || 0, 0) / 2; // quote side of the pool
  if (!(depth > 0)) return 0;
  const keep = depth / (depth + n) - 0.002; // fixed overhead: priority fee, rounding
  return Math.max(0, Math.min(1, keep));
}

/**
 * The liquidity figure a sale can actually be priced against.
 *
 * A pool cannot lose 99% of its depth between two reads without the price moving
 * with it, so a reading like that is a feed gap, not a drain — and pricing a sale
 * against it paid out nothing at all. Four exits were booked as -100% while their
 * quotes were up 3%, 5% and 9%. A $0 reading is never usable, and one below 1% of
 * the depth we bought into is treated the same way: fall back to the entry depth,
 * where slippage is modelled honestly. If the pool really did drain, the price has
 * collapsed too and the fill is small anyway.
 */
export function exitDepth(pos, liqUsd, notionalUsd = 0, priceUsd = null) {
  const reported = Number(liqUsd);
  const entry = Number(pos?.entryLiqUsd) || 0;
  const px = Number(priceUsd ?? pos?.lastPrice) || 0;
  const entryPx = Number(pos?.entryPrice) || 0;
  // Only an absurd multiple counts as a stale print in a pool reporting no depth
  // (the 23,000x case the old cap existed for). A 1.5x threshold was wrong: a
  // position up 75% in a pool that briefly reported $0 depth was paid out at $0
  // and booked -86% on a winner, which is the bug it was meant to prevent.
  const staleWin = entryPx > 0 && px > entryPx * 20;
  if (!(reported > 0)) {
    if (staleWin) return 0;
    return entry > 0 ? entry : Math.max(Number(notionalUsd) || 0, 1);
  }
  if (entry > 0 && reported < entry * 0.01) return staleWin ? reported : entry;
  return reported;
}

/**
 * The pool a graduated token now trades in, or null if it hasn't moved.
 *
 * A token that graduates leaves the old pair reporting ~$0 while it trades on in
 * a new one. Selling into the old pair is what booked total losses on live
 * positions; the token has to be followed, not dumped.
 */
export function pickMigratedPool(pairs = [], currentPool = '', minLiq = 500) {
  const live = (pairs || [])
    .filter((p) => String(p.poolAddress) !== String(currentPool) && Number(p.liqUsd) >= Math.max(1, minLiq))
    .sort((a, b) => Number(b.liqUsd) - Number(a.liqUsd));
  return live[0] || null;
}

export function venueProfile(cfg, venue) {
  return cfg.venues?.[venue] || cfg.venues?.amm || { costBps: 1200, exits: {} };
}

/** Round-trip cost in basis points for a venue. */
export function costBpsFor(cfg, venue) {
  return venueProfile(cfg, venue).costBps;
}

/** Exit threshold set for a venue. */
export function exitsFor(cfg, venue) {
  return venueProfile(cfg, venue).exits;
}

/**
 * What escalation costs, in basis points of the position.
 *
 * Escalation buys nothing but speed: a higher priority fee (gas) and a wider
 * slippage tolerance (price). Expressing both in bps lets the caller check them
 * against the profit at stake before spending anything.
 */
export function escalationCostBps(cfg) {
  const esc = cfg.exitEscalation || {};
  const extra = Number(esc.extraBps) || 0;
  const slip = ((Number(esc.slippagePct) || 0) * 100) / 2; // half the widened tolerance
  return extra + slip;
}

/**
 * Should this exit pay extra to guarantee it lands?
 *
 * Entries never escalate. Stop losses do not either: the token is already
 * underwater, and paying more to sell at a loss only deepens it. Escalation is
 * reserved for taking profit (locking in gains is worth a higher fee) and for
 * rug escapes (getting out at any cost beats holding a dead pool).
 *
 * @param {number} pnlPct net PnL of the position right now
 * @param {'profit'|'rug'|'stop'} kind
 * @param {object} cfg
 */
export function shouldEscalate(pnlPct, kind, cfg) {
  const raw = String(cfg.exitEscalation?.policy ?? 'profit,rug').toLowerCase().trim();
  if (!raw || raw === 'off' || raw === 'none') return false;
  const parts = raw.split(',').map((s) => s.trim());
  if (parts.includes('all')) return true;
  if (parts.includes('rug') && kind === 'rug') return true;
  if (parts.includes('profit') && kind === 'profit' && pnlPct > 0) return true;
  return false;
}

/**
 * Is paying for the exit worth it?
 *
 * Policy alone says *when* escalation is allowed; this says whether it still
 * leaves money on the table. A +2% trailing exit that pays 4.5% for the rush is
 * a loss dressed as a profit-taking, so the exit goes out at the base fee
 * instead. Rug escapes skip the check: the pool is dead, the fee is gas, and
 * anything beats holding.
 *
 * @param {number} pnlPct net PnL of the position right now
 * @param {'profit'|'rug'|'stop'} kind
 * @param {object} cfg
 */
export function worthEscalating(pnlPct, kind, cfg) {
  if (!shouldEscalate(pnlPct, kind, cfg)) return false;
  if (kind === 'rug') return true;
  return pnlPct * 10000 > escalationCostBps(cfg);
}
