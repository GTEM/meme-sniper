import { writeJson, readJson, ensureDataDir } from './lib/store.js';
import { costBpsFor, exitsFor, venueOf, depthFillRate, exitDepth } from './venues.js';

const round = (x, d = 4) => Math.round(x * 10 ** d) / 10 ** d;

export function dayKey(ts = Date.now()) {
  return new Date(ts).toISOString().slice(0, 10);
}

/**
 * How a closed trade should be counted.
 *
 *  win   net positive
 *  fees  the price rose, but the round trip cost more than it made
 *  loss  the price fell
 *
 * A trade that exited above its entry is never counted as a loss; when fees are
 * what turned it negative it is counted in the fee bucket instead, so the loss
 * column only ever holds trades where the price went against us.
 */
export function outcomeOf(t = {}) {
  const net = Number(t.pnlUsd) || 0;
  if (net >= 0) return 'win';
  const gross = Number.isFinite(Number(t.grossPnlUsd))
    ? Number(t.grossPnlUsd)
    : net + (Number(t.feesUsd) || 0);
  return gross > 0 ? 'fees' : 'loss';
}

/**
 * Portfolio + risk accounting. Every number the UI shows comes from here.
 * Cash accounting is explicit so a live-mode swap and a paper fill go through
 * the exact same bookkeeping path.
 */
export class Portfolio {
  constructor(cfg, saved = {}) {
    this.cfg = cfg;
    this.cash = Number.isFinite(saved.cash) ? saved.cash : cfg.bankroll;
    this.startingBankroll = saved.startingBankroll ?? cfg.bankroll;
    this.positions = saved.positions || [];
    this.trades = saved.trades || [];
    this.equityCurve = saved.equityCurve || [];
    this.day = saved.day || { key: dayKey(), startEquity: this.startingBankroll, realized: 0 };
    this.consecutiveLosses = saved.consecutiveLosses || 0;
    this.cooldowns = saved.cooldowns || {};
    this.pausedUntil = saved.pausedUntil || null;
    this.seen = saved.seen || {};
    this.totals = saved.totals || { trades: 0, wins: 0, losses: 0, realizedUsd: 0, feesUsd: 0 };
    // Migrate positions saved before venues existed, and before the peak was
    // seeded properly (a net PnL of exactly zero is impossible with exit costs).
    for (const p of this.positions) {
      if (!p.venue) {
        p.venue = venueOf({ dex: p.dex });
        p.venueCostBps = costBpsFor(this.cfg, p.venue);
      }
      if (p.peakPnlPct === 0) p.peakPnlPct = this.netPnlPct(p, p.entryPrice);
    }
    // The tallies are derived from the trades themselves, never accumulated
    // separately: realizedUsd used to charge the whole basis again on a closing
    // leg after a partial profit, so 60 trades summed to $10.66 while the
    // dashboard reported $2.13.
    this.recount();
  }

  /**
   * Count the book: a trade that exited above its entry is not a loss.
   *
   *  win   net positive
   *  fees  the price rose, but the round trip cost more than it made
   *  loss   the price fell
   *
   * The fee bucket is kept separate so a fee-eaten winner never reads as a loss.
   */
  recount() {
    let wins = 0;
    let losses = 0;
    let feeLosses = 0;
    let feeLossUsd = 0;
    for (const t of this.trades || []) {
      const kind = outcomeOf(t);
      if (kind === 'win') wins += 1;
      else if (kind === 'fees') {
        feeLosses += 1;
        feeLossUsd += Number(t.pnlUsd) || 0;
      } else losses += 1;
    }
    const trades = this.trades || [];
    this.totals.trades = trades.length;
    this.totals.wins = wins;
    this.totals.losses = losses;
    this.totals.feeLosses = feeLosses;
    this.totals.feeLossUsd = round(feeLossUsd, 2);
    this.totals.realizedUsd = round(trades.reduce((s, t) => s + (Number(t.pnlUsd) || 0), 0), 2);
    return this.totals;
  }

  // -- valuation -----------------------------------------------------------

  positionValue(pos, price = pos.lastPrice) {
    return pos.qty * price;
  }

  exposure() {
    return this.positions.reduce((s, p) => s + this.positionValue(p), 0);
  }

  equity() {
    return this.cash + this.exposure();
  }

  /** Net PnL of a position in dollars, including the cost to exit right now. */
  netPnlUsd(pos, price = pos.lastPrice, liqUsd = pos.lastLiqUsd) {
    const costBps = pos.venueCostBps ?? costBpsFor(this.cfg, pos.venue);
    const exitValue = estimateExitValue(pos, price, liqUsd, costBps);
    return pos.realizedUsd + exitValue - pos.investedUsd;
  }

  netPnlPct(pos, price = pos.lastPrice, liqUsd = pos.lastLiqUsd) {
    if (!pos.investedUsd) return 0;
    return this.netPnlUsd(pos, price, liqUsd) / pos.investedUsd;
  }

  // -- risk gates ----------------------------------------------------------

  sizeForEntry() {
    const equity = this.equity();
    const target = (equity * this.cfg.positionSizePct) / 100;
    return Math.max(0, Math.min(target, this.cash * 0.98));
  }

  /** @returns {string|null} reason entry is blocked */
  entryBlock(tokenAddress) {
    const now = Date.now();
    if (this.pausedUntil && this.pausedUntil > now) return 'risk pause active';
    if (this.positions.length >= this.cfg.maxPositions) return 'max positions reached';
    if (this.cash < (this.cfg.minTradeUsd ?? 1)) return `insufficient cash (min trade $${this.cfg.minTradeUsd ?? 1})`;
    if (this.positions.some((p) => p.tokenAddress === tokenAddress)) return 'already holding';
    if (this.isCoolingDown(tokenAddress, now)) return 'token cooling down after loss';
    if (this.consecutiveLosses >= this.cfg.maxConsecutiveLosses)
      return `${this.consecutiveLosses} losses in a row - halted`;
    const day = this.rollDay(now);
    if (day.startEquity > 0) {
      const dd = (this.equity() - day.startEquity) / day.startEquity;
      if (dd <= -this.cfg.dailyLossCapPct / 100) return `daily loss cap hit (${(dd * 100).toFixed(1)}%)`;
    }
    return null;
  }

  isCoolingDown(tokenAddress, now = Date.now()) {
    const until = this.cooldowns[tokenAddress];
    return Boolean(until && until > now);
  }

  cooldown(tokenAddress, minutes, now = Date.now()) {
    this.cooldowns[tokenAddress] = now + minutes * 60 * 1000;
  }

  rollDay(now = Date.now()) {
    const key = dayKey(now);
    if (this.day.key !== key) {
      this.day = { key, startEquity: this.equity(), realized: 0 };
    }
    return this.day;
  }

  // -- mutations -----------------------------------------------------------

  openPosition({ candidate, sizeUsd, fill, score, features, reasons, mode }) {
    const venue = candidate.venue || venueOf(candidate.pool);
    const pos = {
      id: `${Date.now().toString(36)}${Math.random().toString(36).slice(2, 6)}`,
      chain: candidate.chain,
      venue,
      venueCostBps: costBpsFor(this.cfg, venue),
      poolAddress: candidate.pool.poolAddress,
      tokenAddress: candidate.pool.baseToken,
      symbol: candidate.pool.symbol || candidate.info?.symbol || '???',
      name: candidate.info?.name || candidate.pool.name,
      imageUrl: candidate.info?.imageUrl || candidate.ds?.imageUrl || null,
      dex: candidate.pool.dex,
      mode,
      entryAt: Date.now(),
      entryPrice: fill.fillPrice,
      qty: fill.qty,
      investedUsd: sizeUsd,
      realizedUsd: 0,
      peakPx: fill.fillPrice,
      // Seed with the net PnL at the entry price (negative, because the exit
      // cost is already priced in) so the running peak starts from reality.
      peakPnlPct: 0,
      lastPrice: fill.fillPrice,
      lastLiqUsd: candidate.pool.liqUsd,
      entryLiqUsd: candidate.pool.liqUsd,
      entryMcapUsd: candidate.pool.mcapUsd,
      ageAtEntrySec: candidate.ageSec,
      score: round(score, 4),
      rugRisk: candidate.rug?.risk ?? null,
      rugSignals: candidate.rug?.signals?.slice(0, 3).map((s) => s.detail) ?? null,
      features,
      reasons,
      ladder: { tp1: false, tp2: false },
      trailArmed: false,
      pnlHistory: [],
      walletTx: fill.txHash || null,
      fills: [{ side: 'buy', at: Date.now(), price: fill.fillPrice, qty: fill.qty, feeUsd: fill.feeUsd }],
      // Fees are tracked per position so a closed trade can report what the
      // round trip actually cost, not just the net PnL.
      feesUsd: Number(fill.feeUsd) || 0,
    };
    this.totals.feesUsd += Number(fill.feeUsd) || 0;
    pos.peakPnlPct = this.netPnlPct(pos, pos.entryPrice);
    this.cash -= sizeUsd;
    this.positions.push(pos);
    return pos;
  }

  /** Sell `fraction` of the remaining position at `fill`. */
  applySell(pos, fraction, fill, reason) {
    const frac = Math.max(0, Math.min(1, fraction));
    const qty = frac >= 1 ? pos.qty : pos.qty * frac;
    if (qty <= 0) return null;
    const proceeds = fill.proceedsUsd;
    pos.qty = Math.max(0, pos.qty - qty);
    pos.realizedUsd += proceeds;
    pos.feesUsd = (Number(pos.feesUsd) || 0) + (Number(fill.feeUsd) || 0);
    pos.fills.push({
      side: 'sell',
      at: Date.now(),
      price: fill.fillPrice,
      qty,
      proceedsUsd: round(proceeds, 2),
      reason,
      fraction: round(frac, 3),
      txHash: fill.txHash || null,
    });
    this.cash += proceeds;
    this.totals.feesUsd += fill.feeUsd || 0;
    this.totals.realizedUsd += proceeds - pos.investedUsd * frac;
    return { qty, proceeds };
  }

  /** Remove a position once fully sold and grade the trade. */
  closePosition(pos, reason) {
    const pnlUsd = pos.realizedUsd - pos.investedUsd;
    const pnlPct = pos.investedUsd ? pnlUsd / pos.investedUsd : 0;
    const trade = {
      id: pos.id,
      chain: pos.chain,
      symbol: pos.symbol,
      name: pos.name,
      tokenAddress: pos.tokenAddress,
      poolAddress: pos.poolAddress,
      mode: pos.mode,
      venue: pos.venue,
      openedAt: pos.entryAt,
      closedAt: Date.now(),
      heldSec: Math.round((Date.now() - pos.entryAt) / 1000),
      entryPrice: pos.entryPrice,
      // The price we actually sold at, not the last price the feed reported.
      // pos.lastPrice is updated after the sale, so a trade that filled at +3.8%
      // showed "exit +19%" next to a +2.3% result and looked mislabelled.
      exitPrice: [...(pos.fills || [])].reverse().find((f) => f.side === 'sell')?.price ?? pos.lastPrice,
      investedUsd: round(pos.investedUsd, 2),
      returnedUsd: round(pos.realizedUsd, 2),
      pnlUsd: round(pnlUsd, 2),
      pnlPct: round(pnlPct, 4),
      peakPnlPct: round(pos.peakPnlPct, 4),
      score: pos.score,
      rugRisk: pos.rugRisk ?? null,
      reasons: pos.reasons,
      exitReason: reason,
      // What the round trip cost, and what it made before those costs.
      feesUsd: round(pos.feesUsd || 0, 4),
      grossPnlUsd: round(pnlUsd + (pos.feesUsd || 0), 2),
      features: pos.features,
    };
    this.positions = this.positions.filter((p) => p.id !== pos.id);
    this.trades.unshift(trade);
    if (this.trades.length > 500) this.trades.length = 500;
    if (pnlUsd >= 0) {
      this.consecutiveLosses = 0;
    } else {
      this.consecutiveLosses += 1;
      // A coin that stopped us out is a coin we do not touch again for a while.
      this.cooldown(pos.tokenAddress, 45);
      if (this.consecutiveLosses >= this.cfg.maxConsecutiveLosses) {
        this.pausedUntil = Date.now() + 60 * 60 * 1000;
      }
    }
    this.rollDay().realized += pnlUsd;
    // Keep every tally equal to the book, not to a separate counter that can
    // drift away from it.
    this.recount();
    return trade;
  }

  recordEquity() {
    this.equityCurve.push({ t: Date.now(), e: round(this.equity(), 2) });
    if (this.equityCurve.length > 720) this.equityCurve = this.equityCurve.slice(-720);
  }

  snapshot() {
    const equity = this.equity();
    const day = this.rollDay();
    return {
      cash: round(this.cash, 2),
      equity: round(equity, 2),
      exposure: round(this.exposure(), 2),
      startingBankroll: this.startingBankroll,
      totalPnlUsd: round(this.totals.realizedUsd, 2),
      totalPnlPct: round((equity / this.startingBankroll - 1), 4),
      dayPnlPct: day.startEquity ? round(equity / day.startEquity - 1, 4) : 0,
      consecutiveLosses: this.consecutiveLosses,
      haltedUntil: this.pausedUntil,
      totals: this.totals,
      positions: this.positions.map((p) => ({
        id: p.id,
        symbol: p.symbol,
        name: p.name,
        imageUrl: p.imageUrl,
        chain: p.chain,
        dex: p.dex,
        venue: p.venue || 'amm',
        rugRisk: p.rugRisk ?? null,
        tp1Pct: exitsFor(this.cfg, p.venue || 'amm').tp1Pct,
        entryPrice: p.entryPrice,
        lastPrice: p.lastPrice,
        qty: p.qty,
        investedUsd: round(p.investedUsd, 2),
        realizedUsd: round(p.realizedUsd, 2),
        pnlPct: round(this.netPnlPct(p), 4),
        pnlUsd: round(this.netPnlUsd(p), 2),
        peakPnlPct: round(p.peakPnlPct, 4),
        ageSec: Math.round((Date.now() - p.entryAt) / 1000),
        score: p.score,
        trailArmed: p.trailArmed,
        ladder: p.ladder,
        entryLiqUsd: p.entryLiqUsd,
        lastLiqUsd: p.lastLiqUsd,
        sells: p.fills.filter((f) => f.side === 'sell').length,
        mode: p.mode,
      })),
      trades: this.trades.slice(0, 60),
      equityCurve: this.equityCurve.slice(-240),
    };
  }

  save() {
    ensureDataDir();
    writeJson('portfolio.json', {
      cash: this.cash,
      startingBankroll: this.startingBankroll,
      positions: this.positions,
      trades: this.trades,
      equityCurve: this.equityCurve,
      day: this.day,
      consecutiveLosses: this.consecutiveLosses,
      cooldowns: this.cooldowns,
      pausedUntil: this.pausedUntil,
      seen: trimSeen(this.seen),
      totals: this.totals,
    });
  }

  static load(cfg) {
    return new Portfolio(cfg, readJson('portfolio.json', {}));
  }
}

/**
 * Value of the remaining tokens if we sold right now, after slippage + fees.
 * @param {number} costBps round-trip cost for this position's venue
 */
export function estimateExitValue(pos, price, liqUsd, costBps) {
  const notional = pos.qty * price;
  // Same depth rule as a real fill, so an open position cannot show a phantom
  // -100% from a feed gap either.
  const keep = depthFillRate(notional, exitDepth(pos, liqUsd, notional, price));
  const feeRate = costBps / 2 / 10000;
  return notional * keep * (1 - feeRate);
}

function trimSeen(seen) {
  const cutoff = Date.now() - 6 * 60 * 60 * 1000;
  const out = {};
  for (const [k, v] of Object.entries(seen || {})) if (v > cutoff) out[k] = v;
  return out;
}
