import { readFileSync, existsSync } from 'node:fs';
import { createRequire } from 'node:module';
import { applySettings } from './settings.js';

// Load .env without a dependency (Node >= 20.6 supports process.loadEnvFile,
// but we fall back to a tiny parser so behaviour is identical everywhere).
function loadDotEnv(path = '.env') {
  if (!existsSync(path)) return;
  const raw = readFileSync(path, 'utf8');
  for (const line of raw.split(/\r?\n/)) {
    const m = /^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*)$/.exec(line);
    if (!m) continue;
    const key = m[1];
    let val = m[2].trim();
    if (val.startsWith('"') && val.endsWith('"')) val = val.slice(1, -1);
    else if (val.startsWith("'") && val.endsWith("'")) val = val.slice(1, -1);
    else val = val.replace(/\s+#.*$/, '');
    if (process.env[key] === undefined) process.env[key] = val;
  }
}
loadDotEnv();

const env = process.env;

const num = (key, def) => {
  const v = env[key];
  if (v === undefined || v === '') return def;
  const n = Number(v);
  return Number.isFinite(n) ? n : def;
};
const str = (key, def = '') => (env[key] === undefined ? def : env[key]);
const list = (key, def) =>
  (env[key] || def)
    .split(',')
    .map((s) => s.trim().toLowerCase())
    .filter(Boolean);

// Exit thresholds are per venue. AMM pools need big moves to clear their
// round-trip cost; a bonding curve with 1.25% fees does not, so it banks much
// smaller pops and cuts losers far sooner.
const EXIT_DEFAULTS = {
  amm: {
    tp1Pct: 60, tp1Size: 0.4,
    tp2Pct: 160, tp2Size: 0.35,
    trailStartPct: 45, trailGapPct: 14,
    stopLossPct: -32,
    peakStopPct: 16, peakStopArmPct: 12,
    timeStopMin: 22, timeStopMinGainPct: 15,
    rugLiqDropPct: 65,
  },
  curve: {
    tp1Pct: 18, tp1Size: 0.45,
    tp2Pct: 70, tp2Size: 0.3,
    trailStartPct: 14, trailGapPct: 10,
    stopLossPct: -18,
    peakStopPct: 12, peakStopArmPct: 10,
    timeStopMin: 12, timeStopMinGainPct: 6,
    rugLiqDropPct: 65,
  },
  pumpswap: {
    tp1Pct: 22, tp1Size: 0.45,
    tp2Pct: 80, tp2Size: 0.3,
    trailStartPct: 16, trailGapPct: 10,
    stopLossPct: -20,
    peakStopPct: 12, peakStopArmPct: 10,
    timeStopMin: 15, timeStopMinGainPct: 8,
    rugLiqDropPct: 65,
  },
};

const exitsFor = (prefix, d) => ({
  tp1Pct: num(`${prefix}TP1_PCT`, d.tp1Pct),
  tp1Size: num(`${prefix}TP1_SIZE`, d.tp1Size),
  tp2Pct: num(`${prefix}TP2_PCT`, d.tp2Pct),
  tp2Size: num(`${prefix}TP2_SIZE`, d.tp2Size),
  trailStartPct: num(`${prefix}TRAIL_START_PCT`, d.trailStartPct),
  trailGapPct: num(`${prefix}TRAIL_GAP_PCT`, d.trailGapPct),
  stopLossPct: num(`${prefix}STOP_LOSS_PCT`, d.stopLossPct),
  peakStopPct: num(`${prefix}PEAK_STOP_PCT`, d.peakStopPct),
  peakStopArmPct: num(`${prefix}PEAK_STOP_ARM_PCT`, d.peakStopArmPct),
  timeStopMin: num(`${prefix}TIME_STOP_MIN`, d.timeStopMin),
  timeStopMinGainPct: num(`${prefix}TIME_STOP_MIN_GAIN_PCT`, d.timeStopMinGainPct),
  rugLiqDropPct: num(`${prefix}RUG_LIQ_DROP_PCT`, d.rugLiqDropPct),
});

export const config = {
  mode: str('MODE', 'paper').toLowerCase() === 'live' ? 'live' : 'paper',
  port: num('PORT', 3001),
  chains: list('CHAINS', 'solana,base'),
  scanIntervalMs: num('SCAN_INTERVAL_MS', 25000),

  bankroll: num('BANKROLL', 1000),
  positionSizePct: num('POSITION_SIZE_PCT', 2.5),
  maxPositions: num('MAX_POSITIONS', 5),
  dailyLossCapPct: num('DAILY_LOSS_CAP_PCT', 30),
  // Smallest stake the bot will commit, and the smallest profit worth banking.
  // Both are in USD so a small test wallet behaves predictably.
  minTradeUsd: num('MIN_TRADE_USD', 1),
  minTakeUsd: num('MIN_TAKE_USD', 1),
  maxConsecutiveLosses: num('MAX_CONSECUTIVE_LOSSES', 6),
  maxSlippageBps: num('MAX_SLIPPAGE_BPS', 1500),

  minAgeSec: num('MIN_AGE_SEC', 15),
  maxAgeSec: num('MAX_AGE_SEC', 1200),
  minLiqUsd: num('MIN_LIQ_USD', 15000),
  maxLiqUsd: num('MAX_LIQ_USD', 600000),
  minTxns5M: num('MIN_TXNS_5M', 8),
  minScore: num('MIN_SCORE', 0.6),
  maxCandidatesPerScan: num('MAX_CANDIDATES_PER_SCAN', 2),

  venues: {
    amm: {
      label: 'DEX pool',
      costBps: num('ROUND_TRIP_COST_BPS', 1200),
      exits: exitsFor('', EXIT_DEFAULTS.amm),
    },
    curve: {
      label: 'pump.fun curve',
      costBps: num('CURVE_ROUND_TRIP_COST_BPS', 250),
      exits: exitsFor('CURVE_', EXIT_DEFAULTS.curve),
    },
    pumpswap: {
      label: 'PumpSwap',
      costBps: num('PUMPSWAP_ROUND_TRIP_COST_BPS', 150),
      exits: exitsFor('PUMPSWAP_', EXIT_DEFAULTS.pumpswap),
    },
  },

  // Paying up to guarantee an exit is only allowed where it protects profit or
  // escapes a rug - never on entries, never on ordinary stop losses.
  exitEscalation: {
    policy: str('EXIT_FEE_ESCALATION', 'profit,rug'),
    extraBps: num('URGENT_EXTRA_FEE_BPS', 150),
    slippagePct: num('URGENT_SLIPPAGE_PCT', 6),
    priorityMultiplier: num('URGENT_PRIORITY_MULTIPLIER', 2),
  },

  // Entry quality gate. Two signals separate the launches that ran from the
  // ones that dumped right after entry, and both have a mechanism behind them:
  // churn (five-minute volume traded against the pool's own depth means you are
  // someone else's exit) and safety (holder concentration plus revoked
  // authorities). Deliberately loose thresholds - the book is small.
  entryQuality: {
    maxVolumeToLiquidity5m: num('MAX_VOL_TO_LIQ_5M', 1 / 3),
    minSafety: num('MIN_SAFETY', 0.7),
    // No data is a rejection, not a neutral score: an unseen pool is not a safe
    // pool. Set REQUIRE_DATA=off to trade on partial information again.
    requireData: str('REQUIRE_DATA', 'on').toLowerCase() !== 'off',
  },

  // Pre-entry rug analysis. Hard vetoes stop a buy outright; signals below the
  // veto level raise the score the coin has to reach instead.
  rug: {
    enabled: str('RUG_ANALYSIS', 'on').toLowerCase() !== 'off',
    maxRisk: num('RUG_MAX_RISK', 70),
    maxTop10Pct: num('RUG_MAX_TOP10_PCT', 70),
    maxLiqDecayPct: num('RUG_MAX_LIQ_DECAY_PCT', 40),
    // A mint that rug-watched out of a position may not be bought again for this
    // long: the entry score cannot predict a drain it has not seen yet.
    blacklistHours: num('RUG_BLACKLIST_HOURS', 24),
    // Copycats reuse the name of whatever just ran: six different mints called
    // "Tradercat" were bought and all but one lost. Symbol pins stop that.
    symbolBlacklistHours: num('RUG_SYMBOL_BLACKLIST_HOURS', 24),
    bonusFromRisk: num('RUG_SCORE_BONUS_FROM_RISK', 40),
    scoreBonus: num('RUG_SCORE_BONUS', 0.1),
  },

  // Entry-time ownership (holder concentration, dev share, bundle clusters) over
  // plain Solana JSON-RPC. Free; fail-soft when the RPC will not serve the call.
  ownership: {
    enabled: str('OWNERSHIP', 'on').toLowerCase() !== 'off',
    deep: str('OWNERSHIP_DEEP', 'off').toLowerCase() === 'on',
    rpcUrl: str('SOLANA_RPC_URL') || str('RPC_URL') || 'https://api.mainnet-beta.solana.com',
  },

  // Optional holder table source. Solscan answers in one request what the RPC
  // walk needs two for, so it keeps the entry gate fed when the RPC throttles.
  // Blank key = the on-chain walk, unchanged.
  solscan: {
    apiKey: str('SOLSCAN_API_KEY', ''),
    baseUrl: str('SOLSCAN_API_URL', 'https://pro-api.solscan.io'),
  },

  // pump.fun's own read-only Developer API. /mint-positions lists the wallets
  // holding a position in a mint, which is the holder table the RPC walk pays two
  // throttled calls for. Needs an approved key; blank = the on-chain walk.
  pumpfun: {
    apiKey: str('PUMPFUN_API_KEY', ''),
    baseUrl: str('PUMPFUN_API_URL', 'https://api.pump.fun/v1'),
  },

  // Post-entry watch: leave on the first sign of a drain instead of waiting for
  // the strategy's 65% liquidity-pull rule, which fires when the pool is gone.
  rugWatch: {
    enabled: str('RUG_WATCH', 'on').toLowerCase() !== 'off',
    liqDropFromEntryPct: num('RUG_WATCH_LIQ_DROP_FROM_ENTRY_PCT', 35),
    tickLiqDropPct: num('RUG_WATCH_TICK_LIQ_DROP_PCT', 18),
    tickPxDropPct: num('RUG_WATCH_TICK_PX_DROP_PCT', 25),
    minDepthMultiple: num('RUG_WATCH_MIN_DEPTH_MULTIPLE', 3),
  },

  // Addresses shown on the dashboard. The paper one is a watch-only label for
  // the simulated book; the live one is checked against the signing key so a
  // typo cannot arm live trading on the wrong wallet.
  wallet: {
    paperAddress: str('PAPER_WALLET_ADDRESS'),
    network: str('PAPER_WALLET_NETWORK', 'mainnet').toLowerCase() === 'devnet' ? 'devnet' : 'mainnet',
    liveAddress: str('LIVE_WALLET_ADDRESS'),
  },

  live: {
    rpcUrl: str('RPC_URL'),
    privateKey: str('WALLET_PRIVATE_KEY'),
    routerAddress: str('ROUTER_ADDRESS'),
    confirm: str('CONFIRM_LIVE'),
    nativeUsdPrice: num('NATIVE_USD_PRICE', 0),
  },
};

// Values saved from the dashboard override env/defaults, so the bot restarts
// with whatever was last set in the UI.
applySettings(config);

// Backwards-compatible aliases: the AMM profile is the original behaviour.
config.exits = config.venues.amm.exits;
config.roundTripCostBps = config.venues.amm.costBps;

export const isLive = config.mode === 'live';

const nodeRequire = createRequire(import.meta.url);

/** ethers is an optional dependency; live EVM trading needs it. */
export function hasEthers() {
  try {
    nodeRequire.resolve('ethers');
    return true;
  } catch {
    return false;
  }
}

/** EVM address controlled by WALLET_PRIVATE_KEY, or null when it cannot be read. */
export function derivedLiveAddress(cfg = config) {
  if (!cfg.live?.privateKey || !hasEthers()) return null;
  try {
    const { Wallet } = nodeRequire('ethers');
    return new Wallet(cfg.live.privateKey).address;
  } catch {
    return null;
  }
}

export function liveConfigProblems(cfg = config) {
  if (cfg.mode !== 'live') return [];
  const problems = [];
  if (!cfg.live.rpcUrl) problems.push('RPC_URL is not set');
  if (!cfg.live.privateKey) problems.push('WALLET_PRIVATE_KEY is not set');
  if (!(cfg.live.nativeUsdPrice > 0))
    problems.push('NATIVE_USD_PRICE is not set (position sizing is in USD and must be converted)');
  if (cfg.live.confirm !== 'I_UNDERSTAND_THE_RISK')
    problems.push('CONFIRM_LIVE must equal I_UNDERSTAND_THE_RISK');
  if (cfg.chains.some((c) => c === 'solana'))
    problems.push('live mode supports EVM chains only (remove "solana" from CHAINS)');
  if (!hasEthers()) problems.push('ethers is not installed (npm i ethers) - the live EVM executor needs it');
  const keyAddress = cfg.wallet?.liveAddress ? derivedLiveAddress(cfg) : null;
  if (cfg.wallet?.liveAddress && keyAddress && keyAddress.toLowerCase() !== cfg.wallet.liveAddress.toLowerCase())
    problems.push(
      `LIVE_WALLET_ADDRESS ${cfg.wallet.liveAddress} is not the wallet WALLET_PRIVATE_KEY controls (${keyAddress})`,
    );
  return problems;
}
