import { getJson } from '../lib/http.js';

const BASE = 'https://api.geckoterminal.com/api/v2';

const num = (v, def = 0) => {
  const n = Number(v);
  return Number.isFinite(n) ? n : def;
};

function stripChain(id, chain) {
  const prefix = `${chain}_`;
  return typeof id === 'string' && id.startsWith(prefix) ? id.slice(prefix.length) : id;
}

/** Normalise a GeckoTerminal pool object into the shape the bot uses. */
export function normalizePool(raw, chain) {
  const a = raw?.attributes;
  if (!a) return null;
  const baseId = raw.relationships?.base_token?.data?.id;
  const baseAddress = baseId ? stripChain(baseId, chain) : null;
  const qt = raw.relationships?.quote_token?.data?.id;
  const m5 = a.transactions?.m5 || {};
  const h1 = a.transactions?.h1 || {};
  const priceUsd = num(a.base_token_price_usd);
  return {
    chain,
    poolAddress: a.address,
    name: a.name || '',
    symbol: (a.name || '').split(' / ')[0] || '',
    dex: raw.relationships?.dex?.data?.id || 'unknown',
    baseToken: baseAddress,
    quoteToken: qt ? stripChain(qt, chain) : null,
    createdAtMs: a.pool_created_at ? Date.parse(a.pool_created_at) : null,
    priceUsd,
    priceNative: num(a.base_token_price_native_currency),
    liqUsd: num(a.reserve_in_usd),
    mcapUsd: num(a.market_cap_usd) || num(a.fdv_usd),
    fdvUsd: num(a.fdv_usd),
    vol: {
      m5: num(a.volume_usd?.m5),
      m15: num(a.volume_usd?.m15),
      m30: num(a.volume_usd?.m30),
      h1: num(a.volume_usd?.h1),
    },
    pc: {
      m5: num(a.price_change_percentage?.m5),
      m15: num(a.price_change_percentage?.m15),
      m30: num(a.price_change_percentage?.m30),
      h1: num(a.price_change_percentage?.h1),
    },
    txns: {
      m5: {
        buys: num(m5.buys),
        sells: num(m5.sells),
        buyers: num(m5.buyers ?? m5.unique_traders),
        sellers: num(m5.sellers),
        uniqueTraders: num(m5.unique_traders),
      },
      h1: {
        buys: num(h1.buys),
        sells: num(h1.sells),
        buyers: num(h1.buyers ?? h1.unique_traders),
        sellers: num(h1.sellers),
        uniqueTraders: num(h1.unique_traders),
      },
    },
    fetchedAt: Date.now(),
  };
}

/** Newest pools on a network. This is the snipe feed. */
export async function newPools(chain, page = 1) {
  const url = `${BASE}/networks/${chain}/new_pools?page=${page}`;
  const data = await getJson(url, { ttlMs: 20000, retries: 1, label: `${chain} new_pools` });
  return (data?.data || []).map((p) => normalizePool(p, chain)).filter(Boolean);
}

/** Batch snapshot for open positions (max ~30 addresses). */
export async function poolSnapshots(chain, addresses) {
  const uniq = [...new Set(addresses)].slice(0, 30);
  if (!uniq.length) return new Map();
  const url = `${BASE}/networks/${chain}/pools/multi/${uniq.join(',')}`;
  try {
    const data = await getJson(url, { ttlMs: 5000, retries: 1, label: `${chain} pools/multi` });
    const map = new Map();
    for (const raw of data?.data || []) {
      const p = normalizePool(raw, chain);
      if (p?.poolAddress) map.set(p.poolAddress, p);
    }
    return map;
  } catch {
    return new Map();
  }
}

/**
 * Every pool a token trades in, deepest first.
 *
 * Used to follow a graduation. DexScreener only lists the pairs it has indexed,
 * so a token that moved to a pool it hasn't picked up yet looks dead there.
 * GeckoTerminal indexes the token directly, which is the second opinion.
 */
export async function tokenPools(chain, address) {
  const url = `${BASE}/networks/${chain}/tokens/${address}/pools?page=1`;
  try {
    const data = await getJson(url, { ttlMs: 30000, retries: 1, label: `${chain} token pools` });
    return (data?.data || [])
      .map((raw) => normalizePool(raw, chain))
      .filter(Boolean)
      .map((p) => ({ poolAddress: p.poolAddress, dex: p.dex, priceUsd: p.priceUsd, liqUsd: p.liqUsd }))
      .sort((a, b) => b.liqUsd - a.liqUsd);
  } catch {
    return [];
  }
}

/** 1-minute OHLCV, oldest first. */
export async function candles(chain, poolAddress, { aggregate = 1, limit = 30, timeframe = 'minute' } = {}) {
  const url = `${BASE}/networks/${chain}/pools/${poolAddress}/ohlcv/${timeframe}?aggregate=${aggregate}&limit=${limit}`;
  const data = await getJson(url, { ttlMs: 25000, label: `${chain} ohlcv` });
  const list = data?.data?.attributes?.ohlcv_list || [];
  return list
    .map(([t, o, h, l, c, v]) => ({ t: t * 1000, o: num(o), h: num(h), l: num(l), c: num(c), v: num(v) }))
    .filter((c2) => c2.c > 0)
    .sort((a, b) => a.t - b.t);
}

/**
 * Token-level intelligence: safety flags, holders, socials.
 * This is what keeps the bot out of honeypots and rug pulls.
 */
export async function tokenInfo(chain, address) {
  const url = `${BASE}/networks/${chain}/tokens/${address}/info`;
  try {
    const data = await getJson(url, { ttlMs: 10 * 60 * 1000, label: `${chain} token info` });
    const a = data?.data?.attributes;
    if (!a) return null;
    return {
      address,
      name: a.name,
      symbol: a.symbol,
      decimals: a.decimals,
      imageUrl: a.image_url,
      socials: {
        twitter: a.twitter_handle || null,
        telegram: a.telegram_handle || null,
        website: (a.websites || [])[0] || null,
        discord: a.discord_url || null,
        farcaster: a.farcaster_url || null,
      },
      gtScore: a.gt_score === null || a.gt_score === undefined ? null : num(a.gt_score),
      gtVerified: Boolean(a.gt_verified),
      categories: a.categories || [],
      holders: a.holders?.count ?? null,
      holderConcentration: topHolderShare(a.holders?.distribution_percentage),
      mintAuthority: a.mint_authority,
      freezeAuthority: a.freeze_authority,
      honeypot: a.is_honeypot,
      devAddress: a.developer_address || null,
      fetchedAt: Date.now(),
    };
  } catch {
    return null;
  }
}

/** Best-effort "how much supply is in few hands" from several possible shapes. */
function topHolderShare(dist) {
  if (dist === null || dist === undefined) return null;
  if (typeof dist === 'number') return dist;
  if (typeof dist === 'string') {
    const n = Number(dist.replace('%', ''));
    return Number.isFinite(n) ? n : null;
  }
  if (Array.isArray(dist)) {
    const nums = dist.map((d) => num(typeof d === 'object' ? d?.percentage : d)).filter((n) => n > 0);
    if (!nums.length) return null;
    return nums.slice(0, 10).reduce((s, n) => s + n, 0);
  }
  if (typeof dist === 'object') {
    const entries = Object.entries(dist);
    const top = entries.find(([k]) => /top.?10/i.test(k));
    if (top) return num(top[1]);
    const vals = entries.map(([, v]) => num(v)).filter((n) => n > 0);
    if (vals.length) return vals.slice(0, 10).reduce((s, n) => s + n, 0);
  }
  return null;
}
