// Entry-time ownership: who actually holds the supply, and are those wallets
// one person?
//
// This is the missing signal. The bot's first 19 trades were 13 liquidity pulls,
// and at entry every market-data feature looked healthy — because a bundler
// holding the float does not show up in price, volume or candle shape. It shows
// up in the holder table.
//
// Source: plain Solana JSON-RPC, free. Two calls per candidate:
//   getTokenLargestAccounts(mint)              top 20 token accounts
//   getMultipleAccounts([...tokenAccounts])    the owner wallet of each
//
// Optional deep mode (OWNERSHIP_DEEP=1) adds funder clustering: for the largest
// holders it walks back to the wallet that paid their first transaction, so ten
// fresh wallets funded by one address collapse into a single cluster. That costs
// two extra calls per holder, which is why it is off by default.
//
// Everything is fail-soft: a rate-limited or blocked RPC returns {ok:false} and
// the model sees neutral features instead of a wrong one. The public
// api.mainnet-beta.solana.com endpoint throttles getTokenLargestAccounts hard;
// a free Helius key (SOLANA_RPC_URL=https://mainnet.helius-rpc.com/?api-key=...)
// is the reliable zero-cost option.

const DEFAULT_RPC = 'https://api.mainnet-beta.solana.com';
const CACHE_TTL_MS = 4 * 60 * 1000;
const FAIL_TTL_MS = 5 * 60 * 1000;
const MAX_HOLDERS_FOR_CLUSTERS = 5;

const cache = new Map();
const blockedUntil = new Map();

const num = (v, d = 0) => {
  const x = Number(v);
  return Number.isFinite(x) ? x : d;
};

function endpoint(cfg) {
  return cfg?.ownership?.rpcUrl || process.env.SOLANA_RPC_URL || process.env.RPC_URL || DEFAULT_RPC;
}

export async function rpc(cfg, method, params, timeoutMs = 8000, urlOverride = null) {
  const url = urlOverride || endpoint(cfg);
  if ((blockedUntil.get(`${url}|${method}`) || 0) > Date.now()) {
    throw new Error(`${method} is cooling down after a rate limit`);
  }
  const ac = new AbortController();
  const timer = setTimeout(() => ac.abort(), timeoutMs);
  try {
    const res = await fetch(url, {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ jsonrpc: '2.0', id: 1, method, params }),
      signal: ac.signal,
    });
    if (res.status === 429) {
      blockedUntil.set(`${url}|${method}`, Date.now() + FAIL_TTL_MS);
      throw new Error(`${method}: 429 rate limited`);
    }
    const text = await res.text();
    let json = null;
    try {
      json = text ? JSON.parse(text) : null;
    } catch {
      json = null;
    }
    if (!json) {
      // An HTML/prose error body (401 Unauthorized, 403 Forbidden) is the most
      // common bad-key symptom; report the status instead of a JSON parse error.
      if (res.status === 401 || res.status === 403) {
        throw new Error(`${method}: HTTP ${res.status} — check the API key`);
      }
      throw new Error(`${method}: HTTP ${res.status} ${text.slice(0, 60)}`);
    }
    if (json.error) {
      const code = json.error.code;
      // A method blocked for this endpoint is not going to start working on the
      // next candidate; back off instead of paying the latency every scan.
      if (code === 429 || /too many requests|blocked|not available/i.test(json.error.message || '')) {
        blockedUntil.set(`${url}|${method}`, Date.now() + FAIL_TTL_MS);
      }
      throw new Error(`${method}: ${json.error.message}`);
    }
    return json.result;
  } finally {
    clearTimeout(timer);
  }
}

/**
 * Pure summariser - the part worth testing without a network.
 *
 * @param {{address:string, owner:string|null, uiAmount:number}[]} accounts largest token accounts
 * @param {{supply?:number, poolAddresses?:string[], devAddress?:string|null}} opts
 */
export function summariseHolders(accounts = [], { supply = 0, poolAddresses = [], devAddress = null } = {}) {
  const pools = new Set(poolAddresses.filter(Boolean));
  const holders = accounts
    .map((a) => ({ address: a.address, owner: a.owner || null, amount: num(a.uiAmount) }))
    // The pool's own token account is the float, not a holder: counting it makes
    // every healthy pool look concentrated.
    .filter((a) => a.amount > 0 && !pools.has(a.address) && !(a.owner && pools.has(a.owner)))
    .sort((a, b) => b.amount - a.amount);

  const sum = holders.reduce((s, a) => s + a.amount, 0);
  const total = supply > 0 ? supply : sum;
  if (!(total > 0) || !holders.length) {
    return { ok: false, reason: 'no holder accounts', holders: 0, top1Pct: null, top10Pct: null, devPct: null, outsideTop20Pct: null };
  }

  const pct = (x) => (x / total) * 100;
  const top10Pct = pct(holders.slice(0, 10).reduce((s, a) => s + a.amount, 0));
  const top1Pct = pct(holders[0].amount);
  const devPct = devAddress ? pct(holders.filter((a) => a.owner === devAddress).reduce((s, a) => s + a.amount, 0)) : null;
  // Supply not sitting in the top-20 accounts: normally the pool plus a long
  // tail. Large here is healthy; small here means the visible wallets hold it all.
  const outsideTop20Pct = supply > 0 ? pct(Math.max(0, supply - sum)) : null;

  return {
    ok: true,
    holders: holders.length,
    top1Pct: +top1Pct.toFixed(2),
    top10Pct: +top10Pct.toFixed(2),
    devPct: devPct === null ? null : +devPct.toFixed(2),
    outsideTop20Pct: outsideTop20Pct === null ? null : +outsideTop20Pct.toFixed(2),
    top: holders.slice(0, 5).map((a) => ({ owner: a.owner, pct: +pct(a.amount).toFixed(2) })),
  };
}

/**
 * Group holder wallets by the address that funded their first transaction. Ten
 * fresh wallets from one funder are one seller, whatever the holder table says.
 *
 * @param {{owner:string, amount:number}[]} holders
 * @param {(owner:string) => Promise<string|null>} funderOf
 */
export async function clusterHolders(holders, funderOf) {
  const groups = new Map();
  let clustered = 0;
  let seen = 0;
  for (const h of holders.slice(0, MAX_HOLDERS_FOR_CLUSTERS)) {
    if (!h.owner) continue;
    let funder = null;
    try {
      funder = await funderOf(h.owner);
    } catch {
      funder = null;
    }
    if (!funder) continue;
    seen += 1;
    const g = groups.get(funder) || { funder, pct: 0, wallets: 0 };
    g.pct += num(h.pct);
    g.wallets += 1;
    groups.set(funder, g);
  }
  const biggest = [...groups.values()].sort((a, b) => b.pct - a.pct)[0] || null;
  if (biggest) clustered = biggest.pct;
  return {
    checked: seen,
    wallets: biggest?.wallets || 0,
    clusterPct: +clustered.toFixed(2),
    funder: biggest?.funder || null,
  };
}

/** The wallet that paid a holder's first transaction. */
async function funderOf(cfg, owner) {
  const sigs = await rpc(cfg, 'getSignaturesForAddress', [owner, { limit: 1000 }], 8000);
  const oldest = Array.isArray(sigs) && sigs.length ? sigs[sigs.length - 1] : null;
  if (!oldest?.signature) return null;
  const tx = await rpc(cfg, 'getTransaction', [oldest.signature, { maxSupportedTransactionVersion: 0, encoding: 'json' }], 8000);
  const keys = tx?.transaction?.message?.accountKeys;
  const payer = Array.isArray(keys) ? (typeof keys[0] === 'string' ? keys[0] : keys[0]?.pubkey) : null;
  return payer || null;
}

/**
 * Full ownership snapshot for a mint.
 * @returns {Promise<object>} always resolves; {ok:false, reason} when unavailable
 */
export async function tokenOwnership(cfg, mint, { poolAddress, devAddress, deep = false } = {}) {
  if (!mint) return { ok: false, reason: 'no mint' };
  if (cfg?.ownership?.enabled === false) return { ok: false, reason: 'disabled' };

  const key = `${mint}|${poolAddress || ''}`;
  const hit = cache.get(key);
  if (hit && hit.at + CACHE_TTL_MS > Date.now()) return hit.value;

  try {
    const [largest, supplyRes] = await Promise.all([
      rpc(cfg, 'getTokenLargestAccounts', [mint]),
      rpc(cfg, 'getTokenSupply', [mint]).catch(() => null),
    ]);
    const accounts = largest?.value || [];
    if (!accounts.length) {
      const value = { ok: false, reason: 'no token accounts' };
      cache.set(key, { at: Date.now(), value });
      return value;
    }

    const owners = await rpc(cfg, 'getMultipleAccounts', [accounts.map((a) => a.address), { encoding: 'jsonParsed' }]);
    const withOwners = accounts.map((a, i) => ({
      address: a.address,
      owner: owners?.value?.[i]?.data?.parsed?.info?.owner || null,
      uiAmount: num(a.uiAmount),
    }));

    const supply = num(supplyRes?.value?.uiAmount) || 0;
    const summary = summariseHolders(withOwners, {
      supply,
      poolAddresses: [poolAddress].filter(Boolean),
      devAddress: devAddress || null,
    });

    let clusters = null;
    if (deep && summary.ok) {
      try {
        clusters = await clusterHolders(summary.top.map((t) => ({ owner: t.owner, pct: t.pct })), (owner) => funderOf(cfg, owner));
      } catch {
        clusters = null;
      }
    }

    const value = { ...summary, clusters, source: 'rpc', at: Date.now() };
    cache.set(key, { at: Date.now(), value });
    return value;
  } catch (err) {
    const value = { ok: false, reason: err.message };
    // Do not cache transport failures for long: the next candidate may work.
    cache.set(key, { at: Date.now() - CACHE_TTL_MS + 30 * 1000, value });
    return value;
  }
}

/**
 * Is this RPC usable for ownership lookups? Runs the two calls the bot needs
 * against a liquid token, so a key that works for getHealth but not for the
 * holder table is caught here instead of silently returning neutral features.
 */
export async function probeRpc(cfg, urlOverride) {
  const temp = { ownership: { ...(cfg?.ownership || {}), rpcUrl: urlOverride || cfg?.ownership?.rpcUrl } };
  clearOwnershipCache();
  const checks = [];
  const mint = 'DezXAZ8z7PnrnRJjz3wXBoRgixCa6xjnB7YaB1pPB263'; // BONK: always liquid

  try {
    await rpc(temp, 'getHealth', [], 10000);
    checks.push({ name: 'getHealth', ok: true, detail: 'reachable' });
  } catch (err) {
    checks.push({ name: 'getHealth', ok: false, detail: err.message });
  }

  try {
    const largest = await rpc(temp, 'getTokenLargestAccounts', [mint], 10000);
    const n = largest?.value?.length || 0;
    checks.push({ name: 'holder table', ok: n > 0, detail: `${n} token accounts` });
  } catch (err) {
    checks.push({ name: 'holder table', ok: false, detail: err.message });
  }

  const host = (() => {
    try {
      return new URL(temp.ownership.rpcUrl).host;
    } catch {
      return 'invalid url';
    }
  })();
  return { ok: checks.every((c) => c.ok), checks, host };
}

export function clearOwnershipCache() {
  cache.clear();
  blockedUntil.clear();
}
