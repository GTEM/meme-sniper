import { getJson } from '../lib/http.js';

// DexScreener is a second opinion: socials, pair age and independent liquidity.
// Divergence between the two feeds is itself a red flag (thin/faked pools).

const num = (v, def = 0) => {
  const n = Number(v);
  return Number.isFinite(n) ? n : def;
};

/**
 * All pairs for a token, best (deepest liquidity) first.
 */
export async function tokenPairs(chain, address) {
  const url = `https://api.dexscreener.com/latest/dex/tokens/${address}`;
  try {
    const data = await getJson(url, { ttlMs: 45000, label: `${chain} dexscreener token` });
    const pairs = (data?.pairs || []).filter((p) => !chain || p.chainId === chain);
    if (!pairs.length) return null;
    pairs.sort((a, b) => num(b.liquidity?.usd) - num(a.liquidity?.usd));
    const p = pairs[0];
    return {
      chain,
      poolAddress: p.pairAddress,
      dex: p.dexId,
      baseToken: p.baseToken?.address || null,
      symbol: p.baseToken?.symbol,
      name: p.baseToken?.name,
      priceUsd: num(p.priceUsd),
      liqUsd: num(p.liquidity?.usd),
      fdvUsd: num(p.fdv),
      mcapUsd: num(p.marketCap),
      createdAtMs: p.pairCreatedAt || null,
      vol: { m5: num(p.volume?.m5), h1: num(p.volume?.h1), h24: num(p.volume?.h24) },
      txns: { m5: p.txns?.m5 || { buys: 0, sells: 0 }, h1: p.txns?.h1 || { buys: 0, sells: 0 } },
      pc: { m5: num(p.priceChange?.m5), h1: num(p.priceChange?.h1), h24: num(p.priceChange?.h24) },
      socials: (p.info?.socials || []).map((s) => s.type),
      websites: (p.info?.websites || []).map((w) => w.url),
      imageUrl: p.info?.imageUrl || null,
      boosts: p.boosts?.active || 0,
      pairCount: pairs.length,
    };
  } catch {
    return null;
  }
}

/**
 * Every pair for a token, deepest liquidity first.
 *
 * Needed to follow a graduation: when a token moves from its launch pool to a
 * new one, the old pair reports ~$0 and the bot used to sell there, booking a
 * total loss on a live position. The token is still trading — just elsewhere.
 */
export async function allTokenPairs(chain, address) {
  const url = `https://api.dexscreener.com/latest/dex/tokens/${address}`;
  try {
    const data = await getJson(url, { ttlMs: 20000, label: `${chain} dexscreener pairs` });
    const pairs = (data?.pairs || []).filter((p) => !chain || p.chainId === chain);
    return pairs
      .map((p) => ({
        poolAddress: p.pairAddress,
        dex: p.dexId,
        priceUsd: num(p.priceUsd),
        liqUsd: num(p.liquidity?.usd),
        createdAtMs: p.pairCreatedAt || null,
      }))
      .sort((a, b) => b.liqUsd - a.liqUsd);
  } catch {
    return [];
  }
}

/**
 * Second, independent discovery source: DexScreener's newest token profiles.
 * Used alongside (and when) GeckoTerminal's new-pools feed is rate limited.
 * Returns objects in the same shape as the GeckoTerminal pool normaliser.
 */
export async function latestPools(chain, limit = 8) {
  let profiles;
  try {
    profiles = await getJson('https://api.dexscreener.com/token-profiles/latest/v1', {
      ttlMs: 60000,
      label: 'dexscreener profiles',
    });
  } catch {
    return [];
  }
  const addrs = (profiles || [])
    .filter((p) => p.chainId === chain && p.tokenAddress)
    .map((p) => p.tokenAddress)
    .slice(0, limit);
  if (!addrs.length) return [];

  const pairs = await Promise.all(addrs.map((a) => tokenPairs(chain, a)));
  return pairs
    .filter((p) => p && p.poolAddress && p.priceUsd > 0)
    .map((p) => ({
      chain,
      poolAddress: p.poolAddress,
      name: p.name,
      symbol: p.symbol,
      dex: p.dex,
      baseToken: p.baseToken,
      createdAtMs: p.createdAtMs,
      priceUsd: p.priceUsd,
      liqUsd: p.liqUsd,
      mcapUsd: p.mcapUsd || p.fdvUsd,
      // DexScreener has no 15m window and no unique-trader count; mirror 5m so
      // the derived features stay neutral instead of inventing signal.
      vol: { m5: p.vol.m5, m15: p.vol.m5, h1: p.vol.h1 },
      pc: { m5: p.pc.m5, m15: p.pc.m5, m30: p.pc.m5, h1: p.pc.h1 },
      txns: {
        m5: { buys: num(p.txns.m5?.buys), sells: num(p.txns.m5?.sells), buyers: 0, sellers: 0, uniqueTraders: 0 },
        h1: { buys: num(p.txns.h1?.buys), sells: num(p.txns.h1?.sells), buyers: 0, sellers: 0, uniqueTraders: 0 },
      },
      fetchedAt: Date.now(),
    }));
}
