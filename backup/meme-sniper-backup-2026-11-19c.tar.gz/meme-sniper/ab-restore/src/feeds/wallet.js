// What the test wallet actually holds, read over the same free RPC the
// ownership checks use. Paper mode seeds its book from this instead of a
// hard-coded bankroll, so the training wheels run on the wallet you aimed at.
//
// Costs nothing: two getTokenAccountsByOwner calls (SPL + token-2022) and one
// DexScreener price call, all cached/backed off by the shared helpers.

import { rpc } from './ownership.js';
import { getJson } from '../lib/http.js';

export const WRAPPED_SOL = 'So11111111111111111111111111111111111111112';
// The test wallet is often the same Phantom address on devnet, where a faucet
// balance lives. Mainnet stays the default: only this read follows the switch.
export const DEVNET_RPC = 'https://api.devnet.solana.com';
export const WALLET_NETWORKS = ['mainnet', 'devnet'];

const TOKEN_PROGRAMS = [
  'TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA', // SPL token (mandatory)
  'TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb', // token-2022 (fail-soft)
];
const DUST = 1e-6;
const MAX_TOKENS = 12;
// A wallet holding thousands of airdropped mints is not worth 125 price calls;
// the tail is listed as unpriced instead of valued.
const MAX_PRICE_MINTS = 50;
const round2 = (n) => Math.round(n * 100) / 100;

/** Deepest-liquidity USD price per mint, batched through DexScreener. */
export async function priceMints(mints) {
  const best = new Map();
  const list = [...new Set(mints.filter(Boolean))];
  for (let i = 0; i < list.length; i += 25) {
    const batch = list.slice(i, i + 25);
    try {
      const data = await getJson(`https://api.dexscreener.com/latest/dex/tokens/${batch.join(',')}`, {
        ttlMs: 60000,
        label: 'dexscreener wallet prices',
      });
      for (const pair of data?.pairs || []) {
        const mint = pair.baseToken?.address;
        const price = Number(pair.priceUsd);
        if (!mint || !Number.isFinite(price) || price <= 0) continue;
        const liq = Number(pair.liquidity?.usd) || 0;
        const prev = best.get(mint);
        if (!prev || liq > prev.liq) best.set(mint, { price, liq });
      }
    } catch {
      // Pricing is best-effort: an unpriced token stays visible, just not valued.
    }
  }
  const out = new Map();
  for (const [mint, v] of best) out.set(mint, v.price);
  return out;
}

/**
 * Pure valuation step: lamports + token balances + a price lookup -> the view
 * the dashboard shows. Kept free of I/O so it can be asserted in the selftest.
 */
export function summariseWallet({ lamports = 0, tokens = [], priceOf = () => null, address = '', at = Date.now() } = {}) {
  const sol = Number(lamports) / 1e9;
  const solPriceUsd = Number(priceOf(WRAPPED_SOL)) || 0;
  const priced = tokens.map((t) => {
    const price = Number(priceOf(t.mint));
    const known = Number.isFinite(price) && price > 0;
    return {
      mint: t.mint,
      amount: Math.round(t.amount * 1e6) / 1e6,
      decimals: t.decimals ?? 0,
      priceUsd: known ? price : null,
      usd: known ? round2(t.amount * price) : null,
    };
  });
  priced.sort((a, b) => (b.usd ?? -1) - (a.usd ?? -1));
  const tokenUsd = priced.reduce((s, t) => s + (t.usd || 0), 0);
  return {
    address,
    at,
    sol: Math.round(sol * 1e6) / 1e6,
    solPriceUsd,
    solUsd: round2(sol * solPriceUsd),
    tokenCount: priced.length,
    tokens: priced.slice(0, MAX_TOKENS),
    tokenUsd: round2(tokenUsd),
    unpriced: priced.filter((t) => t.usd === null).length,
    totalUsd: round2(sol * solPriceUsd + tokenUsd),
  };
}

/** Read a wallet: native SOL, SPL + token-2022 balances, then value them. */
export async function readTestWallet(cfg, address, { network = 'mainnet' } = {}) {
  const target = String(address || '').trim();
  if (!target) throw new Error('no test wallet address set');
  const url = network === 'devnet' ? DEVNET_RPC : null;

  const balance = await rpc(cfg, 'getBalance', [target], 10000, url);
  const lamports = Number(balance?.value ?? 0);

  // Both token programs in parallel; token-2022 is allowed to fail silently so a
  // node without support still shows the classic balances.
  const results = await Promise.allSettled(
    TOKEN_PROGRAMS.map((programId) =>
      rpc(cfg, 'getTokenAccountsByOwner', [target, { programId }, { encoding: 'jsonParsed' }], 12000, url),
    ),
  );
  if (results[0].status === 'rejected') throw results[0].reason;

  const held = new Map();
  for (const result of results) {
    if (result.status !== 'fulfilled') continue;
    for (const acc of result.value?.value || []) {
      const info = acc?.account?.data?.parsed?.info;
      const amount = Number(info?.tokenAmount?.uiAmount ?? 0);
      if (!info?.mint || !(amount > DUST)) continue;
      const prev = held.get(info.mint);
      if (prev) prev.amount += amount;
      else held.set(info.mint, { mint: info.mint, amount, decimals: Number(info.tokenAmount?.decimals ?? 0) });
    }
  }

  const tokens = [...held.values()];
  const toPrice = tokens.slice(0, MAX_PRICE_MINTS);
  const prices = await priceMints([WRAPPED_SOL, ...toPrice.map((t) => t.mint)]);
  const view = summariseWallet({ lamports, tokens: toPrice, priceOf: (m) => prices.get(m) ?? null, address: target });
  view.network = network;
  // Keep the full count so the dashboard reports what it did not value.
  view.tokenCount = tokens.length;
  view.notPriceChecked = Math.max(0, tokens.length - toPrice.length);
  return view;
}
