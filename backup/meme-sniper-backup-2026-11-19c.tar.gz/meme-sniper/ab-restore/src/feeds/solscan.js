// Holder table from Solscan's Pro API, as an alternative to walking the chain.
//
// The RPC path (feeds/ownership.js) needs two JSON-RPC calls per candidate and
// the public endpoint throttles getTokenLargestAccounts hard, which is how a
// launch ends up vetoed as "not enough data: holder table". Solscan answers the
// same question in one request:
//
//   GET https://pro-api.solscan.io/v2.0/token/holders?address=<mint>&page_size=40
//   header: token: <SOLSCAN_API_KEY>
//
// Each item carries `percentage` of supply directly, so the summary does not
// need the mint supply. It is optional and fail-soft: with no key configured, or
// any error, the engine falls back to the RPC walk and behaviour is unchanged.

const DEFAULT_BASE = 'https://pro-api.solscan.io';
const CACHE_TTL_MS = 4 * 60 * 1000;
const FAIL_TTL_MS = 5 * 60 * 1000;

const cache = new Map();
const blockedUntil = new Map();

// A key whose plan does not include /token/holders answers the same way for every
// mint. Remember that once, so the scan does not spend a request (and a warning)
// on each candidate for the next half hour.
const PLAN_TTL_MS = 30 * 60 * 1000;
let planLimitedUntil = 0;

const num = (v, d = 0) => {
  const x = Number(v);
  return Number.isFinite(x) ? x : d;
};

/**
 * Pure summariser: Solscan holder rows in, the same shape the RPC path returns.
 *
 * @param {{address?:string, owner?:string|null, percentage?:number, amount_str?:string, decimals?:number}[]} items
 * @param {{poolAddresses?:string[], devAddress?:string|null, total?:number}} opts
 */
export function summariseSolscanHolders(items = [], { poolAddresses = [], devAddress = null, total = null } = {}) {
  const pools = new Set(poolAddresses.filter(Boolean));
  const rows = (Array.isArray(items) ? items : [])
    .map((it) => ({
      address: it.address || null,
      owner: it.owner || null,
      pct: num(it.percentage),
    }))
    .filter((r) => r.pct > 0)
    // The pool's own token account is the float, not a holder.
    .filter((r) => !(r.address && pools.has(r.address)) && !(r.owner && pools.has(r.owner)))
    .sort((a, b) => b.pct - a.pct);

  if (!rows.length) {
    return { ok: false, reason: 'no holder rows', source: 'solscan', holders: 0, top1Pct: null, top10Pct: null, devPct: null, outsideTop20Pct: null };
  }

  const top1Pct = rows[0].pct;
  const top10Pct = rows.slice(0, 10).reduce((s, r) => s + r.pct, 0);
  const devPct = devAddress ? rows.filter((r) => r.owner === devAddress).reduce((s, r) => s + r.pct, 0) : null;
  const visible = rows.reduce((s, r) => s + r.pct, 0);

  return {
    ok: true,
    source: 'solscan',
    holders: Number.isFinite(Number(total)) ? Number(total) : rows.length,
    top1Pct: +top1Pct.toFixed(2),
    top10Pct: +top10Pct.toFixed(2),
    devPct: devPct === null ? null : +devPct.toFixed(2),
    // Supply not visible in the rows we fetched: normally the pool plus the tail.
    outsideTop20Pct: total ? null : +(Math.max(0, 100 - visible)).toFixed(2),
    top: rows.slice(0, 5).map((r) => ({ owner: r.owner, pct: +r.pct.toFixed(2) })),
  };
}

export function solscanConfigured(cfg) {
  return Boolean(String(cfg?.solscan?.apiKey || '').trim());
}

/**
 * @param {object} cfg bot config (uses cfg.solscan)
 * @returns {Promise<object>} ownership summary, or {ok:false, reason} — never throws
 */
export async function solscanHolders(cfg, mint, { poolAddresses = [], devAddress = null } = {}) {
  const apiKey = String(cfg?.solscan?.apiKey || '').trim();
  if (!apiKey) return { ok: false, reason: 'no SOLSCAN_API_KEY', source: 'solscan' };
  if (!mint) return { ok: false, reason: 'no mint', source: 'solscan' };

  if (planLimitedUntil > Date.now()) {
    return { ok: false, reason: 'plan does not include /token/holders', quiet: true, source: 'solscan' };
  }

  const hit = cache.get(mint);
  if (hit && hit.at + CACHE_TTL_MS > Date.now()) return hit.value;
  if ((blockedUntil.get(mint) || 0) > Date.now()) return { ok: false, reason: 'cooling down after an error', source: 'solscan' };

  const base = String(cfg?.solscan?.baseUrl || DEFAULT_BASE).replace(/\/+$/, '');
  const url = `${base}/v2.0/token/holders?address=${encodeURIComponent(mint)}&page=1&page_size=40`;
  const ac = new AbortController();
  const timer = setTimeout(() => ac.abort(), 8000);
  try {
    const res = await fetch(url, { headers: { accept: 'application/json', token: apiKey }, signal: ac.signal });
    const text = await res.text();
    if (res.status === 401 || res.status === 403) {
      let message = '';
      try {
        message = JSON.parse(text)?.errors?.message || '';
      } catch {
        message = String(text || '').slice(0, 120);
      }
      // A valid key on the free plan gets 401 "Please upgrade your api key level".
      if (/upgrade/i.test(message)) {
        planLimitedUntil = Date.now() + PLAN_TTL_MS;
        return {
          ok: false,
          reason: 'plan does not include /token/holders (Solscan: upgrade your api key level)',
          quiet: true,
          source: 'solscan',
        };
      }
      blockedUntil.set(mint, Date.now() + FAIL_TTL_MS);
      return { ok: false, reason: `Solscan rejected the key (HTTP ${res.status})`, source: 'solscan' };
    }
    if (res.status === 429) {
      blockedUntil.set(mint, Date.now() + FAIL_TTL_MS);
      return { ok: false, reason: 'Solscan rate limited (429)', source: 'solscan' };
    }
    if (!res.ok) return { ok: false, reason: `Solscan HTTP ${res.status}`, source: 'solscan' };

    let json = null;
    try {
      json = text ? JSON.parse(text) : null;
    } catch {
      json = null;
    }
    if (!json || json.success === false) return { ok: false, reason: json?.error || 'Solscan returned no JSON', source: 'solscan' };

    const value = summariseSolscanHolders(json.data?.items || [], {
      poolAddresses,
      devAddress,
      total: json.data?.total ?? null,
    });
    if (value.ok) cache.set(mint, { at: Date.now(), value });
    else blockedUntil.set(mint, Date.now() + FAIL_TTL_MS);
    return value;
  } catch (err) {
    return { ok: false, reason: err?.name === 'AbortError' ? 'Solscan timed out' : err.message, source: 'solscan' };
  } finally {
    clearTimeout(timer);
  }
}

const PROBE_MINT = 'EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v'; // USDC

/**
 * Turns the two probe status codes into a verdict.
 *
 * Solscan's free plan grants "API Public endpoints", and the docs list exactly
 * one of those (Chain Information); every /token/* route, holders included, is
 * Pro API v2. A valid free key is therefore a real key that simply cannot serve
 * the holder table - worth saying plainly instead of leaving a silent fallback.
 */
export function classifyProbe({ chainStatus = 0, holdersStatus = 0, holdersMessage = '', chainMessage = '' } = {}) {
  // Solscan answers a valid but under-privileged key with 401 and "Please upgrade
  // your api key level", so the message - not the status - says whether the key
  // itself is good. The documented free Chain Information route currently 404s,
  // so it can only ever be a secondary signal.
  const upgrade = holdersStatus === 401 && /upgrade/i.test(String(holdersMessage));
  const holdersOk = holdersStatus === 200;
  // 429 also proves the key was accepted - the limit is per key, not per caller.
  const keyValid = holdersOk || upgrade || holdersStatus === 429 || chainStatus === 200;
  let verdict;
  if (holdersOk) {
    verdict = 'holder table served by Solscan - the bot will use it before the RPC walk';
  } else if (upgrade) {
    verdict = 'key accepted, but a free Level 1 key cannot call any /v2.0 Pro endpoint (Solscan: "Please upgrade your api key level"), so the bot keeps using the on-chain walk';
  } else if (holdersStatus === 401) {
    verdict = 'key rejected by Solscan - check the key was copied whole';
  } else if (holdersStatus === 403 || chainStatus === 403) {
    verdict = 'key rejected (403) - check the key';
  } else if (holdersStatus === 429) {
    verdict = 'key works, but the holders call was rate limited (free plan allows 60 requests/60s)';
  } else if (!holdersStatus && !chainStatus) {
    verdict = `could not reach Solscan${holdersMessage ? ` (${holdersMessage})` : ''}`;
  } else {
    verdict = `holders endpoint answered HTTP ${holdersStatus || 'nothing'}`;
  }
  return { keyValid, holdersOk, upgrade, verdict };
}

async function probeCall(url, key) {
  const ac = new AbortController();
  const timer = setTimeout(() => ac.abort(), 8000);
  try {
    const res = await fetch(url, { headers: { accept: 'application/json', token: key }, signal: ac.signal });
    const text = await res.text();
    let message = '';
    try {
      const json = text ? JSON.parse(text) : null;
      message = json?.errors?.message || json?.error || json?.message || '';
    } catch {
      message = text.slice(0, 120);
    }
    return { status: res.status, message, error: message || `HTTP ${res.status}` };
  } catch (err) {
    return { status: 0, message: '', error: err?.name === 'AbortError' ? 'timed out' : err.message };
  } finally {
    clearTimeout(timer);
  }
}

/** Ask Solscan what this key can actually do. Never throws. */
export async function probeSolscan(cfg, { apiKey, mint = PROBE_MINT } = {}) {
  const key = String(apiKey || cfg?.solscan?.apiKey || '').trim();
  const base = String(cfg?.solscan?.baseUrl || DEFAULT_BASE).replace(/\/+$/, '');
  const host = (() => {
    try {
      return new URL(base).host;
    } catch {
      return base;
    }
  })();
  if (!key) {
    return { ok: false, keyValid: false, holdersOk: false, host, checks: [], verdict: 'no Solscan key set - add one in Settings first' };
  }
  const chain = await probeCall(`${base}/v2.0/chaininfo`, key);
  const holders = await probeCall(`${base}/v2.0/token/holders?address=${encodeURIComponent(mint)}&page=1&page_size=10`, key);
  const c = classifyProbe({
    chainStatus: chain.status,
    chainMessage: chain.message,
    holdersStatus: holders.status,
    holdersMessage: holders.message,
  });
  return {
    ok: c.holdersOk,
    keyValid: c.keyValid,
    holdersOk: c.holdersOk,
    upgrade: c.upgrade,
    host,
    mint,
    verdict: c.verdict,
    checks: [
      { name: 'key accepted', ok: c.keyValid, detail: holders.message || `HTTP ${holders.status}` },
      { name: 'token/holders', ok: holders.status === 200, detail: holders.message || `HTTP ${holders.status}` },
    ],
  };
}

export function resetSolscanCache() {
  cache.clear();
  blockedUntil.clear();
  planLimitedUntil = 0;
}
