// Holder table from pump.fun's own read-only Developer API.
//
//   GET https://api.pump.fun/v1/mint-positions/{mint}?page=1&pageSize=50
//   Authorization: Bearer pf_live_...
//   -> { positions: [{ walletAddress, amountHeld, costBasisUsd, pnlUsd, ... }],
//        totalCount, hasMore, nextPageToken }
//
// Free for approved teams (2 req/s, 50,000/day). It is the first free source that
// returns per-wallet token amounts, which is what holder concentration needs -
// the RPC walk pays two throttled calls for the same answer.
//
// Two honest limits:
//   * It lists pump.fun-visible positions, not every token account, so a wallet
//     that never used pump.fun may be missing. Summaries are tagged
//     source:'pumpfun' and the RPC walk stays available as the cross-check.
//   * It returns amounts, not percentages, and no supply. The caller supplies the
//     mint supply from getTokenSupply (one cheap call, unlike the throttled
//     getTokenLargestAccounts). No supply means no summary - never a guessed one.

const DEFAULT_BASE = 'https://api.pump.fun/v1';
const CACHE_TTL_MS = 4 * 60 * 1000;
const FAIL_TTL_MS = 5 * 60 * 1000;
const PAGE_GAP_MS = 550; // the key allows 2 requests/second

const cache = new Map();
const blockedUntil = new Map();

const num = (v, d = 0) => {
  const x = Number(v);
  return Number.isFinite(x) ? x : d;
};

/**
 * Pure summariser: pump.fun position rows in, the ownership shape the entry gate
 * consumes out.
 *
 * @param {{walletAddress?:string, profileWallet?:string, amountHeld?:number}[]} positions
 * @param {{supply?:number, poolAddresses?:string[], devAddress?:string|null, total?:number|null}} opts
 */
export function summarisePumpfunPositions(positions = [], { supply = 0, poolAddresses = [], devAddress = null, total = null } = {}) {
  const pools = new Set(poolAddresses.filter(Boolean));
  const rows = (Array.isArray(positions) ? positions : [])
    .map((p) => ({ owner: p.walletAddress || p.profileWallet || null, amount: num(p.amountHeld) }))
    .filter((r) => r.owner && r.amount > 0)
    // The pool's own wallet is the float, not a holder.
    .filter((r) => !pools.has(r.owner))
    .sort((a, b) => b.amount - a.amount);

  const empty = { ok: false, source: 'pumpfun', holders: 0, top1Pct: null, top10Pct: null, devPct: null, outsideTop20Pct: null };
  if (!rows.length) return { ...empty, reason: 'no positions listed' };
  // Amounts are meaningless without the supply to divide by.
  if (!(supply > 0)) return { ...empty, reason: 'no mint supply to measure against' };

  const pct = (x) => (x / supply) * 100;
  const sum = rows.reduce((s, r) => s + r.amount, 0);
  const top10Pct = pct(rows.slice(0, 10).reduce((s, r) => s + r.amount, 0));
  const top1Pct = pct(rows[0].amount);
  const devPct = devAddress ? pct(rows.filter((r) => r.owner === devAddress).reduce((s, r) => s + r.amount, 0)) : null;
  // Supply this source cannot see: the pool plus wallets with no pump.fun
  // position. Large is normal; small means the listed wallets hold everything.
  const outside = pct(Math.max(0, supply - sum));

  return {
    ok: true,
    source: 'pumpfun',
    holders: Number.isFinite(Number(total)) && Number(total) > 0 ? Number(total) : rows.length,
    top1Pct: +top1Pct.toFixed(2),
    top10Pct: +top10Pct.toFixed(2),
    devPct: devPct === null ? null : +devPct.toFixed(2),
    outsideTop20Pct: +outside.toFixed(2),
    top: rows.slice(0, 5).map((r) => ({ owner: r.owner, pct: +pct(r.amount).toFixed(2) })),
  };
}

export function pumpfunConfigured(cfg) {
  return Boolean(String(cfg?.pumpfun?.apiKey || '').trim());
}

async function getJson(url, apiKey) {
  const ac = new AbortController();
  const timer = setTimeout(() => ac.abort(), 8000);
  try {
    const res = await fetch(url, {
      headers: { accept: 'application/json', authorization: `Bearer ${apiKey}` },
      signal: ac.signal,
    });
    const text = await res.text();
    let json = null;
    try {
      json = text ? JSON.parse(text) : null;
    } catch {
      json = null;
    }
    return { status: res.status, json, text };
  } catch (err) {
    return { status: 0, json: null, text: '', error: err?.name === 'AbortError' ? 'timed out' : err.message };
  } finally {
    clearTimeout(timer);
  }
}

/**
 * Holder summary for a mint from pump.fun positions. Never throws.
 *
 * @param {object} cfg bot config (uses cfg.pumpfun)
 * @param {string} mint token mint
 * @param {{poolAddresses?:string[], devAddress?:string|null, supply?:number, pages?:number}} opts
 * @returns {Promise<object>} ownership summary, or {ok:false, reason, quiet?}
 */
export async function pumpfunHolders(cfg, mint, { poolAddresses = [], devAddress = null, supply = 0, pages = 2 } = {}) {
  const apiKey = String(cfg?.pumpfun?.apiKey || '').trim();
  if (!apiKey) return { ok: false, reason: 'no PUMPFUN_API_KEY', source: 'pumpfun' };
  if (!mint) return { ok: false, reason: 'no mint', source: 'pumpfun' };
  if (!(supply > 0)) return { ok: false, reason: 'no mint supply', source: 'pumpfun' };

  const hit = cache.get(mint);
  if (hit && hit.at + CACHE_TTL_MS > Date.now()) return hit.value;
  if ((blockedUntil.get(mint) || 0) > Date.now()) {
    return { ok: false, reason: 'cooling down after an error', quiet: true, source: 'pumpfun' };
  }

  const base = String(cfg?.pumpfun?.baseUrl || DEFAULT_BASE).replace(/\/+$/, '');
  const all = [];
  let total = null;

  for (let page = 1; page <= Math.max(1, pages); page += 1) {
    if (page > 1) await new Promise((r) => setTimeout(r, PAGE_GAP_MS));
    const url = `${base}/mint-positions/${encodeURIComponent(mint)}?page=${page}&pageSize=50`;
    const res = await getJson(url, apiKey);

    if (res.status === 401 || res.status === 403) {
      blockedUntil.set(mint, Date.now() + FAIL_TTL_MS);
      const msg = res.json?.error?.message || res.json?.error || '';
      return {
        ok: false,
        reason: `pump.fun rejected the key (HTTP ${res.status})${msg ? `: ${msg}` : ''}`,
        quiet: true,
        source: 'pumpfun',
      };
    }
    if (res.status === 429) {
      blockedUntil.set(mint, Date.now() + FAIL_TTL_MS);
      return { ok: false, reason: 'pump.fun rate limited (429)', quiet: true, source: 'pumpfun' };
    }
    if (!res.status) return { ok: false, reason: res.error || 'pump.fun unreachable', source: 'pumpfun' };
    if (res.status !== 200) return { ok: false, reason: `pump.fun HTTP ${res.status}`, source: 'pumpfun' };

    const list = res.json?.positions || res.json?.data?.positions || [];
    if (Array.isArray(list)) all.push(...list);
    if (Number.isFinite(Number(res.json?.totalCount))) total = Number(res.json.totalCount);
    if (!res.json?.hasMore || !list.length) break;
  }

  const value = summarisePumpfunPositions(all, { supply, poolAddresses, devAddress, total });
  if (value.ok) cache.set(mint, { at: Date.now(), value });
  else blockedUntil.set(mint, Date.now() + FAIL_TTL_MS);
  return value;
}

export function resetPumpfunCache() {
  cache.clear();
  blockedUntil.clear();
}
