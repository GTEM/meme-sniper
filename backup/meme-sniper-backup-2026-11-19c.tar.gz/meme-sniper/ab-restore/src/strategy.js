import { estimateExitValue } from './portfolio.js';
import { exitsFor, costBpsFor, worthEscalating } from './venues.js';

// Exit engine. Ordered by urgency: get out of a rug first, then protect
// capital, then take profit in steps, then let a winner run on a trail.
//
// Thresholds and costs come from the position's venue profile, so a 1.25%-fee
// bonding curve banks +18% while a 12%-cost AMM pool waits for +60%.

/**
 * @returns {{action:'hold'|'sell', fraction:number, reason:string, pnlPct:number, peakPnlPct:number, urgent:boolean}}
 */
/**
 * The price an exit should fill at.
 *
 * The rule acted on `decisionPrice`; pos.lastPrice can be older, because a move
 * that trips the feed's 4x guard is held pending confirmation. Filling at the
 * stale price booked six peak-stop exits at the peak (booked +34%, rule saw
 * -2%) after the price had already gone. A print more than 4x away from the
 * confirmed price is still treated as a bad feed row, so there the confirmed
 * price wins: that guard is what stopped phantom -100% fills.
 */
export function exitFillPrice(confirmedPrice, decisionPrice) {
  const confirmed = Number(confirmedPrice) || 0;
  const live = Number(decisionPrice) || 0;
  if (!(live > 0)) return confirmed;
  if (!(confirmed > 0)) return live;
  const ratio = live / confirmed;
  return ratio > 0.25 && ratio < 4 ? live : confirmed;
}

export function evaluateExit(pos, pool, cfg, now = Date.now()) {
  const venue = pos.venue || 'amm';
  const e = exitsFor(cfg, venue);
  const costBps = pos.venueCostBps ?? costBpsFor(cfg, venue);
  const price = pool?.priceUsd > 0 ? pool.priceUsd : pos.lastPrice;
  const liq = pool?.liqUsd > 0 ? pool.liqUsd : pos.lastLiqUsd;
  const exitValue = estimateExitValue(pos, price, liq, costBps);
  const pnlUsd = pos.realizedUsd + exitValue - pos.investedUsd;
  const pnlPct = pos.investedUsd ? pnlUsd / pos.investedUsd : 0;

  pos.pnlHistory.push(+pnlPct.toFixed(4));
  if (pos.pnlHistory.length > 8) pos.pnlHistory.shift();

  // The peak belongs to the position, not to the caller: the trailing stop has
  // to keep working even if a tick misses a price update.
  if (price > (pos.peakPx || 0)) pos.peakPx = price;
  const peakPx = pos.peakPx || price;
  const peakValue = estimateExitValue(pos, peakPx, liq, costBps);
  const peakPnlPct = pos.investedUsd ? (pos.realizedUsd + peakValue - pos.investedUsd) / pos.investedUsd : 0;
  // Persist the running peak so the dashboard and the closed-trade record show
  // what the trade actually reached, not just where it happened to be.
  pos.peakPnlPct = Math.max(pos.peakPnlPct ?? peakPnlPct, peakPnlPct);

  // A take-profit is only worth the exit fees if it banks real money: a $2
  // position at +18% makes pennies, so the ladder waits for the move to grow.
  // Protective exits (stop, collapse, rug) are never held back by this.
  //
  // The floor is judged on the trade's net profit and is capped at a share of
  // the stake. A flat dollar floor does not scale: on a ~$1.90 position a $1
  // minimum made every rung unreachable (TP1 is +22% x 45% = about $0.19), so a
  // position that ran +87% never banked a cent and rode the whole move back
  // into a rug. The floor now only suppresses genuinely tiny exits.
  const minTake = Math.min(Number(cfg.minTakeUsd) || 0, Math.max(0, pos.investedUsd) * 0.15);
  const banksEnough = () => pnlUsd >= minTake;

  // The message that goes in the log must not confuse the two: pnlPct is net of
  // exit costs and moves with the liquidity reading, while pricePct is what the
  // token is worth against the entry. Reading "now -2%" as the exit price is how
  // a +38% exit got recorded as a loss; every reason now states the price.
  const pricePct = pos.investedUsd ? (pos.realizedUsd + pos.qty * price - pos.investedUsd) / pos.investedUsd : 0;

  const heldSec = (now - pos.entryAt) / 1000;
  const hold = (reason = 'holding') => ({ action: 'hold', fraction: 0, reason, pnlPct, peakPnlPct, urgent: false });
  const sell = (fraction, reason, kind) => ({
    action: 'sell',
    fraction,
    reason,
    // The price this decision was made on: the fill must use it, not lastPrice.
    price,
    pnlPct,
    peakPnlPct,
    // Escalation must pay for itself: never trade a profit for a landing fee.
    urgent: worthEscalating(pnlPct, kind, cfg),
  });

  // 1. Rug detection: liquidity pulled or price gapping through the stop.
  if (pos.entryLiqUsd > 0 && liq > 0) {
    const drop = 1 - liq / pos.entryLiqUsd;
    if (drop * 100 >= e.rugLiqDropPct) return sell(1, `liquidity pulled ${(drop * 100).toFixed(0)}%`, 'rug');
  }
  if (pnlPct <= e.stopLossPct / 100) return sell(1, `stop loss ${(pnlPct * 100).toFixed(1)}%`, 'stop');

  // 2. Hard failure: price collapsed but stop loss not hit only because of the
  //    exit-slippage model; a 55% dump is unrecoverable in a 20 minute window.
  if (pnlPct <= -0.55) return sell(1, 'collapse', 'stop');

  // 3. Profit ladder (partials only fire once each).
  if (!pos.ladder.tp1 && pnlPct >= e.tp1Pct / 100 && banksEnough()) {
    pos.ladder.tp1 = true;
    return sell(e.tp1Size, `take profit 1 at +${(pnlPct * 100).toFixed(0)}% ($${(pnlUsd * e.tp1Size).toFixed(2)})`, 'profit');
  }
  if (!pos.ladder.tp2 && pnlPct >= e.tp2Pct / 100 && banksEnough()) {
    pos.ladder.tp2 = true;
    return sell(e.tp2Size, `take profit 2 at +${(pnlPct * 100).toFixed(0)}% ($${(pnlUsd * e.tp2Size).toFixed(2)})`, 'profit');
  }

  // 3b. Peak-drawdown stop. Every fast rug in the book had the same shape: a
  //     run to +40..+87%, then a collapse straight through the entry stop in a
  //     single tick, so the stop loss filled near the bottom (-100%). A stop
  //     measured from entry cannot fire inside a gap, but a stop measured from
  //     the peak acts on the give-back and exits while there is still a bid.
  //     It only arms once the trade has actually run, so entry noise and the
  //     ordinary stop loss still govern a trade that never moved.
  const drawdown = peakPx > 0 && price > 0 ? 1 - price / peakPx : 0;
  if (peakPnlPct >= e.peakStopArmPct / 100 && drawdown * 100 >= e.peakStopPct) {
    return sell(
      1,
      `peak stop: -${(drawdown * 100).toFixed(0)}% from the peak (peak +${(peakPnlPct * 100).toFixed(0)}%, now ${(pnlPct * 100).toFixed(0)}% net, price ${(pricePct * 100).toFixed(0)}%)`,
      'stop',
    );
  }

  // 4. Trailing stop on whatever is left, armed once the trade has run.
  if (peakPnlPct >= e.trailStartPct / 100) pos.trailArmed = true;
  if (pos.trailArmed) {
    const floor = peakPnlPct * (1 - e.trailGapPct / 100);
    // No dollar floor here: a trailing stop defends a gain that already exists,
    // and making it wait for a bigger one is how a +87% peak became a -100%
    // loss. The net PnL already has the exit cost priced in, so any remaining
    // gain is worth banking.
    if (pnlPct <= floor && pnlPct > 0) {
      return sell(
        1,
        `trailing stop at +${(pnlPct * 100).toFixed(0)}% net (peak +${(peakPnlPct * 100).toFixed(0)}%, price ${(pricePct * 100).toFixed(0)}%)`,
        'profit',
      );
    }
  }

  // 5. Momentum death: three consecutive lower readings while underwater.
  const h = pos.pnlHistory;
  if (h.length >= 4 && pnlPct < -0.08) {
    const last3 = h.slice(-3);
    if (last3[0] > last3[1] && last3[1] > last3[2] && last3[2] < 0) {
      return sell(1, 'momentum exhausted', 'profit');
    }
  }

  // 6. Time stop: dead money ties up a slot that a fresh launch could use.
  if (heldSec >= e.timeStopMin * 60 && pnlPct < e.timeStopMinGainPct / 100) {
    return sell(1, `time stop after ${Math.round(heldSec / 60)}m`, 'profit');
  }

  return hold();
}

/**
 * Pre-trade sanity on size: never take a position so large relative to pool
 * depth that the exit would move the price against us.
 */
export function maxSizeForPool(liqUsd, cfg) {
  return Math.max(0, liqUsd * 0.01); // <=1% of pool liquidity
}
