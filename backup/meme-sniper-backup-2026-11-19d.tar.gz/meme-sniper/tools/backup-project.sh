#!/usr/bin/env bash
# Build the off-app backup archive and publish it into the mirror's static
# assets. The archive holds the project with every secret redacted, and this
# script refuses to publish anything whose scan comes back dirty — a key must
# live in .env and the host's environment only, never in a file that leaves
# this machine.
#
#   bash tools/backup-project.sh 2026-11-19c
#
# then redeploy the site (the archive is a static asset) so the mirror and the
# GitHub workflow both pick up the new MANIFEST.
set -euo pipefail
cd "$(dirname "$0")/.."

STAMP="${1:-$(date -u +%Y-%m-%dT%H-%M)}"
NAME="meme-sniper-backup-${STAMP}.tar.gz"
OUT="site/assets/backup"
STAGE="$(mktemp -d)"
trap 'rm -rf "$STAGE"' EXIT
ROOT="$STAGE/meme-sniper"
mkdir -p "$ROOT" "$OUT"

echo "== staging project (env files, logs and built bundles excluded)"
tar -cf - \
  --exclude='./node_modules' --exclude='./.git' --exclude='./.secrets' \
  --exclude='./.env' --exclude='*/.env' --exclude='*/.env.*' \
  --exclude='*.log' --exclude='./site/assets' \
  --exclude='./deploy/render/app.tar.gz' --exclude='./deploy/meme-sniper.tar.gz' \
  . | tar -xf - -C "$ROOT"
# Both of those are built bundles, not source: the second one is an old build
# that still carries the settings.json snapshots with the key in them.

echo "== redacting secrets in the staged copy"
node - "$ROOT" <<'NODE'
const fs = require('fs');
const path = require('path');

const root = process.argv[2];
const RULES = [
  // ?api-key=<uuid> in a saved RPC URL. Length floor keeps placeholders and the
  // fake key in the selftests intact (they are 12 characters or fewer).
  [/api-key=[A-Za-z0-9._-]{20,}/g, 'api-key=REDACTED'],
  // Solscan bearer token (a JWT: three dot-separated base64url segments).
  [/eyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}/g, 'REDACTED'],
  // The same two values when they sit in a settings.json field.
  [/"((?:solanaRpcUrl|solscanApiKey|pumpfunApiKey|rpcUrl))"\s*:\s*"[^"]*"/g, '"$1": "REDACTED"'],
  // Bearer-style keys that could leak through a log or a snapshot.
  [/((?:INGEST_TOKEN|PUMPFUN_API_KEY|SOLSCAN_API_KEY)\s*[=:]\s*)["']?[A-Za-z0-9_]{20,}["']?/g, '$1REDACTED'],
];

const SKIP = new Set(['node_modules', '.git']);
let files = 0;
let hits = 0;

function walk(dir) {
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    if (SKIP.has(entry.name)) continue;
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) { walk(full); continue; }
    if (!entry.isFile()) continue;
    let text;
    try { text = fs.readFileSync(full, 'utf8'); } catch { continue; }
    if (!text || text.includes('\u0000')) continue; // binary
    files += 1;
    let out = text;
    for (const [re, to] of RULES) out = out.replace(re, to);
    if (out !== text) { fs.writeFileSync(full, out); hits += 1; }
  }
}

walk(root);
console.log(`   scanned ${files} text files, rewrote ${hits}`);
NODE

PATTERN='api-key=[A-Za-z0-9._-]{20,}|eyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\.|(INGEST_TOKEN|PUMPFUN_API_KEY|SOLSCAN_API_KEY)[=:][ ]*[A-Za-z0-9_]{20,}'

# A key can also be hiding inside a nested archive, where the text scan skips it
# as binary. Unpack every archive in the tree and scan what comes out.
scan_nested() {
  local dir="$1" depth="$2" found="" nested tmp hits
  while IFS= read -r nested; do
    [ -n "$nested" ] || continue
    tmp="$(mktemp -d)"
    case "$nested" in
      *.zip) command -v unzip >/dev/null && unzip -qq -o "$nested" -d "$tmp" 2>/dev/null || true ;;
      *) tar xf "$nested" -C "$tmp" 2>/dev/null || true ;;
    esac
    hits="$(grep -rIlE "$PATTERN" "$tmp" 2>/dev/null || true)"
    if [ -z "$hits" ] && [ "$depth" -gt 1 ]; then hits="$(scan_nested "$tmp" "$((depth - 1))")"; fi
    rm -rf "$tmp"
    [ -n "$hits" ] && found="$found$nested"'
'
  done < <(find "$dir" -type f \( -name '*.tar.gz' -o -name '*.tgz' -o -name '*.tar' -o -name '*.zip' \))
  printf '%s' "$found"
}

echo "== scanning the staged copy for anything that still looks like a key"
DIRTY="$(grep -rIlE "$PATTERN" "$ROOT" || true)"
NESTED="$(scan_nested "$ROOT" 2)"
if [ -n "$DIRTY" ] || [ -n "$NESTED" ]; then
  echo "!! refusing to publish: a secret survived redaction in" >&2
  [ -n "$DIRTY" ] && printf '   %s\n' $DIRTY >&2
  [ -n "$NESTED" ] && printf '   nested archive: %s\n' $NESTED >&2
  exit 23
fi
echo "   clean (including nested archives)"

echo "== packing"
tar -czf "$OUT/$NAME" -C "$STAGE" meme-sniper
SHA="$(sha256sum "$OUT/$NAME" | cut -d' ' -f1)"
BYTES="$(stat -c%s "$OUT/$NAME")"
COUNT="$(tar -tzf "$OUT/$NAME" | wc -l)"

cat > "$OUT/MANIFEST.txt" <<TXT
project  meme-sniper
archive  $NAME
sha256   $SHA
bytes    $BYTES
files    $COUNT
built    $(date -u +%Y-%m-%dT%H:%M:%SZ)
source   https://meme-sniper-jkzxfz-preview.freebuff.site/backup/$NAME
secrets  redacted api-key=<uuid>, Solscan token, settings.json key fields, bearer keys
excluded .env, .secrets, node_modules, .git, logs, site/assets, deploy/render/app.tar.gz
note     restore with: tar xzf $NAME && cd meme-sniper && npm ci
TXT

# One archive at a time: an older build must not keep serving a key.
find "$OUT" -maxdepth 1 -name '*.tar.gz' ! -name "$NAME" -print -delete

echo "== published $NAME"
echo "   sha256 $SHA"
echo "   $BYTES bytes, $COUNT entries"
