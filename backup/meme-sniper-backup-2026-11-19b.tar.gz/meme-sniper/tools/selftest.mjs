// Deterministic verification of the money path: fill accounting, the profit
// ladder, the trailing stop, the stop loss, rug detection and the time stop.
// Runs offline against a scripted price path, no network needed.
//
//   node tools/selftest.mjs

import { Portfolio } from '../src/portfolio.js';
import { evaluateExit } from '../src/strategy.js';
import { createPaperExecutor } from '../src/exec/paper.js';
import { config } from '../src/config.js';
import { shouldEscalate, worthEscalating, escalationCostBps, depthFillRate } from '../src/venues.js';
import { analyzeRug, fastRugExit } from '../src/rug.js';
import { SignalModel, PRIORS } from '../src/ai/model.js';
import { FEATURE_NAMES, extractFeatures } from '../src/ai/features.js';
import { summariseHolders, clusterHolders } from '../src/feeds/ownership.js';
import { saveSettings, settingsView, maskSecret } from '../src/settings.js';
import { derivedLiveAddress, liveConfigProblems } from '../src/config.js';
import { summariseWallet, WRAPPED_SOL } from '../src/feeds/wallet.js';

const cfg = { ...config, bankroll: 1000, positionSizePct: 5, roundTripCostBps: 1200, maxSlippageBps: 1500 };
const exec = createPaperExecutor(cfg);
const LIQ = 20000;
const NOW = Date.now();
let failures = 0;

const check = (label, cond, detail = '') => {
  if (!cond) failures += 1;
  console.log(`${cond ? '  ok  ' : ' FAIL '} ${label}${detail ? ` — ${detail}` : ''}`);
};

function freshPortfolio() {
  return new Portfolio(cfg, { cash: 1000, startingBankroll: 1000 });
}

async function open(priceUsd = 0.001) {
  const pf = freshPortfolio();
  const fill = await exec.buy({ priceUsd, sizeUsd: 50, liqUsd: LIQ });
  const pos = pf.openPosition({
    candidate: {
      chain: 'solana',
      pool: { poolAddress: 'POOL', baseToken: 'TOKEN', symbol: 'TEST', name: 'Test Coin', dex: 'raydium', liqUsd: LIQ, mcapUsd: 30000 },
      ageSec: 90,
    },
    sizeUsd: 50,
    fill,
    score: 0.71,
    features: {},
    reasons: ['test'],
    mode: 'paper',
  });
  return { pf, pos };
}

const pool = (priceUsd, liqUsd = LIQ) => ({ priceUsd, liqUsd });

// ---------------------------------------------------------------------------
console.log('\n[1] entry accounting');
{
  const { pf, pos } = await open(0.001);
  check('cash reduced by exactly the position size', Math.abs(pf.cash - 950) < 1e-9, `cash=${pf.cash}`);
  check('qty is net of the entry fee and slippage', pos.qty > 0 && pos.qty * pos.entryPrice < 50, `notional=${(pos.qty * pos.entryPrice).toFixed(2)}`);
  const immediate = evaluateExit(pos, pool(0.001), cfg, NOW);
  check('round-trip cost makes a flat trade a loss', immediate.pnlPct < -0.1, `pnl=${(immediate.pnlPct * 100).toFixed(1)}%`);
  check('flat trade is not sold', immediate.action === 'hold');
}

// ---------------------------------------------------------------------------
console.log('\n[2] profit ladder + trailing stop');
{
  const { pf, pos } = await open(0.001);
  const entryQty = pos.qty;

  const up1 = evaluateExit(pos, pool(0.001 * 1.95), cfg, NOW);
  check('TP1 fires on a strong move', up1.action === 'sell' && up1.fraction === 0.4, up1.reason);
  await (async () => {
    const fill = await exec.sell({ position: pos, priceUsd: 0.001 * 1.95, fraction: 0.4, liqUsd: LIQ });
    pf.applySell(pos, 0.4, fill, up1.reason);
  })();
  check('40% of the position was sold', Math.abs(pos.qty - entryQty * 0.6) < entryQty * 1e-6, `qty=${(pos.qty / entryQty).toFixed(3)} of entry`);
  check('proceeds landed in cash', pf.cash > 950, `cash=${pf.cash.toFixed(2)}`);

  const mid = evaluateExit(pos, pool(0.001 * 3.4), cfg, NOW);
  check('second leg waits for its own threshold', mid.action === 'hold', `pnl ${(mid.pnlPct * 100).toFixed(0)}% < TP2 ${cfg.exits.tp2Pct}%`);

  const up2 = evaluateExit(pos, pool(0.001 * 4.4), cfg, NOW);
  check('TP2 fires after the second leg', up2.action === 'sell' && up2.fraction === 0.35, up2.reason);
  await (async () => {
    const fill = await exec.sell({ position: pos, priceUsd: 0.001 * 4.4, fraction: 0.35, liqUsd: LIQ });
    pf.applySell(pos, 0.35, fill, up2.reason);
  })();
  check('trailing stop armed past +45%', pos.trailArmed, `peak=${(evaluateExit(pos, pool(0.001 * 4.4), cfg, NOW).peakPnlPct * 100).toFixed(0)}%`);

  const drop = evaluateExit(pos, pool(0.001 * 1.7), cfg, NOW);
  check('trailing stop exits the remainder', drop.action === 'sell' && drop.fraction === 1, drop.reason);
  await (async () => {
    const fill = await exec.sell({ position: pos, priceUsd: 0.001 * 1.7, fraction: 1, liqUsd: LIQ });
    pf.applySell(pos, 1, fill, drop.reason);
  })();
  const trade = pf.closePosition(pos, drop.reason);
  check('trade closed green', trade.pnlPct > 0.2, `net ${(trade.pnlPct * 100).toFixed(1)}% on $${trade.investedUsd}`);
  check('cash grew well past the bankroll', pf.cash > 1050, `cash=${pf.cash.toFixed(2)}`);
  check('position removed from book', pf.positions.length === 0 && pf.trades.length === 1);
}

// ---------------------------------------------------------------------------
console.log('\n[3] stop loss');
{
  const { pf, pos } = await open(0.001);
  const hit = evaluateExit(pos, pool(0.00055), cfg, NOW);
  check('stop loss triggers on a 45% dump', hit.action === 'sell' && hit.fraction === 1, hit.reason);
  const fill = await exec.sell({ position: pos, priceUsd: 0.00055, fraction: 1, liqUsd: LIQ });
  pf.applySell(pos, 1, fill, hit.reason);
  const trade = pf.closePosition(pos, hit.reason);
  check('loss is inside the modelled stop', trade.pnlPct < -0.3 && trade.pnlPct > -0.7, `${(trade.pnlPct * 100).toFixed(1)}%`);
  check('losing token is put on cooldown', pf.isCoolingDown('TOKEN'));
  check('loss streak counted', pf.consecutiveLosses === 1);
}

// ---------------------------------------------------------------------------
console.log('\n[4] rug detection');
{
  const { pf, pos } = await open(0.001);
  const rug = evaluateExit(pos, pool(0.00098, LIQ * 0.2), cfg, NOW);
  check('liquidity pull exits immediately', rug.action === 'sell' && /liquidity pulled/.test(rug.reason), rug.reason);
}

// ---------------------------------------------------------------------------
console.log('\n[5] time stop');
{
  const { pos } = await open(0.001);
  const later = NOW + 23 * 60 * 1000;
  const t = evaluateExit(pos, pool(0.0011), cfg, later);
  check('dead trade is recycled after the time stop', t.action === 'sell' && /time stop/.test(t.reason), t.reason);
}

// ---------------------------------------------------------------------------
console.log('\n[6] risk brakes');
{
  const pf = freshPortfolio();
  pf.pausedUntil = Date.now() + 60000;
  check('risk pause blocks entries', pf.entryBlock('X') === 'risk pause active');
  pf.pausedUntil = null;
  for (let i = 0; i < cfg.maxPositions; i++) pf.positions.push({ tokenAddress: `T${i}`, qty: 1, lastPrice: 1 });
  check('max positions enforced', /max positions/.test(pf.entryBlock('NEW')));
  pf.positions = [];
  pf.consecutiveLosses = cfg.maxConsecutiveLosses;
  check('loss streak halts entries', /losses in a row/.test(pf.entryBlock('NEW')));
}

// ---------------------------------------------------------------------------
console.log('\n[7] cheap-fee venue + exit fee escalation');
{
  const pf = freshPortfolio();
  const fill = await exec.buy({ priceUsd: 0.001, sizeUsd: 50, liqUsd: LIQ, venue: 'curve' });
  const pos = pf.openPosition({
    candidate: {
      chain: 'solana',
      venue: 'curve',
      pool: { poolAddress: 'CURVE', baseToken: 'CURVETOKEN', symbol: 'CURVE', name: 'Curve Coin', dex: 'pump-fun', liqUsd: LIQ, mcapUsd: 20000 },
      ageSec: 40,
    },
    sizeUsd: 50,
    fill,
    score: 0.7,
    features: {},
    reasons: ['test'],
    mode: 'paper',
  });
  check('venue detected from the pool dex id', pos.venue === 'curve', pos.venue);
  check('venue carries the cheap cost model', pos.venueCostBps === cfg.venues.curve.costBps, `${pos.venueCostBps}bps`);

  const flat = evaluateExit(pos, pool(0.001), cfg, NOW);
  check('a flat curve trade costs ~2.5%, not ~13%', flat.pnlPct > -0.05 && flat.pnlPct < -0.015, (flat.pnlPct * 100).toFixed(1) + '%');

  const up = evaluateExit(pos, pool(0.0013), cfg, NOW);
  check('curve TP1 banks a much smaller pop', up.action === 'sell' && up.fraction === cfg.venues.curve.exits.tp1Size && /take profit 1/.test(up.reason), up.reason);
  check('a profitable exit is allowed to pay for landing', up.urgent === true);

  const stop = evaluateExit(pos, pool(0.0007), cfg, NOW);
  check('stop loss never escalates fees', stop.action === 'sell' && /stop loss/.test(stop.reason) && stop.urgent === false, stop.reason);

  check('policy off disables escalation', shouldEscalate(0.2, 'profit', { exitEscalation: { policy: 'off' } }) === false);
  check('profit policy only escalates winners',
    shouldEscalate(0.2, 'profit', { exitEscalation: { policy: 'profit' } }) === true &&
      shouldEscalate(-0.1, 'profit', { exitEscalation: { policy: 'profit' } }) === false);
  check('rug escalation ignores the PnL sign', shouldEscalate(-0.4, 'rug', { exitEscalation: { policy: 'rug' } }) === true);

  // Paying to land is only worth it while the profit survives the fee.
  check('escalation cost is priced in basis points', escalationCostBps(cfg) === 450, `${escalationCostBps(cfg)}bps`);
  check('a thin profit is not worth an escalated exit', worthEscalating(0.02, 'profit', cfg) === false, '+2% vs 4.5%');
  check('a real profit still pays for the landing', worthEscalating(0.3, 'profit', cfg) === true);
  check('a rug escape escalates at any price', worthEscalating(-0.6, 'rug', cfg) === true);
  check('stop losses never escalate', worthEscalating(0.9, 'stop', cfg) === false);

  {
    const tight = { ...cfg, minTakeUsd: 0, venues: { ...cfg.venues, curve: { ...cfg.venues.curve, exits: { ...cfg.venues.curve.exits, tp1Pct: 0.5 } } } };
    const pf2 = freshPortfolio();
    const f2 = await exec.buy({ priceUsd: 0.001, sizeUsd: 50, liqUsd: LIQ, venue: 'curve' });
    const p2 = pf2.openPosition({
      candidate: { chain: 'solana', venue: 'curve', pool: { poolAddress: 'C2', baseToken: 'T2', symbol: 'T2', name: 'T2', dex: 'pump-fun', liqUsd: LIQ, mcapUsd: 20000 }, ageSec: 40 },
      sizeUsd: 50, fill: f2, score: 0.7, features: {}, reasons: ['test'], mode: 'paper',
    });
    // With the $1 floor on (the default) this $0.22 take never fires; with the
    // floor off it fires and must not buy priority fees to save $0.22.
    const floored = evaluateExit(p2, pool(0.001 * 1.05), { ...tight, minTakeUsd: 1 }, NOW);
    check('the take-profit floor suppresses a $0.22 take', floored.action === 'hold', `${(floored.pnlPct * 100).toFixed(1)}% ${floored.action}`);
    const small = evaluateExit(p2, pool(0.001 * 1.05), tight, NOW);
    check('a +2% exit sells without buying the rush', small.action === 'sell' && small.urgent === false, `${(small.pnlPct * 100).toFixed(1)}% urgent=${small.urgent}`);
  }

  const escalatedFill = await exec.sell({ position: pos, priceUsd: 0.0013, fraction: 1, liqUsd: LIQ, urgent: true });
  const plainFill = await exec.sell({ position: pos, priceUsd: 0.0013, fraction: 1, liqUsd: LIQ, urgent: false });
  check('an escalated exit really costs more', escalatedFill.proceedsUsd < plainFill.proceedsUsd, `$${escalatedFill.proceedsUsd.toFixed(2)} vs $${plainFill.proceedsUsd.toFixed(2)}`);
}

// ---------------------------------------------------------------------------
console.log('\n[8] fills are liquidity-proportional');
{
  const deep = depthFillRate(50, 20000);
  const thin = depthFillRate(50, 100);
  const dead = depthFillRate(50, 0);
  check('a deep pool costs almost nothing to cross', deep > 0.99 && deep <= 1, deep.toFixed(4));
  check('a thin pool takes a real haircut', thin > 0 && thin < 0.7, thin.toFixed(3));
  check('an emptied pool returns exactly nothing', dead === 0, String(dead));

  // The bug this guards against: a bag marked at 24x in a pool that no longer exists.
  const { pf, pos } = await open(0.001);
  pos.lastPrice = 0.024;
  pos.lastLiqUsd = 0;
  check('you cannot exit at a high price into dead liquidity', pf.netPnlPct(pos) === -1, (pf.netPnlPct(pos) * 100).toFixed(0) + '%');
}

// ---------------------------------------------------------------------------
console.log('\n[9] rug analysis');
{
  const cleanPool = {
    liqUsd: 30000, mcapUsd: 120000, priceUsd: 0.001,
    txns: { m5: { buys: 40, sells: 18, uniqueTraders: 30 }, h1: { buys: 90, sells: 40 } },
    pc: { m5: 20 }, createdAtMs: NOW - 120000,
  };
  const cleanInfo = {
    honeypot: 'no', mintAuthority: 'no', freezeAuthority: 'no',
    holderConcentration: 30, holders: 120, gtVerified: true, socials: { twitter: 'x' },
  };
  const flat = Array.from({ length: 10 }, (_, i) => ({ t: NOW - (10 - i) * 60000, o: 0.001, h: 0.0012, l: 0.00095, c: 0.001, v: 100 }));

  const clean = analyzeRug({ pool: cleanPool, info: cleanInfo, ds: {}, candles: flat }, cfg);
  check('a healthy launch scores low risk', clean.risk < 25 && clean.veto === null, `risk ${clean.risk}`);

  const honey = analyzeRug({ pool: cleanPool, info: { ...cleanInfo, honeypot: 'yes' }, ds: {}, candles: flat }, cfg);
  check('honeypot is a hard veto', /honeypot/.test(honey.veto || '') && honey.risk === 100, honey.veto);

  const concentrated = analyzeRug({ pool: cleanPool, info: { ...cleanInfo, holderConcentration: 82 }, ds: {}, candles: flat }, cfg);
  check('top-10 concentration blocks entry', /top 10/.test(concentrated.veto || ''), concentrated.veto);

  const draining = analyzeRug({ pool: { ...cleanPool, liqUsd: 12000 }, info: cleanInfo, ds: {}, candles: flat }, cfg, { history: { firstLiqUsd: 30000 } });
  check('a pool already draining is refused', /liquidity already down/.test(draining.veto || ''), draining.veto);

  const dump = analyzeRug({ pool: cleanPool, info: cleanInfo, ds: {}, candles: [...flat, { t: NOW, o: 0.001, h: 0.001, c: 0.0002, v: 500 }] }, cfg);
  check('a single-minute dump is a hard veto', /dump in one minute/.test(dump.veto || ''), dump.veto);

  // No candles this scan (only the first candidate gets them): the pool's own
  // price window still has to catch a dump that is already happening.
  const noCandles = analyzeRug({ pool: { ...cleanPool, pc: { m5: -58 } }, info: cleanInfo, ds: {}, candles: [] }, cfg);
  check('a dump visible only in the price window still scores', noCandles.risk >= 25 && noCandles.signals.some((s) => s.id === 'dump-5m'), `risk ${noCandles.risk}: ${noCandles.summary}`);

  const pressure = analyzeRug({
    pool: {
      ...cleanPool,
      liqUsd: 9000,
      mcapUsd: 300000,
      txns: { m5: { buys: 20, sells: 30, uniqueTraders: 15 }, h1: { buys: 20, sells: 25 } },
    },
    info: { ...cleanInfo, holderConcentration: 60, gtVerified: false, socials: {} },
    ds: {}, candles: flat,
  }, cfg);
  check('distribution pressure accumulates risk', pressure.risk >= 40 && pressure.risk < cfg.rug.maxRisk, `risk ${pressure.risk}: ${pressure.summary}`);
  check('risky-but-not-fatal raises the entry bar instead of blocking', pressure.veto === null && pressure.risk >= cfg.rug.bonusFromRisk, pressure.veto || 'no veto');
}

// ---------------------------------------------------------------------------
console.log('\n[10] fast post-entry rug watch');
{
  // A real drain always comes with price damage: the last price sits below the
  // position's peak. Liquidity-only signals are gated on that.
  const base = { symbol: 'T', qty: 50000, lastPrice: 0.001, peakPx: 0.0011, entryLiqUsd: 20000, lastLiqUsd: 20000 };
  check('a healthy position is left alone', fastRugExit({ ...base }, cfg) === null);

  const tickLiq = fastRugExit({ ...base, tickLiqDropPct: 0.22 }, cfg);
  check('a 22% depth drop in one tick triggers an exit', Boolean(tickLiq) && /liquidity -22% in one tick/.test(tickLiq.reason), tickLiq?.reason);

  const fromEntry = fastRugExit({ ...base, lastLiqUsd: 12000 }, cfg);
  check('liquidity 40% below entry triggers an exit', Boolean(fromEntry) && /from entry/.test(fromEntry.reason), fromEntry?.reason);

  const shallow = fastRugExit({ ...base, entryLiqUsd: 100, lastLiqUsd: 100 }, cfg);
  check('a pool thinner than 3x the position triggers an exit', Boolean(shallow) && /depth/.test(shallow.reason), shallow?.reason);

  const dump = fastRugExit({ ...base, tickPxDropPct: 0.3 }, cfg);
  check('a 30% single-tick dump triggers an exit', Boolean(dump) && /price -30%/.test(dump.reason), dump?.reason);

  check('a drained pool is not waited on for the 65% rule', fastRugExit({ ...base, lastLiqUsd: 8000 }, cfg)?.kind === 'rug');

  const phantom = fastRugExit({ ...base, peakPx: 0.001, tickLiqDropPct: 0.95 }, cfg);
  check('a depth collapse while the price prints a new high is a feed gap, not a rug', phantom === null, phantom?.reason);
}

// ---------------------------------------------------------------------------
console.log('\n[11] self-learning feature signs');
{
  const neutral = Object.fromEntries(FEATURE_NAMES.map((n) => [n, 0.5]));
  const learnBoth = (model) => {
    for (let i = 0; i < 16; i++) {
      // socials present -> the trade rugs; no socials -> it makes money
      model.learn({ ...neutral, social: 1 }, -0.6, { kind: 'rug' });
      model.learn({ ...neutral, social: 0 }, 0.25, { kind: 'profit' });
    }
  };

  const learning = new SignalModel();
  learnBoth(learning);
  check('a prior the book contradicts flips its anchor', learning.flippedSigns().some((f) => f.name === 'social'), learning.flippedSigns().map((f) => f.name).join(',') || 'none');
  check('the contradicted feature ends up negative', learning.weights.social < 0, learning.weights.social.toFixed(2));
  check('the flip is reported in the model stats', Array.isArray(learning.stats().flippedSigns));

  const frozen = new SignalModel({}, { signLearning: false });
  learnBoth(frozen);
  check('sign learning can be disabled for measurement', frozen.flippedSigns().length === 0, `${frozen.flippedSigns().length} flipped`);

  const early = new SignalModel();
  early.learn({ ...neutral, social: 1 }, -0.6, { kind: 'rug' });
  check('a single bad trade cannot flip a prior', early.flippedSigns().length === 0);
  check('priors stay the anchor before the sample gate', early.anchorTarget('social') === PRIORS.social);
}

// ---------------------------------------------------------------------------
console.log('\n[12] entry-time ownership');
{
  const accounts = [
    { address: 'POOL_ACCOUNT', owner: 'POOL', uiAmount: 500000 },
    { address: 'A1', owner: 'W1', uiAmount: 200000 },
    { address: 'A2', owner: 'W2', uiAmount: 100000 },
    { address: 'A3', owner: 'DEV', uiAmount: 50000 },
    { address: 'A4', owner: 'W4', uiAmount: 50000 },
  ];
  const s = summariseHolders(accounts, { supply: 1000000, poolAddresses: ['POOL_ACCOUNT'], devAddress: 'DEV' });
  check('the pool token account is not counted as a holder', s.holders === 4 && Math.abs(s.outsideTop20Pct - 60) < 0.01, `holders=${s.holders} outside top20=${s.outsideTop20Pct}%`);
  check('top-10 share is measured against supply', Math.abs(s.top10Pct - 40) < 0.01, `${s.top10Pct}%`);
  check('dev share is measured against supply', Math.abs(s.devPct - 5) < 0.01, `${s.devPct}%`);

  const clusters = await clusterHolders(
    [{ owner: 'W1', pct: 20 }, { owner: 'W2', pct: 10 }, { owner: 'W4', pct: 5 }],
    async (owner) => (owner === 'W4' ? 'W9' : 'FUNDER'),
  );
  check('wallets funded by one address collapse into a cluster', clusters.wallets === 2 && Math.abs(clusters.clusterPct - 30) < 0.01, JSON.stringify(clusters));

  const fpool = {
    priceUsd: 0.001, liqUsd: 30000, mcapUsd: 100000, createdAtMs: NOW - 120000,
    txns: { m5: { buys: 20, sells: 10, uniqueTraders: 10 }, h1: { buys: 40, sells: 20 } },
    vol: { m5: 5000, h1: 20000 }, pc: { m5: 10 },
  };
  const withOwn = extractFeatures({ pool: fpool, info: {}, ds: {}, candles: [], ownership: s }, cfg);
  const without = extractFeatures({ pool: fpool, info: {}, ds: {}, candles: [] }, cfg);
  check('ownership moves the holder feature', withOwn.features.holderTop10 < 0.8 && Math.abs(without.features.holderTop10 - 0.5) < 1e-9, `with ${withOwn.features.holderTop10}, without ${without.features.holderTop10}`);
  check('missing ownership stays neutral', without.features.bundleShare === 0.5 && without.features.devShare === 0.5);

  const pooled = summarizeClean();
  const concentrated = analyzeRug({
    pool: pooled.pool, info: {}, ds: {}, candles: pooled.candles,
    ownership: { ok: true, top10Pct: 85, holders: 12, devPct: 2, clusters: null },
  }, cfg);
  check('on-chain concentration vetoes without GeckoTerminal data', /top 10/.test(concentrated.veto || ''), concentrated.veto);

  const bundled = analyzeRug({
    pool: pooled.pool, info: {}, ds: {}, candles: pooled.candles,
    ownership: { ok: true, top10Pct: 30, holders: 40, devPct: 1, clusters: { checked: 4, wallets: 3, clusterPct: 75 } },
  }, cfg);
  check('one funder behind the top wallets is a hard veto', /share one funder/.test(bundled.veto || ''), bundled.veto);

  const devHold = analyzeRug({
    pool: pooled.pool, info: {}, ds: {}, candles: pooled.candles,
    ownership: { ok: true, top10Pct: 20, holders: 40, devPct: 20, clusters: null },
  }, cfg);
  check('a dev still holding the float adds risk', devHold.signals.some((x) => x.id === 'dev-holding'), devHold.summary);
}

function summarizeClean() {
  const candles = Array.from({ length: 10 }, (_, i) => ({ t: NOW - (10 - i) * 60000, o: 0.001, h: 0.0012, l: 0.00095, c: 0.001, v: 100 }));
  return {
    candles,
    pool: {
      liqUsd: 30000, mcapUsd: 120000, priceUsd: 0.001,
      txns: { m5: { buys: 40, sells: 18, uniqueTraders: 30 }, h1: { buys: 90, sells: 40 } },
      pc: { m5: 20 }, createdAtMs: NOW - 120000,
    },
  };
}

// ---------------------------------------------------------------------------
console.log('\n[13] dashboard settings');
{
  const cfg2 = {
    mode: 'paper',
    ownership: { enabled: true, deep: false, rpcUrl: '' },
    minScore: 0.6, minLiqUsd: 15000, maxLiqUsd: 600000, positionSizePct: 2.5,
    maxPositions: 5, scanIntervalMs: 25000,
    exitEscalation: { policy: 'profit,rug' },
    rug: { maxRisk: 70 },
    rugWatch: { tickLiqDropPct: 18, liqDropFromEntryPct: 35, tickPxDropPct: 25 },
  };
  const res = saveSettings(
    {
      minScore: '0.75',
      rugWatchTickLiqPct: 12,
      maxPositions: 99,
      exitFeeEscalation: 'nonsense',
      solanaRpcUrl: 'https://example.test/?api-key=REDACTED',
      notASetting: 1,
    },
    cfg2,
    { persist: false },
  );
  check('a saved setting applies to the live config', cfg2.minScore === 0.75 && cfg2.rugWatch.tickLiqDropPct === 12, `minScore=${cfg2.minScore}`);
  check('numbers are clamped to their bounds', cfg2.maxPositions === 20, String(cfg2.maxPositions));
  check('an invalid option is rejected', res.rejected.some((r) => r.key === 'exitFeeEscalation'), JSON.stringify(res.rejected.map((r) => r.key)));
  check('an unknown key is rejected', res.rejected.some((r) => r.key === 'notASetting'));
  check('a bad URL is rejected', saveSettings({ solanaRpcUrl: 'not-a-url' }, cfg2, { persist: false }).rejected.some((r) => r.key === 'solanaRpcUrl'));

  const view = JSON.stringify(settingsView(cfg2));
  check('the API key is masked, never echoed', !view.includes('abcdef123456'), 'masked');
  check('a configured secret is reported as set', settingsView(cfg2).fields.find((f) => f.key === 'solanaRpcUrl').configured === true);
  check('short secrets are fully masked', maskSecret('abc') === '••••');

  const cfg3 = { wallet: { paperAddress: '', network: 'mainnet', liveAddress: '' } };
  saveSettings({ paperWalletAddress: '9WzDXwBbmkg8ZTbNMqUxvQRAyrZzDsGYdLVL9zYtAWWM' }, cfg3, { persist: false });
  check('a Solana test wallet is accepted', cfg3.wallet.paperAddress.startsWith('9WzDX'), cfg3.wallet.paperAddress);
  saveSettings({ paperWalletAddress: '0x' + 'ab'.repeat(20) }, cfg3, { persist: false });
  check('an EVM test wallet is accepted', cfg3.wallet.paperAddress === '0x' + 'ab'.repeat(20));
  check(
    'a junk test wallet is rejected',
    saveSettings({ paperWalletAddress: 'my phantom wallet' }, cfg3, { persist: false }).rejected.some((r) => r.key === 'paperWalletAddress'),
  );
  saveSettings({ liveWalletAddress: '0x' + 'AB'.repeat(20) }, cfg3, { persist: false });
  check('a live EVM wallet keeps its checksum casing', cfg3.wallet.liveAddress === '0x' + 'AB'.repeat(20));
  check(
    'a live wallet must be 0x-hex, not base58',
    saveSettings({ liveWalletAddress: '9WzDXwBbmkg8ZTbNMqUxvQRAyrZzDsGYdLVL9zYtAWWM' }, cfg3, { persist: false }).rejected.some((r) => r.key === 'liveWalletAddress'),
  );
  saveSettings({ paperWalletNetwork: 'devnet' }, cfg3, { persist: false });
  check('the test wallet can be switched to devnet', cfg3.wallet.network === 'devnet', cfg3.wallet.network);
  check(
    'an unknown network is rejected',
    saveSettings({ paperWalletNetwork: 'testnet' }, cfg3, { persist: false }).rejected.some((r) => r.key === 'paperWalletNetwork'),
  );
  check('an empty wallet clears the field', (() => {
    saveSettings({ paperWalletAddress: '' }, cfg3, { persist: false });
    return cfg3.wallet.paperAddress === '';
  })());

  // derivedLiveAddress must never throw when ethers (optional) is absent.
  check('the live key address degrades safely without ethers', derivedLiveAddress({ live: { privateKey: '0x' + '11'.repeat(32) }, wallet: {} }) === null || typeof derivedLiveAddress({ live: { privateKey: '0x' + '11'.repeat(32) }, wallet: {} }) === 'string');
  const liveProblems = liveConfigProblems({ mode: 'live', live: { rpcUrl: 'x', privateKey: '', nativeUsdPrice: 1, confirm: 'I_UNDERSTAND_THE_RISK' }, chains: ['base'], wallet: {} });
  check('live mode requires a signing key', liveProblems.some((p) => /WALLET_PRIVATE_KEY/.test(p)), JSON.stringify(liveProblems));
}

// ---------------------------------------------------------------------------
console.log('\n[14] test wallet balances');
{
  const prices = { [WRAPPED_SOL]: 150, MemeCoin111: 0.01 };
  const view = summariseWallet({
    lamports: 2_500_000_000,
    tokens: [{ mint: 'MemeCoin111', amount: 1000, decimals: 6 }, { mint: 'NoMarket222', amount: 5, decimals: 0 }],
    priceOf: (m) => prices[m] ?? null,
    address: 'TestWallet',
    at: 1,
  });
  check('SOL is valued at the SOL price', view.sol === 2.5 && view.solUsd === 375, `${view.sol} SOL / $${view.solUsd}`);
  check('a priced token contributes USD value', view.tokenUsd === 10, String(view.tokenUsd));
  check('an unpriced token is listed but not counted', view.unpriced === 1 && view.tokenCount === 2, JSON.stringify([view.unpriced, view.tokenCount]));
  check('total = SOL + priced tokens', view.totalUsd === 385, String(view.totalUsd));
  check('zero balance reads as zero, not NaN', summariseWallet({ priceOf: () => null }).totalUsd === 0);
  check('an empty wallet has no token value', summariseWallet({ lamports: 1e9, priceOf: () => 150 }).tokenCount === 0);
}

// ---------------------------------------------------------------------------
console.log('\n[15] minimum trade + minimum take-profit');
{
  const { Portfolio } = await import('../src/portfolio.js');
  const { evaluateExit } = await import('../src/strategy.js');
  const cfgT = { ...config, minTradeUsd: 1, minTakeUsd: 1 };

  const seeded = new Portfolio(cfgT, { cash: 1.5, startingBankroll: 1.5 });
  check('a $1.50 book clears the cash gate at a $1 minimum', seeded.entryBlock('MintA') === null, String(seeded.entryBlock('MintA')));
  const broke = new Portfolio(cfgT, { cash: 0.9, startingBankroll: 0.9 });
  check('a $0.90 book is refused', /insufficient cash/.test(broke.entryBlock('MintA')), String(broke.entryBlock('MintA')));

  const mkPos = (gain) => ({
    venue: 'curve',
    venueCostBps: 250,
    qty: 1000,
    entryPrice: 0.00183,
    investedUsd: 1.83,
    realizedUsd: 0,
    lastPrice: 0.00183 * (1 + gain),
    lastLiqUsd: 20000,
    entryLiqUsd: 20000,
    ladder: { tp1: false, tp2: false },
    pnlHistory: [],
    peakPx: 0.00183 * (1 + gain),
    peakPnlPct: 0,
    entryAt: Date.now(),
  });

  // The $1 floor used to make every rung unreachable on a sub-$2 position: a
  // +18% pop nets about $0.30, so the ladder never fired and winners rode back
  // down. The floor now scales with the stake.
  const rung = evaluateExit(mkPos(0.22), null, cfgT);
  check('a +22% pop banks its rung on a $1.83 position', rung.action === 'sell' && /take profit 1/.test(rung.reason), `${rung.action} ${rung.reason}`);
  const big = evaluateExit(mkPos(1.3), null, cfgT);
  check('a +130% pop still banks TP1', big.action === 'sell' && /take profit 1/.test(big.reason), big.reason);
  const penny = evaluateExit(mkPos(0.05), null, cfgT);
  check('a +5% pop is below the first rung and still holds', penny.action === 'hold', `${penny.action} ${penny.reason}`);
  const hugeFloor = evaluateExit(mkPos(0.22), null, { ...cfgT, minTakeUsd: 1000 });
  check('a floor larger than the stake cannot block the ladder', hugeFloor.action === 'sell' && /take profit 1/.test(hugeFloor.reason), hugeFloor.reason);
  const noFloor = evaluateExit(mkPos(0.22), null, { ...cfgT, minTakeUsd: 0 });
  check('with the floor at $0 the same pop takes profit', noFloor.action === 'sell' && /take profit 1/.test(noFloor.reason), noFloor.reason);

  // A trailing stop defends an existing gain; it must not wait for a dollar.
  const defended = mkPos(0.05);
  defended.peakPx = 0.00183 * 1.45; // it did run to +45% before giving most of it back
  defended.peakPnlPct = 0.45;
  defended.trailArmed = true;
  // Widen the peak stop so this checks the trailing rule, not the rule that now
  // gets there first on a 28% give-back.
  const trailCfg = { ...cfgT, venues: { ...cfgT.venues, curve: { ...cfgT.venues.curve, exits: { ...cfgT.venues.curve.exits, peakStopPct: 99 } } } };
  const trail = evaluateExit(defended, null, trailCfg);
  check('the trailing stop banks a small gain instead of waiting for $1', trail.action === 'sell' && /trailing stop/.test(trail.reason), trail.reason);

  const stop = evaluateExit(mkPos(-0.3), null, cfgT);
  check('the stop loss is never held back by the take-profit floor', stop.action === 'sell' && /stop loss/.test(stop.reason), stop.reason);
}

// ---------------------------------------------------------------------------
console.log('\n[16] drained pools cannot pay out');
{
  const { createPaperExecutor } = await import('../src/exec/paper.js');
  const { Engine } = await import('../src/engine.js');
  const pex = createPaperExecutor(cfg);
  const { pos } = await open(0.001);

  const drained = await pex.sell({ position: pos, priceUsd: 0.35, fraction: 1, liqUsd: 0 });
  check('an exit into a drained pool pays nothing', drained.proceedsUsd === 0 && drained.fillPrice === 0, `proceeds=${drained.proceedsUsd}`);

  const thin = await pex.sell({ position: pos, priceUsd: 0.35, fraction: 1, liqUsd: 70 });
  check('an exit is capped at the pool quote depth', thin.grossUsd <= 35.0001, `gross=$${thin.grossUsd.toFixed(2)}`);

  const normal = await pex.sell({ position: pos, priceUsd: 0.0012, fraction: 1, liqUsd: LIQ });
  check('a normal exit is unaffected by the cap', normal.proceedsUsd > 40 && normal.proceedsUsd < 60, `proceeds=$${normal.proceedsUsd.toFixed(2)}`);

  const engineUnderTest = new Engine(cfg);
  check('a missing depth reading falls back to the last real depth', engineUnderTest.exitDepth({ lastLiqUsd: 30000, lastObservedLiqUsd: 0 }) === 30000);

  // Regression: some PumpSwap pairs report $0 liquidity while still trading, and
  // the old code turned that into a $0 fill on a position that was actually up.
  const { pos: live } = await open(0.001);
  engineUnderTest.applyPrice(live, { priceUsd: 0.002, liqUsd: 0 });
  check('a zero liquidity tick does not wipe the exit depth', engineUnderTest.exitDepth(live) === LIQ, `depth=${engineUnderTest.exitDepth(live)}`);
  const upExit = await pex.sell({ position: live, priceUsd: 0.002, fraction: 1, liqUsd: engineUnderTest.exitDepth(live) });
  check('a position up 2x still fills at depth after a zero liquidity tick', upExit.proceedsUsd > 40, `proceeds=$${upExit.proceedsUsd.toFixed(2)}`);
  engineUnderTest.applyPrice(live, { priceUsd: 0.002, liqUsd: 35 });
  check('a real thin reading still caps the exit', engineUnderTest.exitDepth(live) === 35, `depth=${engineUnderTest.exitDepth(live)}`);
  check('exit depth uses the thinner of the two readings', engineUnderTest.exitDepth({ lastLiqUsd: 30000, lastObservedLiqUsd: 35 }) === 35);
  check('exit depth falls back when nothing was observed', engineUnderTest.exitDepth({ lastLiqUsd: 30000 }) === 30000);
}

// ---------------------------------------------------------------------------
console.log('\n[17] peak-drawdown stop (fast rug guard)');
{
  const { evaluateExit } = await import('../src/strategy.js');
  const mk = (gain, peakGain) => ({
    venue: 'pumpswap',
    venueCostBps: 150,
    qty: 1000,
    entryPrice: 0.0019, // qty * entryPrice === investedUsd, or every case reads as -45%
    investedUsd: 1.9,
    realizedUsd: 0,
    lastPrice: 0.0019 * (1 + gain),
    peakPx: 0.0019 * (1 + peakGain),
    lastLiqUsd: 20000,
    entryLiqUsd: 20000,
    // TP1 already banked, so the rung cannot answer these checks for us.
    ladder: { tp1: true, tp2: false },
    trailArmed: false,
    pnlHistory: [],
    peakPnlPct: 0,
    entryAt: Date.now(),
  });

  const gaveBack = evaluateExit(mk(0.05, 0.87), null, config);
  check('a winner giving back past the peak stop exits before the entry stop', gaveBack.action === 'sell' && /peak stop/.test(gaveBack.reason), `${gaveBack.action} ${gaveBack.reason}`);

  const underwater = evaluateExit(mk(-0.12, 0.4), null, config);
  check('the peak stop also catches a run-up that has gone underwater', underwater.action === 'sell' && /peak stop/.test(underwater.reason), `${underwater.action} ${underwater.reason}`);

  const neverRan = evaluateExit(mk(-0.1, 0.03), null, config);
  check('a trade that never ran is left to the ordinary stop loss', neverRan.action === 'hold', `${neverRan.action} ${neverRan.reason}`);

  const smallPeak = evaluateExit(mk(0.05, 0.12), null, config);
  check('a peak under the arm threshold does not trigger it', smallPeak.action === 'hold', `${smallPeak.action} ${smallPeak.reason}`);

  const widened = { ...config, venues: { ...config.venues, pumpswap: { ...config.venues.pumpswap, exits: { ...config.venues.pumpswap.exits, peakStopPct: 99 } } } };
  const wide = evaluateExit(mk(0.05, 0.87), null, widened);
  // With the peak stop widened past the drawdown the trailing stop takes over,
  // so what matters is that the peak rule itself no longer fires.
  check('the threshold is per venue and configurable', !/peak stop/.test(wide.reason), `${wide.action} ${wide.reason}`);
}

// ---------------------------------------------------------------------------
console.log('\n[18] entry quality gate');
{
  const { entryQualityVeto } = await import('../src/rug.js');
  check('a quiet, safe launch passes', entryQualityVeto({ features: { safety: 0.9 }, volToLiq5m: 0.1 }, config) === null);

  // The cap is a ratio against pool liquidity, so it is asserted at explicit
  // thresholds rather than at whatever today's default happens to be: the
  // coupling with MIN_LIQ_USD is exactly why a thin pool trips it.
  const at = (cap) => ({ ...config, entryQuality: { ...config.entryQuality, maxVolumeToLiquidity5m: cap } });
  const churn = entryQualityVeto({ features: { safety: 0.9 }, volToLiq5m: 0.55 }, at(1 / 3));
  check('churn above a third of the pool is vetoed when the cap is a third', /churn/.test(churn || ''), String(churn));
  check('the same ratio passes at the 100% cap', entryQualityVeto({ features: { safety: 0.9 }, volToLiq5m: 0.55 }, at(1)) === null);
  check(
    'a pool trading twice its own liquidity is still vetoed at the 100% cap',
    /churn/.test(entryQualityVeto({ features: { safety: 0.9 }, volToLiq5m: 2.2 }, at(1)) || ''),
  );

  const unsafe = entryQualityVeto({ features: { safety: 0.62 }, volToLiq5m: 0.1 }, config);
  check('a weak safety score is vetoed', /safety/.test(unsafe || ''), String(unsafe));

  check('a zero churn ratio on its own is not a churn veto', entryQualityVeto({ features: { safety: 0.9 }, volToLiq5m: 0 }, config) === null);
  check('missing safety data is not a safety veto', entryQualityVeto({ features: {}, volToLiq5m: 0.1 }, config) === null);

  // Unknown is not the same as fine: gaps reported by the feature extractor are
  // a rejection, and the veto names what could not be seen.
  const noVol = entryQualityVeto({ features: { safety: 0.9 }, volToLiq5m: 0, missing: ['5m volume'] }, config);
  check('missing inputs are a rejection, not a neutral score', /not enough data: 5m volume/.test(noVol || ''), String(noVol));

  const noHolders = entryQualityVeto({ features: { safety: 0.9 }, volToLiq5m: 0.1, missing: ['holder table', 'market cap'] }, config);
  check('every missing input is named in the veto', /holder table, market cap/.test(noHolders || ''), String(noHolders));

  const missingFirst = entryQualityVeto({ features: { safety: 0.1 }, volToLiq5m: 5, missing: ['liquidity'] }, config);
  check('missing data is reported before churn or safety', /not enough data/.test(missingFirst || ''), String(missingFirst));

  const lenient = entryQualityVeto({ features: { safety: 0.9 }, volToLiq5m: 0.1, missing: ['5m volume'] }, { ...config, entryQuality: { ...config.entryQuality, requireData: false } });
  check('with requireData off partial data trades again', lenient === null, String(lenient));

  const off = entryQualityVeto({ features: { safety: 0.1 }, volToLiq5m: 5 }, { ...config, entryQuality: { maxVolumeToLiquidity5m: 0, minSafety: 0 } });
  check('the gate can be disabled from config', off === null, String(off));

  // A chain with no holder source can never satisfy requireData, so it is not
  // worth scanning (and spending rate limit on).
  const { scannableChains } = await import('../src/engine.js');
  const strict = scannableChains({ chains: ['solana', 'base'], entryQuality: { requireData: true } });
  check('with requireData on, only chains that can supply holders are scanned', strict.length === 1 && strict[0] === 'solana', JSON.stringify(strict));
  const loose = scannableChains({ chains: ['solana', 'base'], entryQuality: { requireData: false } });
  check('requireData off restores every configured chain', loose.length === 2, JSON.stringify(loose));
  check('a Solana-only config is untouched', JSON.stringify(scannableChains({ chains: ['solana'], entryQuality: { requireData: true } })) === JSON.stringify(['solana']));
}

// ---------------------------------------------------------------------------
console.log('\n[19] entry gate accounting');
{
  const { GateStats, classifyVeto } = await import('../src/gate-stats.js');
  check('a churn veto is classified', classifyVeto('churn: 5m volume is 55% of pool liquidity (max 33%)') === 'churn');
  check('a safety veto is classified', classifyVeto('safety 0.62 < 0.7 (holder concentration / authorities)') === 'safety');
  check('a rug veto is classified', classifyVeto('rug 82/100 — top 10 wallets hold ~95%') === 'rug');
  check('an empty veto is ignored', classifyVeto('') === null);

  const g = new GateStats();
  g.ensureBaseline({ trades: 26, wins: 18, losses: 8, realizedUsd: 11.23 });
  g.record('churn: x');
  g.record('churn: y');
  g.record('safety 0.5 < 0.7');
  const tally = g.endScan();
  check('the per-scan tally splits by rule', tally.churn === 2 && tally.safety === 1 && tally.rug === 0, JSON.stringify(tally));
  check('the tally resets after a scan', g.endScan().churn === 0);

  const v = g.view({ trades: 30, wins: 21, losses: 9, realizedUsd: 15.5 });
  check('the baseline is frozen at first sight', v.baseline.trades === 26 && v.baseline.winRate === 0.6923, JSON.stringify(v.baseline));
  check('the book since the gate is the delta', v.book.trades === 4 && v.book.wins === 3 && v.book.winRate === 0.75, JSON.stringify(v.book));
  check('cumulative counts survive the scan boundary', v.counts.churn === 2 && v.counts.safety === 1, JSON.stringify(v.counts));
  check('a later baseline call does not overwrite', g.ensureBaseline({ trades: 99, wins: 99, losses: 0 }) && g.baseline.trades === 26);
}

// ---------------------------------------------------------------------------
console.log('\n[20] solscan holder table');
{
  const { summariseSolscanHolders, solscanConfigured } = await import('../src/feeds/solscan.js');
  const items = [
    { address: 'POOLACC', owner: 'POOL', percentage: 40 },
    { address: 'A1', owner: 'W1', percentage: 20 },
    { address: 'A2', owner: 'W2', percentage: 12 },
    { address: 'A3', owner: 'W1', percentage: 8 },
  ];
  const s = summariseSolscanHolders(items, { poolAddresses: ['POOLACC'], devAddress: 'W1', total: 500 });
  check('the pool account is excluded from the holder table', s.ok && s.top1Pct === 20, JSON.stringify(s.top1Pct));
  check('top-10 share sums the real holders', s.top10Pct === 40, String(s.top10Pct));
  check('dev share follows the dev wallet', s.devPct === 28, String(s.devPct));
  check('the holder count comes from the API total', s.holders === 500, String(s.holders));
  check('the summary is tagged with its source', s.source === 'solscan', String(s.source));
  check('an empty table is not a result', summariseSolscanHolders([], {}).ok === false);
  check('no key means the source stays off', solscanConfigured({ solscan: { apiKey: '' } }) === false && solscanConfigured({ solscan: { apiKey: 'k' } }) === true);
  check('config carries the solscan block', typeof config.solscan === 'object' && 'apiKey' in config.solscan, JSON.stringify(Object.keys(config.solscan || {})));

  // What a key can actually do: the free plan is public endpoints only, and the
  // docs list exactly one of those, so a free key must say so plainly.

  const { classifyProbe } = await import('../src/feeds/solscan.js');
  // Solscan's real answer on a free key: 401 with "Please upgrade your api key
  // level" - valid key, insufficient plan. The status alone would misreport it.
  const free = classifyProbe({ holdersStatus: 401, holdersMessage: 'Unauthorized: Please upgrade your api key level.' });
  check('a free key is valid but cannot read holders', free.keyValid === true && free.holdersOk === false, free.verdict);
  check('and the verdict names the plan limit', /Level 1/.test(free.verdict) && /upgrade/.test(free.verdict), free.verdict);
  const paid = classifyProbe({ holdersStatus: 200 });
  check('a Pro key is reported as usable', paid.holdersOk === true && /will use it/.test(paid.verdict), paid.verdict);
  const bad = classifyProbe({ holdersStatus: 401, holdersMessage: 'Unauthorized: invalid api key' });
  check('a rejected key is called out as the key', bad.keyValid === false && /check the key/.test(bad.verdict), bad.verdict);
  const limited = classifyProbe({ holdersStatus: 429 });
  check('rate limiting is distinguished from a bad key', limited.keyValid === true && /rate limited/.test(limited.verdict), limited.verdict);
}

// ---------------------------------------------------------------------------
console.log('\n[21] pump.fun holder table');
{
  const { summarisePumpfunPositions, pumpfunConfigured } = await import('../src/feeds/pumpfun.js');
  const positions = [
    { walletAddress: 'POOLWALLET', amountHeld: 400000 },
    { walletAddress: 'W1', amountHeld: 200000 },
    { walletAddress: 'W2', amountHeld: 150000 },
    { walletAddress: 'DEV', amountHeld: 50000 },
    { walletAddress: 'W4', amountHeld: 30000 },
  ];
  const s = summarisePumpfunPositions(positions, { supply: 1000000, poolAddresses: ['POOLWALLET'], devAddress: 'DEV', total: 500 });
  check('positions are measured against supply', s.ok && Math.abs(s.top1Pct - 20) < 0.01, `${s.top1Pct}%`);
  check('top-10 share sums the listed holders', Math.abs(s.top10Pct - 43) < 0.01, `${s.top10Pct}%`);
  check('dev share follows the dev wallet', Math.abs(s.devPct - 5) < 0.01, `${s.devPct}%`);
  check('the pool wallet is not counted as a holder', Math.abs(s.top10Pct - 43) < 0.01, `${s.top10Pct}%`);
  check('supply outside the listed positions is reported', Math.abs(s.outsideTop20Pct - 57) < 0.01, `${s.outsideTop20Pct}%`);
  check('the holder count comes from the API total', s.holders === 500, String(s.holders));
  check('the summary is tagged with its source', s.source === 'pumpfun', String(s.source));
  check('no supply means no summary, not a guessed one', summarisePumpfunPositions(positions, { supply: 0 }).ok === false);
  check('an empty position list is not a result', summarisePumpfunPositions([], { supply: 1000000 }).ok === false);
  check('no key means the source stays off', pumpfunConfigured({ pumpfun: { apiKey: '' } }) === false && pumpfunConfigured({ pumpfun: { apiKey: 'pf_live_x' } }) === true);
  check('config carries the pumpfun block', typeof config.pumpfun === 'object' && 'apiKey' in config.pumpfun, JSON.stringify(Object.keys(config.pumpfun || {})));
}

// ---------------------------------------------------------------------------
console.log('\n[22] rug blacklist');
{
  const { RugBlacklist, shouldBlacklist } = await import('../src/rug-blacklist.js');
  const file = 'selftest-blacklist.json';
  const t0 = 1_700_000_000_000;
  const bl = new RugBlacklist({ rug: { blacklistHours: 24 } }, { file, now: t0 });
  check('an unknown mint is tradeable', bl.check('MINT_A', t0) === null);
  const pin = bl.block('MINT_A', { symbol: 'GTA', reason: 'fast rug watch: liquidity -100% in one tick', pnlPct: -0.9 }, t0);
  check('a rug pins the mint', Boolean(pin) && bl.check('MINT_A', t0)?.symbol === 'GTA');
  check('the pin lasts the configured cooldown', pin.until - t0 === 24 * 3600 * 1000, String(pin.until - t0));
  check('the pin expires', bl.check('MINT_A', t0 + 24 * 3600 * 1000 + 1) === null);
  const reloaded = new RugBlacklist({ rug: { blacklistHours: 24 } }, { file, now: t0 + 1000 });
  check('the pin survives a restart', reloaded.check('MINT_A', t0 + 1000)?.symbol === 'GTA');
  const pruned = new RugBlacklist({ rug: { blacklistHours: 24 } }, { file, now: t0 + 25 * 3600 * 1000 });
  check('an expired pin is pruned on load', pruned.check('MINT_A', t0 + 25 * 3600 * 1000) === null);
  check('a rug exit pins', shouldBlacklist({ kind: 'rug', pnlPct: -0.1 }) === true);
  check('a half-position loss pins even without the rug kind', shouldBlacklist({ kind: 'stop', pnlPct: -0.55 }) === true);
  check('a normal stop does not pin', shouldBlacklist({ kind: 'stop', pnlPct: -0.12 }) === false);
  check('a profit never pins', shouldBlacklist({ kind: 'profit', pnlPct: 0.3 }) === false);
  check('config carries the blacklist window', config.rug.blacklistHours === 24, String(config.rug.blacklistHours));

  // Six different mints called "Tradercat" were bought: the name repeats too.
  check('an unknown symbol is tradeable', bl.checkSymbol('Newcoin', t0) === null);
  const symPin = bl.blockSymbol('Tradercat', { reason: 'fast rug watch', mint: 'MINT_B' }, t0);
  check('a rug pins the name as well', Boolean(symPin) && bl.checkSymbol('tradercat', t0)?.symbol === 'TRADERCAT');
  check('symbol pins ignore case', bl.checkSymbol('TRADERCAT', t0) !== null && bl.checkSymbol('TradercaT', t0) !== null);
  check('a symbol pin expires', bl.checkSymbol('Tradercat', t0 + 24 * 3600 * 1000 + 1) === null);
  check('a blank symbol is never pinned', bl.blockSymbol('  ', {}, t0) === null && bl.checkSymbol('', t0) === null);
  check('the view reports both kinds of pin', bl.view(t0).count >= 1 && bl.view(t0).symbolCount >= 1, JSON.stringify({ mints: bl.view(t0).count, names: bl.view(t0).symbolCount }));
  try { (await import('node:fs')).unlinkSync('data/' + file); } catch { /* already gone */ }
}

// ---------------------------------------------------------------------------
console.log('\n[22b] rug watch needs the price to agree');
{
  const { fastRugExit } = await import('../src/rug.js');
  const base = {
    qty: 130000,
    lastPrice: 0.0000155,
    peakPx: 0.0000165,
    lastLiqUsd: 1, // a depth print that would collapse the fill
    entryLiqUsd: 30000,
    tickLiqDropPct: null,
    tickPxDropPct: null,
  };
  check('a "no depth" print alone does not exit while the price holds', fastRugExit(base, config) === null, JSON.stringify(fastRugExit(base, config)));
  const crashed = fastRugExit({ ...base, lastPrice: 0.0000100 }, config);
  check('the same depth print exits once the price has fallen', Boolean(crashed) && /rug/.test(crashed.kind), JSON.stringify(crashed));
}

console.log('\n[23] exit fill price');
{
  const { exitFillPrice } = await import('../src/strategy.js');
  // The real case: price ran to +36% and the rule fired when it fell back to -2%.
  check('an exit fills at the price the rule acted on', exitFillPrice(1.36, 0.98) === 0.98, String(exitFillPrice(1.36, 0.98)));
  check('the stale peak price is not used', exitFillPrice(1.36, 0.98) !== 1.36);
  check('a bad feed row keeps the confirmed price', exitFillPrice(1.0, 0.2) === 1.0, String(exitFillPrice(1.0, 0.2)));
  check('a missing decision price falls back to the confirmed one', exitFillPrice(1.0, null) === 1.0);
  check('a missing confirmed price uses the decision price', exitFillPrice(0, 1.2) === 1.2);
}

// ---------------------------------------------------------------------------
console.log('\n[24] retrain guard');
{
  const { refitRefusals, flipLimit } = await import('../src/ai/retrain-guard.js');
  // The refit that actually happened: 0.52 LOO against priors at 0.63, 12 flips.
  const bad = refitRefusals({ refitAuc: 0.52, priorAuc: 0.63, flips: 12, features: 18, trades: 53 });
  check('a refit worse than the priors is refused', bad.some((r) => /does not beat the priors/.test(r)), bad.join(' | '));
  check('bulk prior flips are refused', bad.some((r) => /prior signs overturned/.test(r)), bad.join(' | '));
  check('a tie with the priors is refused too', refitRefusals({ refitAuc: 0.63, priorAuc: 0.63, flips: 0, features: 18, trades: 53 }).length > 0);
  check('a refit that beats the priors is installed', refitRefusals({ refitAuc: 0.72, priorAuc: 0.63, flips: 1, features: 18, trades: 53 }).length === 0, JSON.stringify(refitRefusals({ refitAuc: 0.72, priorAuc: 0.63, flips: 1, features: 18, trades: 53 })));
  check('chance-level separation is refused', refitRefusals({ refitAuc: 0.54, priorAuc: 0.50, flips: 0, features: 18, trades: 53 }).some((r) => /chance/.test(r)));
  check('an unscorable refit is refused', refitRefusals({ refitAuc: NaN, priorAuc: 0.63, flips: 0, features: 18, trades: 53 }).length === 1);
  check('a small book allows only a few flips', flipLimit(18, 53) === 3, String(flipLimit(18, 53)));
  check('a large book allows half the priors to move', flipLimit(18, 150) === 9, String(flipLimit(18, 150)));
  check('flips under the limit pass', refitRefusals({ refitAuc: 0.70, priorAuc: 0.63, flips: 9, features: 18, trades: 150 }).length === 0);
  check('flips over the limit fail even with a good AUC', refitRefusals({ refitAuc: 0.70, priorAuc: 0.63, flips: 10, features: 18, trades: 150 }).length === 1);
}

// ---------------------------------------------------------------------------
console.log('\n[25] exit fills never pay $0 for a bad depth reading');
{
  const { createPaperExecutor } = await import('../src/exec/paper.js');
  const { exitDepth } = await import('../src/venues.js');
  const ex = createPaperExecutor(config);
  const pos = { qty: 130000, entryPrice: 0.0000155, entryLiqUsd: 30000, venue: 'pumpswap' };
  const gap = await ex.sell({ position: pos, priceUsd: 0.0000162, fraction: 1, liqUsd: 0 });
  check('a $0 depth reading does not zero the payout', gap.proceedsUsd > 2, JSON.stringify(gap));
  check('and it fills at the quote, not at a fabricated price', gap.fillPrice > 0.000016, String(gap.fillPrice));
  const thin = await ex.sell({ position: pos, priceUsd: 0.0000162, fraction: 1, liqUsd: 3000 });
  check('a pool 10x thinner than at entry pays less but still pays', thin.proceedsUsd > 0 && thin.proceedsUsd < gap.proceedsUsd, `${thin.proceedsUsd} vs ${gap.proceedsUsd}`);
  check('a real depth reading is used as-is', exitDepth(pos, 30000, 2) === 30000);
  check('a reading under 1% of entry depth is a feed gap', exitDepth(pos, 100, 2) === 30000);
  check('a position with no entry depth still gets a floor', exitDepth({}, 0, 500) === 500);
  // The live bug: a winner up 75% in a pool reading $0 was paid out at $0.
  const up = { qty: 113000, entryPrice: 0.00001705, entryLiqUsd: 30000, venue: 'pumpswap' };
  const win = await ex.sell({ position: up, priceUsd: 0.00002979, fraction: 1, liqUsd: 0 });
  check('a winner in a $0-depth pool is still paid', win.proceedsUsd > 1.7, JSON.stringify({ proceeds: win.proceedsUsd, price: win.fillPrice }));
  const absurd = await ex.sell({ position: up, priceUsd: 0.3513, fraction: 1, liqUsd: 0 });
  check('an absurd 20,000x print with no depth still pays nothing', absurd.proceedsUsd === 0, String(absurd.proceedsUsd));
}

// ---------------------------------------------------------------------------
console.log('\n[26] a graduated token is followed to its new pool');
{
  const { pickMigratedPool } = await import('../src/venues.js');
  const pairs = [
    { poolAddress: 'NEWPOOL1', dex: 'pumpswap', priceUsd: 0.0000341, liqUsd: 41000 },
    { poolAddress: 'OLDPOOL1', dex: 'pumpfun', priceUsd: 0.0000001, liqUsd: 12 },
  ];
  const next = pickMigratedPool(pairs, 'OLDPOOL1', 500);
  check('the token is followed to the pool it moved to', next?.poolAddress === 'NEWPOOL1', JSON.stringify(next));
  check('the pool we are already in is never chosen', pickMigratedPool(pairs, 'NEWPOOL1', 500) === null);
  check('a dust pool is not good enough to follow', pickMigratedPool([{ poolAddress: 'X', liqUsd: 40 }], 'OLD', 500) === null);
  check('no alternative pool means no rebind', pickMigratedPool([], 'OLD', 500) === null);
  check('the deepest live pool wins when there are several',
    pickMigratedPool([
      { poolAddress: 'A', liqUsd: 9000, priceUsd: 1 },
      { poolAddress: 'B', liqUsd: 21000, priceUsd: 1 },
    ], 'OLD', 500)?.poolAddress === 'B');
}

// ---------------------------------------------------------------------------
console.log('\n[27] the 3001 desk read: indicators and live order flow');
{
  const ind = await import('../src/ai/indicators.js');
  const { flowRead, describePulse } = await import('../src/feeds/pulse.js');

  check('SMA over the last five closes', ind.sma([1, 2, 3, 4, 5], 5) === 3, String(ind.sma([1, 2, 3, 4, 5], 5)));
  check('too few bars is null, not zero', ind.sma([1, 2], 5) === null);
  check('an EMA of a flat series is that value', Math.abs(ind.ema([7, 7, 7, 7, 7], 3) - 7) < 1e-9);
  check('RSI of a monotonic rise is 100', ind.rsi(Array.from({ length: 20 }, (_, i) => 100 + i)) === 100);
  check('RSI of a monotonic fall is 0', ind.rsi(Array.from({ length: 20 }, (_, i) => 200 - i)) === 0);
  check('rate of change over one bar', Math.abs(ind.roc([100, 110], 1) - 10) < 1e-9);
  const bars = Array.from({ length: 40 }, (_, i) => ({ t: i, o: 10 + i, h: 11 + i, l: 9 + i, c: 10 + i, v: 1 }));
  check('ATR on a two-wide range series is 2', Math.abs(ind.atr(bars, 14) - 2) < 1e-9, String(ind.atr(bars, 14)));

  const swingBars = Array.from({ length: 40 }, (_, i) => {
    const base = 10 + Math.sin(i / 3) * 2;
    return { t: i, o: base, h: base + 1, l: base - 1, c: base, v: 1 };
  });
  const levels = ind.swingLevels(swingBars, 10);
  check(
    'support sits below the price and resistance above it',
    levels.support.length > 0 && levels.resistance.length > 0 && levels.support.every((v) => v < 10) && levels.resistance.every((v) => v > 10),
    JSON.stringify(levels),
  );

  const bull = ind.scoreBias({ price: 120, sma20: 110, sma50: 100, ema12: 115, ema26: 105, macdHist: 0.4, rsi14: 62, roc20: 8, samples: 60 });
  check('six bullish signals give an up lean at high confidence', bull.direction === 'up' && bull.confidence === 'high', JSON.stringify(bull));
  const bear = ind.scoreBias({ price: 80, sma20: 90, sma50: 100, ema12: 85, ema26: 95, macdHist: -0.4, rsi14: 38, roc20: -8, samples: 60 });
  check('the mirrored series gives a down lean', bear.direction === 'down', JSON.stringify(bear));
  const mixed = ind.scoreBias({ price: 100, sma20: 99, sma50: 101, ema12: 100, ema26: 100, macdHist: 0.01, rsi14: 50, roc20: 0.1, samples: 60 });
  check('mixed evidence stays neutral instead of calling a direction', mixed.direction === 'neutral', JSON.stringify(mixed));
  check('a short series reports low confidence', ind.indicatorPass(bars.slice(0, 12)).bias.confidence === 'low');
  check('missing candles yield nulls, never zeros', ind.indicatorPass([]).sma50 === null && ind.indicatorPass([]).price === null);

  const mk = (over = {}) => ({
    symbol: 'T', name: null, dex: 'pumpswap', pool: 'P', price: 1e-5, ageHours: 3, poolCount: 1,
    liquidityUsd: 20000, liquiditySource: 'test', marketCapUsd: 400000, liqToMcapPct: 5,
    change: { m5: 1, h1: 2, h6: 5, h24: 20 }, volume: { m5: 100, h1: 1200, h6: 4000, h24: 20000 },
    txns: { m5: { buys: 3, sells: 1 }, h1: { buys: 60, sells: 20 }, h24: { buys: 400, sells: 300 } },
    ...over,
  });
  const hot = flowRead(mk({ volume: { m5: 100, h1: 5000, h6: 9000, h24: 20000 } }));
  check('buyers with accelerating volume read as buyers', hot.pressure === 'buyers' && /accelerating/.test(hot.note), JSON.stringify(hot));
  const dump = flowRead(
    mk({
      txns: { m5: { buys: 1, sells: 3 }, h1: { buys: 10, sells: 90 }, h24: { buys: 400, sells: 300 } },
      volume: { m5: 100, h1: 5000, h6: 9000, h24: 20000 },
    }),
  );
  check('sellers with accelerating volume are called distribution', dump.pressure === 'sellers' && /distribution/.test(dump.note), JSON.stringify(dump));
  const dead = flowRead(
    mk({ volume: { m5: 0, h1: 0, h6: 0, h24: 20000 }, txns: { m5: null, h1: null, h24: { buys: 400, sells: 300 } } }),
  );
  check('no volume in six hours is dormant, not neutral', dead.dormant === true && /gone quiet/.test(dead.note), JSON.stringify(dead));
  const none = flowRead(mk({ txns: { m5: null, h1: null, h24: null }, volume: { m5: null, h1: null, h6: null, h24: null } }));
  check('no reported trades is none, with no basis claimed', none.pressure === 'none' && none.basis === null);
  const flat = flowRead(mk({ txns: { m5: { buys: 5, sells: 5 }, h1: { buys: 50, sells: 50 }, h24: { buys: 400, sells: 300 } } }));
  check('an even split is balanced', flat.pressure === 'balanced', JSON.stringify(flat));

  const caution = describePulse(mk({ liquidityUsd: 0, liqToMcapPct: 0 }));
  check('a $0 depth reading is stated as $0, not as unknown', /\$0 of liquidity/.test(caution), caution.split('\n')[1]);
  check('no pair at all says so instead of inventing a read', /no trading pair/i.test(describePulse(null)), describePulse(null));
}

// ---------------------------------------------------------------------------
console.log('\n[28] the DexScreener lane does not depend on GeckoTerminal');
{
  const { poolsFromPairs } = await import('../src/feeds/dexscreener.js');
  const pair = (over = {}) => ({
    chainId: 'solana',
    dexId: 'pumpswap',
    pairAddress: 'P1',
    priceUsd: '0.001',
    pairCreatedAt: Date.now() - 60000,
    baseToken: { address: 'MINT1', symbol: 'AAA', name: 'Aaa' },
    liquidity: { usd: 30000 },
    marketCap: 200000,
    fdv: 210000,
    volume: { m5: 400, h1: 5000 },
    priceChange: { m5: 4, h1: 9 },
    txns: { m5: { buys: 12, sells: 3 }, h1: { buys: 90, sells: 40 } },
    ...over,
  });
  const rows = poolsFromPairs(
    'solana',
    [
      pair(),
      pair({ pairAddress: 'P2', liquidity: { usd: 12000 } }),
      pair({ pairAddress: 'P3', baseToken: { address: 'MINT2', symbol: 'BBB' }, liquidity: { usd: 90000 } }),
      pair({ pairAddress: 'P4', baseToken: { address: 'MINT3' }, priceUsd: '0' }),
      pair({ pairAddress: 'P5', chainId: 'base' }),
    ],
    { limit: 24 },
  );
  check('one row per mint, not one per pair', rows.length === 2, JSON.stringify(rows.map((r) => r.baseToken)));
  check('the deepest pool represents its mint', rows.find((r) => r.baseToken === 'MINT1')?.poolAddress === 'P1');
  check('rows come out deepest liquidity first', rows[0].baseToken === 'MINT2', JSON.stringify(rows.map((r) => [r.baseToken, r.liqUsd])));
  check('a pair with no price is dropped', !rows.some((r) => r.baseToken === 'MINT3'));
  check('another chain is dropped', !rows.some((r) => r.poolAddress === 'P5'));
  check('5m trades survive so the entry filter can read them', rows[0].txns.m5.buys === 12, String(rows[0].txns.m5.buys));
  check('m15 is mirrored from m5 rather than invented', rows[0].vol.m15 === rows[0].vol.m5);
  check(
    'the limit is honoured',
    poolsFromPairs('solana', [pair(), pair({ pairAddress: 'PX', baseToken: { address: 'MINT9' } })], { limit: 1 }).length === 1,
  );
}

// ---------------------------------------------------------------------------
console.log('\n[29] a held position is separated from the live table');
{
  const pf = freshPortfolio();
  const fill = await exec.buy({ priceUsd: 0.001, sizeUsd: 50, liqUsd: LIQ });
  const pos = pf.openPosition({
    candidate: {
      chain: 'solana',
      pool: { poolAddress: 'PHELD', baseToken: 'THELD', symbol: 'HELD', name: 'Held Coin', dex: 'raydium', liqUsd: LIQ, mcapUsd: 30000 },
      ageSec: 90,
    },
    sizeUsd: 50,
    fill,
    score: 0.71,
    features: {},
    reasons: ['test'],
    mode: 'paper',
  });
  const live = pf.snapshot().positions.find((p) => p.id === pos.id);
  check('a position that can be exited is not held', live.held === false, JSON.stringify({ held: live.held }));
  pos.migrationHoldAt = Date.now() - 60000;
  pos.unpriced = 'the exit booked $0 into a pool with no tradeable depth';
  const held = pf.snapshot().positions.find((p) => p.id === pos.id);
  check('a held position is flagged for the dashboard', held.held === true);
  check('its reason is carried through, not invented', /no tradeable depth/.test(held.heldReason || ''), String(held.heldReason));
  check('how long it has been held is reported', held.heldSec >= 59, String(held.heldSec));
  check('the flag clears when the hold does, so it returns to the live table', (() => {
    pos.migrationHoldAt = null;
    pos.unpriced = null;
    return pf.snapshot().positions.find((p) => p.id === pos.id).held === false;
  })());
}

console.log(`\n${failures === 0 ? 'ALL CHECKS PASSED' : `${failures} CHECK(S) FAILED`}\n`);
process.exit(failures === 0 ? 0 : 1);
